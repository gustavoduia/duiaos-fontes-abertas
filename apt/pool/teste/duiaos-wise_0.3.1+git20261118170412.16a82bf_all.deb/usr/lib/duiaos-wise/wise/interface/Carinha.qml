// Wise — o rosto do Wise (botão flutuante e cabeçalho da janela).
// Um corpo de vidro com volume (luz de cima, reflexo, sombra de contato), um visor escuro e dois olhos
// luminosos que se mexem. Nada de antena nem traços de desenho animado: a expressão vem só dos olhos
// e da luz.
// estado: "aberto"      olhos abertos, piscam e olham em volta
//         "feliz"       olhos em arco (cumprimentando, comemorando)
//         "pensando"    olham para cima e a luz corre de um olho ao outro
//         "ouvindo"     olhos bem abertos e ondas saindo do rosto
//         "falando"     a boca de luz acompanha a fala
//         "descansando" olhos fechados (duas linhas), luz baixa, respiração lenta
// pular(): um pulinho de alegria (usado na saudação).
// O corpo é pintado uma vez (Canvas); tudo o que se mexe são itens simples, animados pela placa de
// vídeo — enquanto a IA pensa, o processador fica para ela.
import QtQuick

Item {
    id: rosto
    property string estado: "descansando"
    property bool destacada: false
    width: 76; height: 80

    readonly property bool acordado: estado !== "descansando"
    readonly property color luz: estado === "ouvindo" ? "#7CF5C4" : "#8FE9FF"      // olhos: ciano; ouvindo: verde-água
    readonly property real u: width / 76                                          // escala (o desenho é feito em 76 × 80)

    function pular() { pulo.restart() }

    // ------------------------------------------------------------ movimento
    property real piscar: 0          // 0 aberto … 1 fechado
    property real olharX: 0          // -1 … 1
    property real olharY: estado === "pensando" ? -0.7 : 0
    property real salto: 0
    property real respiro: 1
    Behavior on olharX { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }
    Behavior on olharY { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }

    SequentialAnimation {
        id: piscada
        NumberAnimation { target: rosto; property: "piscar"; to: 1; duration: 80; easing.type: Easing.InQuad }
        NumberAnimation { target: rosto; property: "piscar"; to: 0; duration: 140; easing.type: Easing.OutQuad }
    }
    Timer {
        running: rosto.estado === "aberto" || rosto.estado === "ouvindo" || rosto.estado === "falando"
        repeat: true; interval: 2800
        onTriggered: { interval = 2400 + Math.random() * 3000; piscada.restart(); if (Math.random() < 0.2) dupla.start() }
    }
    Timer { id: dupla; interval: 260; onTriggered: piscada.restart() }
    Timer {
        running: rosto.estado === "aberto"
        repeat: true; interval: 3600
        onTriggered: rosto.olharX = Math.random() < 0.45 ? 0 : (Math.random() < 0.5 ? -0.75 : 0.75)
    }
    onEstadoChanged: { if (estado !== "aberto") olharX = 0; piscar = 0 }

    SequentialAnimation {
        id: pulo
        NumberAnimation { target: rosto; property: "salto"; to: -10; duration: 170; easing.type: Easing.OutQuad }
        NumberAnimation { target: rosto; property: "salto"; to: 0; duration: 260; easing.type: Easing.OutBounce }
    }
    // Respiração (descansando) — bem lenta
    SequentialAnimation on respiro {
        running: !rosto.acordado; loops: Animation.Infinite
        NumberAnimation { to: 1.025; duration: 2400; easing.type: Easing.InOutSine }
        NumberAnimation { to: 1.0; duration: 2400; easing.type: Easing.InOutSine }
    }

    // ------------------------------------------------------------ sombra de contato
    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height - 10 * rosto.u
        width: 38 * rosto.u * (1 + rosto.salto / 40); height: 5 * rosto.u; radius: height / 2
        color: "#0B1533"; opacity: 0.16 * (1 + rosto.salto / 30)
    }

    // ------------------------------------------------------------ ondas (ouvindo)
    Repeater {
        model: 2
        Rectangle {
            required property int index
            visible: rosto.estado === "ouvindo"
            anchors.centerIn: corpo
            width: corpo.width; height: corpo.height; radius: 22 * rosto.u
            color: "transparent"; border { color: rosto.luz; width: 1.5 }
            SequentialAnimation on scale {
                running: rosto.estado === "ouvindo"; loops: Animation.Infinite
                PauseAnimation { duration: index * 700 }
                NumberAnimation { from: 1.0; to: 1.28; duration: 1400; easing.type: Easing.OutCubic }
            }
            SequentialAnimation on opacity {
                running: rosto.estado === "ouvindo"; loops: Animation.Infinite
                PauseAnimation { duration: index * 700 }
                NumberAnimation { from: 0.55; to: 0; duration: 1400; easing.type: Easing.OutCubic }
            }
        }
    }

    // ------------------------------------------------------------ corpo
    Item {
        id: corpo
        x: 6 * rosto.u; y: 6 * rosto.u + rosto.salto * rosto.u
        width: 64 * rosto.u; height: 62 * rosto.u
        scale: (rosto.destacada ? 1.05 : 1.0) * rosto.respiro
        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }

        Canvas {
            id: pintura
            anchors.fill: parent
            anchors.margins: -2
            renderStrategy: Canvas.Cooperative
            onWidthChanged: requestPaint()
            function caixa(ctx, x, y, w, h, r) {
                ctx.beginPath()
                ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r)
                ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
                ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r)
                ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y)
                ctx.closePath()
            }
            onPaint: {
                var ctx = getContext("2d"), s = rosto.u, w = width, h = height
                ctx.reset()
                // Corpo: azul profundo embaixo, claro em cima (a luz vem de cima, à esquerda)
                var g = ctx.createLinearGradient(0, 0, w * 0.6, h)
                g.addColorStop(0, "#9DB8FF"); g.addColorStop(0.35, "#5B7CFA"); g.addColorStop(0.8, "#2C3FB8"); g.addColorStop(1, "#1B2A80")
                caixa(ctx, 2, 2, w - 4, h - 4, 21 * s)
                ctx.fillStyle = g; ctx.fill()
                // Volume: brilho largo no alto
                var b = ctx.createRadialGradient(w * 0.32, h * 0.12, 1, w * 0.32, h * 0.12, w * 0.7)
                b.addColorStop(0, "rgba(255,255,255,0.55)"); b.addColorStop(0.35, "rgba(255,255,255,0.12)"); b.addColorStop(1, "rgba(255,255,255,0)")
                ctx.fillStyle = b; ctx.fill()
                // Luz de contorno embaixo, à direita
                var r = ctx.createRadialGradient(w * 0.85, h * 0.95, 1, w * 0.85, h * 0.95, w * 0.55)
                r.addColorStop(0, "rgba(120,220,255,0.38)"); r.addColorStop(1, "rgba(120,220,255,0)")
                ctx.fillStyle = r; ctx.fill()
                // Borda fina de luz
                ctx.lineWidth = 1; ctx.strokeStyle = "rgba(255,255,255,0.35)"; ctx.stroke()

                // Visor: vidro escuro, rebaixado
                var vx = 8 * s + 2, vy = 14 * s + 2, vw = w - 16 * s - 4, vh = 32 * s
                caixa(ctx, vx, vy, vw, vh, 15 * s)
                var v = ctx.createLinearGradient(0, vy, 0, vy + vh)
                v.addColorStop(0, "#070B22"); v.addColorStop(1, "#141E4A")
                ctx.fillStyle = v; ctx.fill()
                ctx.lineWidth = 1.2; ctx.strokeStyle = "rgba(10,14,40,0.55)"; ctx.stroke()
                // Reflexo do vidro: uma faixa clara, inclinada, no canto de cima
                ctx.save()
                caixa(ctx, vx, vy, vw, vh, 15 * s); ctx.clip()
                var f = ctx.createLinearGradient(vx, vy, vx + vw * 0.6, vy + vh)
                f.addColorStop(0, "rgba(255,255,255,0.20)"); f.addColorStop(0.3, "rgba(255,255,255,0.04)"); f.addColorStop(0.31, "rgba(255,255,255,0)")
                ctx.fillStyle = f; ctx.fillRect(vx, vy, vw, vh)
                ctx.restore()
                // Luz embaixo do visor (borda de dentro)
                ctx.beginPath(); ctx.moveTo(vx + 14 * s, vy + vh + 0.8); ctx.lineTo(vx + vw - 14 * s, vy + vh + 0.8)
                ctx.lineWidth = 1; ctx.strokeStyle = "rgba(255,255,255,0.28)"; ctx.stroke()
            }
        }

        // -------------------------------------------------------- olhos
        Repeater {
            model: [-1, 1]
            Item {
                id: olho
                required property int modelData
                readonly property real aberto: rosto.acordado ? 1 - rosto.piscar : 0
                readonly property bool arco: rosto.estado === "feliz"
                x: corpo.width / 2 + modelData * 13 * rosto.u - width / 2 + rosto.olharX * 3.2 * rosto.u
                y: 30 * rosto.u - height / 2 + rosto.olharY * 3.5 * rosto.u
                width: 12 * rosto.u; height: 16 * rosto.u

                // Brilho em volta (três camadas no lugar de um desfoque)
                Repeater {
                    model: 3
                    Rectangle {
                        required property int index
                        visible: rosto.acordado && !olho.arco
                        anchors.centerIn: pupila
                        width: pupila.width + (index + 1) * 5 * rosto.u; height: pupila.height + (index + 1) * 5 * rosto.u
                        radius: width / 2
                        color: rosto.luz; opacity: 0.10 - index * 0.028
                    }
                }
                Rectangle {
                    id: pupila
                    visible: !olho.arco
                    anchors.centerIn: parent
                    width: (rosto.estado === "ouvindo" ? 9.5 : 8.5) * rosto.u
                    height: Math.max(2 * rosto.u, (rosto.estado === "ouvindo" ? 15 : 13) * rosto.u * olho.aberto)
                    radius: Math.min(width, height) / 2
                    opacity: rosto.acordado ? 1 : 0.55
                    gradient: Gradient {
                        GradientStop { position: 0; color: "#FFFFFF" }
                        GradientStop { position: 0.45; color: rosto.luz }
                        GradientStop { position: 1; color: Qt.darker(rosto.luz, 1.25) }
                    }
                    Behavior on width { NumberAnimation { duration: 180 } }
                }
                // Feliz: um arco (olhos sorrindo)
                Canvas {
                    visible: olho.arco
                    anchors.centerIn: parent
                    width: 13 * rosto.u; height: 9 * rosto.u
                    onVisibleChanged: requestPaint()
                    onPaint: {
                        var ctx = getContext("2d"); ctx.reset()
                        ctx.lineWidth = 3 * rosto.u; ctx.lineCap = "round"; ctx.strokeStyle = rosto.luz
                        ctx.beginPath(); ctx.arc(width / 2, height * 1.0, width / 2 - 2 * rosto.u, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke()
                    }
                }
                // Pensando: a luz corre de um olho ao outro
                SequentialAnimation on opacity {
                    running: rosto.estado === "pensando"; loops: Animation.Infinite
                    PauseAnimation { duration: olho.modelData < 0 ? 0 : 380 }
                    NumberAnimation { from: 1; to: 0.35; duration: 380; easing.type: Easing.InOutSine }
                    NumberAnimation { from: 0.35; to: 1; duration: 380; easing.type: Easing.InOutSine }
                    PauseAnimation { duration: olho.modelData < 0 ? 380 : 0 }
                }
                onVisibleChanged: opacity = 1
                Connections { target: rosto; function onEstadoChanged() { if (rosto.estado !== "pensando") olho.opacity = 1 } }
            }
        }

        // -------------------------------------------------------- boca de luz (falando)
        Row {
            visible: rosto.estado === "falando"
            anchors.horizontalCenter: parent.horizontalCenter
            y: 51 * rosto.u - height / 2
            height: 9 * rosto.u
            spacing: 2.2 * rosto.u
            Repeater {
                model: 5
                Rectangle {
                    required property int index
                    width: 2.6 * rosto.u; radius: width / 2
                    anchors.verticalCenter: parent.verticalCenter
                    color: "#E8F7FF"; opacity: 0.92
                    height: 3 * rosto.u
                    SequentialAnimation on height {
                        running: rosto.estado === "falando"; loops: Animation.Infinite
                        PauseAnimation { duration: (index * 83) % 190 }
                        NumberAnimation { to: (4 + (index * 7) % 6) * rosto.u; duration: 150 + index * 23; easing.type: Easing.InOutSine }
                        NumberAnimation { to: 2.4 * rosto.u; duration: 170 + index * 17; easing.type: Easing.InOutSine }
                    }
                }
            }
        }
        // Em repouso (sem falar): um ponto de luz de "ligado", discreto
        Rectangle {
            visible: rosto.estado !== "falando"
            anchors.horizontalCenter: parent.horizontalCenter
            y: 51 * rosto.u - height / 2
            width: (rosto.estado === "feliz" ? 12 : 7) * rosto.u; height: 2.4 * rosto.u; radius: height / 2
            color: "#E8F7FF"; opacity: rosto.acordado ? 0.75 : 0.3
            Behavior on width { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
        }
    }
}
