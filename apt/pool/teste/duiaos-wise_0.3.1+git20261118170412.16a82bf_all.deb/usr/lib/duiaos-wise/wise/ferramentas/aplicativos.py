"""Ferramentas de aplicativos: procurar (N0) e instalar, remover e atualizar o
sistema (N2, com aprovação — W2).

As ações N2 passam pelo agente do sistema (duiaos-agente): o Wise só pede o
plano, mostra o impacto e, com a aprovação da pessoa, pede para executar. O
agente simula de novo, confere a autorização e registra tudo.
"""
import re
import subprocess

from ..agente_do_sistema import Agente, AgenteIndisponivel, Recusado, tamanho_legivel
from . import alternativas as _alternativas
from .base import ErroDeArgumentos, Ferramenta, Plano, normalizar_texto

NOME_PACOTE = re.compile(r"^[a-z0-9][a-z0-9+.-]{1,62}$")
# Pacotes que não são aplicativos para a pessoa (bibliotecas, documentação...).
# "lib" no começo é biblioteca, menos o LibreOffice e o LibreCAD (que são aplicativos).
NAO_APLICATIVO = re.compile(r"^lib(?!re(office|cad))|-(dev|doc|dbg|dbgsym|data|common|l10n.*|locale.*)$")

_agente = Agente()


def _rodar(*comando, tempo=20):
    try:
        r = subprocess.run(comando, capture_output=True, text=True, timeout=tempo, check=False,
                           env={"PATH": "/usr/bin:/bin", "LC_ALL": "C.UTF-8"})
        return r.stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _instalados(nomes):
    if not nomes:
        return set()
    saida = _rodar("dpkg-query", "-W", "-f", "${Package}\t${db:Status-Abbrev}\n", *nomes)
    return {l.split("\t")[0] for l in saida.splitlines() if "\t" in l and l.split("\t")[1].startswith("ii")}


def _existem(nomes):
    """Pacotes que o apt deste computador conhece (entre os nomes dados)."""
    if not nomes:
        return set()
    saida = _rodar("apt-cache", "--no-all-versions", "show", *nomes)
    return {l.split(":", 1)[1].strip() for l in saida.splitlines() if l.startswith("Package:")}


def procurar_aplicativo(texto):
    texto = " ".join(str(texto).split())[:60]
    if len(texto) < 2:
        raise ErroDeArgumentos("diga pelo menos duas letras do nome ou do que o aplicativo faz")
    conhecido = _alternativas.procurar(texto)
    if conhecido is not None:
        # Programa que só existe para Windows/macOS: resposta direta com o que dá para usar aqui
        pacotes = [pacote for pacote, _ in conhecido["alternativas"]]
        return _alternativas.resposta(conhecido, _existem(pacotes), _instalados(pacotes))
    # apt-cache search usa expressão regular: cada palavra entra como texto literal
    palavras = [re.escape(p) for p in texto.lower().split()[:4]]
    saida = _rodar("apt-cache", "search", *palavras)
    achados = []
    for linha in saida.splitlines():
        nome, _, descricao = linha.partition(" - ")
        nome = nome.strip()
        if not NOME_PACOTE.match(nome) or NAO_APLICATIVO.search(nome):
            continue
        achados.append({"pacote": nome, "descricao": descricao.strip()[:100]})
    # Primeiro os que têm a palavra no nome
    primeira = texto.lower().split()[0]
    achados.sort(key=lambda a: (primeira not in a["pacote"], len(a["pacote"])))
    achados = achados[:10]
    instalados = _instalados([a["pacote"] for a in achados])
    for a in achados:
        a["instalado"] = a["pacote"] in instalados
    resultado = {"procurado": texto, "quantidade": len(achados), "aplicativos": achados}
    palavras = normalizar_texto(texto).split()
    if achados and not any(p in normalizar_texto(a["pacote"]) for a in achados for p in palavras):
        # Ex.: um cliente de e-mail achado só pela descrição: não é o aplicativo pedido
        resultado["aviso"] = ("nenhum pacote tem esse nome; estes só têm palavras parecidas na descrição. "
                              "Se não for o que a pessoa pediu, diga que não existe para o DuiaOS.")
    elif not achados:
        resultado["aviso"] = "nada encontrado: diga que não existe para o DuiaOS e pergunte para que ela precisa"
    return resultado


# -------------------------------------------------------------------- N2
def tem_icone(pacote):
    """True se o pacote põe um aplicativo na Central (um .desktop em /usr/share/applications)."""
    saida = _rodar("dpkg-query", "-L", pacote)
    return any(l.startswith("/usr/share/applications/") and l.endswith(".desktop") for l in saida.splitlines())


def _instalar(plano, ao_progresso, cancelado):
    resultado = _executar_no_agente(plano, ao_progresso, cancelado)
    pacote = plano.dados.get("pacote", "")
    if resultado.get("feito") and pacote and not tem_icone(pacote):
        # Ex.: 7zip é de terminal: a pessoa procurou o ícone na Central e não achou
        resultado["sem_icone"] = (f"{pacote} é um programa de terminal, sem janela: não aparece na Central de "
                                  "Aplicativos nem pode ser fixado na Ilha. Explique isso à pessoa e ofereça "
                                  "procurar um aplicativo com janela que faça o mesmo.")
    return resultado


def _plano_do_agente(acao, argumentos):
    try:
        p = _agente.preparar(acao, argumentos)
    except AgenteIndisponivel as erro:
        return Plano("", recusa=f"ainda não consigo fazer isso aqui: {erro}")
    except Recusado as erro:
        return Plano("", recusa=str(erro))
    if p.get("recusa"):
        return Plano(str(p.get("resumo") or ""), recusa=str(p["recusa"].get("mensagem", ""))[:300])
    mudancas = p.get("mudancas") or {}
    detalhes = []
    if p.get("baixar_bytes"):
        detalhes.append(f"Download: {tamanho_legivel(p['baixar_bytes'])}")
    if p.get("espaco_bytes"):
        detalhes.append(f"Espaço usado: {tamanho_legivel(p['espaco_bytes'])}")
    for chave, rotulo in (("instalar", "Novos"), ("atualizar", "Atualizados"), ("remover", "Removidos")):
        nomes = [str(m.get("pacote", ""))[:40] for m in mudancas.get(chave) or []]
        if nomes:
            mais = f" e mais {len(nomes) - 6}" if len(nomes) > 6 else ""
            detalhes.append(f"{rotulo} ({len(nomes)}): " + ", ".join(nomes[:6]) + mais)
    return Plano(str(p.get("resumo", ""))[:200], detalhes, dados={"id": p["id"], **argumentos})


def _executar_no_agente(plano, ao_progresso, cancelado):
    try:
        fim = _agente.executar(plano.dados["id"], ao_progresso, cancelado)
    except (AgenteIndisponivel, Recusado) as erro:
        return {"erro": str(erro)}
    if fim["resultado"] == "ok":
        return {"feito": True, "mensagem": fim["mensagem"]}
    if fim["resultado"] == "cancelada":
        return {"nao_feito": fim["mensagem"]}
    return {"erro": fim["mensagem"] or "a ação não deu certo"}


def _pacote(pacote):
    pacote = str(pacote).strip().lower()
    if not NOME_PACOTE.match(pacote):
        raise ErroDeArgumentos("nome de pacote inválido; use procurar_aplicativo para achar o nome certo")
    return pacote


FERRAMENTAS = [
    Ferramenta("procurar_aplicativo", "Procurar aplicativo",
               "Procura aplicativos para instalar pelo nome ou pelo que fazem (ex.: 'vlc', 'editor de fotos' "
               "em inglês: 'photo editor'). Devolve o nome do pacote, a descrição e se já está instalado. "
               "Use antes de instalar_aplicativo para achar o nome exato.",
               procurar_aplicativo,
               {"type": "object", "properties": {"texto": {"type": "string", "description": "O que procurar."}},
                "required": ["texto"]}),
    Ferramenta("instalar_aplicativo", "Instalar aplicativo",
               "Instala um aplicativo pelo nome exato do pacote. A pessoa vê o impacto e aprova antes.",
               _instalar,
               {"type": "object", "properties": {"pacote": {"type": "string", "description": "Nome exato do pacote."}},
                "required": ["pacote"]},
               nivel="N2", preparar=lambda pacote: _plano_do_agente("instalar_aplicativo", {"pacote": _pacote(pacote)})),
    Ferramenta("remover_aplicativo", "Remover aplicativo",
               "Remove um aplicativo instalado pelo nome exato do pacote. A pessoa vê o impacto e aprova antes. "
               "Partes essenciais do sistema nunca são removidas.",
               _executar_no_agente,
               {"type": "object", "properties": {"pacote": {"type": "string", "description": "Nome exato do pacote."}},
                "required": ["pacote"]},
               nivel="N2", preparar=lambda pacote: _plano_do_agente("remover_aplicativo", {"pacote": _pacote(pacote)})),
    Ferramenta("atualizar_sistema", "Atualizar o sistema",
               "Baixa e instala todas as atualizações do sistema e dos aplicativos. A pessoa vê o que muda e "
               "aprova antes.",
               _executar_no_agente, nivel="N2", preparar=lambda: _plano_do_agente("atualizar_sistema", {})),
]
