"""Presença do Wise na sessão: o botão flutuante (bolha) e o arquivo de estado.

- A bolha roda num processo filho (wise.interface.bolha); se ela fechar ou
  travar, é aberta de novo.
- Estado do Wise para o resto do sistema (Barra de Recursos):
  $XDG_RUNTIME_DIR/duiaos-wise.estado, JSON {"pid": ..., "estado": ...}, com
  estado "aberto", "descansando" ou "pensando". Contrato com o DuiaOS.
"""
import json
import os
import sys
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, QTimer
from PySide6.QtNetwork import QLocalSocket

from .bolha import NOME_SOCKET_BOLHA

ARQUIVO_ESTADO = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "duiaos-wise.estado"
RAIZ_PACOTE = str(Path(__file__).resolve().parents[2])


class Presenca(QObject):
    def __init__(self, com_bolha=True):
        super().__init__()
        self._com_bolha = com_bolha
        self._estado = "descansando"
        self._progresso = None
        self._fila = []
        self._encerrando = False
        self._processo = None
        self._socket = QLocalSocket(self)
        self._socket.connected.connect(self._ao_conectar)
        self._socket.disconnected.connect(self._tentar_conectar)
        self._reconectar = QTimer(self, interval=400, singleShot=True, timeout=self._conectar)

    # --------------------------------------------------------------- bolha
    def iniciar(self):
        self._gravar_estado()
        if self._com_bolha:
            self._abrir_bolha()

    def _abrir_bolha(self):
        if self._encerrando:
            return
        self._processo = QProcess(self)
        ambiente = QProcessEnvironment.systemEnvironment()
        ambiente.insert("QT_WAYLAND_SHELL_INTEGRATION", "layer-shell")
        ambiente.insert("PYTHONPATH", RAIZ_PACOTE + os.pathsep + ambiente.value("PYTHONPATH", ""))
        self._processo.setProcessEnvironment(ambiente)
        self._processo.setProcessChannelMode(QProcess.ProcessChannelMode.ForwardedChannels)
        self._processo.finished.connect(self._bolha_fechou)
        self._processo.start(sys.executable, ["-m", "wise.interface.bolha"])
        self._reconectar.start()

    def _bolha_fechou(self, *_):
        if not self._encerrando:
            QTimer.singleShot(2000, self._abrir_bolha)   # a bolha volta sozinha

    def _conectar(self):
        if self._socket.state() == QLocalSocket.LocalSocketState.UnconnectedState:
            self._socket.connectToServer(NOME_SOCKET_BOLHA)
            if not self._socket.waitForConnected(200):
                self._tentar_conectar()

    def _tentar_conectar(self):
        if not self._encerrando and self._com_bolha:
            self._reconectar.start()

    def _ao_conectar(self):
        pendentes, self._fila = self._fila, []
        self._enviar({"estado": self._estado})
        if self._progresso is not None:
            self._enviar({"progresso": self._progresso})
        for mensagem in pendentes:
            self._enviar(mensagem)

    def _enviar(self, mensagem):
        if self._socket.state() != QLocalSocket.LocalSocketState.ConnectedState:
            if "saudacao" in mensagem or "resposta" in mensagem:
                self._fila.append(mensagem)
            return
        self._socket.write((json.dumps(mensagem, ensure_ascii=False) + "\n").encode("utf-8"))
        self._socket.flush()

    # -------------------------------------------------------------- estado
    def definir_estado(self, estado):
        if estado == self._estado:
            return
        self._estado = estado
        self._gravar_estado()
        self._enviar({"estado": estado})

    def saudar(self, texto):
        self._enviar({"saudacao": texto})

    def avisar_resposta(self, texto):
        """Resumo da resposta no balão (a janela está fechada); clicar abre a conversa."""
        self._enviar({"resposta": texto})

    def fechar_balao(self):
        self._enviar({"fechar": True})

    def progresso(self, dados):
        """Mostra (dict com titulo, detalhe, fracao, nota) ou esconde (None) o
        progresso de um trabalho do sistema no balão do Wise."""
        if dados == self._progresso:
            return
        self._progresso = dados
        self._enviar({"progresso": dados})

    def _gravar_estado(self):
        try:
            temporario = ARQUIVO_ESTADO.with_suffix(".tmp")
            temporario.write_text(json.dumps({"pid": os.getpid(), "estado": self._estado}))
            temporario.replace(ARQUIVO_ESTADO)
        except OSError:
            pass

    def encerrar(self):
        self._encerrando = True
        if self._processo is not None:
            self._processo.terminate()
            self._processo.waitForFinished(1000)
        try:
            ARQUIVO_ESTADO.unlink()
        except OSError:
            pass
