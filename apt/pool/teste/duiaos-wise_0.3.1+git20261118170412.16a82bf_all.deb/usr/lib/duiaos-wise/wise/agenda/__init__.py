"""Agenda do Wise: junta a agenda do computador e as contas conectadas (W14).

Contas em ~/.config/duiaos/wise/agenda.json (sem segredos):
  [{"id", "tipo": "ics"|"caldav"|"google"|"microsoft", "nome", "url", "usuario", "calendarios"}]
Segredos (endereço .ics, senha CalDAV, tokens) no cofre: "agenda-<id>".

Conectar e remover contas é coisa da pessoa, nas Configurações do Wise: as
credenciais nunca passam pelo modelo de IA.
"""
import datetime
import json
import secrets
import threading
from concurrent.futures import ThreadPoolExecutor, wait

from .. import segredos
from ..configuracao import PASTA_CONFIG
from . import fontes, oauth
from .fontes import AgendaLocal, ErroDaAgenda

ARQUIVO_CONTAS = PASTA_CONFIG / "agenda.json"
TEMPO_POR_FONTE = 20
_trava = threading.Lock()


def contas(arquivo=None):
    try:
        dados = json.loads((arquivo or ARQUIVO_CONTAS).read_text())
    except (OSError, ValueError):
        return []
    validas = []
    for c in dados if isinstance(dados, list) else []:
        if isinstance(c, dict) and c.get("tipo") in fontes.TIPOS and isinstance(c.get("id"), str):
            validas.append(c)
    return validas


def _salvar(lista, arquivo=None):
    arquivo = arquivo or ARQUIVO_CONTAS
    arquivo.parent.mkdir(parents=True, exist_ok=True)
    temporario = arquivo.with_suffix(".tmp")
    temporario.write_text(json.dumps(lista, ensure_ascii=False, indent=1))
    temporario.replace(arquivo)


def _nova(tipo, nome, **campos):
    return {"id": f"{tipo}-{secrets.token_hex(4)}", "tipo": tipo, "nome": nome[:60], **campos}


def adicionar_link(nome, url):
    url = fontes.normalizar_link(url)
    conta = _nova("ics", nome.strip() or "Agenda assinada")
    segredos.gravar(f"agenda-{conta['id']}", url, f"Wise — endereço da agenda {conta['nome']}")
    try:
        fontes.LinkIcs(conta).eventos(*_semana())        # confere que o link funciona
    except (ErroDaAgenda, ValueError) as erro:
        segredos.apagar(f"agenda-{conta['id']}")
        raise ErroDaAgenda(f"não consegui ler essa agenda: {erro}") from erro
    with _trava:
        _salvar(contas() + [conta])
    return conta


def adicionar_caldav(nome, url, usuario, senha):
    url = url.strip()
    if not url.startswith("https://"):
        raise ErroDaAgenda("o endereço do servidor precisa começar com https://")
    conta = _nova("caldav", nome.strip() or "CalDAV", url=url, usuario=usuario.strip()[:120])
    segredos.gravar(f"agenda-{conta['id']}", senha, f"Wise — senha da agenda {conta['nome']}")
    try:
        conta["calendarios"] = fontes.CalDav(conta).descobrir()
    except ErroDaAgenda:
        segredos.apagar(f"agenda-{conta['id']}")
        raise
    with _trava:
        _salvar(contas() + [conta])
    return conta


def conectar(provedor, cancelado=None, abrir_navegador=None):
    """Login com Google ou Microsoft (abre o navegador e espera)."""
    nomes = {"google": "Google Agenda", "microsoft": "Outlook / Teams"}
    if provedor not in nomes:
        raise ErroDaAgenda("provedor desconhecido")
    conta = _nova(provedor, nomes[provedor])
    try:
        oauth.entrar(provedor, f"agenda-{conta['id']}", abrir_navegador, cancelado=cancelado)
    except oauth.ErroDeLogin as erro:
        raise ErroDaAgenda(str(erro)) from erro
    with _trava:
        _salvar(contas() + [conta])
    return conta


def remover(id_conta):
    with _trava:
        _salvar([c for c in contas() if c["id"] != id_conta])
    try:
        segredos.apagar(f"agenda-{id_conta}")
    except segredos.CofreIndisponivel:
        pass


def todas_as_fontes():
    return [AgendaLocal()] + [fontes.TIPOS[c["tipo"]](c) for c in contas()]


def fonte(id_fonte):
    for f in todas_as_fontes():
        if f.id == id_fonte:
            return f
    return None


def _semana():
    agora = datetime.datetime.now().astimezone()
    return agora, agora + datetime.timedelta(days=7)


def eventos(de, ate, lista_de_fontes=None):
    """(eventos de todas as fontes em ordem, avisos das que falharam).
    As fontes são lidas ao mesmo tempo; uma lenta ou fora do ar não segura as outras."""
    lista_de_fontes = lista_de_fontes if lista_de_fontes is not None else todas_as_fontes()
    resultado, avisos = [], []
    grupo = ThreadPoolExecutor(max_workers=max(1, min(6, len(lista_de_fontes))))
    tarefas = {grupo.submit(f.eventos, de, ate): f for f in lista_de_fontes}
    prontas, atrasadas = wait(tarefas, timeout=TEMPO_POR_FONTE)
    grupo.shutdown(wait=False, cancel_futures=True)     # a atrasada termina sozinha, sem segurar a resposta
    for tarefa in prontas:
        try:
            resultado += tarefa.result()
        except (ErroDaAgenda, segredos.CofreIndisponivel, ValueError) as erro:
            avisos.append(f"{tarefas[tarefa].nome}: {erro}")
        except Exception as erro:  # noqa: BLE001 — uma fonte nunca derruba a agenda
            avisos.append(f"{tarefas[tarefa].nome}: falhou ({type(erro).__name__})")
    for tarefa in atrasadas:
        avisos.append(f"{tarefas[tarefa].nome}: não respondeu a tempo")
    # Mesmo compromisso vindo de duas fontes (ex.: Google pelo login e pelo link .ics)
    vistos, unicos = set(), []
    for e in sorted(resultado, key=lambda e: e.inicio):
        chave = (e.titulo.lower(), e.inicio.timestamp(), e.fim.timestamp())
        if chave not in vistos:
            vistos.add(chave)
            unicos.append(e)
    return unicos, avisos
