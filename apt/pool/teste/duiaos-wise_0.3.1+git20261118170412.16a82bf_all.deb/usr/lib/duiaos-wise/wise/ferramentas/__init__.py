"""Ferramentas do Wise: ações declaradas, tipadas e com nível de risco.

O modelo de IA só pode pedir ferramentas que estão neste registro. Cada uma
tem um esquema JSON dos argumentos, que é validado antes da execução, e um
nível de autonomia (docs/arquitetura.md):

  N0 consultar    — lê e explica; roda sem pedir confirmação
  N1 preparar     — monta rascunho, não efetiva
  N1 também cobre o que só muda dados do próprio Wise ou da pessoa neste
     computador e se desfaz fácil (cidade da previsão, agenda do computador)
  N2 executar     — altera o sistema, a nuvem ou fala com outras pessoas; mostra
                    o impacto (preparar) e só executa com aprovação (W2)
"""
from .base import Ferramenta, Plano, Registro, ErroDeArgumentos  # noqa: F401
from . import agenda, aplicativos, clima, computador, conexoes, energia_e_ilha, sistema

__all__ = ["Ferramenta", "Plano", "Registro", "ErroDeArgumentos", "registro_padrao"]


def registro_padrao():
    registro = Registro()
    for grupo in (sistema.FERRAMENTAS, clima.FERRAMENTAS, agenda.FERRAMENTAS, aplicativos.FERRAMENTAS,
                  computador.FERRAMENTAS, energia_e_ilha.FERRAMENTAS, conexoes.FERRAMENTAS):
        for ferramenta in grupo:
            registro.adicionar(ferramenta)
    return registro
