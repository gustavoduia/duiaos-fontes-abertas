"""Ferramentas de agenda (W14): ver (N0), anotar na agenda do computador (N1) e
criar compromisso numa conta conectada (N2, com aprovação: pode avisar
outras pessoas e fica na nuvem).
"""
import datetime
import re

from .. import agenda
from .base import ErroDeArgumentos, Ferramenta, Plano

LIMITE_EVENTOS = 60


def _fuso():
    return datetime.datetime.now().astimezone().tzinfo


def _data(texto, nome):
    """'2026-10-14', 'hoje', 'amanhã' -> date."""
    texto = str(texto or "").strip().lower()
    hoje = datetime.datetime.now(_fuso()).date()
    if texto in ("", "hoje"):
        return hoje
    if texto in ("amanhã", "amanha"):
        return hoje + datetime.timedelta(days=1)
    try:
        return datetime.date.fromisoformat(texto[:10])
    except ValueError as erro:
        raise ErroDeArgumentos(f"'{nome}' deve ser uma data AAAA-MM-DD") from erro


def _data_hora(texto, nome):
    """'2026-10-14T14:00' ou '2026-10-14 14:00' -> datetime com fuso; só data -> (data, dia inteiro)."""
    texto = str(texto or "").strip().replace(" ", "T")
    try:
        if len(texto) == 10:
            d = datetime.date.fromisoformat(texto)
            return datetime.datetime.combine(d, datetime.time(), _fuso()), True
        valor = datetime.datetime.fromisoformat(texto)
    except ValueError as erro:
        hora = re.search(r"T(\d{1,2}):(\d{2})", texto)
        if hora and (int(hora.group(1)) > 23 or int(hora.group(2)) > 59):
            # "19:60" (log de 12/10): não existe; o modelo não deve trocar sozinho
            raise ErroDeArgumentos(f"a hora {hora.group(1)}:{hora.group(2)} não existe. Pergunte à pessoa a hora "
                                   "certa; não escolha outra por ela") from erro
        raise ErroDeArgumentos(f"'{nome}' deve ser data e hora, ex.: 2026-10-14T14:00") from erro
    return (valor if valor.tzinfo else valor.replace(tzinfo=_fuso())), False


def ver_agenda(de="", dias=1):
    inicio_dia = _data(de, "de")
    fuso = _fuso()
    inicio = datetime.datetime.combine(inicio_dia, datetime.time(), fuso)
    fim = inicio + datetime.timedelta(days=max(1, min(int(dias or 1), 31)))
    eventos, avisos = agenda.eventos(inicio, fim)
    contas = agenda.contas()
    resultado = {
        "periodo": f"{inicio_dia.isoformat()} a {(fim.date() - datetime.timedelta(days=1)).isoformat()}",
        "quantidade": len(eventos),
        "compromissos": [e.para_ferramenta(fuso) for e in eventos[:LIMITE_EVENTOS]],
        "agendas": ["Agenda do computador"] + [c.get("nome", "") for c in contas],
    }
    if len(eventos) > LIMITE_EVENTOS:
        resultado["mais"] = len(eventos) - LIMITE_EVENTOS
    if avisos:
        resultado["avisos"] = avisos[:6]
    if not contas:
        resultado["dica"] = ("só a agenda do computador está ligada; a pessoa pode conectar Google, Outlook/Teams, "
                             "iCloud ou outro provedor em Configurações do Wise > Agenda")
    return resultado


def _periodo(inicio, fim, duracao_minutos):
    comeco, dia_inteiro = _data_hora(inicio, "inicio")
    if fim:
        termino, _ = _data_hora(fim, "fim")
    elif dia_inteiro:
        termino = comeco + datetime.timedelta(days=1)
    else:
        termino = comeco + datetime.timedelta(minutes=max(5, min(int(duracao_minutos or 60), 24 * 60)))
    if termino <= comeco:
        raise ErroDeArgumentos("o fim tem que ser depois do início")
    return comeco, termino, dia_inteiro


def _titulo(titulo):
    titulo = " ".join(str(titulo or "").split())[:120]
    if not titulo:
        raise ErroDeArgumentos("falta o título do compromisso")
    return titulo


def anotar_na_agenda(titulo, inicio, fim="", duracao_minutos=60, local=""):
    comeco, termino, dia_inteiro = _periodo(inicio, fim, duracao_minutos)
    evento = agenda.AgendaLocal().criar(_titulo(titulo), comeco, termino, " ".join(str(local).split())[:120],
                                        dia_inteiro=dia_inteiro)
    return {"anotado": evento.para_ferramenta(_fuso()), "agenda": "Agenda do computador"}


def _escolher_conta(nome):
    nome = str(nome or "").strip().lower()
    contas = [c for c in agenda.contas() if c["tipo"] != "ics"]      # link .ics é só leitura
    if not contas:
        return None, "nenhuma conta com escrita está conectada (conecte em Configurações do Wise > Agenda)"
    if not nome:
        return (contas[0], "") if len(contas) == 1 else \
            (None, "há mais de uma conta; pergunte em qual: " + ", ".join(c["nome"] for c in contas))
    for c in contas:
        if nome in c["nome"].lower() or nome == c["tipo"]:
            return c, ""
    return None, "não achei essa conta; as conectadas são: " + ", ".join(c["nome"] for c in contas)


def preparar_compromisso(titulo, inicio, fim="", duracao_minutos=60, local="", conta="", reuniao_online=False):
    titulo = _titulo(titulo)
    comeco, termino, dia_inteiro = _periodo(inicio, fim, duracao_minutos)
    escolhida, problema = _escolher_conta(conta)
    if escolhida is None:
        return Plano("", recusa=problema)
    local = " ".join(str(local).split())[:120]
    fuso = _fuso()
    if dia_inteiro:
        quando = comeco.astimezone(fuso).strftime("%d/%m/%Y") + " (dia inteiro)"
    else:
        quando = comeco.astimezone(fuso).strftime("%d/%m/%Y, %H:%M") + "–" + termino.astimezone(fuso).strftime("%H:%M")
    detalhes = [f"Quando: {quando}", f"Onde fica: {escolhida['nome']}"]
    if local:
        detalhes.append(f"Local: {local}")
    if reuniao_online:
        detalhes.append("Com reunião on-line (" + ("Teams" if escolhida["tipo"] == "microsoft" else "Meet") + ")")
    return Plano(f"Criar '{titulo}' na agenda {escolhida['nome']}", detalhes,
                 dados={"conta": escolhida["id"], "titulo": titulo, "inicio": comeco, "fim": termino,
                        "local": local, "dia_inteiro": dia_inteiro, "online": bool(reuniao_online)})


def criar_compromisso(plano, _ao_progresso, _cancelado):
    d = plano.dados
    destino = agenda.fonte(d["conta"])
    if destino is None:
        return {"erro": "a conta foi desconectada"}
    try:
        evento = destino.criar(d["titulo"], d["inicio"], d["fim"], d["local"], dia_inteiro=d["dia_inteiro"],
                               online=d["online"])
    except agenda.ErroDaAgenda as erro:
        return {"erro": str(erro)}
    return {"feito": True, "mensagem": f"Criado na agenda {destino.nome}.",
            "compromisso": evento.para_ferramenta(_fuso())}


_PERIODO = {
    "titulo": {"type": "string", "description": "Nome do compromisso."},
    "inicio": {"type": "string", "description": "Início: AAAA-MM-DDTHH:MM (ou só AAAA-MM-DD para o dia inteiro)."},
    "fim": {"type": "string", "description": "Fim (opcional), mesmo formato."},
    "duracao_minutos": {"type": "integer", "minimum": 5, "maximum": 1440, "description": "Duração se não houver fim."},
    "local": {"type": "string", "description": "Local (opcional)."},
}

FERRAMENTAS = [
    Ferramenta("ver_agenda", "Agenda",
               "Compromissos da pessoa num período, juntando a agenda do computador e as contas conectadas "
               "(Google, Outlook/Teams, iCloud, CalDAV, links .ics). Use data_e_hora antes se precisar saber "
               "que dia é hoje.",
               ver_agenda,
               {"type": "object", "properties": {
                   "de": {"type": "string", "description": "Primeiro dia: AAAA-MM-DD, 'hoje' ou 'amanhã' (padrão hoje)."},
                   "dias": {"type": "integer", "minimum": 1, "maximum": 31,
                            "description": "Quantos dias a partir de 'de' (padrão 1; semana = 7)."}}}),
    Ferramenta("anotar_na_agenda", "Anotar na agenda do computador",
               "Anota um compromisso na agenda do computador (só neste computador, ninguém é avisado).",
               anotar_na_agenda,
               {"type": "object", "properties": dict(_PERIODO), "required": ["titulo", "inicio"]}, nivel="N1"),
    Ferramenta("criar_compromisso", "Criar compromisso na conta",
               "Cria um compromisso numa conta conectada (Google, Outlook/Teams ou CalDAV), opcionalmente com "
               "reunião on-line. A pessoa vê os detalhes e aprova antes.",
               criar_compromisso,
               {"type": "object", "properties": {
                   **_PERIODO,
                   "conta": {"type": "string", "description": "Nome da conta, se houver mais de uma."},
                   "reuniao_online": {"type": "boolean", "description": "Criar reunião do Teams ou do Meet."}},
                "required": ["titulo", "inicio"]},
               nivel="N2", preparar=preparar_compromisso),
]
