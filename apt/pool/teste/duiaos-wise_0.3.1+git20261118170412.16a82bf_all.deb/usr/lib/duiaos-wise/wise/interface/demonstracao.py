"""Modo demonstração: um "modelo" de regras simples, sem IA, para testar a
janela e as ferramentas sem Ollama nem chave do Gemini (duiaos-wise --demonstracao)."""
import json
import time

from ..modelos import ChamadaDeFerramenta, Gateway, Provedor, Resposta

REGRAS = [
    (("lento", "memória", "memoria", "processador"), "uso_do_computador"),
    (("espaço", "espaco", "disco"), "uso_do_computador"),
    (("internet", "wi-fi", "wifi", "rede"), "rede"),
    (("atualiza",), "atualizacoes_disponiveis"),
    (("hora", "dia"), "data_e_hora"),
    (("programa", "pesad"), "programas_mais_pesados"),
]


class Demonstracao(Provedor):
    nome = "demonstracao"
    titulo = "Demonstração"
    modelo = "qwen3.5:4b"
    nuvem = False

    def disponivel(self):
        return True, ""

    def responder(self, instrucoes, conversa, ferramentas, cancelado=None, ao_parcial=None):
        time.sleep(0.6)
        ultima = conversa[-1]
        if ultima.papel == "ferramenta":
            resumo = json.dumps(ultima.resultado, ensure_ascii=False)[:300]
            return Resposta(texto=f"**Demonstração.** Consultei *{ultima.ferramenta}* e recebi:\n\n`{resumo}`")
        pedido = ultima.texto.lower()
        for palavras, ferramenta in REGRAS:
            if any(p in pedido for p in palavras):
                return Resposta(chamadas=[ChamadaDeFerramenta(ferramenta, {})])
        return Resposta(texto="Modo demonstração: pergunte sobre lentidão, espaço, internet, atualizações ou hora.")


def gateway_de_demonstracao(configuracao):
    demo = Demonstracao()
    gateway = Gateway(configuracao, lambda: None, local=demo, gemini=demo, openai=demo)
    return gateway
