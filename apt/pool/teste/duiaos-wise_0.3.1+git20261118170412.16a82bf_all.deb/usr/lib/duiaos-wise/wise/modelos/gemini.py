"""Provedor Google Gemini (API REST generateContent, com function calling).

- A chave fica no cofre do sistema (wise.segredos, nome "gemini").
- Só é usado com consentimento explícito da pessoa (Configuracao.nuvem_permitida):
  na camada gratuita, o Google pode usar o conteúdo para melhorar os produtos dele.
- Os modelos Gemini 3 devolvem "thoughtSignature" nas partes da resposta; elas
  precisam voltar intactas no histórico, por isso guardamos a mensagem bruta.
"""
from .base import ChamadaDeFerramenta, ErroDoProvedor, Provedor, ProvedorIndisponivel, Resposta, post_json

URL = "https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"


class Gemini(Provedor):
    nome = "gemini"
    titulo = "Gemini"
    nuvem = True

    def __init__(self, modelo, ler_chave, consentimento, url=URL):
        self.modelo = modelo
        self._ler_chave = ler_chave          # função: devolve a chave ou None
        self._consentimento = consentimento  # função: devolve True/False
        self._url = url

    def disponivel(self):
        if not self._consentimento():
            return False, "o uso da nuvem não foi autorizado nas configurações"
        try:
            chave = self._ler_chave()
        except Exception as erro:  # cofre fora do ar
            return False, f"não consegui ler a chave do Gemini ({erro})"
        if not chave:
            return False, "falta a chave do Gemini nas configurações"
        return True, ""

    # ------------------------------------------------------------ conversão
    @staticmethod
    def converter_ferramentas(declaracoes):
        funcoes = []
        for d in declaracoes:
            funcao = {"name": d["nome"], "description": d["descricao"]}
            if d["parametros"].get("properties"):
                funcao["parametersJsonSchema"] = d["parametros"]
            funcoes.append(funcao)
        return [{"functionDeclarations": funcoes}] if funcoes else []

    @staticmethod
    def converter_conversa(conversa):
        conteudos = []
        for m in conversa:
            if m.papel == "pessoa":
                conteudos.append({"role": "user", "parts": [{"text": m.texto}]})
            elif m.papel == "wise":
                if m.bruto and m.bruto.get("provedor") == "gemini":
                    conteudos.append(m.bruto["conteudo"])   # mantém thoughtSignature
                else:
                    partes = [{"text": m.texto}] if m.texto else []
                    partes += [{"functionCall": {"name": c.nome, "args": c.argumentos}} for c in m.chamadas]
                    conteudos.append({"role": "model", "parts": partes or [{"text": ""}]})
            elif m.papel == "ferramenta":
                parte = {"functionResponse": {"name": m.ferramenta, "response": {"resultado": m.resultado}}}
                # Respostas de várias ferramentas do mesmo turno vão juntas
                if conteudos and conteudos[-1]["role"] == "user" and "functionResponse" in conteudos[-1]["parts"][0]:
                    conteudos[-1]["parts"].append(parte)
                else:
                    conteudos.append({"role": "user", "parts": [parte]})
        return conteudos

    # ------------------------------------------------------------- chamada
    def responder(self, instrucoes, conversa, ferramentas, cancelado=None, ao_parcial=None):
        pronto, motivo = self.disponivel()
        if not pronto:
            raise ProvedorIndisponivel(motivo)
        corpo = {
            "systemInstruction": {"parts": [{"text": instrucoes}]},
            "contents": self.converter_conversa(conversa),
            "generationConfig": {"temperature": 0.3},
        }
        declaradas = self.converter_ferramentas(ferramentas)
        if declaradas:
            corpo["tools"] = declaradas
        dados = post_json(self._url.format(modelo=self.modelo), corpo,
                          {"x-goog-api-key": self._ler_chave()}, tempo=90)
        candidatos = dados.get("candidates") or []
        if not candidatos:
            bloqueio = (dados.get("promptFeedback") or {}).get("blockReason")
            raise ErroDoProvedor(f"o Gemini não respondeu{' (' + bloqueio + ')' if bloqueio else ''}")
        conteudo = candidatos[0].get("content") or {"role": "model", "parts": []}
        conteudo.setdefault("role", "model")
        textos, chamadas = [], []
        for parte in conteudo.get("parts", []):
            if parte.get("thought"):
                continue
            if "text" in parte:
                textos.append(parte["text"])
            if "functionCall" in parte:
                chamada = parte["functionCall"]
                chamadas.append(ChamadaDeFerramenta(chamada.get("name", ""), chamada.get("args") or {},
                                                    chamada.get("id", "")))
        return Resposta(texto="".join(textos).strip(), chamadas=chamadas,
                        bruto={"provedor": "gemini", "conteudo": conteudo})
