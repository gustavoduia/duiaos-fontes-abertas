// Wise — botão flutuante numa janela comum, para testar o visual (--demonstracao).
import QtQuick
import QtQuick.Window

Window {
    visible: true
    color: "#E8F0FE"
    title: "Wise (bolha, demonstração)"
    width: 480; height: 300
    ConteudoBolha {
        id: conteudo
        anchors { right: parent.right; bottom: parent.bottom }
        width: implicitWidth; height: implicitHeight
        estado: bolha.estado
        progresso: bolha.progresso
        onClicado: bolha.clicar()
        onAbrir: bolha.abrir()
    }
    Connections {
        target: bolha
        function onSaudar(texto) { conteudo.saudar(texto) }
        function onResponder(texto) { conteudo.responder(texto) }
        function onFecharBalao() { conteudo.textoBalao = "" }
    }
}
