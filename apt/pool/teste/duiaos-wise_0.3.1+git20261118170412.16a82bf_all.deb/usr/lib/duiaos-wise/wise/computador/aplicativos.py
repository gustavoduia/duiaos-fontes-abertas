"""Aplicativos instalados (arquivos .desktop) e janelas abertas."""
import os
import shlex
import subprocess
import unicodedata
from pathlib import Path

_DADOS = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":")
PASTAS = [Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "applications"] + \
         [Path(p) / "applications" for p in _DADOS if p]
PROPRIOS = {"duiaos-wise"}          # o Wise não opera a própria janela


def normalizar(texto):
    decomposto = unicodedata.normalize("NFD", str(texto))
    return "".join(c for c in decomposto if not unicodedata.combining(c)).casefold().strip()


def _ler(caminho):
    dados, na_secao = {}, False
    try:
        linhas = caminho.read_text(encoding="utf-8", errors="ignore").splitlines()
    except OSError:
        return None
    for linha in linhas:
        linha = linha.strip()
        if linha.startswith("["):
            na_secao = linha == "[Desktop Entry]"
        elif na_secao and "=" in linha:
            chave, valor = linha.split("=", 1)
            dados.setdefault(chave.strip(), valor.strip())
    if dados.get("Type", "Application") != "Application" or \
            dados.get("NoDisplay", "").lower() == "true" or dados.get("Hidden", "").lower() == "true":
        return None

    def local(chave):
        return dados.get(chave + "[pt_BR]") or dados.get(chave + "[pt]") or dados.get(chave, "")
    nome = local("Name") or caminho.stem
    return {"id": caminho.name, "nome": nome[:80], "descricao": (local("GenericName") or local("Comment"))[:100],
            "exec": dados.get("Exec", ""), "terminal": dados.get("Terminal", "").lower() == "true",
            "classe": dados.get("StartupWMClass", "").lower(),
            "busca": normalizar(" ".join([nome, local("GenericName"), local("Keywords"), caminho.stem]))}


def listar():
    vistos = {}
    for pasta in PASTAS:
        if pasta.is_dir():
            for caminho in sorted(pasta.glob("*.desktop")):
                if caminho.name not in vistos:
                    vistos[caminho.name] = _ler(caminho)
    return sorted((a for a in vistos.values() if a and Path(a["id"]).stem not in PROPRIOS),
                  key=lambda a: normalizar(a["nome"]))


def procurar(nome):
    """Aplicativos que combinam com o nome (o nome exato primeiro)."""
    alvo = normalizar(nome)
    if not alvo:
        return []
    exatos, comecam, contem = [], [], []
    for app in listar():
        nome_app = normalizar(app["nome"])
        if alvo in (nome_app, normalizar(Path(app["id"]).stem)):
            exatos.append(app)
        elif nome_app.startswith(alvo):
            comecam.append(app)
        elif all(p in app["busca"] for p in alvo.split()):
            contem.append(app)
    return exatos + comecam + contem


def comando(app):
    try:
        partes = shlex.split(app["exec"])
    except ValueError:
        return []
    partes = [p for p in partes if not (len(p) == 2 and p.startswith("%"))]
    return (["foot", "--"] + partes) if partes and app.get("terminal") else partes


def abrir(app):
    argumentos = comando(app)
    if not argumentos:
        raise ValueError(f"não sei abrir {app['nome']}")
    ambiente = dict(os.environ)
    ambiente.pop("QT_WAYLAND_SHELL_INTEGRATION", None)       # janela comum, não painel
    subprocess.Popen(argumentos, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True, env=ambiente, cwd=str(Path.home()))


# ------------------------------------------------------------------ janelas
def janelas():
    """[{"app", "titulo"}] das janelas abertas (sem a do Wise)."""
    try:
        saida = subprocess.run(["wlrctl", "toplevel", "list"], capture_output=True, text=True, timeout=3,
                               check=False).stdout
    except (OSError, subprocess.TimeoutExpired):
        return []
    lista = []
    for linha in saida.splitlines():
        app, _, titulo = linha.partition(":")
        app, titulo = app.strip(), titulo.strip()
        if app and app not in PROPRIOS:
            lista.append({"app": app[:80], "titulo": titulo[:150]})
    return lista


def achar_janela(nome):
    """A janela aberta que combina com o nome (app_id, título ou nome do aplicativo)."""
    alvo = normalizar(nome)
    abertas = janelas()
    for j in abertas:
        if alvo in (normalizar(j["app"]), normalizar(j["app"].split(".")[-1])):
            return j
    for app in procurar(nome):
        chaves = {normalizar(Path(app["id"]).stem), app["classe"]}
        for j in abertas:
            if normalizar(j["app"]) in chaves or normalizar(j["app"]).split(".")[-1] in chaves:
                return j
    for j in abertas:
        if alvo and alvo in normalizar(j["titulo"]):
            return j
    return None


def focar(janela):
    subprocess.run(["wlrctl", "toplevel", "focus", "app_id:" + janela["app"]], capture_output=True, timeout=3,
                   check=False)
