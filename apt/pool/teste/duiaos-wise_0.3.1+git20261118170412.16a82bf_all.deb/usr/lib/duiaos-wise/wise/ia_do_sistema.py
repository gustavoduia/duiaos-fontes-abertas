"""IA do sistema (serviço duiaos-ia do DuiaOS, ADRs 029–031 do DuiaOS).

O DuiaOS tem um só modelo de IA local ativo para o sistema inteiro, escolhido
na Central de IA. O Wise só lê o estado público do serviço:
  /var/lib/duiaos-ia/estado.json
  {"ativo": "qwen3.5:4b", "endereco": "http://127.0.0.1:11434",
   "tarefa": {"modelo", "fracao", "concluido", "total", "automatico", ...} ou null,
   "ultima": {"modelo", "resultado": "ok"|"erro"|"cancelado", "mensagem", "quando"} ou null}

O arquivo é dado, nunca instrução: cada campo é conferido antes de usar.
Sem o serviço (outro Linux, desenvolvimento), o Wise usa o modelo das
próprias preferências.
"""
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path

ARQUIVO = Path(os.environ.get("DUIAOS_IA_ESTADO", "/var/lib/duiaos-ia/estado.json"))
_NOME_MODELO = re.compile(r"^[a-z0-9][a-z0-9._-]{0,60}(:[a-z0-9._-]{1,40})?$")
_ENDERECO_LOCAL = re.compile(r"^http://(127\.0\.0\.1|localhost|\[::1\]):\d{1,5}$")

# Nomes para a pessoa (o catálogo completo fica no DuiaOS; aqui só o necessário)
_FAMILIAS = {"qwen3.5": "Qwen3.5", "qwen3": "Qwen3", "gemma4": "Gemma 4", "llama3.3": "Llama 3.3",
             "llama3.2": "Llama 3.2", "llama3.1": "Llama 3.1", "llama3": "Llama 3", "phi4-mini": "Phi-4 mini",
             "phi4": "Phi-4", "phi3.5": "Phi-3.5", "phi3": "Phi-3"}


def nome_amigavel(modelo):
    """'qwen3.5:4b' -> 'Qwen3.5 4B'."""
    familia, _, tamanho = modelo.partition(":")
    return f"{_FAMILIAS.get(familia, familia)} {tamanho.upper()}".strip()


@dataclass
class Tarefa:
    modelo: str
    fracao: float
    concluido: int
    total: int
    automatico: bool


@dataclass
class Ultima:
    modelo: str
    resultado: str
    mensagem: str
    quando: int


@dataclass
class EstadoIA:
    ativo: str = ""
    endereco: str = "http://127.0.0.1:11434"
    manter: object = "30m"          # keep_alive do modelo ativo: -1 (sempre) ou ex.: "30m"
    carregado: bool = False         # o modelo ativo já está na memória
    calibrando: bool = False        # o duiaos-ia está medindo as opções mais rápidas
    opcoes: dict = None             # opções do Ollama para este computador (num_thread, num_gpu)

    def __post_init__(self):
        if self.opcoes is None:
            self.opcoes = {}
    tarefa: Tarefa = None
    ultima: Ultima = None


def _modelo(valor):
    return valor if isinstance(valor, str) and _NOME_MODELO.match(valor) else ""


def _inteiro(valor):
    return valor if isinstance(valor, int) and not isinstance(valor, bool) and valor >= 0 else 0


def ler(arquivo=None):
    """Estado da IA do sistema, ou None se o DuiaOS não tem o serviço."""
    try:
        dados = json.loads(Path(arquivo or ARQUIVO).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(dados, dict):
        return None
    estado = EstadoIA(ativo=_modelo(dados.get("ativo")))
    endereco = dados.get("endereco")
    if isinstance(endereco, str) and _ENDERECO_LOCAL.match(endereco):
        estado.endereco = endereco
    manter = dados.get("manter")
    if manter == -1 or (isinstance(manter, str) and re.fullmatch(r"\d{1,4}[smh]", manter)):
        estado.manter = manter
    estado.carregado = dados.get("carregado") is True
    estado.calibrando = dados.get("calibrando") is True
    opcoes = dados.get("opcoes")
    if isinstance(opcoes, dict):
        estado.opcoes = {k: v for k, v in opcoes.items()
                         if k in ("num_thread", "num_gpu") and isinstance(v, int) and not isinstance(v, bool)
                         and 0 <= v <= 999}
    tarefa = dados.get("tarefa")
    if isinstance(tarefa, dict) and _modelo(tarefa.get("modelo")):
        fracao = tarefa.get("fracao")
        fracao = float(fracao) if isinstance(fracao, (int, float)) and not isinstance(fracao, bool) else 0.0
        estado.tarefa = Tarefa(tarefa["modelo"], min(max(fracao, 0.0), 1.0), _inteiro(tarefa.get("concluido")),
                               _inteiro(tarefa.get("total")), tarefa.get("automatico") is True)
    ultima = dados.get("ultima")
    if isinstance(ultima, dict) and _modelo(ultima.get("modelo")) and \
            ultima.get("resultado") in ("ok", "erro", "cancelado"):
        mensagem = ultima.get("mensagem") if isinstance(ultima.get("mensagem"), str) else ""
        estado.ultima = Ultima(ultima["modelo"], ultima["resultado"], mensagem[:300], _inteiro(ultima.get("quando")))
    return estado


def _gb(numero):
    return f"{numero / 1024 ** 3:.1f}".replace(".", ",")


class Acompanhamento:
    """Acompanha o estado da IA do sistema para o Wise avisar a pessoa.

    Só o download automático (o modelo padrão no 1º login) aparece no balão do
    Wise; os que a pessoa pede na Central de IA aparecem na própria Central.
    atualizar(estado) devolve (progresso, mensagem, mudou):
      progresso  dict para o balão (titulo, detalhe, fracao, nota) ou None
      mensagem   texto para o balão quando o download termina, ou None
      mudou      True quando o modelo ativo mudou (a janela atualiza a situação)
    """

    def __init__(self):
        self._baixando = ""         # modelo do download automático acompanhado
        self._ativo = None

    def atualizar(self, estado):
        if estado is None:
            self._baixando = ""
            return None, None, False
        mudou = self._ativo is not None and estado.ativo != self._ativo
        self._ativo = estado.ativo
        tarefa = estado.tarefa
        if tarefa and tarefa.automatico:
            self._baixando = tarefa.modelo
            nome = nome_amigavel(tarefa.modelo)
            detalhe = f"{nome} · {tarefa.fracao * 100:.0f}%"
            if tarefa.total:
                detalhe += f" · {_gb(tarefa.concluido)} de {_gb(tarefa.total)} GB"
            return ({"titulo": "Preparando a IA do sistema", "detalhe": detalhe, "fracao": tarefa.fracao,
                     "nota": "Pode usar o computador normalmente; aviso quando terminar."}, None, mudou)
        mensagem = None
        if self._baixando and not tarefa:
            ultima = estado.ultima
            if ultima and ultima.modelo == self._baixando:
                nome = nome_amigavel(ultima.modelo)
                if ultima.resultado == "ok":
                    mensagem = (f"Pronto! A IA do sistema ({nome}) está pronta. Agora posso conversar "
                                "com você aqui mesmo, sem internet.")
                elif ultima.resultado == "erro":
                    mensagem = (f"Não consegui baixar a IA do sistema ({nome}): {ultima.mensagem} "
                                "Abra a Central de IA para tentar de novo.")
            self._baixando = ""
            mudou = True
        return None, mensagem, mudou
