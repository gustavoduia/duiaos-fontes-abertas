// Wise — botão flutuante no canto inferior direito (painel layer-shell).
// Fica acima da Ilha de Aplicativos (respeita a área reservada por ela).
import QtQuick
import QtQuick.Window
import org.kde.layershell 1.0 as LayerShell

Window {
    id: janela
    visible: true
    color: "transparent"
    title: "Wise"
    width: conteudo.implicitWidth
    height: conteudo.implicitHeight

    LayerShell.Window.anchors: LayerShell.Window.AnchorBottom | LayerShell.Window.AnchorRight
    LayerShell.Window.layer: LayerShell.Window.LayerTop
    LayerShell.Window.exclusionZone: 0
    LayerShell.Window.keyboardInteractivity: LayerShell.Window.KeyboardInteractivityNone
    LayerShell.Window.scope: "duiaos-wise-bolha"

    ConteudoBolha {
        id: conteudo
        anchors.fill: parent
        estado: bolha.estado
        progresso: bolha.progresso
        onClicado: bolha.clicar()
        onAbrir: bolha.abrir()
    }
    Connections {
        target: bolha
        function onSaudar(texto) { conteudo.saudar(texto) }
        function onResponder(texto) { conteudo.responder(texto) }
        function onFecharBalao() { conteudo.textoBalao = "" }
    }
}
