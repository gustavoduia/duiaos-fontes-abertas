"""Fontes de agenda do Wise (W14).

- Agenda do computador: arquivo .ics local (~/.local/share/duiaos/agenda),
  sem conta e sem internet. O Wise pode anotar compromissos nela.
- Link .ics: o "endereço secreto" que Google, Outlook, iCloud e outros dão
  para assinar a agenda. Só leitura. O endereço é um segredo (quem tem, lê a
  agenda): fica no cofre do sistema.
- CalDAV: provedores próprios ou privados (Nextcloud, iCloud, Fastmail, Zimbra,
  servidores de empresas). Endereço e usuário nas preferências; a senha de
  aplicativo no cofre. Lê e cria.
- Google Agenda e Microsoft (Outlook e Teams): login OAuth (wise.agenda.oauth),
  tokens no cofre. Lê todas as agendas visíveis e cria na principal.

O que vem de fora é dado, nunca instrução: textos cortados, datas conferidas.
"""
import base64
import datetime
import json
import os
import re
import time
import urllib.parse
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

from .. import segredos
from ..internet import SemInternet, baixar
from . import ics, oauth
from .ics import Evento

PASTA_LOCAL = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "duiaos" / "agenda"
CACHE = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "duiaos" / "wise" / "agenda"
VALIDADE_CACHE = 600          # links .ics: no máximo uma busca a cada 10 min


class ErroDaAgenda(Exception):
    """Mensagem pronta para a pessoa."""


def _utc(d):
    return d.astimezone(datetime.timezone.utc)


# ------------------------------------------------------------------- local
class AgendaLocal:
    tipo, id, nome, pode_criar = "local", "local", "Agenda do computador", True

    def __init__(self, pasta=None):
        self.arquivo = Path(pasta or PASTA_LOCAL) / "duiaos.ics"

    def _ler(self):
        try:
            return self.arquivo.read_bytes()
        except OSError:
            return b""

    def eventos(self, de, ate):
        conteudo = self._ler()
        return ics.ler(conteudo, de, ate, self.nome, self.id) if conteudo else []

    def criar(self, titulo, inicio, fim, local="", descricao="", dia_inteiro=False, online=False):
        import icalendar
        conteudo = self._ler()
        calendario = icalendar.Calendar.from_ical(conteudo) if conteudo else ics.novo_calendario()
        componente = ics.componente_de_evento(titulo, inicio, fim, local, descricao, dia_inteiro=dia_inteiro)
        calendario.add_component(componente)
        self._gravar(calendario.to_ical())
        return Evento(titulo, inicio, fim, dia_inteiro, local, descricao, str(componente["uid"]), self.nome, self.id)

    def apagar(self, uid):
        import icalendar
        conteudo = self._ler()
        if not conteudo:
            return False
        calendario = icalendar.Calendar.from_ical(conteudo)
        antes = len(calendario.subcomponents)
        calendario.subcomponents = [c for c in calendario.subcomponents
                                    if not (c.name == "VEVENT" and str(c.get("UID", "")) == uid)]
        if len(calendario.subcomponents) == antes:
            return False
        self._gravar(calendario.to_ical())
        return True

    def _gravar(self, dados):
        self.arquivo.parent.mkdir(parents=True, exist_ok=True)
        temporario = self.arquivo.with_suffix(".tmp")
        temporario.write_bytes(dados)
        os.replace(temporario, self.arquivo)          # nunca deixa o arquivo pela metade


# --------------------------------------------------------------- link .ics
class LinkIcs:
    tipo, pode_criar = "ics", False

    def __init__(self, conta):
        self.id, self.nome = conta["id"], conta.get("nome") or "Agenda assinada"

    def eventos(self, de, ate):
        arquivo = CACHE / f"{self.id}.ics"
        try:
            novo = time.time() - arquivo.stat().st_mtime < VALIDADE_CACHE
        except OSError:
            novo = False
        if not novo:
            url = segredos.ler(f"agenda-{self.id}")
            if not url:
                raise ErroDaAgenda(f"o endereço da agenda '{self.nome}' sumiu do cofre; adicione de novo")
            try:
                _c, _h, dados = baixar(url, tempo=15)
                CACHE.mkdir(parents=True, exist_ok=True)
                arquivo.write_bytes(dados)
            except SemInternet as erro:
                if not arquivo.exists():
                    raise ErroDaAgenda(f"não consegui ler '{self.nome}': {erro}") from erro
        return ics.ler(arquivo.read_bytes(), de, ate, self.nome, self.id)


def normalizar_link(url):
    url = url.strip()
    if url.startswith("webcal://"):
        url = "https://" + url[len("webcal://"):]
    if not url.startswith("https://") or len(url) > 2000 or any(c.isspace() for c in url):
        raise ErroDaAgenda("o endereço precisa começar com https:// ou webcal://")
    return url


# ------------------------------------------------------------------ CalDAV
DAV = {"d": "DAV:", "c": "urn:ietf:params:xml:ns:caldav"}


class CalDav:
    tipo, pode_criar = "caldav", True

    def __init__(self, conta):
        self.id, self.nome = conta["id"], conta.get("nome") or "CalDAV"
        self.url, self.usuario = conta["url"], conta.get("usuario", "")
        self.calendarios = list(conta.get("calendarios") or [])

    def _pedir(self, metodo, url, corpo=None, profundidade=None, extra=None):
        senha = segredos.ler(f"agenda-{self.id}") or ""
        credencial = base64.b64encode(f"{self.usuario}:{senha}".encode()).decode()
        cabecalhos = {"Authorization": f"Basic {credencial}", **(extra or {})}
        if corpo is not None:
            cabecalhos["Content-Type"] = "application/xml; charset=utf-8" if metodo != "PUT" \
                else "text/calendar; charset=utf-8"
        if profundidade is not None:
            cabecalhos["Depth"] = str(profundidade)
        try:
            _c, _h, dados = baixar(url, cabecalhos, tempo=20, metodo=metodo,
                                   corpo=corpo.encode() if isinstance(corpo, str) else corpo)
        except SemInternet as erro:
            if "401" in str(erro) or "403" in str(erro):
                raise ErroDaAgenda(f"o servidor de '{self.nome}' recusou o usuário ou a senha") from erro
            raise ErroDaAgenda(f"não consegui falar com '{self.nome}': {erro}") from erro
        return dados

    def _propfind(self, url, propriedades, profundidade=0):
        corpo = ('<?xml version="1.0"?><d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
                 f"<d:prop>{propriedades}</d:prop></d:propfind>")
        try:
            return ET.fromstring(self._pedir("PROPFIND", url, corpo, profundidade))
        except ET.ParseError as erro:
            raise ErroDaAgenda(f"o servidor de '{self.nome}' respondeu algo que não entendi") from erro

    def descobrir(self):
        """Acha as agendas da conta: principal → calendar-home-set → coleções de agenda."""
        url = self.url
        raiz = self._propfind(url, "<d:current-user-principal/>")
        principal = raiz.find(".//d:current-user-principal/d:href", DAV)
        if principal is not None:
            url = urllib.parse.urljoin(url, principal.text.strip())
            raiz = self._propfind(url, "<c:calendar-home-set/>")
            casa = raiz.find(".//c:calendar-home-set/d:href", DAV)
            if casa is not None:
                url = urllib.parse.urljoin(url, casa.text.strip())
        raiz = self._propfind(url, "<d:resourcetype/><d:displayname/><c:supported-calendar-component-set/>", 1)
        achados = []
        for resposta in raiz.findall("d:response", DAV):
            if resposta.find(".//d:resourcetype/c:calendar", DAV) is None:
                continue
            componentes = [c.get("name") for c in resposta.findall(".//c:comp", DAV)]
            if componentes and "VEVENT" not in componentes:
                continue                                  # só tarefas (VTODO): não é agenda de compromissos
            href = resposta.find("d:href", DAV).text.strip()
            nome = resposta.find(".//d:displayname", DAV)
            achados.append({"url": urllib.parse.urljoin(url, href),
                            "nome": (nome.text or "").strip()[:80] if nome is not None else ""})
        if not achados:
            raise ErroDaAgenda("não achei nenhuma agenda nessa conta")
        self.calendarios = achados
        return achados

    def eventos(self, de, ate):
        inicio, fim = _utc(de).strftime("%Y%m%dT%H%M%SZ"), _utc(ate).strftime("%Y%m%dT%H%M%SZ")
        corpo = ('<?xml version="1.0"?><c:calendar-query xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
                 '<d:prop><c:calendar-data/></d:prop><c:filter><c:comp-filter name="VCALENDAR">'
                 f'<c:comp-filter name="VEVENT"><c:time-range start="{inicio}" end="{fim}"/>'
                 "</c:comp-filter></c:comp-filter></c:filter></c:calendar-query>")
        eventos = []
        for calendario in self.calendarios or self.descobrir():
            try:
                raiz = ET.fromstring(self._pedir("REPORT", calendario["url"], corpo, 1))
            except ET.ParseError:
                continue
            nome = f"{self.nome} · {calendario['nome']}" if calendario.get("nome") else self.nome
            for dado in raiz.findall(".//c:calendar-data", DAV):
                if dado.text:
                    eventos += ics.ler(dado.text.encode(), de, ate, nome, self.id)
        return eventos

    def criar(self, titulo, inicio, fim, local="", descricao="", dia_inteiro=False, online=False):
        calendario = (self.calendarios or self.descobrir())[0]
        uid = f"{uuid.uuid4()}@duiaos"
        cal = ics.novo_calendario()
        cal.add_component(ics.componente_de_evento(titulo, inicio, fim, local, descricao, uid, dia_inteiro))
        destino = calendario["url"].rstrip("/") + f"/{uid}.ics"
        self._pedir("PUT", destino, cal.to_ical(), extra={"If-None-Match": "*"})
        return Evento(titulo, inicio, fim, dia_inteiro, local, descricao, uid, self.nome, self.id)


# ------------------------------------------------------------------ Google
class Google:
    tipo, pode_criar = "google", True
    API = "https://www.googleapis.com/calendar/v3"

    def __init__(self, conta):
        self.id, self.nome = conta["id"], conta.get("nome") or "Google Agenda"

    def _json(self, url, metodo="GET", corpo=None):
        try:
            token = oauth.acesso("google", f"agenda-{self.id}")
        except oauth.ErroDeLogin as erro:
            raise ErroDaAgenda(str(erro)) from erro
        cab = {"Authorization": f"Bearer {token}"}
        if corpo is not None:
            cab["Content-Type"] = "application/json"
        try:
            _c, _h, dados = baixar(url, cab, tempo=20, metodo=metodo,
                                   corpo=json.dumps(corpo).encode() if corpo is not None else None)
            return json.loads(dados)
        except (SemInternet, ValueError) as erro:
            raise ErroDaAgenda(f"não consegui falar com o Google Agenda: {erro}") from erro

    def eventos(self, de, ate):
        agendas = self._json(f"{self.API}/users/me/calendarList?minAccessRole=reader").get("items") or []
        eventos = []
        for agenda in agendas[:20]:
            if agenda.get("selected") is False or agenda.get("hidden"):
                continue
            parametros = urllib.parse.urlencode({"timeMin": _utc(de).isoformat(), "timeMax": _utc(ate).isoformat(),
                                                 "singleEvents": "true", "orderBy": "startTime", "maxResults": 250})
            id_agenda = urllib.parse.quote(str(agenda.get("id", "")), safe="")
            nome = self.nome if agenda.get("primary") else f"{self.nome} · {str(agenda.get('summary', ''))[:60]}"
            for item in self._json(f"{self.API}/calendars/{id_agenda}/events?{parametros}").get("items") or []:
                evento = _evento_google(item, nome, self.id)
                if evento:
                    eventos.append(evento)
        return eventos

    def criar(self, titulo, inicio, fim, local="", descricao="", dia_inteiro=False, online=False):
        corpo = {"summary": titulo, "location": local, "description": descricao}
        if dia_inteiro:
            corpo["start"], corpo["end"] = {"date": inicio.date().isoformat()}, {"date": fim.date().isoformat()}
        else:
            corpo["start"], corpo["end"] = {"dateTime": inicio.isoformat()}, {"dateTime": fim.isoformat()}
        url = f"{self.API}/calendars/primary/events"
        if online:
            corpo["conferenceData"] = {"createRequest": {"requestId": uuid.uuid4().hex,
                                                         "conferenceSolutionKey": {"type": "hangoutsMeet"}}}
            url += "?conferenceDataVersion=1"
        item = self._json(url, "POST", corpo)
        return _evento_google(item, self.nome, self.id) or Evento(titulo, inicio, fim, dia_inteiro, local,
                                                                  descricao, "", self.nome, self.id)


def _evento_google(item, nome, conta):
    if not isinstance(item, dict) or item.get("status") == "cancelled":
        return None
    try:
        inicio, fim = item["start"], item["end"]
        if "date" in inicio:
            fuso = datetime.datetime.now().astimezone().tzinfo
            i = datetime.datetime.combine(datetime.date.fromisoformat(inicio["date"]), datetime.time(), fuso)
            f = datetime.datetime.combine(datetime.date.fromisoformat(fim["date"]), datetime.time(), fuso)
            dia = True
        else:
            i = datetime.datetime.fromisoformat(inicio["dateTime"].replace("Z", "+00:00"))
            f = datetime.datetime.fromisoformat(fim["dateTime"].replace("Z", "+00:00"))
            dia = False
    except (KeyError, TypeError, ValueError):
        return None
    link = str(item.get("hangoutLink") or "")[:500]
    return Evento(ics._texto(item.get("summary")) or "(sem título)", i, f, dia, ics._texto(item.get("location")),
                  ics._texto(item.get("description")), str(item.get("id", ""))[:200], nome, conta, link)


# --------------------------------------------------------------- Microsoft
class Microsoft:
    tipo, pode_criar = "microsoft", True
    API = "https://graph.microsoft.com/v1.0"

    def __init__(self, conta):
        self.id, self.nome = conta["id"], conta.get("nome") or "Outlook"

    def _json(self, url, metodo="GET", corpo=None):
        try:
            token = oauth.acesso("microsoft", f"agenda-{self.id}")
        except oauth.ErroDeLogin as erro:
            raise ErroDaAgenda(str(erro)) from erro
        cab = {"Authorization": f"Bearer {token}", "Prefer": 'outlook.timezone="UTC"'}
        if corpo is not None:
            cab["Content-Type"] = "application/json"
        try:
            _c, _h, dados = baixar(url, cab, tempo=20, metodo=metodo,
                                   corpo=json.dumps(corpo).encode() if corpo is not None else None)
            return json.loads(dados)
        except (SemInternet, ValueError) as erro:
            raise ErroDaAgenda(f"não consegui falar com a conta Microsoft: {erro}") from erro

    def eventos(self, de, ate):
        parametros = urllib.parse.urlencode({
            "startDateTime": _utc(de).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "endDateTime": _utc(ate).strftime("%Y-%m-%dT%H:%M:%SZ"), "$top": "200",
            "$select": "id,subject,start,end,location,isAllDay,isCancelled,isOnlineMeeting,onlineMeeting,bodyPreview"})
        url = f"{self.API}/me/calendarView?{parametros}"
        eventos = []
        for _pagina in range(5):
            dados = self._json(url)
            for item in dados.get("value") or []:
                evento = _evento_microsoft(item, self.nome, self.id)
                if evento:
                    eventos.append(evento)
            url = dados.get("@odata.nextLink")
            if not url or not str(url).startswith(self.API):
                break
        return eventos

    def criar(self, titulo, inicio, fim, local="", descricao="", dia_inteiro=False, online=False):
        def quando(d):
            return {"dateTime": _utc(d).strftime("%Y-%m-%dT%H:%M:%S"), "timeZone": "UTC"}
        corpo = {"subject": titulo, "start": quando(inicio), "end": quando(fim), "isAllDay": dia_inteiro,
                 "body": {"contentType": "text", "content": descricao}}
        if dia_inteiro:
            corpo["start"] = {"dateTime": inicio.strftime("%Y-%m-%dT00:00:00"), "timeZone": "UTC"}
            corpo["end"] = {"dateTime": fim.strftime("%Y-%m-%dT00:00:00"), "timeZone": "UTC"}
        if local:
            corpo["location"] = {"displayName": local}
        if online:
            corpo["isOnlineMeeting"] = True
            corpo["onlineMeetingProvider"] = "teamsForBusiness"
        item = self._json(f"{self.API}/me/events", "POST", corpo)
        return _evento_microsoft(item, self.nome, self.id) or Evento(titulo, inicio, fim, dia_inteiro, local,
                                                                     descricao, "", self.nome, self.id)


def _evento_microsoft(item, nome, conta):
    if not isinstance(item, dict) or item.get("isCancelled"):
        return None
    try:
        def ler(campo):
            texto = re.sub(r"\.\d+$", "", str(item[campo]["dateTime"]))
            return datetime.datetime.fromisoformat(texto).replace(tzinfo=datetime.timezone.utc)
        i, f = ler("start"), ler("end")
    except (KeyError, TypeError, ValueError):
        return None
    dia = bool(item.get("isAllDay"))
    if dia:                                   # dia inteiro vem como meia-noite UTC: é a data local
        fuso = datetime.datetime.now().astimezone().tzinfo
        i = datetime.datetime.combine(i.date(), datetime.time(), fuso)
        f = datetime.datetime.combine(f.date(), datetime.time(), fuso)
    link = str(((item.get("onlineMeeting") or {}).get("joinUrl")) or "")[:500]
    local = ics._texto((item.get("location") or {}).get("displayName"))
    return Evento(ics._texto(item.get("subject")) or "(sem título)", i, f, dia, local,
                  ics._texto(item.get("bodyPreview")), str(item.get("id", ""))[:200], nome, conta, link)


TIPOS = {"ics": LinkIcs, "caldav": CalDav, "google": Google, "microsoft": Microsoft}
