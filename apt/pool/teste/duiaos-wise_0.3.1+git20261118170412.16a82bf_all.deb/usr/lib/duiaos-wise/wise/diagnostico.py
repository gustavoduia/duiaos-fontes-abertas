"""Diagnóstico do Wise no registro do sistema (W19; ADR 040 do DuiaOS).

O Wise registra como todo programa do DuiaOS: pelo `duiaos_registro` (pacote duiaos-relatorios), no journal,
com SYSLOG_IDENTIFIER=duiaos-wise e eventos "wise.<tipo>". Quem junta, anonimiza e envia é o coletor do
sistema (duiaos-relatorios), conforme o nível de "Ajude a melhorar o DuiaOS" escolhido pela pessoa.

Conteúdo da pessoa (pedidos, respostas, comentários, argumentos de ferramentas, saída do modelo) só entra
no registro no nível "desenvolvimento" (computadores de teste). Nos outros níveis ficam só os fatos: o que
aconteceu, quanto tempo levou, qual ferramenta, qual erro.

Prioridades (o que cada nível do coletor leva):
  falhas (erro)                         3 — sempre, com o rastro
  avisos, reclamações, tarefa que falhou 4 — a partir de "erros"
  pedido, rodada, tarefa ok, medidas     6 — só em "desenvolvimento"

Sem o duiaos_registro (fora do DuiaOS, testes), nada é gravado.
"""
import subprocess
import sys

try:
    import duiaos_registro as _registro
except ImportError:                                    # fora do DuiaOS
    _registro = None

COMPONENTE = "duiaos-wise"
# Campos com o que a pessoa escreveu, leu ou o modelo respondeu
CONTEUDO = {"texto", "pedido", "resposta", "comentario", "bruto", "argumentos", "valor", "atividades", "erro_texto"}
AVISOS = {"aviso", "reclamacao", "erro_do_provedor", "provedor_indisponivel", "voz_erro"}
_ligado = False


def iniciar(versao):
    """Liga o registro (falhas não tratadas e avisos do Qt viram registro do sistema)."""
    global _ligado
    if _registro is None:
        return False
    _registro.ligar(COMPONENTE, qt=False)
    _ligado = True
    registrar("inicio", versao=versao, argumentos=sys.argv[1:])
    return True


def instalar_no_qt():
    if _registro is not None:
        _registro.instalar_no_qt()


def com_conteudo():
    """True só no nível "desenvolvimento" de "Ajude a melhorar o DuiaOS"."""
    return _registro is not None and _registro.nivel() == "desenvolvimento"


def _sem_conteudo(dados):
    resultado = {}
    for chave, valor in dados.items():
        if chave in CONTEUDO:
            if isinstance(valor, str):
                resultado[f"{chave}_tamanho"] = len(valor)
            continue
        if chave == "chamadas" and isinstance(valor, list):     # só os nomes das ferramentas
            resultado[chave] = [c.get("nome") if isinstance(c, dict) else str(c) for c in valor]
            continue
        resultado[chave] = valor
    return resultado


def _prioridade(tipo, dados):
    if tipo in AVISOS or (tipo == "tarefa" and dados.get("estado") == "falhou"):
        return 4
    return 6


def registrar(tipo, **dados):
    if not _ligado or _registro is None:
        return
    try:
        if not com_conteudo():
            dados = _sem_conteudo(dados)
        mensagem = dados.get("onde") or dados.get("estado") or tipo
        _registro.registrar(_prioridade(tipo, dados), f"wise.{tipo}", f"Wise: {tipo} — {mensagem}",
                            componente=COMPONENTE, **dados)
    except Exception:  # noqa: BLE001 — registrar nunca derruba o Wise
        pass


def erro(onde, excecao=None, rastro=None, **dados):
    """Falha com o rastro completo (dentro do `except`, sem passar a exceção)."""
    if not _ligado or _registro is None:
        return
    if excecao is None:
        excecao = sys.exc_info()[1]
    if not com_conteudo():
        dados = _sem_conteudo(dados)
    try:
        _registro.falha(onde, excecao, rastro, componente=COMPONENTE, **dados)
    except Exception:  # noqa: BLE001
        pass


def uso(evento, **dados):
    """Uso agregado de "Ajude a melhorar o DuiaOS" (lista conhecida em duiaos/relatorios/uso.py; só sai somado
    e no nível "erros e uso"). Nunca com conteúdo: só nomes de ferramenta e de provedor."""
    if not _ligado or _registro is None:
        return
    try:
        _registro.info(f"uso.{evento}", f"Wise: {evento}", componente=COMPONENTE, **dados)
    except Exception:  # noqa: BLE001
        pass


def medida(nome, segundos, **dados):
    registrar("medida", nome=nome, segundos=round(segundos, 3), **dados)


def enviar_agora():
    """Pede ao coletor do sistema a coleta e o envio já (a regra do polkit deixa a sessão ativa pedir).
    Sem "Ajude a melhorar o DuiaOS" ligado, o serviço não envia nada."""
    try:
        subprocess.Popen(["systemctl", "start", "--no-block", "duiaos-relatorios.service"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        return True
    except OSError:
        return False
