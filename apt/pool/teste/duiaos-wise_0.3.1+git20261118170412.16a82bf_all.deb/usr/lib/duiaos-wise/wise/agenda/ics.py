"""iCalendar (.ics): ler compromissos de um período (com repetições) e escrever.

Usa python3-icalendar (BSD) e python3-dateutil (BSD/Apache) do Debian. O que
vem de fora (link .ics, CalDAV) é dado: textos são cortados e datas
conferidas; um evento estragado é ignorado sem derrubar a agenda inteira.
"""
import datetime
import uuid
from dataclasses import dataclass, field

LIMITE_TEXTO = 300
LIMITE_REPETICOES = 1000      # instâncias por evento repetido (proteção)


@dataclass
class Evento:
    titulo: str
    inicio: datetime.datetime          # sempre com fuso
    fim: datetime.datetime
    dia_inteiro: bool = False
    local: str = ""
    descricao: str = ""
    uid: str = ""
    fonte: str = ""                    # nome da agenda/conta ("Agenda do computador", "Google")
    conta: str = ""                    # id da conta
    link: str = ""                     # reunião on-line (Teams, Meet), se houver
    extra: dict = field(default_factory=dict)

    def para_ferramenta(self, fuso):
        inicio, fim = self.inicio.astimezone(fuso), self.fim.astimezone(fuso)
        item = {"titulo": self.titulo, "agenda": self.fonte}
        if self.dia_inteiro:
            item["dia"] = inicio.date().isoformat()
            item["dia_inteiro"] = True
            dias = (fim.date() - inicio.date()).days
            if dias > 1:
                item["ate"] = (fim.date() - datetime.timedelta(days=1)).isoformat()
        else:
            item["inicio"] = inicio.strftime("%Y-%m-%d %H:%M")
            item["fim"] = fim.strftime("%H:%M") if fim.date() == inicio.date() else fim.strftime("%Y-%m-%d %H:%M")
        if self.local:
            item["local"] = self.local[:120]
        if self.link:
            item["reuniao_online"] = True
        return item


def _texto(valor):
    return " ".join(str(valor or "").split())[:LIMITE_TEXTO]


def _como_datahora(valor, fuso):
    """date ou datetime (com ou sem fuso) -> (datetime com fuso, é dia inteiro)."""
    if isinstance(valor, datetime.datetime):
        if valor.tzinfo is None:
            valor = valor.replace(tzinfo=fuso)        # "hora flutuante": a do computador
        return valor, False
    if isinstance(valor, datetime.date):
        return datetime.datetime.combine(valor, datetime.time(), tzinfo=fuso), True
    raise ValueError("data inválida")


def ler(conteudo, de, ate, fonte="", conta="", fuso=None):
    """Eventos de um .ics que acontecem entre de e ate (datetimes com fuso)."""
    import icalendar
    from dateutil.rrule import rruleset, rrulestr

    fuso = fuso or datetime.datetime.now().astimezone().tzinfo
    try:
        calendario = icalendar.Calendar.from_ical(conteudo)
    except (ValueError, KeyError, IndexError) as erro:
        raise ValueError("o arquivo de agenda não está no formato iCalendar") from erro
    eventos, substituidos, alterados = [], set(), []
    componentes = list(calendario.walk("VEVENT"))
    for c in componentes:                      # instâncias alteradas de eventos repetidos
        if c.get("RECURRENCE-ID") is not None:
            try:
                rid, _ = _como_datahora(c.decoded("RECURRENCE-ID"), fuso)
                substituidos.add((str(c.get("UID", "")), rid))
                alterados.append(c)
            except (ValueError, KeyError):
                continue
    for c in componentes:
        try:
            if str(c.get("STATUS", "")).upper() == "CANCELLED":
                continue
            inicio, dia_inteiro = _como_datahora(c.decoded("DTSTART"), fuso)
            if c.get("DTEND") is not None:
                fim, _ = _como_datahora(c.decoded("DTEND"), fuso)
            elif c.get("DURATION") is not None:
                fim = inicio + c.decoded("DURATION")
            else:
                fim = inicio + (datetime.timedelta(days=1) if dia_inteiro else datetime.timedelta(0))
            duracao = max(fim - inicio, datetime.timedelta(0))
            uid = str(c.get("UID", ""))[:200]
            base = Evento(_texto(c.get("SUMMARY")) or "(sem título)", inicio, fim, dia_inteiro,
                          _texto(c.get("LOCATION")), _texto(c.get("DESCRIPTION")), uid, fonte, conta,
                          _link_de_reuniao(c))
            if c.get("RRULE") is not None and c.get("RECURRENCE-ID") is None:
                conjunto = rruleset()
                conjunto.rrule(_regra(c.get("RRULE").to_ical().decode(), inicio, rrulestr))
                for exdate in _lista(c.get("EXDATE")):
                    for d in getattr(exdate, "dts", []):
                        conjunto.exdate(_como_datahora(d.dt, fuso)[0])
                for n, quando in enumerate(conjunto.between(de - duracao, ate, inc=True)):
                    if n >= LIMITE_REPETICOES:
                        break
                    if (uid, quando) in substituidos:
                        continue
                    eventos.append(Evento(base.titulo, quando, quando + duracao, dia_inteiro, base.local,
                                          base.descricao, uid, fonte, conta, base.link))
            elif fim > de and inicio < ate or (duracao == datetime.timedelta(0) and de <= inicio < ate):
                eventos.append(base)
        except (ValueError, KeyError, TypeError, OverflowError):
            continue                                       # evento estragado: ignora só ele
    return sorted(eventos, key=lambda e: e.inicio)


def _regra(texto, inicio, rrulestr):
    """RRULE -> rrule do dateutil. Com DTSTART com fuso, o dateutil exige UNTIL em
    UTC; muitas agendas mandam só a data (UNTIL=20261231): vira o fim desse dia."""
    try:
        return rrulestr(texto, dtstart=inicio)
    except ValueError:
        partes = []
        for parte in texto.split(";"):
            if parte.upper().startswith("UNTIL="):
                valor = parte.split("=", 1)[1].rstrip("Zz")
                data = valor[:8]
                parte = f"UNTIL={data}T235959Z"
            partes.append(parte)
        return rrulestr(";".join(partes), dtstart=inicio)


def _lista(valor):
    if valor is None:
        return []
    return valor if isinstance(valor, list) else [valor]


def _link_de_reuniao(c):
    for chave in ("X-MICROSOFT-SKYPETEAMSMEETINGURL", "X-GOOGLE-CONFERENCE", "URL"):
        valor = str(c.get(chave, "") or "")
        if valor.startswith("https://"):
            return valor[:500]
    descricao = str(c.get("DESCRIPTION", "") or "")
    for marca in ("https://teams.microsoft.com/", "https://meet.google.com/", "https://zoom.us/j/"):
        if marca in descricao:
            inicio = descricao.index(marca)
            return descricao[inicio:].split()[0][:500].rstrip(">")
    return ""


def novo_calendario(nome="Agenda do DuiaOS"):
    import icalendar
    calendario = icalendar.Calendar()
    calendario.add("prodid", "-//DuiaOS//Wise//PT-BR")
    calendario.add("version", "2.0")
    calendario.add("x-wr-calname", nome)
    return calendario


def componente_de_evento(titulo, inicio, fim, local="", descricao="", uid=None, dia_inteiro=False):
    import icalendar
    evento = icalendar.Event()
    evento.add("uid", uid or f"{uuid.uuid4()}@duiaos")
    evento.add("dtstamp", datetime.datetime.now(datetime.timezone.utc))
    evento.add("summary", titulo)
    if dia_inteiro:
        evento.add("dtstart", inicio.date())
        evento.add("dtend", fim.date())
    else:
        evento.add("dtstart", inicio.astimezone(datetime.timezone.utc))
        evento.add("dtend", fim.astimezone(datetime.timezone.utc))
    if local:
        evento.add("location", local)
    if descricao:
        evento.add("description", descricao)
    return evento
