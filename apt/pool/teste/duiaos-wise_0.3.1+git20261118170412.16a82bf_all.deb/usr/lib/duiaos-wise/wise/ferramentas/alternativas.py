"""Aplicativos que não existem para o DuiaOS e o que oferecer no lugar.

Reclamação de 12/10: perguntaram como instalar uma suíte de escritório que só
existe para Windows e macOS; a busca do apt trouxe um pacote sem relação pela
descrição e a resposta ficou vaga ("baixe do site oficial"). Para os nomes mais
pedidos, procurar_aplicativo agora responde direto: não existe para o DuiaOS,
por quê, a versão web (quando houver) e os equivalentes que dá para instalar.

Os nomes são conferidos sem acento e sem diferença de maiúsculas, palavra a
palavra ("Microsoft 365", "microsoft365" e "o word" acham a mesma entrada).
"""
from .base import normalizar_texto

# chave: nomes como a pessoa escreve → dados da resposta
CATALOGO = [
    {"nomes": ["microsoft 365", "microsoft365", "office 365", "office365", "microsoft office", "ms office", "office",
               "word", "excel", "powerpoint"],
     "nome": "Microsoft 365 (Word, Excel, PowerPoint)",
     "web": "office.com — Word, Excel e PowerPoint pelo navegador, com uma conta Microsoft",
     "alternativas": [("libreoffice", "LibreOffice: textos, planilhas e apresentações; abre e salva arquivos do Office")]},
    {"nomes": ["outlook"], "nome": "Outlook",
     "web": "outlook.com — e-mail e agenda pelo navegador",
     "alternativas": [("thunderbird", "Thunderbird: e-mail e agenda; funciona com contas do Outlook")]},
    {"nomes": ["teams", "microsoft teams"], "nome": "Microsoft Teams",
     "web": "teams.microsoft.com — reuniões e conversas pelo navegador", "alternativas": []},
    {"nomes": ["zoom"], "nome": "Zoom", "web": "app.zoom.us — reuniões pelo navegador", "alternativas": []},
    {"nomes": ["whatsapp", "whats app", "zap"], "nome": "WhatsApp",
     "web": "web.whatsapp.com — conecta com o celular pelo código QR", "alternativas": []},
    {"nomes": ["discord"], "nome": "Discord", "web": "discord.com/app — pelo navegador", "alternativas": []},
    {"nomes": ["spotify"], "nome": "Spotify", "web": "open.spotify.com — músicas pelo navegador", "alternativas": []},
    {"nomes": ["netflix", "disney", "disney plus", "prime video", "amazon prime", "hbo max", "globoplay"],
     "nome": "serviços de filmes e séries", "web": "o site do próprio serviço, pelo navegador", "alternativas": []},
    {"nomes": ["itunes", "apple music"], "nome": "Apple Music",
     "web": "music.apple.com — pelo navegador", "alternativas": []},
    {"nomes": ["photoshop", "adobe photoshop"], "nome": "Adobe Photoshop",
     "web": "Photoshop na web, com assinatura da Adobe",
     "alternativas": [("gimp", "GIMP: edição de fotos e imagens"), ("krita", "Krita: pintura e desenho digital")]},
    {"nomes": ["lightroom", "adobe lightroom"], "nome": "Adobe Lightroom", "web": "",
     "alternativas": [("darktable", "darktable: revelação e organização de fotos")]},
    {"nomes": ["illustrator", "adobe illustrator", "coreldraw", "corel draw", "corel"], "nome": "desenho vetorial (Illustrator, CorelDRAW)",
     "web": "", "alternativas": [("inkscape", "Inkscape: desenho vetorial, logotipos e cartazes")]},
    {"nomes": ["premiere", "adobe premiere", "after effects", "vegas", "sony vegas", "capcut"], "nome": "edição de vídeo",
     "web": "", "alternativas": [("kdenlive", "Kdenlive: edição de vídeo"), ("shotcut", "Shotcut: edição de vídeo simples")]},
    {"nomes": ["autocad", "auto cad", "sketchup"], "nome": "desenho técnico (AutoCAD, SketchUp)", "web": "",
     "alternativas": [("librecad", "LibreCAD: desenho técnico 2D"), ("freecad", "FreeCAD: modelagem 3D")]},
    {"nomes": ["acrobat", "adobe reader", "acrobat reader", "adobe acrobat"], "nome": "Adobe Acrobat Reader", "web": "",
     "alternativas": [("evince", "Visualizador de documentos: abre PDFs"), ("okular", "Okular: abre e anota PDFs")]},
    {"nomes": ["winrar", "win rar", "winzip"], "nome": "WinRAR", "web": "",
     "alternativas": [("file-roller", "Gerenciador de arquivos compactados: abre .zip, .rar e .7z")]},
    {"nomes": ["notepad", "bloco de notas", "notepad++"], "nome": "Bloco de Notas", "web": "",
     "alternativas": [("gnome-text-editor", "Editor de texto simples")]},
    {"nomes": ["google chrome", "chrome"], "nome": "Google Chrome", "web": "",
     "alternativas": [("chromium", "Chromium: a base aberta do Chrome, com sincronização de favoritos"),
                      ("firefox-esr", "Firefox: navegador")]},
    {"nomes": ["visual studio code", "vs code", "vscode"], "nome": "Visual Studio Code",
     "web": "vscode.dev — pelo navegador", "alternativas": [("geany", "Geany: editor de código leve")]},
    {"nomes": ["canva"], "nome": "Canva", "web": "canva.com — pelo navegador", "alternativas": []},
    {"nomes": ["onedrive", "one drive", "google drive", "dropbox", "icloud"], "nome": "armazenamento na nuvem",
     "web": "o site do próprio serviço, pelo navegador", "alternativas": []},
]

MOTIVO = ("não existe versão para o DuiaOS: é um programa só para Windows e macOS (ou só para celular), e o "
          "fabricante não publica para Linux")

_INDICE = sorted(((normalizar_texto(nome), entrada) for entrada in CATALOGO for nome in entrada["nomes"]),
                 key=lambda par: -len(par[0]))      # nomes mais longos primeiro ("office 365" antes de "office")


def procurar(texto):
    """Entrada do catálogo para o que a pessoa escreveu, ou None."""
    procurado = f" {normalizar_texto(texto)} "
    for nome, entrada in _INDICE:
        if f" {nome} " in procurado:
            return entrada
    return None


def resposta(entrada, existem, instalados):
    """Resultado de procurar_aplicativo para um aplicativo que não existe aqui.
    existem/instalados: conjuntos de pacotes do apt deste computador."""
    alternativas = [{"pacote": pacote, "descricao": descricao, "instalado": pacote in instalados}
                    for pacote, descricao in entrada["alternativas"] if pacote in existem]
    resultado = {"disponivel_no_duiaos": False, "aplicativo": entrada["nome"], "motivo": MOTIVO,
                 "alternativas_para_instalar": alternativas,
                 "como_responder": ("Diga em uma frase que não existe para o DuiaOS e por quê; ofereça a versão web "
                                    "(se houver) e as alternativas, em poucas linhas. Pergunte se quer instalar uma "
                                    "alternativa; não mande baixar instaladores de sites.")}
    if entrada["web"]:
        resultado["versao_web"] = entrada["web"]
    return resultado
