"""Provedor local: modelo rodando no próprio computador pelo Ollama.

O Ollama (licença MIT) roda como serviço separado em 127.0.0.1:11434; o
Wise só fala com ele pela API HTTP /api/chat. Nada sai do computador.

No DuiaOS, o modelo é o ativo da IA do sistema (um só para todos os programas,
escolhido na Central de IA; wise.ia_do_sistema). Fora dele, vale o modelo das
preferências do Wise: Qwen3.5 4B (Apache-2.0); 2B com pouca memória.
"""
import json

from .. import diagnostico
from ..ia_do_sistema import nome_amigavel
from .base import (ChamadaDeFerramenta, ErroDoProvedor, Mensagem, Provedor, ProvedorIndisponivel, Resposta,
                   get_json, post_json, post_json_em_partes)

# Abertura fixa de toda conversa com o modelo local (ADR 032 do DuiaOS).
# Modelos como o Qwen3.5 (atenção híbrida) só reaproveitam o que já leram em
# pontos de parada ("checkpoints"), criados no fim de cada pedido. O Wise
# "aquece" o modelo com instruções + ferramentas + o primeiro pedido desta
# abertura; como toda conversa começa igual, a pergunta de verdade continua
# desse ponto e o modelo só lê as palavras novas (de ~6 s para ~0,4 s no teste).
# Números do Ollama guardados no diagnóstico de cada rodada (tempos em nanossegundos);
# done_reason "length" = a resposta foi cortada no limite de pedaços.
METRICAS = ("done_reason", "load_duration", "prompt_eval_count", "prompt_eval_duration", "eval_count",
            "eval_duration", "total_duration")

ABERTURA = [Mensagem("pessoa", "Olá, Wise."), Mensagem("wise", "Olá! Estou aqui para ajudar.")]


class Local(Provedor):
    nome = "local"
    titulo = "Local"
    nuvem = False

    def __init__(self, modelo, endereco="http://127.0.0.1:11434", estado_do_sistema=None):
        self._modelo_preferido = modelo
        self._endereco_preferido = endereco.rstrip("/")
        # Função que devolve o estado da IA do sistema (ou None fora do DuiaOS)
        self._estado_do_sistema = estado_do_sistema or (lambda: None)

    @property
    def do_sistema(self):
        return self._estado_do_sistema() is not None

    @property
    def modelo(self):
        estado = self._estado_do_sistema()
        return estado.ativo if estado is not None else self._modelo_preferido

    @property
    def endereco(self):
        estado = self._estado_do_sistema()
        return (estado.endereco if estado is not None else self._endereco_preferido).rstrip("/")

    def modelos_instalados(self):
        dados = get_json(f"{self.endereco}/api/tags")
        return [m.get("name", "") for m in dados.get("models", [])]

    def disponivel(self):
        estado = self._estado_do_sistema()
        if estado is not None and not estado.ativo:
            if estado.tarefa:
                return False, (f"a IA do sistema ainda está sendo baixada "
                               f"({nome_amigavel(estado.tarefa.modelo)}, {estado.tarefa.fracao * 100:.0f}%)")
            return False, "nenhum modelo de IA ativo no sistema (escolha um na Central de IA)"
        try:
            instalados = self.modelos_instalados()
        except ErroDoProvedor:
            return False, "o motor de IA local (Ollama) não está rodando"
        base = self.modelo if ":" in self.modelo else self.modelo + ":latest"
        if self.modelo not in instalados and base not in instalados:
            return False, f"o modelo local {self.modelo} ainda não foi baixado"
        return True, ""

    @staticmethod
    def converter_ferramentas(declaracoes):
        return [{"type": "function", "function": {"name": d["nome"], "description": d["descricao"],
                                                  "parameters": d["parametros"]}} for d in declaracoes]

    @staticmethod
    def converter_conversa(instrucoes, conversa, abertura=True):
        mensagens = [{"role": "system", "content": instrucoes}]
        for m in (ABERTURA if abertura else []) + list(conversa):
            if m.papel == "pessoa":
                mensagens.append({"role": "user", "content": m.texto})
            elif m.papel == "wise":
                msg = {"role": "assistant", "content": m.texto}
                if m.chamadas:
                    msg["tool_calls"] = [{"function": {"name": c.nome, "arguments": c.argumentos}}
                                         for c in m.chamadas]
                mensagens.append(msg)
            elif m.papel == "ferramenta":
                # JSON compacto: menos pedaços de texto para o modelo ler
                mensagens.append({"role": "tool", "tool_name": m.ferramenta,
                                  "content": json.dumps(m.resultado, ensure_ascii=False, separators=(",", ":"))})
        return mensagens

    def _corpo(self, instrucoes, conversa, ferramentas):
        corpo = {
            "model": self.modelo,
            "messages": self.converter_conversa(instrucoes, conversa),
            "think": False,            # sem "raciocínio" longo: no processador, respostas rápidas valem mais
            # Limite de segurança: no processador cada pedaço escrito leva ~0,1–0,2 s
            "options": {"temperature": 0.3, "num_predict": 600},
        }
        estado = self._estado_do_sistema()
        if estado is not None:
            # No DuiaOS o contexto é o mesmo para todos (ollama.service); o tempo na
            # memória e as opções medidas para este computador (threads, placa de
            # vídeo) vêm da IA do sistema: outros valores recarregariam o modelo
            corpo["keep_alive"] = estado.manter
            corpo["options"].update(estado.opcoes)
        else:
            corpo["options"]["num_ctx"] = 8192
            corpo["keep_alive"] = "10m"
        if ferramentas:
            corpo["tools"] = self.converter_ferramentas(ferramentas)
        return corpo

    def aquecer(self, instrucoes, ferramentas, cancelado=None):
        """Deixa o modelo com as instruções, as ferramentas e a abertura já lidas,
        para a próxima pergunta só ler as palavras novas. Devolve os segundos gastos,
        ou None se foi cancelado (uma pergunta chegou: ela vai na frente)."""
        corpo = self._corpo(instrucoes, ABERTURA[:1], ferramentas)
        corpo["messages"] = self.converter_conversa(instrucoes, ABERTURA[:1], abertura=False)
        corpo["stream"] = True         # em partes: dá para desistir no meio
        corpo["options"]["num_predict"] = 1
        partes = post_json_em_partes(f"{self.endereco}/api/chat", corpo, tempo=900, cancelado=cancelado)
        try:
            for dados in partes:
                if cancelado is not None and cancelado.is_set():
                    return None        # fechar a conexão faz o Ollama parar
                if dados.get("done"):
                    return (dados.get("total_duration") or 0) / 1e9
        finally:
            partes.close()
        return None if cancelado is not None and cancelado.is_set() else 0.0

    def responder(self, instrucoes, conversa, ferramentas, cancelado=None, ao_parcial=None):
        pronto, motivo = self.disponivel()
        if not pronto:
            raise ProvedorIndisponivel(motivo)
        corpo = self._corpo(instrucoes, conversa, ferramentas)
        corpo["stream"] = True         # o texto aparece enquanto é escrito
        texto, chamadas, metricas = [], [], {}
        partes = post_json_em_partes(f"{self.endereco}/api/chat", corpo, tempo=300, cancelado=cancelado)
        try:
            for dados in partes:
                if cancelado is not None and cancelado.is_set():
                    break              # fechar a conexão faz o Ollama parar de escrever
                if dados.get("error"):
                    raise ErroDoProvedor(str(dados["error"])[:300])
                mensagem = dados.get("message") or {}
                if mensagem.get("content"):
                    texto.append(mensagem["content"])
                    if ao_parcial is not None:
                        ao_parcial("".join(texto))
                for chamada in mensagem.get("tool_calls") or []:
                    funcao = chamada.get("function") or {}
                    argumentos = funcao.get("arguments") or {}
                    if isinstance(argumentos, str):
                        try:
                            argumentos = json.loads(argumentos)
                        except json.JSONDecodeError:
                            diagnostico.registrar("aviso", onde="argumentos da ferramenta ilegíveis",
                                                  ferramenta=funcao.get("name", ""), bruto=argumentos)
                            argumentos = {}
                    chamadas.append(ChamadaDeFerramenta(funcao.get("name", ""), argumentos))
                if dados.get("done"):
                    metricas = {chave: dados[chave] for chave in METRICAS if chave in dados}
                    break
        finally:
            partes.close()
        return Resposta(texto="".join(texto).strip(), chamadas=chamadas, metricas=metricas)
