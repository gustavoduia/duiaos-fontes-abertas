"""Acesso à internet das ferramentas do Wise (clima, agenda por link).

- Só HTTPS, com o certificado conferido pelo sistema.
- Identifica o Wise (os serviços públicos pedem isso), sem dados da pessoa.
- Tempo limite curto e tamanho máximo da resposta: um serviço lento ou
  enorme não trava nem enche a memória do Wise.
- O que chega é dado, nunca instrução: quem chama confere os campos.
"""
import json
import urllib.error
import urllib.parse
import urllib.request

from . import VERSAO

AGENTE = f"DuiaOS-Wise/{VERSAO} (+https://github.com/gustavoduia/duiaos-fontes-abertas)"
LIMITE_BYTES = 4 * 1024 * 1024


class SemInternet(Exception):
    """Não deu para falar com o serviço; a mensagem é para a pessoa."""


def baixar(url, cabecalhos=None, tempo=10, limite=LIMITE_BYTES, metodo="GET", corpo=None):
    """Devolve (código HTTP, cabeçalhos, bytes). 304 é devolvido sem erro."""
    if urllib.parse.urlsplit(url).scheme != "https":
        raise SemInternet("só endereços https são aceitos")
    pedido = urllib.request.Request(url, data=corpo, method=metodo,
                                    headers={"User-Agent": AGENTE, "Accept-Encoding": "identity",
                                             **(cabecalhos or {})})
    try:
        with urllib.request.urlopen(pedido, timeout=tempo) as resposta:
            dados = resposta.read(limite + 1)
            if len(dados) > limite:
                raise SemInternet("a resposta do serviço é grande demais")
            return resposta.status, dict(resposta.headers), dados
    except urllib.error.HTTPError as erro:
        if erro.code == 304:
            return 304, dict(erro.headers), b""
        raise SemInternet(f"o serviço respondeu com erro {erro.code}") from erro
    except (urllib.error.URLError, TimeoutError, OSError) as erro:
        raise SemInternet("sem conexão com a internet (ou o serviço não respondeu)") from erro


def baixar_json(url, cabecalhos=None, tempo=10):
    _codigo, _cab, dados = baixar(url, cabecalhos, tempo)
    try:
        return json.loads(dados)
    except ValueError as erro:
        raise SemInternet("o serviço mandou uma resposta que não entendi") from erro
