"""Base das ferramentas do Wise: declaração, validação de argumentos e registro."""
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Callable

NIVEIS = ("N0", "N1", "N2", "N3", "N4")
TIPOS_JSON = {"string": str, "integer": int, "number": (int, float), "boolean": bool,
              "object": dict, "array": list}


class ErroDeArgumentos(ValueError):
    pass


def normalizar_texto(texto):
    """Minúsculas, sem acentos e só letras e números separados por um espaço."""
    decomposto = unicodedata.normalize("NFD", str(texto))
    sem_acento = "".join(c for c in decomposto if not unicodedata.combining(c)).casefold()
    return " ".join(re.sub(r"[^0-9a-z]+", " ", sem_acento).split())


def chave_de_argumento(nome):
    """'início', 'Inicio' e 'inicio' são o mesmo argumento (o modelo às vezes acentua)."""
    return normalizar_texto(nome).replace(" ", "_")


@dataclass
class Plano:
    """O que uma ferramenta N2 vai fazer, mostrado à pessoa antes de aprovar."""
    resumo: str                                    # uma frase: "Instalar vlc (3.0.21-1)"
    detalhes: list = field(default_factory=list)   # linhas curtas: tamanho, pacotes, destinatário…
    recusa: str = ""                               # não dá para fazer: explica por quê (sem pedir aprovação)
    dados: dict = field(default_factory=dict)      # para executar() (ex.: id do plano no duiaos-agente)
    # False: a ação foi avaliada como sem risco (ex.: clicar em "Abrir" na tela) e
    # roda sem perguntar — fica registrada do mesmo jeito. Quem decide é preparar().
    aprovacao: bool = True


@dataclass
class Ferramenta:
    nome: str                     # identificador usado pelo modelo (snake_case)
    titulo: str                   # como aparece para a pessoa ("Uso do computador")
    descricao: str                # para o modelo: quando usar
    executar: Callable[..., dict]
    parametros: dict = field(default_factory=lambda: {"type": "object", "properties": {}})
    nivel: str = "N0"
    # N2: preparar(**argumentos) -> Plano, sem mudar nada. Depois da aprovação,
    # executar(plano, ao_progresso, cancelado) faz a ação e devolve o resultado.
    preparar: Callable[..., Plano] = None
    # Argumentos que só valem se a pessoa disse aquilo na conversa (ex.: a cidade):
    # o orquestrador recusa o que o modelo inventou.
    da_pessoa: tuple = ()
    # conferir(argumentos, ultimo_pedido) -> motivo ou None: recusa uma ação que não é a
    # que a pessoa pediu (ex.: desligar o computador quando ela pediu para desligar o Wi-Fi)
    conferir: Callable[[dict, str], str] = None

    def __post_init__(self):
        if self.nivel not in NIVEIS:
            raise ValueError(f"nível inválido: {self.nivel}")
        if self.nivel == "N2" and self.preparar is None:
            raise ValueError(f"{self.nome}: ferramenta N2 precisa de preparar()")
        self.parametros.setdefault("type", "object")
        self.parametros.setdefault("properties", {})

    def validar(self, argumentos):
        """Confere tipos, obrigatórios e valores permitidos; devolve só os campos declarados."""
        if argumentos is None:
            argumentos = {}
        if not isinstance(argumentos, dict):
            raise ErroDeArgumentos("os argumentos devem ser um objeto")
        propriedades = self.parametros.get("properties", {})
        nomes = {chave_de_argumento(nome): nome for nome in propriedades}
        argumentos = {nomes.get(chave_de_argumento(nome), nome): valor for nome, valor in argumentos.items()}
        for obrigatorio in self.parametros.get("required", []):
            if obrigatorio not in argumentos:
                raise ErroDeArgumentos(f"falta o argumento '{obrigatorio}'")
        limpos = {}
        for nome, valor in argumentos.items():
            if nome not in propriedades:
                continue   # ignora argumentos não declarados
            esquema = propriedades[nome]
            tipo = TIPOS_JSON.get(esquema.get("type"))
            if tipo and (not isinstance(valor, tipo) or (tipo is int and isinstance(valor, bool))):
                # Modelos às vezes mandam números como texto: converte com cuidado
                if esquema.get("type") == "integer" and isinstance(valor, (str, float)):
                    try:
                        valor = int(valor)
                    except ValueError as erro:
                        raise ErroDeArgumentos(f"'{nome}' deve ser um número inteiro") from erro
                else:
                    raise ErroDeArgumentos(f"'{nome}' deve ser do tipo {esquema.get('type')}")
            if "enum" in esquema and valor not in esquema["enum"]:
                raise ErroDeArgumentos(f"'{nome}' deve ser um de: {', '.join(map(str, esquema['enum']))}")
            if "minimum" in esquema and valor < esquema["minimum"]:
                raise ErroDeArgumentos(f"'{nome}' deve ser no mínimo {esquema['minimum']}")
            if "maximum" in esquema and valor > esquema["maximum"]:
                raise ErroDeArgumentos(f"'{nome}' deve ser no máximo {esquema['maximum']}")
            limpos[nome] = valor
        return limpos

    def declaracao(self):
        """Formato neutro, convertido por cada provedor (Gemini, Ollama)."""
        return {"nome": self.nome, "descricao": self.descricao, "parametros": self.parametros}


class Registro:
    def __init__(self):
        self._ferramentas = {}

    def adicionar(self, ferramenta):
        if ferramenta.nome in self._ferramentas:
            raise ValueError(f"ferramenta repetida: {ferramenta.nome}")
        self._ferramentas[ferramenta.nome] = ferramenta

    def obter(self, nome):
        return self._ferramentas.get(nome)

    def todas(self):
        return list(self._ferramentas.values())

    def declaracoes(self):
        return [f.declaracao() for f in self._ferramentas.values()]
