"""Wise — o assistente do DuiaOS.

Software proprietário, todos os direitos reservados.

O Wise não é um chat solto: ele transforma pedidos em tarefas, executadas por
ferramentas declaradas (wise.ferramentas), com nível de risco, registro em
auditoria (wise.auditoria) e cancelamento. O modelo de IA (wise.modelos)
interpreta e planeja; quem autoriza e executa é código determinístico.
"""

VERSAO = "0.3.0"
