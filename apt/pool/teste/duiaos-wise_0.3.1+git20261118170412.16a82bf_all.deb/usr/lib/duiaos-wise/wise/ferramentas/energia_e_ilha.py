"""Energia do computador e aplicativos fixados na Ilha (pedidos do log de 12/10).

energia (N2): bloquear, suspender, reiniciar, desligar ou reiniciar no Windows,
com os mesmos comandos do Menu de Energia do DuiaOS. Reiniciar, desligar e ir
para o Windows fecham os aplicativos: sempre com aprovação. Bloquear e
suspender não perdem nada: rodam sem perguntar (ficam registrados).

fixar_na_ilha / desafixar_da_ilha (N1): mudam só a preferência da pessoa em
~/.config/duiaos/ilha-de-aplicativos.conf (formato do DuiaOS: [ilha] fixados =
a.desktop;b.desktop). A Ilha vigia o arquivo e se atualiza sozinha.
"""
import configparser
import os
import subprocess
from pathlib import Path

from ..computador import aplicativos
from .base import ErroDeArgumentos, Ferramenta, Plano, normalizar_texto

BLOQUEAR = Path("/usr/share/duiaos/shell/bloqueio/bloquear")
SERVICO_WINDOWS = "duiaos-reiniciar-no-windows.service"
PASTAS_SERVICOS = (Path("/usr/lib/systemd/system"), Path("/etc/systemd/system"))
ESPERA = 3      # segundos antes de reiniciar/desligar: a resposta do Wise aparece antes

ACOES = {
    "bloquear": {"resumo": "Bloquear a tela", "aprovacao": False, "comando": [str(BLOQUEAR)]},
    "suspender": {"resumo": "Suspender o computador", "aprovacao": False, "comando": ["systemctl", "suspend"]},
    "reiniciar": {"resumo": "Reiniciar o computador", "aprovacao": True, "comando": ["systemctl", "reboot"]},
    "desligar": {"resumo": "Desligar o computador", "aprovacao": True, "comando": ["systemctl", "poweroff"]},
    "reiniciar_no_windows": {"resumo": "Reiniciar no Windows", "aprovacao": True,
                             "comando": ["systemctl", "start", "--no-block", SERVICO_WINDOWS]},
}
AVISO_FECHA = "Os aplicativos abertos serão fechados: salve o que estiver aberto antes."


def _tem_windows():
    return any((pasta / SERVICO_WINDOWS).exists() for pasta in PASTAS_SERVICOS)


def preparar_energia(acao):
    if acao not in ACOES:
        raise ErroDeArgumentos(f"'acao' deve ser um de: {', '.join(ACOES)}")
    dados = ACOES[acao]
    if acao == "reiniciar_no_windows" and not _tem_windows():
        return Plano(dados["resumo"], recusa="este computador não tem o Windows instalado ao lado do DuiaOS")
    if acao == "bloquear" and not BLOQUEAR.exists():
        return Plano(dados["resumo"], recusa="a Tela de Bloqueio do DuiaOS não está instalada aqui")
    detalhes = [AVISO_FECHA] if dados["aprovacao"] else []
    if acao == "reiniciar_no_windows":
        detalhes.append("O Windows abre uma vez; na próxima vez o computador volta ao DuiaOS.")
    return Plano(dados["resumo"], detalhes, dados={"acao": acao}, aprovacao=dados["aprovacao"])


# Pedido sobre outra coisa que "desliga": não é o computador
OUTROS_APARELHOS = ("wifi", "wi fi", "wireless", "bluetooth", "internet", "rede", "som", "volume", "tela",
                    "monitor", "brilho", "notificacao", "notificacoes", "aplicativo", "programa", "janela")
COMPUTADOR = ("computador", "pc", "notebook", "maquina", "sistema", "tudo")


def conferir_energia(argumentos, pedido):
    """Desligar/reiniciar só quando o pedido é sobre o computador, não sobre o Wi-Fi, a tela etc."""
    if argumentos.get("acao") not in ("desligar", "reiniciar", "reiniciar_no_windows", "suspender"):
        return None
    palavras = f" {normalizar_texto(pedido)} "
    sobre_outro = [p for p in OUTROS_APARELHOS if f" {p} " in palavras]
    if sobre_outro and not any(f" {p} " in palavras for p in COMPUTADOR):
        return (f"a pessoa pediu sobre '{sobre_outro[0]}', não sobre o computador inteiro. Use a ferramenta "
                "certa para isso (Wi-Fi e Bluetooth: ligar_desligar); se não houver, diga que ainda não consegue.")
    return None


def executar_energia(plano, ao_progresso, cancelado):
    acao = plano.dados["acao"]
    comando = ACOES[acao]["comando"]
    if ACOES[acao]["aprovacao"]:
        # Espera alguns segundos: o "Fiz" e a resposta aparecem antes de a sessão fechar
        comando = ["sh", "-c", f"sleep {ESPERA}; exec \"$0\" \"$@\"", *comando]
    try:
        subprocess.Popen(comando, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError as erro:
        return {"erro": f"não consegui: {erro}"}
    return {"feito": True, "mensagem": f"{ACOES[acao]['resumo']}: feito."
            + (f" Em {ESPERA} segundos." if ACOES[acao]["aprovacao"] else "")}


# ------------------------------------------------------------------- Ilha
ARQUIVO_ILHA = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "duiaos" / "ilha-de-aplicativos.conf"
FIXADOS_PADRAO = ["foot.desktop"]          # o mesmo padrão da Ilha (duiaos/shell/ilha-de-aplicativos)


def ler_fixados(arquivo=None):
    config = configparser.ConfigParser()
    config.read(arquivo or ARQUIVO_ILHA)
    texto = config.get("ilha", "fixados", fallback=";".join(FIXADOS_PADRAO))
    return [item.strip() for item in texto.split(";") if item.strip()]


def gravar_fixados(fixados, arquivo=None):
    arquivo = Path(arquivo or ARQUIVO_ILHA)
    arquivo.parent.mkdir(parents=True, exist_ok=True)
    temporario = arquivo.with_suffix(".tmp")
    temporario.write_text("# DuiaOS — Ilha de Aplicativos.\n"
                          "# fixados: arquivos .desktop separados por ponto e vírgula (;)\n"
                          "[ilha]\nfixados = " + ";".join(fixados) + "\n", encoding="utf-8")
    temporario.replace(arquivo)


def _achar(nome):
    achados = aplicativos.procurar(nome)
    if not achados:
        return None, {"erro": f"não achei um aplicativo com janela chamado '{nome}' na Central de Aplicativos",
                      "dica": "programas de terminal não aparecem na Central nem na Ilha; use procurar_aplicativo "
                              "para ver se dá para instalar um com janela"}
    return achados[0], None


def fixar_na_ilha(aplicativo):
    app, erro = _achar(aplicativo)
    if erro:
        return erro
    fixados = ler_fixados()
    if app["id"] in fixados:
        return {"ja_estava": f"{app['nome']} já está fixado na Ilha"}
    gravar_fixados(fixados + [app["id"]])
    return {"fixado": app["nome"], "onde": "Ilha de Aplicativos (barra de baixo)"}


def desafixar_da_ilha(aplicativo):
    app, erro = _achar(aplicativo)
    if erro:
        return erro
    fixados = ler_fixados()
    if app["id"] not in fixados:
        return {"nao_estava": f"{app['nome']} não está fixado na Ilha"}
    gravar_fixados([f for f in fixados if f != app["id"]])
    return {"desafixado": app["nome"]}


FERRAMENTAS = [
    Ferramenta("energia", "Energia do computador",
               "Bloqueia a tela, suspende, reinicia, desliga ou reinicia no Windows o computador inteiro (não "
               "serve para Wi-Fi). Reiniciar, desligar e Windows pedem aprovação da pessoa (o sistema mostra o "
               "cartão).",
               executar_energia,
               {"type": "object", "properties": {"acao": {"type": "string", "enum": list(ACOES)}},
                "required": ["acao"]},
               nivel="N2", preparar=preparar_energia, conferir=conferir_energia),
    Ferramenta("fixar_na_ilha", "Fixar na Ilha",
               "Fixa um aplicativo instalado na Ilha de Aplicativos (a barra de baixo), para abrir com um "
               "clique. Todo aplicativo com janela já aparece sozinho na Central de Aplicativos.",
               fixar_na_ilha,
               {"type": "object", "properties": {"aplicativo": {"type": "string", "description": "Nome do aplicativo."}},
                "required": ["aplicativo"]},
               nivel="N1"),
    Ferramenta("desafixar_da_ilha", "Tirar da Ilha",
               "Tira um aplicativo da Ilha de Aplicativos (ele continua instalado).",
               desafixar_da_ilha,
               {"type": "object", "properties": {"aplicativo": {"type": "string", "description": "Nome do aplicativo."}},
                "required": ["aplicativo"]},
               nivel="N1"),
]
