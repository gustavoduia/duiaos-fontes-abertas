"""Tipos comuns do gateway de modelos.

Cada provedor (Gemini, local) converte esta conversa neutra para o próprio
formato. O orquestrador só conhece estes tipos.
"""
import json
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass, field


class ErroDoProvedor(Exception):
    """Falha ao falar com o provedor (rede, chave, limite, resposta inválida)."""


class ProvedorIndisponivel(ErroDoProvedor):
    """O provedor não pode ser usado agora (sem chave, sem consentimento, serviço fora)."""


@dataclass
class ChamadaDeFerramenta:
    nome: str
    argumentos: dict
    id: str = ""


@dataclass
class Mensagem:
    papel: str                       # "pessoa", "wise" ou "ferramenta"
    texto: str = ""
    chamadas: list = field(default_factory=list)   # [ChamadaDeFerramenta] (papel "wise")
    ferramenta: str = ""             # nome da ferramenta (papel "ferramenta")
    resultado: dict = None           # resultado da ferramenta (papel "ferramenta")
    bruto: dict = None               # formato original do provedor (ex.: assinaturas do Gemini)


@dataclass
class Resposta:
    texto: str = ""
    chamadas: list = field(default_factory=list)
    bruto: dict = None               # mensagem original, devolvida no histórico ao mesmo provedor
    metricas: dict = None            # números do provedor (pedaços lidos/escritos, tempos), para o diagnóstico


class Provedor:
    nome = "provedor"
    titulo = "Provedor"
    nuvem = False

    def disponivel(self):
        """(bool, motivo) — se pode ser usado agora."""
        raise NotImplementedError

    def responder(self, instrucoes, conversa, ferramentas, cancelado=None, ao_parcial=None):
        """Recebe a conversa neutra e devolve uma Resposta. ao_parcial(texto), se o
        provedor souber, recebe o texto da resposta enquanto ele é escrito."""
        raise NotImplementedError


def post_json(url, corpo, cabecalhos=None, tempo=120):
    dados = json.dumps(corpo).encode("utf-8")
    pedido = urllib.request.Request(url, data=dados, method="POST",
                                    headers={"Content-Type": "application/json", **(cabecalhos or {})})
    try:
        with urllib.request.urlopen(pedido, timeout=tempo) as resposta:
            return json.loads(resposta.read().decode("utf-8"))
    except urllib.error.HTTPError as erro:
        detalhe = erro.read().decode("utf-8", "replace")[:500]
        raise ErroDoProvedor(f"HTTP {erro.code}: {detalhe}") from erro
    except (urllib.error.URLError, TimeoutError, OSError) as erro:
        raise ErroDoProvedor(f"sem conexão: {erro}") from erro
    except json.JSONDecodeError as erro:
        raise ErroDoProvedor("resposta inválida do provedor") from erro


def get_json(url, tempo=3):
    try:
        with urllib.request.urlopen(url, timeout=tempo) as resposta:
            return json.loads(resposta.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as erro:
        raise ErroDoProvedor(str(erro)) from erro


def post_json_em_partes(url, corpo, tempo=300, cancelado=None):
    """POST que devolve a resposta aos pedaços (uma linha JSON por pedaço, como o
    Ollama faz com "stream": true). Fechar o gerador ou marcar `cancelado` corta a
    conexão na hora — inclusive enquanto o Ollama ainda lê o pedido e não mandou
    nada — e o Ollama para o trabalho. Cancelado, o gerador só termina, sem erro."""
    import http.client
    import socket
    import urllib.parse

    endereco = urllib.parse.urlsplit(url)
    classe = http.client.HTTPSConnection if endereco.scheme == "https" else http.client.HTTPConnection
    conexao = classe(endereco.hostname, endereco.port, timeout=tempo)
    terminou = threading.Event()

    def vigiar():
        while not terminou.is_set():
            if cancelado.wait(0.2):
                try:
                    if conexao.sock is not None:
                        conexao.sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                return

    if cancelado is not None:
        threading.Thread(target=vigiar, daemon=True).start()
    try:
        caminho = endereco.path + (f"?{endereco.query}" if endereco.query else "")
        conexao.request("POST", caminho, body=json.dumps(corpo).encode("utf-8"),
                        headers={"Content-Type": "application/json"})
        resposta = conexao.getresponse()
        if resposta.status >= 400:
            detalhe = resposta.read().decode("utf-8", "replace")[:500]
            raise ErroDoProvedor(f"HTTP {resposta.status}: {detalhe}")
        for linha in resposta:
            linha = linha.strip()
            if not linha:
                continue
            try:
                yield json.loads(linha.decode("utf-8"))
            except json.JSONDecodeError as erro:
                raise ErroDoProvedor("resposta inválida do provedor") from erro
    except (TimeoutError, OSError, http.client.HTTPException, ValueError) as erro:
        if cancelado is not None and cancelado.is_set():
            return                     # nós mesmos cortamos
        raise ErroDoProvedor(f"sem conexão: {erro}") from erro
    finally:
        terminou.set()
        conexao.close()
