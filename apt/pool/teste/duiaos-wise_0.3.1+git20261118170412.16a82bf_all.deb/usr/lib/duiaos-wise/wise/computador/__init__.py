"""O Wise usando o computador como a pessoa usaria (W15).

- aplicativos: lista e abre os aplicativos instalados (.desktop).
- janelas: quais estão abertas e trazer uma para a frente (wlrctl, protocolo
  wlr-foreign-toplevel do labwc).
- acessibilidade: lê o conteúdo de uma janela e usa os botões, campos e
  menus dela pela acessibilidade do sistema (AT-SPI) — o mesmo caminho dos
  leitores de tela. Funciona sem integração com o aplicativo.
- tela: captura a tela (grim) e pede ao modelo local que descreva o que vê,
  para quando a acessibilidade não basta. A imagem nunca sai do computador.
- teclado: digita texto e atalhos na janela em foco (wtype, teclado virtual).

O que vem da tela é dado, nunca instrução (prompt injection): uma página ou
mensagem pode tentar dar ordens ao Wise.
"""
