"""Botão flutuante do Wise (a "bolha"), no canto inferior direito da tela.

Roda num processo próprio, filho da janela do Wise: a bolha é um painel
layer-shell e a janela é uma janela comum, e no Qt essa escolha vale para o
processo inteiro.

- Recebe do processo principal, por socket local, mensagens JSON (uma por
  linha): {"estado": "aberto"|"descansando"|"pensando"},
  {"saudacao": "texto"}, {"resposta": "resumo"} (resposta pronta com a janela
  fechada), {"fechar": true} e {"progresso": {"titulo", "detalhe", "fracao", "nota"} ou null}.
- Um clique na carinha manda "alternar" ao processo principal (abre/fecha);
  um clique no balão manda "mostrar" (abre na conversa).
"""
import json
import os
import sys
from pathlib import Path

from PySide6.QtCore import QObject, Property, Signal, Slot
from PySide6.QtGui import QGuiApplication
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtQml import QQmlApplicationEngine

PASTA = Path(__file__).resolve().parent
NOME_SOCKET_BOLHA = f"duiaos-wise-bolha-{os.getuid()}"
NOME_SOCKET_WISE = f"duiaos-wise-{os.getuid()}"


class Bolha(QObject):
    mudou = Signal()
    saudar = Signal(str)
    responder = Signal(str)
    fecharBalao = Signal()
    progressoMudou = Signal()

    def __init__(self):
        super().__init__()
        self._estado = "descansando"
        self._progresso = None
        self._conexoes = []
        self._servidor = QLocalServer(self)
        QLocalServer.removeServer(NOME_SOCKET_BOLHA)
        self._servidor.listen(NOME_SOCKET_BOLHA)
        self._servidor.newConnection.connect(self._nova_conexao)

    def _nova_conexao(self):
        conexao = self._servidor.nextPendingConnection()
        self._conexoes.append(conexao)
        conexao.readyRead.connect(lambda: self._ler(conexao))

    def _ler(self, conexao):
        while conexao.canReadLine():
            linha = bytes(conexao.readLine()).decode("utf-8", "ignore").strip()
            try:
                mensagem = json.loads(linha)
            except json.JSONDecodeError:
                continue
            if mensagem.get("estado") in ("aberto", "descansando", "pensando", "falando", "ouvindo"):
                self._estado = mensagem["estado"]
                self.mudou.emit()
            if isinstance(mensagem.get("saudacao"), str) and mensagem["saudacao"]:
                self.saudar.emit(mensagem["saudacao"][:400])
            if isinstance(mensagem.get("resposta"), str) and mensagem["resposta"]:
                self.responder.emit(mensagem["resposta"][:400])
            if mensagem.get("fechar") is True:
                self.fecharBalao.emit()
            if "progresso" in mensagem:
                self._progresso = _progresso_valido(mensagem["progresso"])
                self.progressoMudou.emit()

    @Slot()
    def clicar(self):
        _pedir_ao_wise(b"alternar")

    @Slot()
    def abrir(self):
        _pedir_ao_wise(b"mostrar")

    estado = Property(str, lambda self: self._estado, notify=mudou)
    progresso = Property("QVariant", lambda self: self._progresso, notify=progressoMudou)


def _pedir_ao_wise(comando):
    socket = QLocalSocket()
    socket.connectToServer(NOME_SOCKET_WISE)
    if socket.waitForConnected(500):
        socket.write(comando)
        socket.flush()
        socket.waitForBytesWritten(500)
        socket.disconnectFromServer()


def _progresso_valido(dados):
    """Só os campos esperados, com os tipos certos (ou None)."""
    if not isinstance(dados, dict):
        return None
    fracao = dados.get("fracao")
    fracao = float(fracao) if isinstance(fracao, (int, float)) and not isinstance(fracao, bool) else 0.0
    return {"titulo": str(dados.get("titulo", ""))[:120], "detalhe": str(dados.get("detalhe", ""))[:160],
            "nota": str(dados.get("nota", ""))[:200], "fracao": min(max(fracao, 0.0), 1.0)}


def main():
    # Só este processo é painel layer-shell (a janela do Wise é comum).
    os.environ.setdefault("QT_QPA_PLATFORM", "wayland")
    if "--demonstracao" not in sys.argv:
        os.environ["QT_WAYLAND_SHELL_INTEGRATION"] = "layer-shell"
    app = QGuiApplication(sys.argv)
    app.setApplicationName("duiaos-wise-bolha")
    bolha = Bolha()
    engine = QQmlApplicationEngine()
    engine.rootContext().setContextProperty("bolha", bolha)
    engine.load(PASTA / ("BolhaDemonstracao.qml" if "--demonstracao" in sys.argv else "Bolha.qml"))
    if not engine.rootObjects():
        return 1
    codigo = app.exec()
    del engine
    return codigo


if __name__ == "__main__":
    sys.exit(main())
