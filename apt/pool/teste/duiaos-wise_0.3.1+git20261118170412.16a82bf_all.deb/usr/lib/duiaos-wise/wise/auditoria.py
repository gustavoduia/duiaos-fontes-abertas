"""Registro de auditoria do Wise (SQLite local).

Tudo o que o Wise faz fica registrado: pedido, provedor usado, cada
ferramenta (argumentos e resumo do resultado), resposta, erros e
cancelamentos. Nunca registra segredos.
"""
import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path

from .configuracao import PASTA_DADOS

ARQUIVO = PASTA_DADOS / "auditoria.sqlite"
LIMITE_TEXTO = 4000

ESQUEMA = """
CREATE TABLE IF NOT EXISTS eventos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quando REAL NOT NULL,
    tarefa TEXT NOT NULL,
    tipo TEXT NOT NULL,
    detalhe TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS eventos_tarefa ON eventos (tarefa);
"""


def _cortar(valor):
    texto = json.dumps(valor, ensure_ascii=False, default=str)
    return texto if len(texto) <= LIMITE_TEXTO else texto[:LIMITE_TEXTO] + "…"


class Auditoria:
    def __init__(self, arquivo=ARQUIVO):
        self._arquivo = Path(arquivo)
        self._arquivo.parent.mkdir(parents=True, exist_ok=True)
        self._trava = threading.Lock()
        with self._conectar() as conexao:
            conexao.executescript(ESQUEMA)

    def _conectar(self):
        return sqlite3.connect(self._arquivo)

    @staticmethod
    def nova_tarefa():
        return uuid.uuid4().hex[:12]

    def registrar(self, tarefa, tipo, **detalhe):
        with self._trava, self._conectar() as conexao:
            conexao.execute(
                "INSERT INTO eventos (quando, tarefa, tipo, detalhe) VALUES (?, ?, ?, ?)",
                (time.time(), tarefa, tipo, _cortar(detalhe)),
            )

    def eventos(self, tarefa=None, limite=200):
        with self._conectar() as conexao:
            if tarefa:
                linhas = conexao.execute(
                    "SELECT quando, tarefa, tipo, detalhe FROM eventos WHERE tarefa = ? ORDER BY id",
                    (tarefa,)).fetchall()
            else:
                linhas = conexao.execute(
                    "SELECT quando, tarefa, tipo, detalhe FROM eventos ORDER BY id DESC LIMIT ?",
                    (limite,)).fetchall()
        return [{"quando": q, "tarefa": t, "tipo": ti, "detalhe": json.loads(d)} for q, t, ti, d in linhas]

    def desde(self, quando, limite=5000):
        """Eventos registrados depois de `quando` (epoch), em ordem (para o diagnóstico)."""
        if not self._arquivo.exists():
            return []
        with self._conectar() as conexao:
            linhas = conexao.execute(
                "SELECT quando, tarefa, tipo, detalhe FROM eventos WHERE quando > ? ORDER BY id LIMIT ?",
                (quando, limite)).fetchall()
        return [{"quando": q, "tarefa": t, "tipo": ti, "detalhe": json.loads(d)} for q, t, ti, d in linhas]
