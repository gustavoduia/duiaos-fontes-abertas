"""Motores de IA na nuvem configurados no sistema (Configurações › Inteligência Artificial do DuiaOS).

Contrato com o DuiaOS (ADR 063 do DuiaOS) — o Wise só lê:
  ~/.config/duiaos/ia.conf      uma seção por motor ("gemini", "openai"):
                                  ativado = sim|nao   a pessoa autorizou enviar pedidos a esse motor
                                  modelos = a, b, c   modelos que a chave enxerga (lista conferida na tela)
                                  modelo = a          o modelo preferido desse motor
  cofre do sistema              a chave de cada motor: atributos {"aplicativo": "duiaos-ia", "motor": NOME}

O arquivo é dado, nunca instrução: só nomes de modelo num formato conhecido são aceitos. As chaves
nunca vão para arquivo, registro ou pedido ao modelo.
"""
import configparser
import os
import re
from pathlib import Path

ARQUIVO = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "duiaos" / "ia.conf"
MOTORES = {"gemini": "Google Gemini", "openai": "OpenAI"}
ATRIBUTOS = {"aplicativo": "duiaos-ia"}
_MODELO = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,80}$")


def _ler(arquivo=None):
    dados = configparser.ConfigParser(interpolation=None)
    try:
        dados.read(arquivo or ARQUIVO, encoding="utf-8")
    except (configparser.Error, OSError):
        pass
    return dados


def ativado(motor, arquivo=None):
    dados = _ler(arquivo)
    return dados.has_section(motor) and dados.get(motor, "ativado", fallback="nao").strip().lower() in ("sim", "true", "1")


def configurado(motor, arquivo=None):
    """True se a tela de Inteligência Artificial já gravou algo sobre o motor (ligado ou desligado)."""
    return _ler(arquivo).has_section(motor)


def modelos(motor, arquivo=None):
    dados = _ler(arquivo)
    lista = [m.strip() for m in dados.get(motor, "modelos", fallback="").split(",")] if dados.has_section(motor) else []
    return [m for m in lista if _MODELO.match(m)][:60]


def modelo_preferido(motor, arquivo=None):
    dados = _ler(arquivo)
    modelo = dados.get(motor, "modelo", fallback="").strip() if dados.has_section(motor) else ""
    return modelo if _MODELO.match(modelo) else ""


def gravar(motor, arquivo=None, **campos):
    """Usado só na migração das preferências antigas do Wise (a tela de IA é quem grava no dia a dia)."""
    if motor not in MOTORES:
        raise ValueError(motor)
    arquivo = Path(arquivo or ARQUIVO)
    dados = _ler(arquivo)
    if not dados.has_section(motor):
        dados.add_section(motor)
    for chave, valor in campos.items():
        dados.set(motor, chave, ("sim" if valor else "nao") if isinstance(valor, bool) else str(valor))
    arquivo.parent.mkdir(parents=True, exist_ok=True)
    temporario = arquivo.with_suffix(".tmp")
    with open(temporario, "w", encoding="utf-8") as saida:
        saida.write("# DuiaOS — motores de IA na nuvem (Configurações › Inteligência Artificial). As chaves ficam no cofre.\n")
        dados.write(saida)
    os.replace(temporario, arquivo)


def ler_chave(motor):
    """A chave do motor no cofre do sistema (ou None). A do Gemini guardada pelo Wise antigo ainda vale."""
    from . import segredos
    colecao = segredos._colecao()
    for item in colecao.search_items({**ATRIBUTOS, "motor": motor}):
        return item.get_secret().decode("utf-8")
    if motor == "gemini":
        return segredos.ler("gemini")
    return None


def migrar(configuracao, arquivo=None):
    """Preferências antigas do Wise (nuvem_permitida) → ia.conf, uma vez só."""
    if configuracao.nuvem_permitida and not configurado("gemini", arquivo):
        try:
            gravar("gemini", arquivo, ativado=True, modelo=configuracao.modelo_gemini, modelos=configuracao.modelo_gemini)
        except OSError:
            pass
