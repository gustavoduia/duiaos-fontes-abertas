"""Login com Google e Microsoft para a agenda (OAuth 2.0 de aplicativo instalado).

Fluxo "loopback" com PKCE (RFC 8252): o Wise abre o navegador na página de
login do provedor; a pessoa entra e autoriza; o provedor devolve o código para
um endereço local (http://127.0.0.1:PORTA), que só este processo escuta por
alguns minutos. A senha da pessoa nunca passa pelo Wise.

Os identificadores dos aplicativos (registrados pelo DuiaOS no Google Cloud e no
Microsoft Entra) ficam em /usr/share/duiaos-wise/contas.json (ou, para testes,
~/.config/duiaos/wise/contas-apps.json). Sem eles, a opção aparece como "ainda
não configurada". Os tokens ficam no cofre do sistema, nunca em arquivo.
"""
import base64
import hashlib
import http.server
import json
import secrets
import subprocess
import threading
import time
import urllib.parse
from pathlib import Path

from .. import segredos
from ..configuracao import PASTA_CONFIG
from ..internet import SemInternet, baixar

ARQUIVOS_APPS = [PASTA_CONFIG / "contas-apps.json", Path("/usr/share/duiaos-wise/contas.json")]

PROVEDORES = {
    "google": {
        "nome": "Google Agenda",
        "autorizar": "https://accounts.google.com/o/oauth2/v2/auth",
        "token": "https://oauth2.googleapis.com/token",
        "escopos": "https://www.googleapis.com/auth/calendar.readonly "
                   "https://www.googleapis.com/auth/calendar.events",
        "extra": {"access_type": "offline", "prompt": "consent"},
        "host": "127.0.0.1",
    },
    "microsoft": {
        "nome": "Microsoft (Outlook e Teams)",
        "autorizar": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "escopos": "offline_access User.Read Calendars.ReadWrite",
        "extra": {"prompt": "select_account"},
        "host": "localhost",      # o Entra aceita qualquer porta em http://localhost
    },
}

PAGINA_FIM = """<!doctype html><meta charset="utf-8"><title>Wise</title>
<body style="font-family:Inter,sans-serif;background:#E8F0FE;color:#1A3A73;display:grid;place-items:center;height:90vh">
<div style="text-align:center"><h1>{titulo}</h1><p>{texto}</p><p>Pode fechar esta aba e voltar ao Wise.</p></div>"""


class ErroDeLogin(Exception):
    pass


def aplicativo(provedor):
    """{"client_id", ["client_secret"]} do provedor, ou None se não configurado."""
    for arquivo in ARQUIVOS_APPS:
        try:
            dados = json.loads(arquivo.read_text())
        except (OSError, ValueError):
            continue
        app = dados.get(provedor) if isinstance(dados, dict) else None
        if isinstance(app, dict) and isinstance(app.get("client_id"), str) and app["client_id"].strip():
            return {k: str(v) for k, v in app.items() if k in ("client_id", "client_secret")}
    return None


def _pkce():
    verificador = base64.urlsafe_b64encode(secrets.token_bytes(48)).rstrip(b"=").decode()
    desafio = base64.urlsafe_b64encode(hashlib.sha256(verificador.encode()).digest()).rstrip(b"=").decode()
    return verificador, desafio


def _pedir_token(provedor, campos):
    p = PROVEDORES[provedor]
    try:
        _c, _h, corpo = baixar(p["token"], {"Content-Type": "application/x-www-form-urlencoded"},
                               tempo=20, metodo="POST", corpo=urllib.parse.urlencode(campos).encode())
        dados = json.loads(corpo)
    except (SemInternet, ValueError) as erro:
        raise ErroDeLogin(f"não consegui confirmar o login: {erro}") from erro
    if not dados.get("access_token"):
        raise ErroDeLogin("o provedor não devolveu o acesso")
    return dados


def entrar(provedor, chave_cofre, abrir_navegador=None, tempo=300, cancelado=None):
    """Faz o login e guarda os tokens no cofre (chave_cofre). Bloqueia até o fim."""
    p = PROVEDORES.get(provedor)
    app = aplicativo(provedor)
    if p is None or app is None:
        raise ErroDeLogin(f"o login com {p['nome'] if p else provedor} ainda não está configurado neste DuiaOS")
    verificador, desafio = _pkce()
    estado = secrets.token_urlsafe(24)
    resultado = {}

    class Retorno(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            consulta = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            if consulta.get("state", [""])[0] != estado:
                self.send_response(400)
                self.end_headers()
                return
            if "code" in consulta:
                resultado["codigo"] = consulta["code"][0]
                titulo, texto = "Pronto!", "A agenda foi conectada ao Wise."
            else:
                resultado["erro"] = consulta.get("error", ["recusado"])[0]
                titulo, texto = "Não conectado", "O acesso não foi autorizado."
            pagina = PAGINA_FIM.format(titulo=titulo, texto=texto).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(pagina)))
            self.end_headers()
            self.wfile.write(pagina)

    servidor = http.server.HTTPServer(("127.0.0.1", 0), Retorno)
    servidor.timeout = 1
    retorno = f"http://{p['host']}:{servidor.server_port}/"
    campos = {"client_id": app["client_id"], "response_type": "code", "redirect_uri": retorno,
              "scope": p["escopos"], "state": estado, "code_challenge": desafio,
              "code_challenge_method": "S256", **p["extra"]}
    url = p["autorizar"] + "?" + urllib.parse.urlencode(campos)
    (abrir_navegador or _abrir)(url)
    limite = time.monotonic() + tempo
    try:
        while not resultado and time.monotonic() < limite:
            if cancelado is not None and cancelado.is_set():
                raise ErroDeLogin("login cancelado")
            servidor.handle_request()
    finally:
        servidor.server_close()
    if "codigo" not in resultado:
        raise ErroDeLogin("o login não foi concluído" if not resultado else "o acesso não foi autorizado")
    pedido = {"client_id": app["client_id"], "grant_type": "authorization_code", "code": resultado["codigo"],
              "redirect_uri": retorno, "code_verifier": verificador}
    if app.get("client_secret"):
        pedido["client_secret"] = app["client_secret"]
    tokens = _pedir_token(provedor, pedido)
    _guardar(chave_cofre, tokens)
    return tokens


def _abrir(url):
    subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)


def _guardar(chave_cofre, tokens, anterior=None):
    dados = {"access_token": tokens["access_token"],
             "refresh_token": tokens.get("refresh_token") or (anterior or {}).get("refresh_token", ""),
             "expira": time.time() + int(tokens.get("expires_in", 3600)) - 60}
    segredos.gravar(chave_cofre, json.dumps(dados), "Wise — acesso à agenda")
    return dados


_travas = {}


def acesso(provedor, chave_cofre):
    """Token de acesso válido (renova com o refresh_token quando vence)."""
    trava = _travas.setdefault(chave_cofre, threading.Lock())
    with trava:
        texto = segredos.ler(chave_cofre)
        if not texto:
            raise ErroDeLogin("a conta foi desconectada; conecte de novo nas Configurações do Wise")
        dados = json.loads(texto)
        if dados.get("expira", 0) > time.time():
            return dados["access_token"]
        app = aplicativo(provedor)
        if not app or not dados.get("refresh_token"):
            raise ErroDeLogin("o acesso à conta venceu; conecte de novo nas Configurações do Wise")
        pedido = {"client_id": app["client_id"], "grant_type": "refresh_token",
                  "refresh_token": dados["refresh_token"]}
        if app.get("client_secret"):
            pedido["client_secret"] = app["client_secret"]
        if provedor == "microsoft":
            pedido["scope"] = PROVEDORES[provedor]["escopos"]
        return _guardar(chave_cofre, _pedir_token(provedor, pedido), dados)["access_token"]
