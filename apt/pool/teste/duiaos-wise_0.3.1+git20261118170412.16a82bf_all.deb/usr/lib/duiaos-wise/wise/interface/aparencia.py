"""Aparência do DuiaOS para a janela do Wise: modo (claro ou escuro) e estilo (futurista ou padrão).

Lê ~/.config/duiaos/preferencias.conf, seção [aparencia] (o mesmo arquivo das Configurações do DuiaOS),
e avisa quando ele muda. Fora do DuiaOS: futurista, claro.
"""
import configparser
import os
from pathlib import Path

from PySide6.QtCore import QFileSystemWatcher, QObject, Property, Signal

ARQUIVO = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "duiaos" / "preferencias.conf"


def ler(arquivo=None):
    dados = configparser.ConfigParser(interpolation=None)
    try:
        dados.read(arquivo or ARQUIVO, encoding="utf-8")
    except (configparser.Error, OSError):
        pass
    modo = dados.get("aparencia", "modo", fallback="claro")
    estilo = dados.get("aparencia", "estilo", fallback="futurista")
    return modo == "escuro", estilo != "padrao"


class Aparencia(QObject):
    mudou = Signal()

    def __init__(self):
        super().__init__()
        self._escuro, self._futurista = ler()
        self._vigia = QFileSystemWatcher(self)
        self._vigiar()
        self._vigia.fileChanged.connect(self._recarregar)
        self._vigia.directoryChanged.connect(self._recarregar)

    def _vigiar(self):
        for caminho in (ARQUIVO, ARQUIVO.parent):
            if caminho.exists() and str(caminho) not in self._vigia.files() + self._vigia.directories():
                self._vigia.addPath(str(caminho))

    def _recarregar(self, *_):
        self._vigiar()
        novo = ler()
        if novo != (self._escuro, self._futurista):
            self._escuro, self._futurista = novo
            self.mudou.emit()

    escuro = Property(bool, lambda self: self._escuro, notify=mudou)
    futurista = Property(bool, lambda self: self._futurista, notify=mudou)
