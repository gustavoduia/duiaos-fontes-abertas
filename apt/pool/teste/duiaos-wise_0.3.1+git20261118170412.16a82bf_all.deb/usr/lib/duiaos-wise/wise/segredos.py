"""Segredos do Wise no cofre do sistema (Secret Service / gnome-keyring).

O cofre é desbloqueado no login pela Tela de Entrada (PAM do greetd com
pam_gnome_keyring). Nenhuma chave vai para arquivo, log ou prompt.
"""
ATRIBUTOS = {"aplicativo": "duiaos-wise"}


class CofreIndisponivel(Exception):
    pass


def _colecao():
    try:
        import secretstorage
    except ImportError as erro:
        raise CofreIndisponivel("pacote python3-secretstorage não instalado") from erro
    try:
        conexao = secretstorage.dbus_init()
        colecao = secretstorage.get_default_collection(conexao)
        if colecao.is_locked():
            colecao.unlock()
        return colecao
    except Exception as erro:  # o secretstorage levanta tipos variados
        raise CofreIndisponivel(f"cofre do sistema indisponível: {erro}") from erro


def ler(nome):
    """Valor guardado (str) ou None."""
    colecao = _colecao()
    for item in colecao.search_items({**ATRIBUTOS, "nome": nome}):
        return item.get_secret().decode("utf-8")
    return None


def gravar(nome, valor, rotulo):
    colecao = _colecao()
    colecao.create_item(rotulo, {**ATRIBUTOS, "nome": nome}, valor.encode("utf-8"), replace=True)


def apagar(nome):
    colecao = _colecao()
    for item in colecao.search_items({**ATRIBUTOS, "nome": nome}):
        item.delete()
