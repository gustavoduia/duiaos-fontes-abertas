"""python3 -m wise — abre o Wise (mesmo que /usr/bin/duiaos-wise)."""
import sys

if "--aquecer-no-boot" in sys.argv[1:]:
    # Serviço do sistema (antes do login): sem interface, sem Qt
    from .aquecimento import main
else:
    from .interface.main import main

sys.exit(main())
