"""Gateway de modelos do Wise: escolhe o provedor de cada tarefa.

Regra (Configuracao.provedor):
  automatico — usa o modelo local quando ele está disponível (privado e grátis);
               sem ele, usa o Gemini, se a pessoa autorizou a nuvem.
  local      — só o modelo local.
  gemini     — só o Gemini.
"""
from .base import (ChamadaDeFerramenta, ErroDoProvedor, Mensagem, Provedor,  # noqa: F401
                   ProvedorIndisponivel, Resposta)
from .gemini import Gemini
from .local import Local
from .openai import OpenAI

__all__ = ["ChamadaDeFerramenta", "ErroDoProvedor", "Mensagem", "Provedor", "ProvedorIndisponivel",
           "Resposta", "Gemini", "Local", "OpenAI", "Gateway"]


class Gateway:
    """Motores (local, gemini, openai) e a escolha de cada pedido.

    O padrão vem das preferências (Configuracao.provedor: "automatico" = local com a nuvem de reserva,
    "local", "gemini", "openai"). Na janela do Wise a pessoa pode escolher outro motor e outro modelo
    para a sessão (definir_sessao); isso não muda o padrão."""

    def __init__(self, configuracao, ler_chave_gemini=None, local=None, gemini=None, openai=None):
        from .. import ia_do_sistema, motores
        from ..configuracao import modelo_local_adequado
        self.configuracao = configuracao
        self._motores = motores
        self.sessao_motor = ""               # "" = o padrão das preferências
        # No DuiaOS o modelo local é o ativo da IA do sistema; o das preferências só vale fora dele.
        self.local = local or Local(modelo_local_adequado(configuracao), configuracao.endereco_local,
                                    estado_do_sistema=ia_do_sistema.ler)
        self.gemini = gemini or Gemini(motores.modelo_preferido("gemini") or configuracao.modelo_gemini,
                                       ler_chave_gemini or (lambda: motores.ler_chave("gemini")),
                                       lambda: self._autorizado("gemini"))
        self.openai = openai or OpenAI(motores.modelo_preferido("openai") or (motores.modelos("openai") or [""])[0],
                                       lambda: motores.ler_chave("openai"), lambda: self._autorizado("openai"))

    def _autorizado(self, motor):
        if self._motores.configurado(motor):
            return self._motores.ativado(motor)
        return motor == "gemini" and self.configuracao.nuvem_permitida      # preferências antigas do Wise

    def motor(self, nome):
        return {"local": self.local, "gemini": self.gemini, "openai": self.openai}.get(nome)

    def nuvem(self):
        return [self.gemini, self.openai]

    # ------------------------------------------------------------ escolha
    def motor_padrao(self):
        preferencia = self.configuracao.provedor
        return preferencia if preferencia in ("gemini", "openai") else "local"

    def motor_atual(self):
        return self.sessao_motor or self.motor_padrao()

    def definir_sessao(self, motor, modelo=""):
        """Motor e modelo desta sessão do Wise (o modelo local é o do sistema: trocar é com o duiaos-ia)."""
        if motor not in ("local", "gemini", "openai"):
            return
        self.sessao_motor = motor
        if modelo and motor != "local":
            self.motor(motor).modelo = modelo

    def candidatos(self):
        if self.sessao_motor:
            atual = self.motor(self.sessao_motor)
            if atual is self.local and self.configuracao.provedor == "automatico":
                return [atual] + self.nuvem()
            return [atual]
        preferencia = self.configuracao.provedor
        if preferencia == "local":
            return [self.local]
        if preferencia in ("gemini", "openai"):
            return [self.motor(preferencia)]
        return [self.local] + self.nuvem()

    def escolher(self):
        """Primeiro provedor disponível, ou ProvedorIndisponivel com os motivos."""
        motivos = []
        for provedor in self.candidatos():
            pronto, motivo = provedor.disponivel()
            if pronto:
                return provedor
            motivos.append(f"{provedor.titulo}: {motivo}")
        raise ProvedorIndisponivel("; ".join(motivos))

    def situacao(self):
        """Para a janela: estado de cada provedor."""
        estado = {}
        vistos = []
        for provedor in (self.local, self.gemini, self.openai):
            if any(provedor is v for v in vistos):
                continue
            vistos.append(provedor)
            pronto, motivo = provedor.disponivel()
            estado[provedor.nome] = {"titulo": provedor.titulo, "modelo": provedor.modelo,
                                     "nuvem": provedor.nuvem, "pronto": pronto, "motivo": motivo,
                                     "sistema": bool(getattr(provedor, "do_sistema", False))}
        return estado
