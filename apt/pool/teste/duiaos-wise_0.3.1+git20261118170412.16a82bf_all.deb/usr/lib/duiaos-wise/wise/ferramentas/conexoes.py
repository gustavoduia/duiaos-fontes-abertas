"""Ligar e desligar o Wi-Fi e o Bluetooth (reclamação de 12/10).

Pediram "desliga o wifi": sem ferramenta para isso, o modelo ofereceu desligar
o computador. Agora há a ação certa. É N1: só muda este computador e se desfaz
na hora (a Barra de Recursos e o próprio Wise ligam de novo).

Wi-Fi pelo NetworkManager (nmcli radio wifi, permitido à sessão ativa pelo polkit
do próprio NetworkManager); Bluetooth pelo rfkill (/dev/rfkill é liberado à
sessão ativa pelo systemd-logind).
"""
import subprocess

from .base import ErroDeArgumentos, Ferramenta

APARELHOS = {"wifi": "Wi-Fi", "bluetooth": "Bluetooth"}


def _rodar(*comando, tempo=10):
    try:
        r = subprocess.run(comando, capture_output=True, text=True, timeout=tempo, check=False,
                           env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C.UTF-8"})
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as erro:
        return 1, str(erro)


def estado(aparelho):
    """True (ligado), False (desligado) ou None (não deu para saber / não existe)."""
    if aparelho == "wifi":
        codigo, saida = _rodar("nmcli", "radio", "wifi")
        valor = saida.strip().lower()
        return None if codigo else {"enabled": True, "disabled": False}.get(valor)
    codigo, saida = _rodar("rfkill", "--noheadings", "--output", "SOFT", "list", "bluetooth")
    linhas = [l.strip() for l in saida.splitlines() if l.strip()]
    if codigo or not linhas:
        return None
    return all(l == "unblocked" for l in linhas)


def ligar_ou_desligar(aparelho, ligar):
    if aparelho not in APARELHOS:
        raise ErroDeArgumentos(f"'aparelho' deve ser um de: {', '.join(APARELHOS)}")
    nome = APARELHOS[aparelho]
    antes = estado(aparelho)
    if antes is None:
        return {"erro": f"não encontrei {nome} neste computador"}
    if antes == ligar:
        return {"ja_estava": f"o {nome} já estava {'ligado' if ligar else 'desligado'}"}
    if aparelho == "wifi":
        codigo, saida = _rodar("nmcli", "radio", "wifi", "on" if ligar else "off")
    else:
        codigo, saida = _rodar("rfkill", "unblock" if ligar else "block", "bluetooth")
    if codigo or estado(aparelho) != ligar:
        return {"erro": f"não consegui {'ligar' if ligar else 'desligar'} o {nome}: {saida.strip()[:120]}"}
    return {"feito": True, "mensagem": f"{nome} {'ligado' if ligar else 'desligado'}."}


FERRAMENTAS = [
    Ferramenta("ligar_desligar", "Wi-Fi e Bluetooth",
               "Liga ou desliga o Wi-Fi ou o Bluetooth deste computador.",
               ligar_ou_desligar,
               {"type": "object", "properties": {
                   "aparelho": {"type": "string", "enum": list(APARELHOS)},
                   "ligar": {"type": "boolean", "description": "true liga, false desliga."}},
                "required": ["aparelho", "ligar"]},
               nivel="N1"),
]
