// Wise — conteúdo do botão flutuante: a carinha de robô e o balão de fala.
//
// O balão mostra:
//   - uma mensagem (saudar(texto)): aparece com um pulinho do Wise, o texto
//     é "digitado" e some sozinho depois de alguns segundos (a linha no pé do
//     balão mostra o tempo; parar o mouse em cima segura o balão);
//   - uma resposta pronta com a janela fechada (responder(resumo)): o começo da
//     resposta, como se o Wise falasse; clicar no balão abre a conversa;
//   - o progresso de um trabalho do sistema (progresso = {titulo, detalhe,
//     fracao, nota}), como o download da IA do sistema: fica enquanto durar.
import QtQuick

Item {
    id: conteudo
    property string estado: "descansando"
    property var progresso: null
    signal clicado()        // clique na carinha: abre ou fecha o Wise
    signal abrir()          // clique no balão: abre o Wise na conversa

    property string textoBalao: ""
    property string tipoMensagem: "saudacao"      // "saudacao" ou "resposta"
    readonly property bool ehResposta: temMensagem && tipoMensagem === "resposta"
    property int letras: 0
    property bool fechadoAMao: false          // a pessoa fechou o progresso: não insiste
    readonly property bool temMensagem: textoBalao !== ""
    readonly property bool temProgresso: progresso !== null && progresso !== undefined && !fechadoAMao
    readonly property bool balaoAberto: temMensagem || temProgresso
    readonly property bool balaoPresente: balao.opacity > 0.01

    readonly property int margem: 14
    readonly property int duracaoMensagem: tipoMensagem === "resposta" ? 20000 : 9000
    implicitWidth: (balaoPresente || balaoAberto) ? balao.width + carinha.width + 10 + margem * 2
                                                  : carinha.width + margem * 2
    implicitHeight: Math.max(carinha.height, (balaoPresente || balaoAberto) ? balao.height + carinha.height * 0.45 : 0)
                    + margem * 2

    function saudar(texto) { mostrarMensagem(texto, "saudacao") }
    function responder(texto) { mostrarMensagem(texto, "resposta") }
    function mostrarMensagem(texto, tipo) {
        tipoMensagem = tipo
        textoBalao = texto
        letras = 0
        digitar.restart()
        tempo.restart()
        carinha.pular()
    }
    function fechar() {
        textoBalao = ""
        if (progresso) fechadoAMao = true
    }
    onProgressoChanged: if (!progresso) fechadoAMao = false

    NumberAnimation {
        id: digitar
        target: conteudo; property: "letras"
        from: 0; to: conteudo.textoBalao.length
        duration: Math.min(2400, conteudo.textoBalao.length * 24)
    }

    // Tempo da mensagem (para enquanto o mouse está sobre o balão)
    property real restante: 1
    NumberAnimation {
        id: tempo
        target: conteudo; property: "restante"
        from: 1; to: 0; duration: conteudo.duracaoMensagem
        paused: running && areaBalao.containsMouse
        onFinished: conteudo.textoBalao = ""
    }

    Carinha {
        id: carinha
        // Cumprimentando, o Wise fica feliz; com um trabalho em andamento, atento
        estado: conteudo.temMensagem ? "feliz"
                : (conteudo.temProgresso && conteudo.estado === "descansando" ? "aberto" : conteudo.estado)
        destacada: areaCarinha.containsMouse
        anchors { right: parent.right; bottom: parent.bottom; margins: conteudo.margem }
        MouseArea {
            id: areaCarinha
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: { conteudo.textoBalao = ""; conteudo.clicado() }
        }
    }

    // ------------------------------------------------------------ balão
    Item {
        id: balao
        width: 304
        height: colunaBalao.height + 38
        anchors { right: carinha.left; rightMargin: 10; bottom: carinha.top; bottomMargin: -carinha.height * 0.45 }
        transformOrigin: Item.BottomRight
        opacity: conteudo.balaoAberto ? 1 : 0
        scale: conteudo.balaoAberto ? 1 : 0.6
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: conteudo.balaoAberto ? 220 : 260 } }
        Behavior on scale { NumberAnimation { duration: conteudo.balaoAberto ? 420 : 260
                                              easing.type: conteudo.balaoAberto ? Easing.OutBack : Easing.InCubic } }
        Behavior on height { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }

        // Sombra suave
        Rectangle {
            anchors { fill: parent; topMargin: 4; leftMargin: 2; rightMargin: -2; bottomMargin: -5 }
            radius: 22
            color: "#1A3A73"
            opacity: 0.12
        }
        Rectangle {
            id: fundo
            anchors.fill: parent
            radius: 20
            color: "white"
            border { color: "#DDE3EC"; width: 1 }

            // Detalhe de cor no topo
            Rectangle {
                anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 20; rightMargin: 20; topMargin: -1 }
                height: 3
                radius: 1.5
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: "#2E6BE6" }
                    GradientStop { position: 1; color: "#7CE0B5" }
                }
            }

            // Tempo restante da mensagem
            Rectangle {
                visible: conteudo.temMensagem
                anchors { left: parent.left; bottom: parent.bottom; leftMargin: 18; bottomMargin: 8 }
                width: (parent.width - 36) * conteudo.restante
                height: 2; radius: 1
                color: "#2E6BE6"
                opacity: 0.35
            }
        }

        // Pontinha do balão apontando para o Wise
        Canvas {
            width: 14; height: 18
            anchors { left: parent.right; leftMargin: -2; bottom: parent.bottom; bottomMargin: 18 }
            onPaint: {
                const c = getContext("2d")
                c.reset()
                c.fillStyle = "white"; c.strokeStyle = "#DDE3EC"; c.lineWidth = 1
                c.beginPath(); c.moveTo(0, 0); c.lineTo(width, height / 2); c.lineTo(0, height); c.closePath()
                c.fill()
                c.beginPath(); c.moveTo(0, 0); c.lineTo(width, height / 2); c.lineTo(0, height); c.stroke()
            }
        }

        Column {
            id: colunaBalao
            anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 18; rightMargin: 34; topMargin: 18 }
            spacing: 12

            // Resposta pronta: quem está falando
            Row {
                visible: conteudo.ehResposta
                spacing: 6
                Rectangle {
                    width: 8; height: 8; radius: 4
                    anchors.verticalCenter: parent.verticalCenter
                    color: "#2FA67A"
                    SequentialAnimation on opacity {
                        running: conteudo.ehResposta; loops: Animation.Infinite
                        NumberAnimation { to: 0.3; duration: 700 }
                        NumberAnimation { to: 1; duration: 700 }
                    }
                }
                Text {
                    text: "O Wise respondeu"
                    color: "#2E6BE6"
                    font { family: "Inter"; pixelSize: 12; weight: Font.Bold; letterSpacing: 0.3 }
                }
            }

            // Mensagem "digitada" (o texto inteiro, invisível, reserva o tamanho)
            Item {
                visible: conteudo.temMensagem
                width: parent.width
                height: visible ? medida.height : 0
                Text {
                    id: medida
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: conteudo.textoBalao
                    font { family: "Inter"; pixelSize: 14 }
                    lineHeight: 1.25
                    opacity: 0
                }
                Text {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: conteudo.textoBalao.substring(0, conteudo.letras)
                    color: "#1F2933"
                    font: medida.font
                    lineHeight: 1.25
                }
            }
            Text {
                visible: conteudo.ehResposta
                text: "Clique aqui para ver a resposta completa"
                color: areaBalao.containsMouse ? "#2E6BE6" : "#5B6675"
                font { family: "Inter"; pixelSize: 12; weight: Font.DemiBold; underline: areaBalao.containsMouse }
            }

            // Progresso (download da IA do sistema e afins)
            Column {
                id: blocoProgresso
                visible: conteudo.temProgresso
                width: parent.width
                spacing: 6
                Text {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: conteudo.progresso ? conteudo.progresso.titulo : ""
                    color: "#1A3A73"
                    font { family: "Inter"; pixelSize: 13; weight: Font.DemiBold }
                }
                Rectangle {
                    width: parent.width
                    height: 8
                    radius: 4
                    color: "#E8F0FE"
                    clip: true
                    Rectangle {
                        id: preenchido
                        width: Math.max(8, parent.width * (conteudo.progresso ? conteudo.progresso.fracao : 0))
                        height: parent.height
                        radius: 4
                        gradient: Gradient {
                            orientation: Gradient.Horizontal
                            GradientStop { position: 0; color: "#2E6BE6" }
                            GradientStop { position: 1; color: "#5B8DEF" }
                        }
                        Behavior on width { NumberAnimation { duration: 500; easing.type: Easing.OutCubic } }
                        // Reflexo que passa pela barra: está trabalhando
                        Rectangle {
                            width: 28; height: parent.height
                            y: 0
                            gradient: Gradient {
                                orientation: Gradient.Horizontal
                                GradientStop { position: 0; color: "#00FFFFFF" }
                                GradientStop { position: 0.5; color: "#88FFFFFF" }
                                GradientStop { position: 1; color: "#00FFFFFF" }
                            }
                            NumberAnimation on x {
                                running: conteudo.temProgresso
                                from: -28; to: preenchido.width; duration: 1400; loops: Animation.Infinite
                            }
                        }
                    }
                }
                Text {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: conteudo.progresso ? conteudo.progresso.detalhe : ""
                    color: "#5B6675"
                    font { family: "Inter"; pixelSize: 12 }
                }
                Text {
                    visible: text !== ""
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: conteudo.progresso && conteudo.progresso.nota ? conteudo.progresso.nota : ""
                    color: "#5B6675"
                    font { family: "Inter"; pixelSize: 12; italic: true }
                }
            }
        }

        // Fechar
        Rectangle {
            width: 24; height: 24; radius: 12
            anchors { right: parent.right; top: parent.top; margins: 8; topMargin: 10 }
            color: areaFechar.containsMouse ? "#E8F0FE" : "transparent"
            Text { anchors.centerIn: parent; text: "×"; color: "#5B6675"; font { pixelSize: 18 } }
            MouseArea { id: areaFechar; anchors.fill: parent; hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor; onClicked: conteudo.fechar() }
        }
        // Clique no balão: abre o Wise na conversa
        MouseArea {
            id: areaBalao
            anchors.fill: parent
            z: -1
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: { conteudo.textoBalao = ""; conteudo.abrir() }
        }
    }
}
