"""Provedor OpenAI (API Chat Completions, com chamadas de ferramentas).

- A chave fica no cofre do sistema e é configurada em Configurações › Inteligência Artificial.
- Só é usado quando a pessoa ativou o motor lá (os pedidos vão para os servidores da OpenAI).
"""
import json

from .base import ChamadaDeFerramenta, ErroDoProvedor, Provedor, ProvedorIndisponivel, Resposta, post_json

URL = "https://api.openai.com/v1/chat/completions"


class OpenAI(Provedor):
    nome = "openai"
    titulo = "OpenAI"
    nuvem = True

    def __init__(self, modelo, ler_chave, consentimento, url=URL):
        self.modelo = modelo
        self._ler_chave = ler_chave
        self._consentimento = consentimento
        self._url = url

    def disponivel(self):
        if not self._consentimento():
            return False, "a OpenAI não está ativada em Configurações › Inteligência Artificial"
        try:
            chave = self._ler_chave()
        except Exception as erro:  # noqa: BLE001 — cofre fora do ar
            return False, f"não consegui ler a chave da OpenAI ({erro})"
        if not chave:
            return False, "falta a chave da OpenAI em Configurações › Inteligência Artificial"
        if not self.modelo:
            return False, "escolha um modelo da OpenAI"
        return True, ""

    @staticmethod
    def converter_ferramentas(declaracoes):
        return [{"type": "function", "function": {"name": d["nome"], "description": d["descricao"],
                                                  "parameters": d["parametros"] or {"type": "object", "properties": {}}}}
                for d in declaracoes]

    @staticmethod
    def converter_conversa(instrucoes, conversa):
        mensagens, pendentes, numero = [{"role": "system", "content": instrucoes}], [], 0
        for m in conversa:
            if m.papel == "pessoa":
                mensagens.append({"role": "user", "content": m.texto})
            elif m.papel == "wise":
                mensagem = {"role": "assistant", "content": m.texto or None}
                pendentes = []
                if m.chamadas:
                    chamadas = []
                    for c in m.chamadas:
                        numero += 1
                        ident = c.id or f"chamada_{numero}"
                        pendentes.append((ident, c.nome))
                        chamadas.append({"id": ident, "type": "function",
                                         "function": {"name": c.nome, "arguments": json.dumps(c.argumentos, ensure_ascii=False)}})
                    mensagem["tool_calls"] = chamadas
                mensagens.append(mensagem)
            elif m.papel == "ferramenta":
                posicao = next((i for i, (_id, nome) in enumerate(pendentes) if nome == m.ferramenta), 0 if pendentes else None)
                if posicao is None:
                    continue                      # resultado sem a chamada (não deveria acontecer): fica de fora
                ident, _nome = pendentes.pop(posicao)
                mensagens.append({"role": "tool", "tool_call_id": ident,
                                  "content": json.dumps({"resultado": m.resultado}, ensure_ascii=False, default=str)})
        return mensagens

    def responder(self, instrucoes, conversa, ferramentas, cancelado=None, ao_parcial=None):
        pronto, motivo = self.disponivel()
        if not pronto:
            raise ProvedorIndisponivel(motivo)
        corpo = {"model": self.modelo, "messages": self.converter_conversa(instrucoes, conversa)}
        declaradas = self.converter_ferramentas(ferramentas)
        if declaradas:
            corpo["tools"] = declaradas
        dados = post_json(self._url, corpo, {"Authorization": "Bearer " + self._ler_chave()}, tempo=120)
        escolhas = dados.get("choices") or []
        if not escolhas:
            raise ErroDoProvedor("a OpenAI não respondeu")
        mensagem = escolhas[0].get("message") or {}
        chamadas = []
        for c in mensagem.get("tool_calls") or []:
            funcao = c.get("function") or {}
            try:
                argumentos = json.loads(funcao.get("arguments") or "{}")
            except ValueError:
                argumentos = {}
            chamadas.append(ChamadaDeFerramenta(funcao.get("name", ""), argumentos if isinstance(argumentos, dict) else {},
                                                c.get("id", "")))
        return Resposta(texto=(mensagem.get("content") or "").strip(), chamadas=chamadas)
