"""Ler e usar janelas pela acessibilidade do sistema (AT-SPI, W15).

É o mesmo caminho dos leitores de tela: cada aplicativo descreve o que mostra
(textos, botões, campos, menus) e aceita ações ("clicar", "escrever"). Assim o
Wise usa qualquer aplicativo GTK, Qt, navegador ou LibreOffice sem integração
própria e sem adivinhar posição na tela.

No DuiaOS a acessibilidade fica ligada na sessão (pacote duiaos-shell). A
leitura numera os elementos que dá para usar; a numeração vale por 3 minutos
(depois, ler de novo). Campos de senha nunca têm o conteúdo lido.
"""
import threading
import time

from .aplicativos import normalizar

VALIDADE = 180
LIMITE_ELEMENTOS = 700
LIMITE_PROFUNDIDADE = 60

PAPEIS = {
    "push button": "botão", "toggle button": "botão de ligar", "check box": "caixa de marcar",
    "radio button": "opção", "combo box": "lista de escolha", "entry": "campo", "password text": "campo de senha",
    "text": "texto", "link": "link", "menu item": "item de menu", "menu": "menu", "check menu item": "item de menu",
    "radio menu item": "item de menu", "page tab": "aba", "list item": "item", "table cell": "célula",
    "tree item": "item", "spin button": "número", "slider": "controle deslizante", "heading": "título",
    "paragraph": "parágrafo", "label": "rótulo", "static": "texto", "document web": "página",
    "image": "imagem", "notification": "aviso", "alert": "alerta", "dialog": "janela de diálogo",
}
INTERATIVOS = {"push button", "toggle button", "check box", "radio button", "combo box", "entry", "password text",
               "link", "menu item", "check menu item", "radio menu item", "page tab", "list item", "tree item",
               "spin button", "slider", "table cell"}
# "text" editável (o campo de texto do Qt e as áreas de edição) também é campo para usar
TEXTUAIS = {"heading", "paragraph", "label", "static", "text", "notification", "alert", "caption", "section"}


class SemAcessibilidade(Exception):
    pass


_barramento_ok = None


def _atspi():
    """O módulo Atspi, só depois de conferir que o barramento de acessibilidade
    responde: sem ele, a libatspi encerra o processo inteiro (dbind-ERROR)."""
    global _barramento_ok
    try:
        import gi
        gi.require_version("Atspi", "2.0")
        gi.require_version("Gio", "2.0")
        from gi.repository import Atspi, Gio, GLib
    except (ImportError, ValueError) as erro:
        raise SemAcessibilidade("a acessibilidade do sistema (AT-SPI) não está instalada") from erro
    if not _barramento_ok:
        try:
            sessao = Gio.bus_get_sync(Gio.BusType.SESSION, None)
            sessao.call_sync("org.a11y.Bus", "/org/a11y/bus", "org.a11y.Bus", "GetAddress", None,
                             GLib.VariantType("(s)"), Gio.DBusCallFlags.NONE, 3000, None)
            _barramento_ok = True
        except GLib.Error as erro:
            raise SemAcessibilidade("a acessibilidade do sistema não está ligada nesta sessão") from erro
    return Atspi


_ultima = {"quando": 0.0, "elementos": {}, "janela": ""}
_trava = threading.Lock()


def _estados(acc, Atspi):
    try:
        conjunto = acc.get_state_set()
        return {nome for nome, tipo in (("visivel", Atspi.StateType.SHOWING), ("ativo", Atspi.StateType.ACTIVE),
                                        ("habilitado", Atspi.StateType.ENABLED),
                                        ("marcado", Atspi.StateType.CHECKED),
                                        ("selecionado", Atspi.StateType.SELECTED),
                                        ("focado", Atspi.StateType.FOCUSED),
                                        ("editavel", Atspi.StateType.EDITABLE))
                if conjunto.contains(tipo)}
    except Exception:  # noqa: BLE001 — aplicativo que fechou no meio da leitura
        return set()


def _texto_de(acc, limite=300):
    try:
        Atspi = _atspi()
        texto = acc.get_text_iface()
        if texto is None:
            return ""
        n = Atspi.Text.get_character_count(texto)
        # Atspi.Text.get_text explícito: texto.get_text() seria o antigo Accessible.get_text
        return " ".join((Atspi.Text.get_text(texto, 0, min(n, limite)) or "").split())
    except Exception:  # noqa: BLE001
        return ""


def _janelas(Atspi):
    """[(aplicativo, janela)] de tudo que está aberto e se descreve."""
    mesa = Atspi.get_desktop(0)
    achadas = []
    for i in range(min(mesa.get_child_count(), 80)):
        app = mesa.get_child_at_index(i)
        if app is None:
            continue
        for j in range(min(app.get_child_count(), 20)):
            janela = app.get_child_at_index(j)
            if janela is not None:
                achadas.append((app, janela))
    return achadas


def escolher_janela(nome="", titulo=""):
    """A janela pedida (pelo app ou título) ou, sem nome, a que está ativa."""
    Atspi = _atspi()
    try:
        candidatas = _janelas(Atspi)
    except Exception as erro:  # noqa: BLE001
        raise SemAcessibilidade("não consegui falar com a acessibilidade do sistema") from erro
    candidatas = [(a, j) for a, j in candidatas if normalizar(a.get_name() or "") not in ("duiaos-wise", "wise")]
    alvo, alvo_titulo = normalizar(nome), normalizar(titulo)
    def pontos(par):
        app, janela = par
        nome_app, nome_janela = normalizar(app.get_name() or ""), normalizar(janela.get_name() or "")
        p = 0
        if alvo and (alvo == nome_app or alvo in nome_app or nome_app in alvo.split(".")):
            p += 4
        if alvo_titulo and alvo_titulo in nome_janela:
            p += 3
        if alvo and alvo in nome_janela:
            p += 2
        if "ativo" in _estados(janela, Atspi):
            p += 1
        return p
    if not candidatas:
        raise SemAcessibilidade("nenhuma janela aberta se descreve para a acessibilidade")
    melhor = max(candidatas, key=pontos)
    if (alvo or alvo_titulo) and pontos(melhor) < 2:
        raise SemAcessibilidade(f"não achei a janela de '{nome or titulo}' na acessibilidade")
    return melhor


def ler(nome="", titulo="", limite_caracteres=3000):
    """Conteúdo da janela: texto corrido e elementos numerados para usar_elemento."""
    Atspi = _atspi()
    app, janela = escolher_janela(nome, titulo)
    linhas, elementos, visitados = [], {}, 0
    pilha = [(janela, 0)]
    while pilha and visitados < LIMITE_ELEMENTOS:
        acc, profundidade = pilha.pop()
        visitados += 1
        try:
            papel = acc.get_role_name() or ""
            nome_acc = " ".join((acc.get_name() or "").split())[:150]
            filhos = acc.get_child_count()
        except Exception:  # noqa: BLE001
            continue
        estados = _estados(acc, Atspi)
        if profundidade and "visivel" not in estados:
            continue                                 # escondido: nem ele nem os filhos
        if papel == "text" and "editavel" in estados:
            papel = "entry"
        if papel in INTERATIVOS:
            n = len(elementos) + 1
            elementos[n] = acc
            valor = ""
            if papel == "password text":
                valor = "(senha, não lida)"
            elif papel in ("entry", "combo box", "spin button"):
                valor = _texto_de(acc, 120)
            marcas = [m for m in ("marcado", "selecionado", "focado") if m in estados]
            if "habilitado" not in estados:
                marcas.append("desativado")
            linha = f"[{n}] {PAPEIS.get(papel, papel)}: {nome_acc or '(sem nome)'}"
            if valor:
                linha += f" = {valor}"
            if marcas:
                linha += f" ({', '.join(marcas)})"
            linhas.append(linha)
        elif papel in TEXTUAIS or papel in ("document web", "dialog", "alert"):
            texto = _texto_de(acc) or nome_acc
            if texto and (not linhas or texto not in linhas[-1]):
                prefixo = "# " if papel == "heading" else ("! " if papel in ("alert", "notification") else "")
                linhas.append(prefixo + texto)
        if profundidade < LIMITE_PROFUNDIDADE:
            for i in reversed(range(min(filhos, 300))):
                try:
                    filho = acc.get_child_at_index(i)
                except Exception:  # noqa: BLE001
                    filho = None
                if filho is not None:
                    pilha.append((filho, profundidade + 1))
    conteudo, total = [], 0
    for linha in linhas:
        if total + len(linha) > limite_caracteres:
            conteudo.append("… (mais conteúdo; peça para ler uma parte específica)")
            break
        conteudo.append(linha)
        total += len(linha) + 1
    with _trava:
        _ultima.update(quando=time.monotonic(), elementos=elementos, janela=janela.get_name() or "",
                       app=app.get_name() or "")
    return {"aplicativo": (app.get_name() or "")[:60], "janela": (janela.get_name() or "")[:150],
            "conteudo": "\n".join(conteudo), "elementos": len(elementos)}


def elemento(n):
    """(acessível, descrição) do elemento n da última leitura."""
    Atspi = _atspi()
    with _trava:
        if time.monotonic() - _ultima["quando"] > VALIDADE:
            raise SemAcessibilidade("a leitura da janela é antiga; leia de novo com ler_janela")
        acc = _ultima["elementos"].get(int(n))
        janela = _ultima["janela"]
    if acc is None:
        raise SemAcessibilidade(f"não há elemento [{n}] na última leitura")
    try:
        papel = acc.get_role_name() or ""
        nome = " ".join((acc.get_name() or "").split())[:150]
    except Exception as erro:  # noqa: BLE001
        raise SemAcessibilidade("o elemento sumiu (a janela mudou); leia de novo") from erro
    return acc, {"papel": papel, "tipo": PAPEIS.get(papel, papel), "nome": nome, "janela": janela,
                 "estados": _estados(acc, Atspi)}


def clicar(acc):
    acao = acc.get_action_iface()
    if acao is not None:
        nomes = [(acao.get_action_name(i) or "").lower() for i in range(acao.get_n_actions())]
        for preferida in ("click", "press", "activate", "jump", "toggle", "select", "open"):
            if preferida in nomes:
                return bool(acao.do_action(nomes.index(preferida)))
        if nomes:
            return bool(acao.do_action(0))
    componente = acc.get_component_iface()
    if componente is not None and componente.grab_focus():
        from .teclado import teclas
        teclas("Return")
        return True
    raise SemAcessibilidade("este elemento não aceita clique pela acessibilidade")


def escrever(acc, texto):
    editavel = acc.get_editable_text_iface()
    if editavel is not None and editavel.set_text_contents(texto):
        return True
    componente = acc.get_component_iface()
    if componente is not None and componente.grab_focus():
        from .teclado import digitar
        digitar(texto)
        return True
    raise SemAcessibilidade("não consegui escrever neste campo")
