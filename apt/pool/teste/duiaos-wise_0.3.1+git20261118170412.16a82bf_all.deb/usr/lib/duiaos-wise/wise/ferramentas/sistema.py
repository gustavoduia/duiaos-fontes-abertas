"""Ferramentas de consulta (N0): só leem o estado do computador.

Nenhuma delas altera nada. Comandos externos rodam com lista de argumentos
(nunca shell), com tempo limite e saída truncada.
"""
import datetime
import glob
import os
import shutil
import subprocess
import time
from pathlib import Path

from .base import ErroDeArgumentos, Ferramenta

LIMITE_ITENS = 200


def _rodar(*comando, tempo=5):
    try:
        resultado = subprocess.run(comando, capture_output=True, text=True, timeout=tempo, check=False,
                                   env={**os.environ, "LC_ALL": "C.UTF-8"})
        return resultado.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _gb(bytes_):
    return round(bytes_ / 1024 ** 3, 1)


# ------------------------------------------------------------------ data e hora

def data_e_hora():
    agora = datetime.datetime.now().astimezone()
    return {
        "data": agora.strftime("%Y-%m-%d"),
        "hora": agora.strftime("%H:%M"),
        "dia_da_semana": ["segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo"][agora.weekday()],
        "fuso": str(agora.tzinfo),
    }


# ------------------------------------------------------------ uso do computador

def _cpu_percentual(intervalo=0.4):
    def ler():
        valores = list(map(int, Path("/proc/stat").read_text().splitlines()[0].split()[1:]))
        ocioso = valores[3] + (valores[4] if len(valores) > 4 else 0)
        return sum(valores), ocioso
    total1, ocioso1 = ler()
    time.sleep(intervalo)
    total2, ocioso2 = ler()
    diferenca = total2 - total1
    return round(100 * (1 - (ocioso2 - ocioso1) / diferenca), 1) if diferenca else 0.0


def _memoria():
    info = {}
    for linha in Path("/proc/meminfo").read_text().splitlines():
        chave, _, valor = linha.partition(":")
        info[chave] = int(valor.split()[0]) * 1024
    total, disponivel = info.get("MemTotal", 0), info.get("MemAvailable", 0)
    return {
        "total_gb": _gb(total),
        "em_uso_gb": _gb(total - disponivel),
        "disponivel_gb": _gb(disponivel),
        "percentual_em_uso": round(100 * (total - disponivel) / total, 1) if total else 0,
        "swap_em_uso_gb": _gb(info.get("SwapTotal", 0) - info.get("SwapFree", 0)),
    }


def _disco(caminho):
    uso = shutil.disk_usage(caminho)
    return {"pasta": str(caminho), "total_gb": _gb(uso.total), "livre_gb": _gb(uso.free),
            "percentual_em_uso": round(100 * uso.used / uso.total, 1) if uso.total else 0}


def _bateria():
    for pasta in sorted(glob.glob("/sys/class/power_supply/BAT*")):
        try:
            return {"percentual": int(Path(pasta, "capacity").read_text()),
                    "situacao": {"Charging": "carregando", "Discharging": "descarregando",
                                 "Full": "cheia", "Not charging": "na tomada, sem carregar"}.get(
                                     Path(pasta, "status").read_text().strip(), "desconhecida")}
        except (OSError, ValueError):
            continue
    return None


def _temperatura():
    maior = None
    for arquivo in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            valor = int(Path(arquivo).read_text()) / 1000
        except (OSError, ValueError):
            continue
        if 0 < valor < 150 and (maior is None or valor > maior):
            maior = valor
    return round(maior, 1) if maior is not None else None


def uso_do_computador():
    carga = os.getloadavg()
    resultado = {
        "processador": {"percentual_em_uso": _cpu_percentual(), "nucleos": os.cpu_count(),
                        "carga_media_1_5_15_min": [round(c, 2) for c in carga]},
        "memoria": _memoria(),
        "disco": [_disco("/")],
        "temperatura_mais_alta_c": _temperatura(),
        "bateria": _bateria(),
    }
    casa = Path.home()
    try:
        if os.stat(casa).st_dev != os.stat("/").st_dev:
            resultado["disco"].append(_disco(casa))
    except OSError:
        pass
    return resultado


# ---------------------------------------------------------- programas pesados

# Processos que não são "aplicativos": a soma para quando chega neles
_RAIZES = {"systemd", "init", "labwc", "cage", "greetd", "sshd", "sh", "bash", "dash", "sudo", "login",
           "kthreadd", "dbus-daemon", "dbus-broker"}
_NOMES = {"ollama": "Ollama (motor de IA local)", "llama-server": "Ollama (motor de IA local)",
          "Xwayland": "Xwayland (programas antigos)", "pipewire": "PipeWire (som)",
          "wireplumber": "PipeWire (som)", "swaybg": "Papel de parede"}


def _processos():
    """{pid: (ppid, nome, ticks_de_cpu, memoria_bytes)} lidos de /proc."""
    pagina = os.sysconf("SC_PAGE_SIZE")
    processos = {}
    for pasta in Path("/proc").iterdir():
        if not pasta.name.isdigit():
            continue
        try:
            stat = (pasta / "stat").read_text()
            nome = stat[stat.index("(") + 1:stat.rindex(")")]
            campos = stat[stat.rindex(")") + 2:].split()
            ppid, ticks = int(campos[1]), int(campos[11]) + int(campos[12])
            residente = int((pasta / "statm").read_text().split()[1]) * pagina
        except (OSError, ValueError, IndexError):
            continue
        if nome in ("python3", "python") or nome.startswith("python3."):
            nome = _nome_python(pasta) or nome
        processos[int(pasta.name)] = (ppid, nome, ticks, residente)
    return processos


def _nome_python(pasta):
    """Programas em Python aparecem como "python3": usa o nome do programa."""
    try:
        argumentos = (pasta / "cmdline").read_bytes().split(b"\0")
    except OSError:
        return ""
    for i, arg in enumerate(argumentos[1:], 1):
        texto = arg.decode(errors="ignore")
        if texto == "-c":
            return "python"                  # código solto, sem nome de programa
        if texto == "-m" and i + 1 < len(argumentos):
            texto = argumentos[i + 1].decode(errors="ignore")
            return "Wise" if texto.startswith("wise") else texto.split(".")[0]
        if texto and not texto.startswith("-"):
            caminho = Path(texto)
            if caminho.parent.name in ("barra-de-recursos", "ilha-de-aplicativos", "central-de-ia",
                                       "menu-de-energia", "entrada", "bloqueio"):
                return caminho.parent.name.replace("-", " ").capitalize()
            return caminho.stem[:40]
    return ""


def programas_mais_pesados(ordenar_por="processador", quantidade=8):
    """Aplicativos que mais usam processador ou memória agora. Cada aplicativo soma
    os processos dele (ex.: todas as abas do navegador). O processador é medido
    agora, por meio segundo (o "ps" mostra a média desde que o programa abriu)."""
    antes = _processos()
    time.sleep(0.5)
    agora = _processos()
    nucleos = os.cpu_count() or 1
    por_segundo = os.sysconf("SC_CLK_TCK")

    def aplicativo(pid):
        # Sobe na árvore até o processo de cima que ainda é um aplicativo
        visto = set()
        while pid in agora and pid not in visto:
            visto.add(pid)
            ppid = agora[pid][0]
            if ppid <= 1 or ppid not in agora or agora[ppid][1] in _RAIZES:
                return agora[pid][1]
            pid = ppid
        return agora.get(pid, (0, "?"))[1]

    apps = {}
    for pid, (ppid, _nome, ticks, residente) in agora.items():
        if pid == 2 or ppid == 2:
            continue                         # tarefas internas do kernel, não são aplicativos
        nome = _NOMES.get(aplicativo(pid), aplicativo(pid))
        if nome in _RAIZES:
            continue
        cpu = max(0, ticks - antes.get(pid, (0, "", ticks, 0))[2]) / por_segundo / 0.5 / nucleos * 100
        app = apps.setdefault(nome, {"programa": nome, "processos": 0, "processador_percentual": 0.0,
                                     "memoria_mb": 0})
        app["processos"] += 1
        app["processador_percentual"] += cpu
        app["memoria_mb"] += residente / 1024 / 1024
    chave = "processador_percentual" if ordenar_por == "processador" else "memoria_mb"
    lista = sorted(apps.values(), key=lambda a: a[chave], reverse=True)[:quantidade]
    for app in lista:
        app["processador_percentual"] = round(app["processador_percentual"], 1)
        app["memoria_mb"] = round(app["memoria_mb"])
    memoria = _memoria()
    return {"ordenado_por": ordenar_por, "memoria_total_gb": memoria["total_gb"],
            "memoria_em_uso_gb": memoria["em_uso_gb"],
            "processador_percentual_total": round(sum(a["processador_percentual"] for a in apps.values()), 1),
            "aplicativos": lista}


# ------------------------------------------------------------------------ rede

def rede():
    conexoes = []
    for linha in _rodar("nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device").splitlines():
        partes = linha.split(":", 3)
        if len(partes) == 4 and partes[1] in ("wifi", "ethernet"):
            conexoes.append({"dispositivo": partes[0], "tipo": "Wi-Fi" if partes[1] == "wifi" else "cabo",
                             "estado": partes[2], "rede": partes[3]})
    wifi = None
    for linha in _rodar("nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL", "device", "wifi", "list", "--rescan", "no").splitlines():
        if linha.startswith("*:"):
            _, ssid, sinal = (linha.split(":") + ["", ""])[:3]
            wifi = {"rede": ssid, "sinal_percentual": int(sinal) if sinal.isdigit() else None}
    enderecos = []
    for linha in _rodar("ip", "-brief", "address").splitlines():
        partes = linha.split()
        if partes and partes[0] != "lo" and len(partes) >= 3:
            enderecos.append({"dispositivo": partes[0], "enderecos": partes[2:]})
    internet = bool(_rodar("getent", "hosts", "deb.debian.org", tempo=3))
    return {"conexoes": conexoes, "wifi_atual": wifi, "enderecos": enderecos, "internet": internet}


# --------------------------------------------------------------------- sistema

def sobre_o_sistema():
    info = {}
    try:
        for linha in Path("/etc/os-release").read_text().splitlines():
            chave, _, valor = linha.partition("=")
            info[chave] = valor.strip('"')
    except OSError:
        pass
    ligado_ha = float(Path("/proc/uptime").read_text().split()[0])
    return {
        "sistema": info.get("PRETTY_NAME", "desconhecido"),
        "kernel": os.uname().release,
        "arquitetura": os.uname().machine,
        "computador": " ".join(filter(None, [
            _ler("/sys/class/dmi/id/sys_vendor"), _ler("/sys/class/dmi/id/product_name")])) or None,
        "ligado_ha_horas": round(ligado_ha / 3600, 1),
        "versao_dos_pacotes_duiaos": _rodar("dpkg-query", "-W", "-f=${Version}", "duiaos-desktop") or None,
    }


def _ler(caminho):
    try:
        return Path(caminho).read_text().strip()
    except OSError:
        return ""


# ----------------------------------------------------------------- atualizações

def atualizacoes_disponiveis():
    """Lê a lista do apt sem atualizá-la (não precisa de root)."""
    pacotes = []
    for linha in _rodar("apt", "list", "--upgradable", tempo=20).splitlines():
        if "/" not in linha or linha.startswith("Listing"):
            continue
        nome = linha.split("/", 1)[0]
        partes = linha.split()
        pacotes.append({"pacote": nome, "versao_nova": partes[1] if len(partes) > 1 else None})
    lista = Path("/var/lib/apt/lists")
    try:
        verificado = max((p.stat().st_mtime for p in lista.glob("*Release")), default=None)
    except OSError:
        verificado = None
    # Só os nomes dos 10 primeiros: a lista inteira (com versões) passava de mil
    # pedaços de texto e o modelo levava dezenas de segundos só para lê-la
    return {
        "quantidade": len(pacotes),
        "alguns_pacotes": [p["pacote"] for p in pacotes[:10]],
        "ultima_verificacao": datetime.datetime.fromtimestamp(verificado).strftime("%Y-%m-%d %H:%M") if verificado else None,
        "observacao": "Lista da última verificação do apt; o Wise ainda não instala atualizações (W2).",
    }


# ------------------------------------------------------------------ arquivos

def _pasta_permitida(caminho):
    """Só pastas dentro da pasta pessoal; nada de arquivos ocultos de configuração."""
    casa = Path.home().resolve()
    alvo = (casa / caminho).resolve() if not Path(caminho).is_absolute() else Path(caminho).resolve()
    if alvo != casa and casa not in alvo.parents:
        raise ErroDeArgumentos("só posso olhar pastas dentro da sua pasta pessoal")
    if any(parte.startswith(".") for parte in alvo.relative_to(casa).parts):
        raise ErroDeArgumentos("pastas ocultas (de configuração) ficam de fora")
    return alvo


def listar_pasta(pasta="", ordenar_por="nome"):
    alvo = _pasta_permitida(pasta or ".")
    if not alvo.is_dir():
        raise ErroDeArgumentos(f"a pasta '{pasta}' não existe")
    itens = []
    for item in alvo.iterdir():
        if item.name.startswith("."):
            continue
        try:
            info = item.stat()
        except OSError:
            continue
        itens.append({"nome": item.name, "tipo": "pasta" if item.is_dir() else "arquivo",
                      "tamanho_mb": round(info.st_size / 1024 ** 2, 2) if item.is_file() else None,
                      "modificado": datetime.datetime.fromtimestamp(info.st_mtime).strftime("%Y-%m-%d %H:%M")})
    chave = {"nome": lambda i: i["nome"].casefold(),
             "tamanho": lambda i: -(i["tamanho_mb"] or 0),
             "modificado": lambda i: i["modificado"]}[ordenar_por]
    itens.sort(key=chave, reverse=(ordenar_por == "modificado"))
    return {"pasta": str(alvo), "quantidade": len(itens), "itens": itens[:LIMITE_ITENS]}


FERRAMENTAS = [
    Ferramenta("data_e_hora", "Data e hora",
               "Data, hora, dia da semana e fuso horário atuais.", data_e_hora),
    Ferramenta("uso_do_computador", "Uso do computador",
               "Uso atual do processador, da memória e do disco, temperatura e bateria. "
               "Use para perguntas sobre lentidão, memória, espaço livre ou bateria.",
               uso_do_computador),
    Ferramenta("programas_mais_pesados", "Programas mais pesados",
               "Lista os aplicativos que mais usam processador ou memória agora, com o consumo de cada "
               "um (processador em % do total e memória em MB). Soma os processos de cada aplicativo.",
               programas_mais_pesados,
               {"type": "object", "properties": {
                   "ordenar_por": {"type": "string", "enum": ["processador", "memoria"],
                                   "description": "Critério de ordenação."},
                   "quantidade": {"type": "integer", "minimum": 1, "maximum": 20,
                                  "description": "Quantos aplicativos listar (padrão 8)."}}}),
    Ferramenta("rede", "Rede e internet",
               "Estado do Wi-Fi e do cabo, rede conectada, força do sinal, endereços e se há internet.",
               rede),
    Ferramenta("sobre_o_sistema", "Sobre o sistema",
               "Versão do DuiaOS, kernel, arquitetura, modelo do computador e há quanto tempo está ligado.",
               sobre_o_sistema),
    Ferramenta("atualizacoes_disponiveis", "Atualizações disponíveis",
               "Quais pacotes têm atualização disponível segundo a última verificação do sistema. "
               "Só consulta; não instala nada.",
               atualizacoes_disponiveis),
    Ferramenta("listar_pasta", "Arquivos de uma pasta",
               "Lista arquivos e pastas de uma pasta dentro da pasta pessoal (ex.: 'Documentos', "
               "'Downloads'). Não abre nem altera arquivos.",
               listar_pasta,
               {"type": "object", "properties": {
                   "pasta": {"type": "string",
                             "description": "Caminho relativo à pasta pessoal; vazio = a própria pasta pessoal."},
                   "ordenar_por": {"type": "string", "enum": ["nome", "tamanho", "modificado"]}}}),
]
