"""Wise no D-Bus da sessão (org.duiaos.Wise1): as telas de Configurações do DuiaOS leem e mudam por aqui
as preferências do Wise, e a Barra de Recursos pede para abrir ou desligar (ADR 063 do DuiaOS).

  Estado() -> s            JSON com as preferências, os motores e modelos, a agenda, a cidade e a voz
  Definir(chave s, valor s)
  Acao(nome s, json s)     ações com parâmetros (cidade, agenda, voz, mostrar, desligar…)
  sinal Mudou(json s)

O D-Bus roda numa linha própria (GLib); os pedidos são entregues à interface por sinais do Qt, e o
Estado devolve a última fotografia montada pela interface. Só a própria pessoa alcança o barramento
da sessão dela. Os valores são conferidos por quem os aplica (a Ponte): aqui nada é executado.
"""
import threading

NOME = "org.duiaos.Wise1"
CAMINHO = "/org/duiaos/Wise1"
XML = """
<node>
  <interface name="org.duiaos.Wise1">
    <method name="Estado"><arg name="json" type="s" direction="out"/></method>
    <method name="Definir"><arg name="chave" type="s" direction="in"/><arg name="valor" type="s" direction="in"/></method>
    <method name="Acao"><arg name="nome" type="s" direction="in"/><arg name="json" type="s" direction="in"/></method>
    <signal name="Mudou"><arg name="json" type="s"/></signal>
  </interface>
</node>
"""


class Servico:
    def __init__(self, ao_definir, ao_acao):
        """ao_definir(chave, valor) e ao_acao(nome, json) são chamados na linha do D-Bus: devem só
        emitir sinais do Qt (que entregam na linha da interface)."""
        self._ao_definir, self._ao_acao = ao_definir, ao_acao
        self._estado = "{}"
        self._conexao = None
        self._laco = None
        self._trava = threading.Lock()
        threading.Thread(target=self._rodar, name="wise-dbus", daemon=True).start()

    def publicar(self, estado_json):
        with self._trava:
            mudou = estado_json != self._estado
            self._estado = estado_json
        if mudou and self._conexao is not None:
            try:
                from gi.repository import GLib
                self._conexao.emit_signal(None, CAMINHO, NOME, "Mudou", GLib.Variant("(s)", (estado_json,)))
            except Exception:  # noqa: BLE001 — barramento caiu: as telas pedem o Estado de novo
                pass

    def _rodar(self):
        try:
            import gi
            gi.require_version("Gio", "2.0")
            from gi.repository import Gio, GLib
        except (ImportError, ValueError):
            return
        no = Gio.DBusNodeInfo.new_for_xml(XML)

        def ao_chamar(_conexao, _remetente, _caminho, _interface, metodo, parametros, invocacao):
            try:
                if metodo == "Estado":
                    with self._trava:
                        invocacao.return_value(GLib.Variant("(s)", (self._estado,)))
                    return
                argumentos = parametros.unpack()
                if metodo == "Definir":
                    self._ao_definir(str(argumentos[0])[:60], str(argumentos[1])[:4000])
                elif metodo == "Acao":
                    self._ao_acao(str(argumentos[0])[:60], str(argumentos[1])[:8000])
                invocacao.return_value(None)
            except Exception as erro:  # noqa: BLE001
                invocacao.return_dbus_error("org.duiaos.Wise1.Erro", str(erro)[:200])

        def ao_conectar(conexao, _nome):
            self._conexao = conexao
            conexao.register_object(CAMINHO, no.interfaces[0], ao_chamar, None, None)

        contexto = GLib.MainContext.new()
        contexto.push_thread_default()
        self._laco = GLib.MainLoop.new(contexto, False)
        Gio.bus_own_name(Gio.BusType.SESSION, NOME, Gio.BusNameOwnerFlags.NONE, ao_conectar, None, None)
        self._laco.run()

    def parar(self):
        if self._laco is not None:
            self._laco.quit()
