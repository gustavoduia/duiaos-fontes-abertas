"""Janela do Wise."""
