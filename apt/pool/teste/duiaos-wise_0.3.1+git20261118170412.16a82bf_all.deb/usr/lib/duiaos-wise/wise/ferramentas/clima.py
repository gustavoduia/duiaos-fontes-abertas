"""Previsão do tempo (N0) e cidade da previsão (N1, preferência do próprio Wise).

Fontes (W13):
- Previsão: MET Norway, Locationforecast 2.0 (api.met.no) — dados CC BY 4.0,
  uso comercial permitido, sem chave; pede identificação (User-Agent), no
  máximo 4 casas decimais nas coordenadas e respeito ao cabeçalho Expires
  (cache local). O Open-Meteo foi descartado: a API gratuita é só para uso
  não comercial.
- Cidade → coordenadas: Nominatim (OpenStreetMap, ODbL), uma consulta quando a
  pessoa escolhe a cidade; o resultado fica guardado nas preferências.

Privacidade: só a posição da cidade (não a da pessoa) sai do computador.
"""
import datetime
import email.utils
import json
import os
import time
import urllib.parse
from collections import Counter
from pathlib import Path

from ..configuracao import PASTA_CONFIG
from ..internet import SemInternet, baixar, baixar_json
from .base import ErroDeArgumentos, Ferramenta

PREVISAO = "https://api.met.no/weatherapi/locationforecast/2.0/compact"
GEOCODIFICAR = "https://nominatim.openstreetmap.org/search"
CACHE = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "duiaos" / "wise" / "clima"
FONTE = "MET Norway (CC BY 4.0)"
ARQUIVO_CIDADE = PASTA_CONFIG / "cidade.json"

CONDICOES = {
    "clearsky": "céu limpo", "fair": "poucas nuvens", "partlycloudy": "parcialmente nublado",
    "cloudy": "nublado", "fog": "neblina",
    "lightrain": "chuva fraca", "rain": "chuva", "heavyrain": "chuva forte",
    "lightrainshowers": "pancadas de chuva fracas", "rainshowers": "pancadas de chuva",
    "heavyrainshowers": "pancadas de chuva fortes",
    "lightrainandthunder": "chuva fraca com trovoadas", "rainandthunder": "chuva com trovoadas",
    "heavyrainandthunder": "chuva forte com trovoadas",
    "lightrainshowersandthunder": "pancadas de chuva com trovoadas",
    "rainshowersandthunder": "pancadas de chuva com trovoadas",
    "heavyrainshowersandthunder": "pancadas de chuva forte com trovoadas",
    "lightsleet": "chuva com neve fraca", "sleet": "chuva com neve", "heavysleet": "chuva com neve forte",
    "lightsnow": "neve fraca", "snow": "neve", "heavysnow": "neve forte",
}
DIAS = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo"]


def _condicao(simbolo):
    base = str(simbolo or "").split("_")[0]
    if base in CONDICOES:
        return CONDICOES[base]
    if "thunder" in base:
        return "trovoadas"
    if "snow" in base or "sleet" in base:
        return "neve"
    if "rain" in base:
        return "chuva"
    return "sem informação"


def _chove(simbolo):
    return any(p in str(simbolo or "") for p in ("rain", "sleet", "snow"))


# ---------------------------------------------------------------- cidade
def cidade_escolhida(arquivo=None):
    """{"cidade", "lat", "lon"} guardado, ou None."""
    try:
        dados = json.loads(Path(arquivo or ARQUIVO_CIDADE).read_text())
        lat, lon = float(dados["lat"]), float(dados["lon"])
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            return {"cidade": str(dados.get("cidade", ""))[:120], "lat": lat, "lon": lon}
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return None


def guardar_cidade(descricao, lat, lon, arquivo=None):
    arquivo = Path(arquivo or ARQUIVO_CIDADE)
    arquivo.parent.mkdir(parents=True, exist_ok=True)
    arquivo.write_text(json.dumps({"cidade": descricao, "lat": round(lat, 4), "lon": round(lon, 4)},
                                  ensure_ascii=False))


def esquecer_cidade(arquivo=None):
    try:
        Path(arquivo or ARQUIVO_CIDADE).unlink()
    except OSError:
        pass


def procurar_cidades(nome, quantidade=5):
    """[{"nome", "descricao", "lat", "lon"}] para um nome de cidade."""
    parametros = urllib.parse.urlencode({"q": nome, "format": "jsonv2", "limit": quantidade,
                                         "addressdetails": 1, "accept-language": "pt-BR"})
    dados = baixar_json(f"{GEOCODIFICAR}?{parametros}")
    achadas = []
    for item in dados if isinstance(dados, list) else []:
        try:
            lat, lon = round(float(item["lat"]), 4), round(float(item["lon"]), 4)
        except (KeyError, TypeError, ValueError):
            continue
        endereco = item.get("address") or {}
        nome_cidade = str(endereco.get("city") or endereco.get("town") or endereco.get("village")
                          or endereco.get("municipality") or item.get("name") or "")[:80]
        partes = [nome_cidade, endereco.get("state"), endereco.get("country")]
        achadas.append({"nome": nome_cidade, "descricao": ", ".join(str(p)[:60] for p in partes if p),
                        "lat": lat, "lon": lon, "pais": str(endereco.get("country_code", ""))[:2]})
    # Cidades do Brasil primeiro (público do DuiaOS), sem repetir
    vistas, unicas = set(), []
    for c in sorted(achadas, key=lambda c: c["pais"] != "br"):
        if c["descricao"] not in vistas:
            vistas.add(c["descricao"])
            unicas.append(c)
    return unicas


def definir_cidade(cidade, escolha=0):
    nome = " ".join(str(cidade).split())[:100]
    if len(nome) < 2:
        raise ErroDeArgumentos("diga o nome da cidade")
    try:
        cidades = procurar_cidades(nome)
    except SemInternet as erro:
        return {"erro": f"não consegui procurar a cidade: {erro}"}
    if not cidades:
        return {"erro": f"não achei a cidade '{nome}'. Pode dizer também o estado?"}
    if len(cidades) > 1 and not escolha:
        # "Serra, Espírito Santo": uma só cidade com esse nome nesse estado → é ela
        partes = [p.strip().lower() for p in nome.split(",")]
        certas = [c for c in cidades if c["nome"].lower() == partes[0]
                  and all(p in c["descricao"].lower() for p in partes[1:])]
        if len(certas) == 1 and len(partes) > 1:
            cidades = certas
    if len(cidades) > 1 and not escolha:
        # Mais de uma: a pessoa escolhe (o modelo pergunta e chama de novo com "escolha")
        return {"precisa_escolher": True, "opcoes": [{"escolha": i + 1, "cidade": c["descricao"]}
                                                     for i, c in enumerate(cidades[:4])]}
    indice = max(0, min((escolha or 1) - 1, len(cidades) - 1))
    c = cidades[indice]
    guardar_cidade(c["descricao"], c["lat"], c["lon"])
    return {"cidade_definida": c["descricao"]}


# --------------------------------------------------------------- previsão
def _ler_cache(lat, lon):
    arquivo = CACHE / f"{lat:.4f}_{lon:.4f}.json"
    try:
        return arquivo, json.loads(arquivo.read_text())
    except (OSError, ValueError):
        return arquivo, None


def buscar_previsao(lat, lon, agora=None):
    """Previsão do MET Norway com cache (respeita Expires e usa If-Modified-Since)."""
    lat, lon = round(lat, 4), round(lon, 4)
    agora = agora or time.time()
    arquivo, cache = _ler_cache(lat, lon)
    if cache and cache.get("expira", 0) > agora:
        return cache["dados"]
    cabecalhos = {"If-Modified-Since": cache["modificado"]} if cache and cache.get("modificado") else {}
    try:
        codigo, cab, corpo = baixar(f"{PREVISAO}?lat={lat}&lon={lon}", cabecalhos)
    except SemInternet:
        if cache:                                   # sem internet: a última previsão serve, com aviso
            cache["dados"]["_antiga"] = True
            return cache["dados"]
        raise
    cab = {k.lower(): v for k, v in cab.items()}
    if codigo == 304 and cache:
        dados = cache["dados"]
    else:
        try:
            dados = json.loads(corpo)
        except ValueError as erro:
            raise SemInternet("o serviço de previsão mandou uma resposta que não entendi") from erro
    expira = agora + 1800
    if cab.get("expires"):
        try:
            expira = email.utils.parsedate_to_datetime(cab["expires"]).timestamp()
        except (TypeError, ValueError):
            pass
    try:
        CACHE.mkdir(parents=True, exist_ok=True)
        arquivo.write_text(json.dumps({"expira": expira, "modificado": cab.get("last-modified", ""),
                                       "dados": dados}))
    except OSError:
        pass
    return dados


def resumir(dados, dias=3, fuso=None, agora=None):
    """Transforma a resposta do MET Norway em agora + dias, já em português."""
    fuso = fuso or datetime.datetime.now().astimezone().tzinfo
    agora = agora or datetime.datetime.now(datetime.timezone.utc)
    serie = []
    for item in (dados.get("properties") or {}).get("timeseries") or []:
        try:
            quando = datetime.datetime.fromisoformat(str(item["time"]).replace("Z", "+00:00"))
            detalhes = item["data"]["instant"]["details"]
        except (KeyError, TypeError, ValueError):
            continue
        prox1 = (item["data"].get("next_1_hours") or {})
        prox6 = (item["data"].get("next_6_hours") or {})
        simbolo = (prox1.get("summary") or prox6.get("summary") or {}).get("symbol_code", "")
        chuva = (prox1.get("details") or {}).get("precipitation_amount")
        serie.append({"quando": quando, "temp": detalhes.get("air_temperature"), "simbolo": simbolo,
                      "chuva_1h": chuva, "chuva_6h": (prox6.get("details") or {}).get("precipitation_amount"),
                      "vento": detalhes.get("wind_speed"), "umidade": detalhes.get("relative_humidity")})
    serie = [s for s in serie if isinstance(s["temp"], (int, float))]
    if not serie:
        return {"erro": "a previsão veio vazia"}
    atual = min(serie, key=lambda s: abs((s["quando"] - agora).total_seconds()))
    resultado = {
        "agora": {"temperatura_c": round(atual["temp"]), "condicao": _condicao(atual["simbolo"]),
                  "vento_kmh": round((atual["vento"] or 0) * 3.6),
                  "umidade": round(atual["umidade"]) if isinstance(atual["umidade"], (int, float)) else None},
        "dias": [], "fonte": FONTE,
    }
    hoje = agora.astimezone(fuso).date()
    por_dia = {}
    for s in serie:
        dia = s["quando"].astimezone(fuso)
        por_dia.setdefault(dia.date(), []).append((dia.hour, s))
    for data in sorted(por_dia)[: dias + 1]:
        if data < hoje or len(resultado["dias"]) >= dias:
            continue
        horas = por_dia[data]
        temps = [s["temp"] for _h, s in horas]
        diurnos = [s["simbolo"] for h, s in horas if 6 <= h <= 18 and s["simbolo"]] or \
                  [s["simbolo"] for _h, s in horas if s["simbolo"]]
        # Chuva do dia: soma das horas (quando há) ou dos blocos de 6 h
        uma_hora = [s["chuva_1h"] for _h, s in horas if isinstance(s["chuva_1h"], (int, float))]
        if len(uma_hora) >= 12:
            chuva = sum(uma_hora)
        else:
            chuva = sum(s["chuva_6h"] for h, s in horas if h % 6 == 0 and isinstance(s["chuva_6h"], (int, float)))
        horas_chuva = [h for h, s in horas if _chove(s["simbolo"])]
        nome = "hoje" if data == hoje else "amanhã" if data == hoje + datetime.timedelta(days=1) \
            else DIAS[data.weekday()]
        resultado["dias"].append({
            "dia": nome, "data": data.isoformat(), "minima_c": round(min(temps)), "maxima_c": round(max(temps)),
            "condicao": _condicao(Counter(diurnos).most_common(1)[0][0]) if diurnos else "sem informação",
            "chuva_mm": round(chuva, 1),
            "chuva_por_volta_de": f"{horas_chuva[0]:02d}h" if horas_chuva else None,
        })
    if dados.get("_antiga"):
        resultado["aviso"] = "sem internet agora: esta é a última previsão guardada"
    return resultado


def previsao_do_tempo(dias=3, cidade=""):
    # Sempre hoje e amanhã: com dias=1 o modelo chegou a dizer que a previsão de hoje era a de amanhã
    dias = max(int(dias or 3), 2)
    cidade = " ".join(str(cidade or "").split())[:100]
    fuso = None
    if cidade:
        try:
            achadas = procurar_cidades(cidade, 3)
        except SemInternet as erro:
            return {"erro": str(erro)}
        if not achadas:
            return {"erro": f"não achei a cidade '{cidade}'"}
        alvo = achadas[0]
        nome, lat, lon = alvo["descricao"], alvo["lat"], alvo["lon"]
        # Fuso aproximado pela longitude (cidades de outro fuso); a da pessoa usa o do sistema
        fuso = datetime.timezone(datetime.timedelta(hours=round(lon / 15)))
    else:
        escolhida = cidade_escolhida()
        if escolhida is None:
            return {"precisa_cidade": True,
                    "orientacao": "pergunte à pessoa em qual cidade ela está e chame definir_cidade"}
        nome, lat, lon = escolhida["cidade"], escolhida["lat"], escolhida["lon"]
    try:
        dados = buscar_previsao(lat, lon)
    except SemInternet as erro:
        return {"erro": f"não consegui a previsão: {erro}"}
    return {"cidade": nome, **resumir(dados, dias, fuso)}


FERRAMENTAS = [
    Ferramenta("previsao_do_tempo", "Previsão do tempo",
               "Tempo agora e previsão dos próximos dias (temperatura, chuva, vento) na cidade da pessoa ou "
               "em outra cidade. Cada dia vem com o nome ('hoje', 'amanhã', 'quarta'...): responda com o dia "
               "que a pessoa perguntou. Se a resposta pedir a cidade, pergunte à pessoa.",
               previsao_do_tempo,
               {"type": "object", "properties": {
                   "dias": {"type": "integer", "minimum": 1, "maximum": 7,
                            "description": "Quantos dias a partir de hoje (padrão 3; hoje e amanhã sempre vêm)."},
                   "cidade": {"type": "string",
                              "description": "Outra cidade que a pessoa citou; vazio = a cidade da pessoa."}}},
               da_pessoa=("cidade",)),
    Ferramenta("definir_cidade", "Cidade da previsão",
               "Guarda a cidade da pessoa para a previsão do tempo, só com a cidade que ELA disser (nunca "
               "escolha uma). Se houver mais de uma cidade com o nome, mostre as opções e chame de novo com "
               "'escolha'.",
               definir_cidade,
               {"type": "object", "properties": {
                   "cidade": {"type": "string", "description": "Nome da cidade, de preferência com o estado."},
                   "escolha": {"type": "integer", "minimum": 1, "maximum": 4,
                               "description": "Número da opção escolhida pela pessoa."}},
                "required": ["cidade"]},
               nivel="N1", da_pessoa=("cidade",)),
]
