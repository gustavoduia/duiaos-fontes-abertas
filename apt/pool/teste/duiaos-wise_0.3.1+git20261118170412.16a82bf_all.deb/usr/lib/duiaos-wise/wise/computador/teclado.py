"""Teclado virtual na janela em foco (wtype, protocolo virtual-keyboard do labwc)."""
import re
import shutil
import subprocess

TECLAS = {"enter": "Return", "return": "Return", "tab": "Tab", "esc": "Escape", "escape": "Escape",
          "backspace": "BackSpace", "apagar": "BackSpace", "delete": "Delete", "del": "Delete",
          "espaco": "space", "espaço": "space", "space": "space", "cima": "Up", "baixo": "Down",
          "esquerda": "Left", "direita": "Right", "up": "Up", "down": "Down", "left": "Left", "right": "Right",
          "home": "Home", "end": "End", "pageup": "Prior", "pagedown": "Next",
          **{f"f{n}": f"F{n}" for n in range(1, 13)}}
MODIFICADORES = {"ctrl": "ctrl", "control": "ctrl", "shift": "shift", "alt": "alt", "super": "logo",
                 "logo": "logo", "win": "logo"}


class SemTeclado(Exception):
    pass


def _wtype(argumentos):
    if not shutil.which("wtype"):
        raise SemTeclado("o teclado virtual (wtype) não está instalado")
    r = subprocess.run(["wtype", *argumentos], capture_output=True, text=True, timeout=30, check=False)
    if r.returncode != 0:
        raise SemTeclado("o teclado virtual falhou: " + (r.stderr.strip()[:120] or "sem mensagem"))


def digitar(texto):
    texto = str(texto)
    if len(texto) > 4000:
        raise SemTeclado("texto grande demais para digitar de uma vez")
    _wtype(["-d", "8", "--", texto])


def converter_atalho(atalho):
    """'Ctrl+S' -> argumentos do wtype (-M ctrl -k s -m ctrl). Valida tudo."""
    partes = [p.strip().lower() for p in re.split(r"\s*\+\s*", str(atalho).strip()) if p.strip()]
    if not partes or len(partes) > 4:
        raise SemTeclado("atalho inválido")
    *mods, tecla = partes
    argumentos = []
    for m in mods:
        if m not in MODIFICADORES:
            raise SemTeclado(f"tecla modificadora desconhecida: {m}")
        argumentos += ["-M", MODIFICADORES[m]]
    if tecla in TECLAS:
        nome = TECLAS[tecla]
    elif len(tecla) == 1 and tecla.isprintable():
        nome = tecla
    else:
        raise SemTeclado(f"tecla desconhecida: {tecla}")
    argumentos += ["-k", nome]
    for m in reversed(mods):
        argumentos += ["-m", MODIFICADORES[m]]
    return argumentos


def teclas(atalho):
    _wtype(converter_atalho(atalho))
