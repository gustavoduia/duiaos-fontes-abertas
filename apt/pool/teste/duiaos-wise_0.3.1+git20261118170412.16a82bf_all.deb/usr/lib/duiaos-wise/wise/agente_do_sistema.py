"""Cliente do agente do sistema (duiaos-agente, D-Bus org.duiaos.Agente1).

O Wise nunca roda nada como administrador: pede ao agente do DuiaOS um plano
(simulação, sem mudar nada), mostra o impacto à pessoa e, se ela aprovar, pede
para executar. O agente confere tudo de novo (polkit, plano da mesma pessoa,
impacto igual ao aprovado) e registra em /var/log/duiaos-agente.

O que vem do agente é dado: textos são cortados e números conferidos antes de
irem para a tela ou para o modelo.
"""
import json
import time

NOME = "org.duiaos.Agente1"
CAMINHO = "/org/duiaos/Agente1"


class AgenteIndisponivel(Exception):
    """Sem o agente do sistema (fora do DuiaOS ou pacote duiaos-agente ausente)."""


class Recusado(Exception):
    """O agente recusou; a mensagem é para a pessoa."""


def _gio():
    try:
        import gi
        gi.require_version("Gio", "2.0")
        from gi.repository import Gio, GLib
        return Gio, GLib
    except (ImportError, ValueError) as erro:
        raise AgenteIndisponivel("o DuiaOS não tem o agente do sistema neste computador") from erro


class Agente:
    def __init__(self, barramento=None):
        self._barramento = barramento      # Gio.BusType; None = sistema
        self._conexao = None

    def _chamar(self, metodo, parametros=None, tipo="()", tempo=600):
        Gio, GLib = _gio()
        try:
            if self._conexao is None:
                self._conexao = Gio.bus_get_sync(self._barramento or Gio.BusType.SYSTEM, None)
            resposta = self._conexao.call_sync(NOME, CAMINHO, NOME, metodo, parametros, GLib.VariantType(tipo),
                                               Gio.DBusCallFlags.NONE, tempo * 1000, None)
        except GLib.Error as erro:
            mensagem = erro.message.split(": ", 1)[-1] if ": " in erro.message else erro.message
            if "ServiceUnknown" in erro.message or "NameHasNoOwner" in erro.message:
                raise AgenteIndisponivel("o agente do sistema (duiaos-agente) não está instalado") from erro
            raise Recusado(mensagem[:300]) from erro
        return resposta.unpack()

    def preparar(self, acao, argumentos):
        """Plano do agente: {"id", "resumo", "mudancas", "baixar_bytes", "espaco_bytes", "recusa"}."""
        _Gio, GLib = _gio()
        texto = self._chamar("Preparar", GLib.Variant("(ss)", (acao, json.dumps(argumentos))), "(s)")[0]
        plano = json.loads(texto)
        if not isinstance(plano, dict) or not isinstance(plano.get("id"), str):
            raise Recusado("resposta inesperada do agente do sistema")
        return plano

    def estado(self):
        return json.loads(self._chamar("Estado", None, "(s)", tempo=10)[0])

    def cancelar(self):
        self._chamar("Cancelar", None, "()", tempo=10)

    def executar(self, id_plano, ao_progresso, cancelado, intervalo=0.5):
        """Executa um plano já aprovado e acompanha até o fim. Devolve a "ultima"
        do agente: {"resultado": "ok"|"erro"|"recusada"|"cancelada", "mensagem"}."""
        _Gio, GLib = _gio()
        self._chamar("Executar", GLib.Variant("(s)", (id_plano,)), "()", tempo=30)
        pediu_cancelar = False
        while True:
            time.sleep(intervalo)
            if cancelado.is_set() and not pediu_cancelar:
                pediu_cancelar = True
                try:
                    self.cancelar()
                except Recusado as erro:       # já está instalando: segue até o fim
                    ao_progresso(None, str(erro))
            estado = self.estado()
            tarefa, ultima = estado.get("tarefa"), estado.get("ultima")
            if tarefa and tarefa.get("id") == id_plano:
                fracao = tarefa.get("fracao")
                ao_progresso(float(fracao) if isinstance(fracao, (int, float)) else None,
                             str(tarefa.get("mensagem") or "")[:120])
            elif ultima and ultima.get("id") == id_plano:
                return {"resultado": str(ultima.get("resultado", "erro"))[:20],
                        "mensagem": str(ultima.get("mensagem", ""))[:300]}
            elif not tarefa:
                return {"resultado": "erro", "mensagem": "o agente do sistema parou sem dizer o resultado"}


def tamanho_legivel(n):
    n = int(n or 0)
    if n >= 1024 ** 3:
        return f"{n / 1024 ** 3:.1f} GB".replace(".", ",")
    if n >= 1024 ** 2:
        return f"{n / 1024 ** 2:.0f} MB"
    return f"{max(n, 0) // 1024} KB"
