"""Preferências do Wise (~/.config/duiaos/wise/wise.conf).

Nada sensível fica aqui: a chave do Gemini vai para o cofre do sistema
(wise.segredos).
"""
import configparser
import os
from dataclasses import dataclass, field
from pathlib import Path

PASTA_CONFIG = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "duiaos" / "wise"
PASTA_DADOS = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "duiaos" / "wise"
ARQUIVO = PASTA_CONFIG / "wise.conf"

# Provedor: "automatico" usa o local quando disponível e o Gemini quando não;
# "local" e "gemini" forçam um deles.
PROVEDORES = ("automatico", "local", "gemini", "openai")
# Saudação ao entrar na sessão: "fala" e "fala_e_escrita" chegam com a voz (W3).
SAUDACOES = ("escrita", "fala", "fala_e_escrita", "desativada")


# Vozes do duiaos-voz (o nome é o que a tela mostra; o resto é com o duiaos-voz)
VOZES = ("dora", "alex", "santa", "faber")


def _velocidade(texto):
    try:
        return min(1.5, max(0.7, float(str(texto).replace(",", "."))))
    except ValueError:
        return 1.0


@dataclass
class Configuracao:
    provedor: str = "automatico"
    # Consentimento explícito para enviar pedidos à nuvem (privacidade por padrão)
    nuvem_permitida: bool = False
    modelo_gemini: str = "gemini-3.8-flash"
    modelo_local: str = "qwen3.5:4b"
    modelo_local_leve: str = "qwen3.5:2b"     # computadores com menos de 8 GB de memória
    endereco_local: str = "http://127.0.0.1:11434"
    saudacao: str = "escrita"
    # Wise usando a tela (W15): pedir aprovação para TODA ação, não só as arriscadas
    aprovar_toda_acao_na_tela: bool = False
    # Voz (duiaos-voz): respostas faladas, a voz escolhida e a velocidade
    falar_respostas: bool = False
    voz: str = "dora"
    velocidade_da_voz: float = 1.0
    extras: dict = field(default_factory=dict)

    @classmethod
    def carregar(cls, arquivo=ARQUIVO):
        dados = configparser.ConfigParser()
        dados.read(arquivo)
        sec = dados["wise"] if dados.has_section("wise") else {}
        padrao = cls()
        provedor = sec.get("provedor", padrao.provedor)
        return cls(
            provedor=provedor if provedor in PROVEDORES else padrao.provedor,
            nuvem_permitida=str(sec.get("nuvem_permitida", "nao")).lower() in ("sim", "true", "1"),
            modelo_gemini=sec.get("modelo_gemini", padrao.modelo_gemini),
            modelo_local=sec.get("modelo_local", padrao.modelo_local),
            modelo_local_leve=sec.get("modelo_local_leve", padrao.modelo_local_leve),
            endereco_local=sec.get("endereco_local", padrao.endereco_local),
            aprovar_toda_acao_na_tela=str(sec.get("aprovar_toda_acao_na_tela", "nao")).lower() in ("sim", "true", "1"),
            falar_respostas=str(sec.get("falar_respostas", "nao")).lower() in ("sim", "true", "1"),
            voz=sec.get("voz", padrao.voz) if sec.get("voz", padrao.voz) in VOZES else padrao.voz,
            velocidade_da_voz=_velocidade(sec.get("velocidade_da_voz", "1.0")),
            saudacao=sec.get("saudacao", padrao.saudacao) if sec.get("saudacao", padrao.saudacao) in SAUDACOES
            else padrao.saudacao,
        )

    def salvar(self, arquivo=ARQUIVO):
        arquivo = Path(arquivo)
        arquivo.parent.mkdir(parents=True, exist_ok=True)
        dados = configparser.ConfigParser()
        dados["wise"] = {
            "provedor": self.provedor,
            "nuvem_permitida": "sim" if self.nuvem_permitida else "nao",
            "modelo_gemini": self.modelo_gemini,
            "modelo_local": self.modelo_local,
            "modelo_local_leve": self.modelo_local_leve,
            "endereco_local": self.endereco_local,
            "saudacao": self.saudacao,
            "aprovar_toda_acao_na_tela": "sim" if self.aprovar_toda_acao_na_tela else "nao",
            "falar_respostas": "sim" if self.falar_respostas else "nao",
            "voz": self.voz,
            "velocidade_da_voz": f"{self.velocidade_da_voz:.2f}",
        }
        with open(arquivo, "w", encoding="utf-8") as saida:
            saida.write("# DuiaOS — preferências do Wise. A chave do Gemini fica no cofre do sistema.\n")
            dados.write(saida)


def memoria_total_gb():
    try:
        for linha in Path("/proc/meminfo").read_text().splitlines():
            if linha.startswith("MemTotal:"):
                return int(linha.split()[1]) / 1024 / 1024
    except (OSError, ValueError, IndexError):
        pass
    return 0.0


def modelo_local_adequado(config):
    """Modelo local conforme a memória do computador."""
    return config.modelo_local if memoria_total_gb() >= 8 else config.modelo_local_leve
