"""Voz do Wise: falar e ouvir pelo comando duiaos-voz do sistema (ADR 063 do DuiaOS).

O duiaos-voz é um programa separado (GPL-3, com o motor de voz); o Wise só conversa com ele pela
linha de comando: manda texto pela entrada e lê linhas JSON da saída. Nada de áudio passa pelo Wise.
"""
import json
import os
import re
import shutil
import subprocess
import threading

COMANDO = os.environ.get("DUIAOS_VOZ", "duiaos-voz")
# Fim de frase: ponto, exclamação, interrogação, dois-pontos ou quebra de linha (e ao menos 12 letras,
# para não picar "Sr." ou "1." em frases de uma palavra)
_FIM_DE_FRASE = re.compile(r"(?<=[.!?…:])\s+|\n+")


def disponivel():
    return shutil.which(COMANDO) is not None


def estado():
    """O que o duiaos-voz tem instalado (dict), ou {} sem ele."""
    if not disponivel():
        return {}
    try:
        saida = subprocess.run([COMANDO, "estado"], capture_output=True, text=True, timeout=20).stdout
        dados = json.loads(saida.strip().splitlines()[-1])
        return dados if isinstance(dados, dict) else {}
    except (OSError, subprocess.SubprocessError, ValueError, IndexError):
        return {}


def frases_prontas(texto, ja_faladas):
    """Frases completas de um texto que ainda está sendo escrito, a partir do que já foi falado.
    Devolve (frases novas, quantos caracteres ficam marcados como falados)."""
    resto = texto[ja_faladas:]
    frases, posicao = [], 0
    for corte in _FIM_DE_FRASE.finditer(resto):
        frase = resto[posicao:corte.start()].strip()
        if len(frase) >= 12:
            frases.append(frase)
            posicao = corte.end()
    return frases, ja_faladas + posicao


class Fala:
    """Uma fala em andamento: as frases entram com dizer() e saem na ordem, sem intervalo."""

    def __init__(self, voz="dora", velocidade=1.0, ao_terminar=None, ao_evento=None):
        self._ao_terminar = ao_terminar or (lambda: None)
        self._ao_evento = ao_evento or (lambda _dados: None)
        self._processo = subprocess.Popen([COMANDO, "falar", "--voz", voz, "--velocidade", f"{velocidade:.2f}"],
                                          stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                          text=True, bufsize=1)
        threading.Thread(target=self._ler, daemon=True).start()

    def _ler(self):
        try:
            for linha in self._processo.stdout:
                try:
                    self._ao_evento(json.loads(linha))
                except ValueError:
                    continue
        finally:
            self._ao_terminar()

    def dizer(self, frase):
        frase = " ".join(str(frase).split())
        if not frase:
            return
        try:
            self._processo.stdin.write(frase + "\n")
            self._processo.stdin.flush()
        except (OSError, ValueError):
            pass

    def concluir(self):
        """Não há mais frases: termina de falar o que já entrou."""
        try:
            self._processo.stdin.close()
        except (OSError, ValueError):
            pass

    def calar(self):
        """Para na hora."""
        try:
            self._processo.terminate()
        except OSError:
            pass


class Escuta:
    """Ouve o microfone até a pessoa parar de falar. ao_evento recebe {"nivel"}, {"transcrevendo"},
    e no fim {"texto", "fim"} ou {"erro"}."""

    def __init__(self, ao_evento, preciso=False):
        self._ao_evento = ao_evento
        comando = [COMANDO, "ouvir"] + (["--preciso"] if preciso else [])
        self._processo = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1)
        threading.Thread(target=self._ler, daemon=True).start()

    def _ler(self):
        terminou = False
        for linha in self._processo.stdout:
            try:
                dados = json.loads(linha)
            except ValueError:
                continue
            if "fim" in dados or "erro" in dados:
                terminou = True
            self._ao_evento(dados)
        if not terminou:
            self._ao_evento({"erro": "o reconhecimento de fala parou antes da hora", "fim": True})

    def parar(self):
        """A pessoa clicou de novo: para de ouvir e transcreve o que já ouviu."""
        try:
            self._processo.terminate()
        except OSError:
            pass


def baixar(item, ao_andar):
    """Baixa uma voz ou o reconhecimento; ao_andar recebe {"fracao"} e, no fim, {"pronto"} ou {"erro"}."""
    processo = subprocess.Popen([COMANDO, "baixar", item], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    ultimo = {}
    for linha in processo.stdout:
        try:
            ultimo = json.loads(linha)
        except ValueError:
            continue
        ao_andar(ultimo)
    processo.wait()
    return bool(ultimo.get("pronto"))
