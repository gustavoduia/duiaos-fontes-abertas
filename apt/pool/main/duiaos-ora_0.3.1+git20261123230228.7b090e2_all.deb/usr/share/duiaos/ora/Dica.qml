// DuiaOS — Ora: dica (balão) que aparece embaixo de um item depois de meio segundo com o mouse em cima.
import QtQuick
import DuiaOS

Item {
    id: dica
    property bool visivel: false
    property string texto: ""
    anchors.fill: parent
    z: 100
    Timer { id: espera; interval: 550; running: dica.visivel && dica.texto !== ""; onTriggered: balao.opacity = 1 }
    onVisivelChanged: if (!visivel) balao.opacity = 0
    Rectangle {
        id: balao
        opacity: 0
        visible: opacity > 0
        x: Math.min(Math.max(0, (dica.width - width) / 2), dica.width + 40)
        y: dica.height + 6
        width: Math.min(320, rotulo.implicitWidth + 16); height: 26; radius: 8
        color: Tema.escuro ? "#E6E9F0" : "#1B2233"
        Behavior on opacity { NumberAnimation { duration: 120 } }
        Text {
            id: rotulo
            anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
            verticalAlignment: Text.AlignVCenter
            text: dica.texto; elide: Text.ElideRight
            color: Tema.escuro ? "#141823" : "white"
            font { family: Tema.fonteTexto; pixelSize: 12 }
        }
    }
}
