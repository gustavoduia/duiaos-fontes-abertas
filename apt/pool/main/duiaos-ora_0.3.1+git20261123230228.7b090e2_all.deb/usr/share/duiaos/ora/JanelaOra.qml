// DuiaOS — Ora: uma janela do navegador.
// Desenho próprio (ADR 075): trilho de abas na lateral (marca, nova aba, fixados, abas, atalhos), ilha em cima
// (navegação numa cápsula, identidade do site no centro, menu pela marca) e a página num cartão arredondado
// (página da web ou página interna do Ora: início, histórico, favoritos, downloads, configurações).
// A janela privada usa o perfil sem disco.
import QtQuick
import QtQuick.Window
import QtWebEngine
import DuiaOS

Window {
    id: janela
    property bool privada: false
    property bool modoAplicativo: false            // um site como aplicativo: só a página, sem abas nem barra
    property var enderecosIniciais: []
    readonly property string idJanela: "j" + Date.now() + "-" + Math.floor(Math.random() * 100000)
    readonly property var perfil: privada ? perfilPrivado : perfilPadrao
    property int atual: 0
    property bool telaCheia: false
    property var fechadas: []                      // abas fechadas, para reabrir (Ctrl+Shift+T)
    property var permissao: null                   // pedido de permissão pendente do site
    property var pedidoTela: null                  // pedido de compartilhar a tela
    property bool menuAberto: false
    readonly property Item aba: repetidor.count > 0 ? repetidor.itemAt(Math.min(atual, repetidor.count - 1)) : null
    readonly property var web: aba ? aba.web : null
    readonly property bool corPrivada: privada
    // Cores da marca do Ora (as mesmas do ícone), independentes do estilo do sistema
    readonly property color ora1: "#22D3EE"
    readonly property color ora2: "#3D5BFF"
    readonly property color ora3: "#A78BFA"

    width: 1280; height: 820
    minimumWidth: 640; minimumHeight: 420
    visible: true
    // Sem a barra de título do sistema (ADR 077): os botões da janela ficam na barra do navegador
    flags: Qt.Window | Qt.FramelessWindowHint
    readonly property bool maximizada: visibility === Window.Maximized || visibility === Window.FullScreen
    color: "transparent"
    title: modoAplicativo ? (aba && aba.titulo ? aba.titulo : "Ora")
                          : (aba && aba.titulo ? aba.titulo + " — " : "") + (privada ? "Ora (janela privada)" : "Ora")

    // ============================================================ abas
    ListModel { id: abas }
    property int seq: 0

    function novaAba(url, ativar, depoisDe) {
        seq++
        var posicao = depoisDe === undefined ? abas.count : Math.min(depoisDe + 1, abas.count)
        abas.insert(posicao, { uid: "a" + seq, urlInicial: url || "" })
        if (ativar !== false) atual = posicao
        else if (posicao <= atual) atual = atual + 1
        return posicao
    }
    function fecharAba(i) {
        if (i < 0 || i >= abas.count) return
        var item = repetidor.itemAt(i)
        if (item && item.url !== "" && !privada) {
            var lista = fechadas.slice(); lista.push(item.url); fechadas = lista.slice(-20)
        }
        if (abas.count === 1) {            // a última aba: a janela continua, com uma nova aba no lugar
            novaAba("", true)
            abas.remove(0)
            atual = 0
            salvarSessao()
            focarEndereco()
            return
        }
        abas.remove(i)
        if (atual >= abas.count) atual = abas.count - 1
        else if (i < atual) atual = atual - 1
        salvarSessao()
    }
    function reabrirFechada() {
        if (fechadas.length === 0) return
        var lista = fechadas.slice(); var url = lista.pop(); fechadas = lista
        novaAba(url, true)
    }
    function abrir(texto, emNovaAba) {
        var url = texto.indexOf("ora://") === 0 ? texto : ora.normalizar(texto)
        if (emNovaAba || !aba) novaAba(url, true, atual)
        else aba.navegar(url)
    }
    function abrirInterna(pagina) {
        // Reaproveita a aba que já mostra essa página interna
        for (var i = 0; i < repetidor.count; i++)
            if (repetidor.itemAt(i).pagina === pagina) { atual = i; return }
        if (aba && aba.pagina === "inicio" && !aba.temWeb) aba.navegar("ora://" + pagina)
        else novaAba("ora://" + pagina, true, atual)
    }
    function salvarSessao() {
        if (privada || modoAplicativo) return
        var lista = []
        for (var i = 0; i < repetidor.count; i++) {
            var it = repetidor.itemAt(i)
            if (it && it.url !== "" && it.url.indexOf("ora://") !== 0) lista.push({ url: it.url, titulo: it.titulo })
        }
        ora.guardarSessao(idJanela, lista)
    }
    function focarEndereco() { barraEndereco.focar() }

    Component.onCompleted: {
        var lista = enderecosIniciais || []
        if (typeof paginaDemonstracao !== "undefined" && paginaDemonstracao !== "") {
            if (paginaDemonstracao === "web" || paginaDemonstracao === "ferramentas") lista = [enderecoDemonstracao]
            else if (["inicio", "aplicativo", "apresentacao", "menu-aba", "chave"].indexOf(paginaDemonstracao) < 0) lista = ["ora://" + paginaDemonstracao]
        }
        if (lista.length === 0) novaAba("", true)
        for (var i = 0; i < lista.length; i++) novaAba(lista[i], i === 0)
        atual = 0
    }
    onActiveChanged: if (active) {
        ora.janelaAtiva(idJanela); menuDoApp.definirMenus(menusDoApp)
        // Voltando de outro programa (Alt+Tab), a página podia aparecer preta até rolar: força um quadro novo
        if (janela.aba) janela.aba.redesenhar()
    }
    onClosing: {
        if (!privada && !modoAplicativo) salvarSessao()
        ora.janelaFechada(idJanela)
    }

    Connections {
        target: ora
        function onAbrirPedido(url, alvo) {
            if (alvo !== janela.idJanela) return
            // Título que o labwc conhece agora (o da aba nova ainda não chegou a ele)
            var tituloAtual = janela.title
            janela.novaAba(url, true)
            janela.raise(); janela.requestActivate()
            ora.trazerParaFrente(ora.quantidadeDeJanelas > 1 ? tituloAtual : "")   // no Wayland, o requestActivate sozinho não traz a janela
        }
        function onAviso(texto) { if (janela.active || ora.ultimaJanela === janela.idJanela) aviso.mostrar(texto) }
    }

    // ============================================================ menus na Barra (ADR 059)
    readonly property var menusDoApp: {
        var it = function (id, rotulo, atalho, ativo, marcado) {
            return { id: id, rotulo: rotulo, tipo: marcado === undefined ? "item" : "marcavel", ativo: ativo !== false,
                     marcado: marcado === true, atalho: atalho || "", itens: [] } }
        var sep = { id: -1, rotulo: "", tipo: "separador", ativo: false, marcado: false, atalho: "", itens: [] }
        var temWeb = janela.web !== null && janela.aba && janela.aba.pagina === ""
        var favs = []
        var barra = ora.favoritosDaBarra
        for (var i = 0; i < Math.min(barra.length, 15); i++) favs.push(it("fav:" + barra[i].url, barra[i].titulo || barra[i].url))
        return [{ rotulo: "Ora", itens: [it("nova-aba", "Nova aba", "Ctrl+T"), it("nova-janela", "Nova janela", "Ctrl+N"),
                                         it("nova-privada", "Nova janela privada", "Ctrl+Shift+N"), sep,
                                         it("reabrir", "Reabrir aba fechada", "Ctrl+Shift+T", janela.fechadas.length > 0),
                                         it("pdf", "Salvar página como PDF", "Ctrl+P", temWeb), sep,
                                         it("configuracoes", "Configurações"), sep,
                                         it("fechar-aba", "Fechar aba", "Ctrl+W"), it("fechar-janela", "Fechar janela", "Ctrl+Shift+W")] },
                { rotulo: "Editar", itens: [it("desfazer", "Desfazer", "Ctrl+Z", temWeb), it("refazer", "Refazer", "Ctrl+Shift+Z", temWeb), sep,
                                            it("recortar", "Recortar", "Ctrl+X", temWeb), it("copiar", "Copiar", "Ctrl+C", temWeb),
                                            it("colar", "Colar", "Ctrl+V", temWeb), it("selecionar-tudo", "Selecionar tudo", "Ctrl+A", temWeb), sep,
                                            it("buscar", "Buscar na página", "Ctrl+F", temWeb), it("endereco", "Ir para o endereço", "Ctrl+L")] },
                { rotulo: "Visualizar", itens: [it("recarregar", "Recarregar", "Ctrl+R", temWeb), sep,
                                                it("zoom-mais", "Aumentar", "Ctrl++", temWeb), it("zoom-menos", "Diminuir", "Ctrl+-", temWeb),
                                                it("zoom-normal", "Tamanho original", "Ctrl+0", temWeb), sep,
                                                it("barra-favoritos", "Fixados no trilho", "Ctrl+Shift+B", true, ora.configuracoes.barra_de_favoritos === true),
                                                it("tela-cheia", "Tela cheia", "F11", true, janela.visibility === Window.FullScreen), sep,
                                                it("codigo-fonte", "Código-fonte da página", "Ctrl+U", temWeb)] },
                { rotulo: "Histórico", itens: [it("voltar", "Voltar", "Alt+←", janela.aba !== null && janela.aba.podeVoltar),
                                               it("avancar", "Avançar", "Alt+→", temWeb && janela.web.canGoForward), sep,
                                               it("historico", "Mostrar todo o histórico", "Ctrl+H")] },
                { rotulo: "Favoritos", itens: [it("favoritar", "Adicionar esta página aos favoritos", "Ctrl+D", temWeb),
                                               it("favoritos", "Mostrar todos os favoritos", "Ctrl+Shift+O")].concat(favs.length ? [sep].concat(favs) : []) },
                { rotulo: "Ferramentas", itens: [it("downloads", "Downloads", "Ctrl+J"),
                                                 it("devtools", "Ferramentas do desenvolvedor", "F12", temWeb)] }]
    }
    onMenusDoAppChanged: if (active) menuDoApp.definirMenus(menusDoApp)
    Connections {
        target: menuDoApp
        function onAcionado(id) {
            if (!janela.active && ora.ultimaJanela !== janela.idJanela) return
            janela.executar(id)
        }
    }

    function executar(id) {
        var w = janela.web
        var temWeb = w !== null && aba && aba.pagina === ""
        if (id.indexOf("fav:") === 0) { abrir(id.slice(4), false); return }
        switch (id) {
        case "nova-aba": novaAba("", true); focarEndereco(); break
        case "nova-janela": ora.novaJanela(false, ""); break
        case "nova-privada": ora.novaJanela(true, ""); break
        case "reabrir": reabrirFechada(); break
        case "pdf": if (temWeb) { var destino = ora.caminhoPdf(aba.titulo); w.printToPdf(destino); aviso.mostrar("PDF salvo em Documentos.") } break
        case "configuracoes": abrirInterna("configuracoes"); break
        case "fechar-aba": fecharAba(atual); break
        case "fechar-janela": janela.close(); break
        case "desfazer": if (temWeb) w.triggerWebAction(WebEngineView.Undo); break
        case "refazer": if (temWeb) w.triggerWebAction(WebEngineView.Redo); break
        case "recortar": if (temWeb) w.triggerWebAction(WebEngineView.Cut); break
        case "copiar": if (temWeb) w.triggerWebAction(WebEngineView.Copy); break
        case "colar": if (temWeb) w.triggerWebAction(WebEngineView.Paste); break
        case "selecionar-tudo": if (temWeb) w.triggerWebAction(WebEngineView.SelectAll); break
        case "buscar": if (temWeb) barraBusca.abrir(); break
        case "endereco": focarEndereco(); break
        case "recarregar": if (temWeb) w.reload(); break
        case "zoom-mais": if (temWeb) w.zoomFactor = Math.min(5, w.zoomFactor + 0.1); break
        case "zoom-menos": if (temWeb) w.zoomFactor = Math.max(0.25, w.zoomFactor - 0.1); break
        case "zoom-normal": if (temWeb) w.zoomFactor = ora.configuracoes.zoom_padrao || 1; break
        case "barra-favoritos": ora.definir("barra_de_favoritos", !ora.configuracoes.barra_de_favoritos); break
        case "tela-cheia": janela.visibility = janela.visibility === Window.FullScreen ? Window.Windowed : Window.FullScreen; break
        case "codigo-fonte": if (temWeb) novaAba("view-source:" + aba.url, true, atual); break
        case "voltar": if (aba) aba.voltar(); break
        case "avancar": if (temWeb) w.goForward(); break
        case "historico": abrirInterna("historico"); break
        case "favoritar": if (temWeb) barraEndereco.abrirFavorito(); break
        case "favoritos": abrirInterna("favoritos"); break
        case "downloads": abrirInterna("downloads"); break
        case "devtools": if (temWeb) abrirDevTools(w); break
        }
    }

    // ============================================================ atalhos de teclado
    Shortcut { sequences: ["Ctrl+T"]; onActivated: janela.executar("nova-aba") }
    Shortcut { sequences: ["Ctrl+N"]; onActivated: janela.executar("nova-janela") }
    Shortcut { sequences: ["Ctrl+Shift+N"]; onActivated: janela.executar("nova-privada") }
    Shortcut { sequences: ["Ctrl+W", "Ctrl+F4"]; onActivated: janela.executar("fechar-aba") }
    Shortcut { sequences: ["Ctrl+Shift+W"]; onActivated: janela.executar("fechar-janela") }
    Shortcut { sequences: ["Ctrl+Shift+T"]; onActivated: janela.executar("reabrir") }
    Shortcut { sequences: ["Ctrl+L", "Alt+D", "F6"]; onActivated: janela.executar("endereco") }
    Shortcut { sequences: ["Ctrl+R", "F5"]; onActivated: janela.executar("recarregar") }
    Shortcut { sequences: ["Ctrl+Shift+R", "Shift+F5"]; onActivated: if (janela.web) janela.web.triggerWebAction(WebEngineView.ReloadAndBypassCache) }
    Shortcut { sequences: ["Ctrl+F", "F3"]; onActivated: janela.executar("buscar") }
    Shortcut { sequences: ["Ctrl+D"]; onActivated: janela.executar("favoritar") }
    Shortcut { sequences: ["Ctrl+H"]; onActivated: janela.executar("historico") }
    Shortcut { sequences: ["Ctrl+J"]; onActivated: janela.executar("downloads") }
    Shortcut { sequences: ["Ctrl+Shift+O"]; onActivated: janela.executar("favoritos") }
    Shortcut { sequences: ["Ctrl+Shift+B"]; onActivated: janela.executar("barra-favoritos") }
    Shortcut { sequences: ["Ctrl+P"]; onActivated: janela.executar("pdf") }
    Shortcut { sequences: ["Ctrl+U"]; onActivated: janela.executar("codigo-fonte") }
    Shortcut { sequences: ["Ctrl+S"]; onActivated: if (janela.web && janela.aba.pagina === "") janela.web.triggerWebAction(WebEngineView.SavePage) }
    Shortcut { sequences: ["Ctrl++", "Ctrl+="]; onActivated: janela.executar("zoom-mais") }
    Shortcut { sequences: ["Ctrl+-"]; onActivated: janela.executar("zoom-menos") }
    Shortcut { sequences: ["Ctrl+0"]; onActivated: janela.executar("zoom-normal") }
    Shortcut { sequences: ["F11"]; onActivated: janela.executar("tela-cheia") }
    Shortcut { sequences: ["F12", "Ctrl+Shift+I"]; onActivated: janela.executar("devtools") }
    Shortcut { sequences: ["Alt+Left", "Back"]; onActivated: janela.executar("voltar") }
    Shortcut { sequences: ["Alt+Right", "Forward"]; onActivated: janela.executar("avancar") }
    Shortcut { sequences: ["Ctrl+Tab", "Ctrl+PgDown"]; onActivated: janela.atual = (janela.atual + 1) % abas.count }
    Shortcut { sequences: ["Ctrl+Shift+Tab", "Ctrl+PgUp"]; onActivated: janela.atual = (janela.atual + abas.count - 1) % abas.count }
    Shortcut { sequences: ["Ctrl+1"]; onActivated: janela.atual = 0 }
    Shortcut { sequences: ["Ctrl+2"]; onActivated: janela.atual = Math.min(1, abas.count - 1) }
    Shortcut { sequences: ["Ctrl+3"]; onActivated: janela.atual = Math.min(2, abas.count - 1) }
    Shortcut { sequences: ["Ctrl+4"]; onActivated: janela.atual = Math.min(3, abas.count - 1) }
    Shortcut { sequences: ["Ctrl+5"]; onActivated: janela.atual = Math.min(4, abas.count - 1) }
    Shortcut { sequences: ["Ctrl+9"]; onActivated: janela.atual = abas.count - 1 }
    Shortcut { sequences: ["Escape"]; enabled: janela.web !== null && janela.web.loading; onActivated: janela.web.stop() }

    // ============================================================ ferramentas do desenvolvedor e popups
    Component {
        id: componenteDevTools
        Window {
            id: jd
            property var alvo: null
            property alias vista: vistaDev
            width: 1000; height: 640
            title: "Ferramentas do desenvolvedor — Ora"
            visible: true
            color: Tema.fundo
            Rectangle {
                id: barraJd
                anchors { left: parent.left; right: parent.right; top: parent.top }
                height: 34; color: Tema.lateral
                Text { anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                       text: "Ferramentas do desenvolvedor"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 12; weight: Font.DemiBold } }
                BotaoIcone { anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                             width: 26; height: 26; icone: "janela"; tamanhoIcone: 13; dica: "Encaixar de novo no Ora"
                             onClicado: janela.encaixarDevTools() }
            }
            WebEngineView {
                id: vistaDev
                anchors { left: parent.left; right: parent.right; top: barraJd.bottom; bottom: parent.bottom }
                profile: janela.perfil
                Component.onCompleted: if (jd.alvo) jd.alvo.devToolsView = vistaDev
            }
            onClosing: {
                if (alvo) { alvo.devToolsView = null; if (janela.devJanela === jd) { janela.devJanela = null; janela.devAlvo = null } }
                destroy()
            }
        }
    }
    // Ferramentas do desenvolvedor (ADR 077): encaixadas à direita da página, como no Chrome; o botão do painel as
    // destaca numa janela separada. F12 de novo fecha.
    property var devAlvo: null                     // a página inspecionada
    property var devJanela: null                   // a janela separada, quando destacadas
    property real larguraDev: Math.min(520, Math.max(320, janela.width * 0.34))
    readonly property bool devEncaixado: devAlvo !== null && devJanela === null
    function abrirDevTools(w) {
        if (devAlvo === w) { fecharDevTools(); return }
        fecharDevTools()
        devAlvo = w
        w.devToolsView = vistaDevEncaixada
    }
    function fecharDevTools() {
        if (devAlvo) devAlvo.devToolsView = null
        if (devJanela) { var j = devJanela; devJanela = null; j.close() }
        devAlvo = null
    }
    function destacarDevTools() {
        if (!devAlvo) return
        var alvo = devAlvo
        alvo.devToolsView = null
        devJanela = componenteDevTools.createObject(janela, { alvo: alvo })
    }
    function encaixarDevTools() {
        if (!devAlvo || !devJanela) return
        var alvo = devAlvo, j = devJanela
        devJanela = null
        alvo.devToolsView = null
        j.alvo = null
        j.close()
        alvo.devToolsView = vistaDevEncaixada
    }
    onAtualChanged: {
        // As ferramentas seguem a aba da frente
        if (devAlvo && web && web !== devAlvo) {
            var naJanela = devJanela !== null
            devAlvo.devToolsView = null
            devAlvo = web
            if (naJanela) devJanela.vista.inspectedView = web
            else web.devToolsView = vistaDevEncaixada
        } else if (devAlvo && !web) fecharDevTools()
    }
    // Janelas que o site pede (login com Google/Microsoft, pagamentos): precisam do window.opener
    Component {
        id: componentePopup
        Window {
            id: jp
            property alias vistaDoPopup: vistaPopup
            width: 520; height: 680
            visible: true
            color: Tema.fundo
            title: (vistaPopup.title || "Ora") + " — Ora"
            Rectangle {
                id: faixaPopup
                anchors { left: parent.left; right: parent.right; top: parent.top }
                height: 32
                color: Tema.lateral
                Icone { id: cadPopup; anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                        nome: vistaPopup.url.toString().indexOf("https://") === 0 ? "cadeado" : "globo"; tamanho: 13; cor: Tema.textoSecundario }
                Text { anchors { left: cadPopup.right; leftMargin: 6; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                       text: ora.paraMostrar(vistaPopup.url.toString()); elide: Text.ElideMiddle
                       font { family: Tema.fonteTexto; pixelSize: 12 } color: Tema.textoSecundario }
            }
            WebEngineView {
                id: vistaPopup
                anchors { left: parent.left; right: parent.right; top: faixaPopup.bottom; bottom: parent.bottom }
                profile: janela.perfil
                onWindowCloseRequested: jp.close()
                onNewWindowRequested: (pedido) => janela.pedidoDeJanela(pedido)
            }
            onClosing: destroy()
        }
    }
    function pedidoDeJanela(pedido) {
        if (pedido.destination === WebEngineNewWindowRequest.InNewDialog) {
            var popup = componentePopup.createObject(janela)
            pedido.openIn(popup.vistaDoPopup)
            return
        }
        if (modoAplicativo) {             // num aplicativo, links para fora abrem numa janela normal do Ora
            ora.novaJanela(false, pedido.requestedUrl.toString())
            return
        }
        var segundoPlano = pedido.destination === WebEngineNewWindowRequest.InNewBackgroundTab && ora.configuracoes.ir_para_nova_aba !== true
        var i = novaAba("about:blank#ora-nova", !segundoPlano, atual)
        var item = repetidor.itemAt(i)
        item.prepararWeb()
        pedido.openIn(item.web)
    }

    // ============================================================ conteúdo das abas
    Item {
        id: areaConteudo
        anchors { left: parent.left; right: parent.right; top: ilha.bottom
                  bottom: janela.cromado && janela.posicaoAbas === "rodape" ? faixaAbas.top : parent.bottom
                  leftMargin: janela.posicaoAbas === "esquerda" ? trilho.width : (janela.cromado ? 10 : 0)
                  rightMargin: (janela.posicaoAbas === "direita" ? trilho.width : (janela.cromado ? 10 : 0))
                               + (janela.devEncaixado ? janela.larguraDev + 6 : 0)
                  bottomMargin: janela.cromado ? (janela.posicaoAbas === "rodape" ? 2 : 10) : 0 }
        Rectangle { anchors.fill: parent; color: Tema.fundo }
        Repeater {
            id: repetidor
            model: abas
            delegate: Aba { }
        }
    }

    // Painel das ferramentas do desenvolvedor, à direita da página
    Rectangle {
        id: painelDev
        visible: janela.devEncaixado
        anchors { top: areaConteudo.top; bottom: areaConteudo.bottom; left: areaConteudo.right; leftMargin: 6 }
        width: janela.larguraDev
        radius: 12
        color: Tema.fundo
        border { width: 1; color: Tema.borda }
        clip: true
        z: 4
        // Puxar a borda esquerda muda a largura
        MouseArea {
            anchors { left: parent.left; top: parent.top; bottom: parent.bottom; leftMargin: -6 }
            width: 10; z: 3
            cursorShape: Qt.SplitHCursor
            property real inicio: 0
            onPressed: (m) => { inicio = m.x }
            onPositionChanged: (m) => { if (pressed) janela.larguraDev = Math.max(280, Math.min(janela.width * 0.7, janela.larguraDev - (m.x - inicio))) }
        }
        Rectangle {
            id: barraDev
            anchors { left: parent.left; right: parent.right; top: parent.top }
            height: 32; color: Tema.lateral; radius: 12
            Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom } height: 12; color: Tema.lateral }
            Icone { id: iconeDev; anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter } nome: "codigo"; tamanho: 14; cor: Tema.textoSecundario }
            Text { anchors { left: iconeDev.right; leftMargin: 8; verticalCenter: parent.verticalCenter }
                   text: "Ferramentas do desenvolvedor"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 12; weight: Font.DemiBold } }
            Row {
                anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
                BotaoIcone { width: 26; height: 26; icone: "janela"; tamanhoIcone: 13; dica: "Abrir numa janela separada"; onClicado: janela.destacarDevTools() }
                BotaoIcone { width: 26; height: 26; icone: "fechar"; tamanhoIcone: 11; dica: "Fechar (F12)"; onClicado: janela.fecharDevTools() }
            }
        }
        WebEngineView {
            id: vistaDevEncaixada
            anchors { left: parent.left; right: parent.right; top: barraDev.bottom; bottom: parent.bottom; margins: 1 }
            profile: janela.perfil
        }
    }

    // A aba: a página da web (criada na primeira navegação) e, por cima, a página interna do Ora
    component Aba: Item {
        id: estaAba
        required property int index
        required property string uid
        required property string urlInicial
        anchors.fill: parent
        visible: index === janela.atual
        property string pagina: "inicio"                 // "" = a página da web
        property bool temWeb: false
        property string urlPedida: ""
        property var web: carregadorWeb.item
        property string erroCertificado: ""
        property var pedidoCertificado: null
        property bool processoParou: false
        property int ajuste: 0
        function redesenhar() { if (temWeb && pagina === "") { ajuste = 1; tempoAjuste.restart() } }
        Timer { id: tempoAjuste; interval: 60; onTriggered: estaAba.ajuste = 0 }
        readonly property string url: pagina !== "" ? (pagina === "inicio" ? "" : "ora://" + pagina)
                                                    : (web ? web.url.toString() : urlPedida)
        readonly property string titulo: pagina !== "" ? ({ inicio: "Nova aba", historico: "Histórico", favoritos: "Favoritos",
                                                             downloads: "Downloads", configuracoes: "Configurações" })[pagina] || "Ora"
                                                       : (web && web.title ? web.title : ora.paraMostrar(url))
        readonly property string icone: pagina === "" && web && web.icon.toString() !== "" ? web.icon.toString() : ""
        readonly property bool carregando: pagina === "" && web !== null && web.loading
        readonly property real progresso: web ? web.loadProgress / 100 : 0
        readonly property bool podeVoltar: (pagina !== "" && temWeb) || (pagina === "" && web !== null && web.canGoBack)
        readonly property bool audivel: web !== null && web.recentlyAudible
        readonly property bool mudo: web !== null && web.audioMuted

        function prepararWeb() { temWeb = true; pagina = "" }
        function navegar(endereco) {
            if (endereco === "") { pagina = "inicio"; return }
            if (endereco.indexOf("ora://") === 0) { pagina = endereco.slice(6); return }
            pagina = ""
            processoParou = false
            if (web) web.url = endereco
            else { urlPedida = endereco; temWeb = true }
        }
        function voltar() {
            if (pagina !== "" && temWeb) pagina = ""
            else if (web && web.canGoBack) web.goBack()
        }
        Component.onCompleted: navegar(urlInicial === "about:blank#ora-nova" ? "" : urlInicial)
        onUrlChanged: janela.salvarSessao()

        Loader {
            id: carregadorWeb
            anchors.fill: parent
            anchors.rightMargin: estaAba.ajuste
            active: estaAba.temWeb
            visible: estaAba.pagina === ""
            sourceComponent: WebEngineView {
                id: vista
                profile: janela.perfil
                url: estaAba.urlPedida !== "" ? estaAba.urlPedida : "about:blank"
                zoomFactor: ora.configuracoes.zoom_padrao || 1
                settings.fullScreenSupportEnabled: true
                settings.pdfViewerEnabled: true
                settings.screenCaptureEnabled: true
                settings.dnsPrefetchEnabled: true
                settings.focusOnNavigationEnabled: true
                settings.localContentCanAccessRemoteUrls: false
                onLoadingChanged: (info) => {
                    if (info.status === WebEngineView.LoadSucceededStatus && !janela.privada)
                        ora.visitou(info.url.toString(), vista.title)
                }
                onTitleChanged: if (!janela.privada && !loading) ora.atualizarTitulo(url.toString(), title)
                onNewWindowRequested: (pedido) => janela.pedidoDeJanela(pedido)
                onWindowCloseRequested: janela.fecharAba(estaAba.index)
                onFullScreenRequested: (pedido) => {
                    pedido.accept()
                    janela.telaCheia = pedido.toggleOn
                    janela.visibility = pedido.toggleOn ? Window.FullScreen : Window.Windowed
                }
                onPermissionRequested: (p) => { janela.permissao = p }
                onDesktopMediaRequested: (pedido) => { janela.pedidoTela = pedido }
                onCertificateError: (erro) => {
                    erro.defer()
                    estaAba.pedidoCertificado = erro
                    estaAba.erroCertificado = erro.description
                }
                onLinkHovered: (endereco) => { bolhaLink.texto = endereco.toString() }
                onRenderProcessTerminated: (estado, codigo) => {
                    if (estado !== WebEngineView.NormalTerminationStatus) estaAba.processoParou = true
                }
                onFindTextFinished: (resultado) => barraBusca.resultado(resultado.numberOfMatches, resultado.activeMatch)
                onContextMenuRequested: (pedido) => {
                    pedido.accepted = true            // o menu do Ora, em português, no lugar do menu do Qt
                    janela.abrirMenuDaPagina(vista, pedido)
                }
                onWebAuthUxRequested: (pedido) => { janela.pedidoChave = pedido }
            }
        }

        Loader {
            anchors.fill: parent
            active: estaAba.pagina !== ""
            visible: active
            sourceComponent: {
                switch (estaAba.pagina) {
                case "historico": return componenteHistorico
                case "favoritos": return componenteFavoritos
                case "downloads": return componenteDownloads
                case "configuracoes": return componenteConfiguracoes
                default: return componenteInicio
                }
            }
        }

        // Erro de certificado: a conexão não é segura
        Rectangle {
            anchors.fill: parent
            visible: estaAba.erroCertificado !== "" && estaAba.pagina === ""
            color: Tema.fundo
            Column {
                anchors.centerIn: parent
                width: Math.min(parent.width - 64, 560)
                spacing: 16
                Icone { nome: "escudo"; tamanho: 56; cor: Tema.erro }
                Titulo { text: "A conexão com este site não é segura"; width: parent.width; wrapMode: Text.WordWrap }
                Rotulo { width: parent.width; wrapMode: Text.WordWrap; secundario: true
                         text: "Alguém pode estar tentando roubar as suas informações de " + ora.dominio(estaAba.url) +
                               " (senhas, mensagens ou cartões).\n\nDetalhe técnico: " + estaAba.erroCertificado }
                Row {
                    spacing: 10
                    Botao { texto: "Voltar para a segurança"; tipo: "primario"
                            onClicado: { estaAba.pedidoCertificado.rejectCertificate(); estaAba.erroCertificado = ""; estaAba.voltar() } }
                    Botao { texto: "Continuar mesmo assim"; visible: estaAba.pedidoCertificado && estaAba.pedidoCertificado.overridable
                            onClicado: { estaAba.pedidoCertificado.acceptCertificate(); estaAba.erroCertificado = "" } }
                }
            }
        }
        // A página parou (o processo do site fechou)
        Rectangle {
            anchors.fill: parent
            visible: estaAba.processoParou && estaAba.pagina === ""
            color: Tema.fundo
            Column {
                anchors.centerIn: parent
                spacing: 14
                Icone { anchors.horizontalCenter: parent.horizontalCenter; nome: "info"; tamanho: 48; cor: Tema.textoSecundario }
                Titulo { anchors.horizontalCenter: parent.horizontalCenter; text: "Esta página parou de funcionar" }
                Botao { anchors.horizontalCenter: parent.horizontalCenter; texto: "Recarregar"; tipo: "primario"
                        onClicado: { estaAba.processoParou = false; estaAba.web.reload() } }
            }
        }
    }

    Component { id: componenteInicio; PaginaInicio { janelaOra: janela } }
    Component { id: componenteHistorico; PaginaHistorico { janelaOra: janela } }
    Component { id: componenteFavoritos; PaginaFavoritos { janelaOra: janela } }
    Component { id: componenteDownloads; PaginaDownloads { janelaOra: janela } }
    Component { id: componenteConfiguracoes; PaginaConfiguracoes { janelaOra: janela } }

    // ============================================================ Trilho (abas na lateral) e Ilha (barra de cima)
    // Desenho próprio do Ora (ADR 075): as abas ficam num trilho vertical à esquerda, com os fixados no alto e os
    // atalhos do Ora embaixo; a página fica num cartão de cantos arredondados que "flutua" sobre o fundo; a barra de
    // cima é uma ilha com a navegação numa cápsula e a identidade do site no centro.
    readonly property bool cromado: !((janela.visibility === Window.FullScreen && janela.telaCheia) || janela.modoAplicativo)
    readonly property bool trilhoCompacto: ora.configuracoes.trilho_compacto === true || janela.width < 820
    // Onde ficam as abas (ADR 076): no trilho, à esquerda ou à direita, ou numa faixa em cima ou embaixo
    readonly property string posicaoAbas: ["esquerda", "direita", "topo", "rodape"].indexOf(ora.configuracoes.posicao_abas) >= 0
                                          ? ora.configuracoes.posicao_abas : "esquerda"
    readonly property bool abasNaLateral: posicaoAbas === "esquerda" || posicaoAbas === "direita"
    readonly property color corFundo: janela.privada ? (Tema.escuro ? "#191329" : "#EEE9FB") : Tema.lateral

    Rectangle {
        id: fundoJanela
        anchors.fill: parent
        z: -1
        visible: janela.cromado
        color: janela.corFundo
        radius: janela.maximizada ? 0 : 10
        border { width: janela.maximizada ? 0 : 1; color: Qt.rgba(0, 0, 0, Tema.escuro ? 0.5 : 0.12) }
        clip: true
        // Brilho aurora no canto: a assinatura visual do Ora
        Rectangle {
            width: 520; height: 520; radius: 260
            x: -200; y: -260
            opacity: Tema.escuro ? 0.16 : 0.10
            gradient: Gradient { orientation: Gradient.Horizontal
                GradientStop { position: 0; color: janela.ora1 } GradientStop { position: 0.55; color: janela.ora2 } GradientStop { position: 1; color: "transparent" } }
        }
    }

    Item {
        id: trilho
        anchors { top: parent.top; bottom: parent.bottom }
        x: janela.posicaoAbas === "direita" ? janela.width - width : 0
        width: janela.cromado && janela.abasNaLateral ? (janela.trilhoCompacto ? 64 : 244) : 0
        visible: width > 0
        clip: true
        z: 5
        Behavior on width { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

        // ---------------------------------------------------- marca e botão de recolher
        Item {
            id: topoTrilho
            anchors { left: parent.left; right: parent.right; top: parent.top }
            height: 44
            MouseArea {
                anchors.fill: parent
                onPressed: (m) => { if (!janela.maximizada) janela.startSystemMove() }
                onDoubleClicked: janela.maximizada ? janela.showNormal() : janela.showMaximized()
            }
            MarcaOra {
                id: marcaTrilho
                anchors { left: parent.left; leftMargin: janela.trilhoCompacto ? 18 : 16; verticalCenter: parent.verticalCenter }
                tamanho: 28
                girando: janela.aba !== null && janela.aba.carregando
            }
            Text {
                visible: !janela.trilhoCompacto
                anchors { left: marcaTrilho.right; leftMargin: 10; verticalCenter: parent.verticalCenter }
                text: janela.privada ? "Ora privado" : "Ora"
                color: Tema.texto
                font { family: Tema.fonteTitulo; pixelSize: 17; weight: Font.Bold; letterSpacing: 0.4 }
            }
            BotaoIcone {
                visible: !janela.trilhoCompacto && janela.width >= 820
                anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                width: 28; height: 28; radius: 9
                icone: "barra"; tamanhoIcone: 14; corIcone: Tema.textoSecundario
                dica: "Recolher o trilho"
                onClicado: ora.definir("trilho_compacto", true)
            }
        }

        // ---------------------------------------------------- nova aba
        Rectangle {
            id: botaoNovaAba
            anchors { left: parent.left; right: parent.right; top: topoTrilho.bottom; leftMargin: 10; rightMargin: 10 }
            height: 38; radius: 12
            color: areaNovaAba.pressed ? Tema.pressionado : (areaNovaAba.containsMouse ? Tema.realce : (Tema.escuro ? Qt.rgba(1, 1, 1, 0.05) : Qt.rgba(1, 1, 1, 0.7)))
            border { width: 1; color: Tema.borda }
            Row {
                anchors { left: parent.left; leftMargin: janela.trilhoCompacto ? 12 : 12; verticalCenter: parent.verticalCenter }
                spacing: 10
                Rectangle {
                    width: 20; height: 20; radius: 10
                    anchors.verticalCenter: parent.verticalCenter
                    gradient: Gradient { orientation: Gradient.Horizontal
                        GradientStop { position: 0; color: janela.ora1 } GradientStop { position: 1; color: janela.ora3 } }
                    Icone { anchors.centerIn: parent; nome: "mais"; tamanho: 12; cor: "white" }
                }
                Text {
                    visible: !janela.trilhoCompacto
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Nova aba"
                    color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13; weight: Font.DemiBold }
                }
            }
            Text {
                visible: !janela.trilhoCompacto
                anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                text: "Ctrl T"; color: Tema.textoApagado; font { family: Tema.fonteTexto; pixelSize: 11 }
            }
            MouseArea { id: areaNovaAba; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: { janela.novaAba("", true); janela.focarEndereco() } }
        }

        // ---------------------------------------------------- fixados (os favoritos da barra)
        Flow {
            id: fixados
            anchors { left: parent.left; right: parent.right; top: botaoNovaAba.bottom; leftMargin: 10; rightMargin: 10; topMargin: 12 }
            visible: ora.configuracoes.barra_de_favoritos === true && !janela.privada && ora.favoritosDaBarra.length > 0
            height: visible ? implicitHeight : 0
            spacing: 6
            Repeater {
                model: ora.configuracoes.barra_de_favoritos === true && !janela.privada ? ora.favoritosDaBarra.slice(0, janela.trilhoCompacto ? 4 : 12) : []
                delegate: Rectangle {
                    required property var modelData
                    width: janela.trilhoCompacto ? 44 : (fixados.width - 18) / 4; height: 40; radius: 11
                    color: areaFixo.pressed ? Tema.pressionado : (areaFixo.containsMouse ? Tema.realce : (Tema.escuro ? Qt.rgba(1, 1, 1, 0.05) : Qt.rgba(1, 1, 1, 0.6)))
                    Favicon { anchors.centerIn: parent; url: modelData.url; titulo: modelData.titulo; tamanho: 18 }
                    MouseArea { id: areaFixo; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                acceptedButtons: Qt.LeftButton | Qt.MiddleButton
                                onClicked: (m) => janela.abrir(modelData.url, m.button === Qt.MiddleButton || (m.modifiers & Qt.ControlModifier)) }
                    Dica { visivel: areaFixo.containsMouse; texto: modelData.titulo || modelData.url }
                }
            }
        }

        // ---------------------------------------------------- abas
        Text {
            id: rotuloAbas
            visible: !janela.trilhoCompacto
            anchors { left: parent.left; leftMargin: 18; top: fixados.bottom; topMargin: 16 }
            text: abas.count === 1 ? "1 aba" : abas.count + " abas"
            color: Tema.textoApagado; font { family: Tema.fonteTexto; pixelSize: 11; weight: Font.DemiBold; capitalization: Font.AllUppercase; letterSpacing: 0.8 }
        }
        ListView {
            id: listaAbas
            anchors { left: parent.left; right: parent.right; top: janela.trilhoCompacto ? fixados.bottom : rotuloAbas.bottom
                      bottom: atalhosTrilho.top; topMargin: 8; bottomMargin: 8; leftMargin: 8; rightMargin: 8 }
            clip: true
            spacing: 3
            model: abas
            boundsBehavior: Flickable.StopAtBounds
            currentIndex: janela.atual
            highlightFollowsCurrentItem: true
            highlightMoveDuration: 160
            // O cartão da aba ativa desliza até ela
            highlight: Rectangle {
                width: listaAbas.width; height: 40; radius: 12
                color: Tema.fundo
                border { width: 1; color: Tema.borda }
                Rectangle {          // filete aurora à esquerda
                    anchors { left: parent.left; leftMargin: 3; verticalCenter: parent.verticalCenter }
                    width: 3; height: 18; radius: 2
                    gradient: Gradient { GradientStop { position: 0; color: janela.ora1 } GradientStop { position: 1; color: janela.ora3 } }
                }
            }
            delegate: Item {
                id: guia
                required property int index
                readonly property Item conteudo: repetidor.count > index ? repetidor.itemAt(index) : null
                readonly property bool ativa: index === janela.atual
                width: listaAbas.width; height: 40
                Rectangle {
                    anchors.fill: parent; radius: 12
                    visible: !guia.ativa
                    color: areaGuia.containsMouse ? Tema.realce : "transparent"
                }
                MouseArea {
                    id: areaGuia
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                    onClicked: (m) => {
                        if (m.button === Qt.MiddleButton) janela.fecharAba(guia.index)
                        else if (m.button === Qt.RightButton) janela.abrirMenuDaAba(guia.index, guia, m.x, m.y)
                        else janela.atual = guia.index
                    }
                }
                // Trilho recolhido: o fechar aparece no canto da aba com o mouse em cima
                BotaoIcone {
                    visible: janela.trilhoCompacto && (areaGuia.containsMouse || hovered)
                    property bool hovered: false
                    anchors { right: parent.right; top: parent.top; rightMargin: 1; topMargin: 1 }
                    width: 18; height: 18; radius: 9; z: 2
                    color: Tema.cartao
                    icone: "fechar"; tamanhoIcone: 9; corIcone: Tema.texto
                    dica: "Fechar a aba"
                    onClicado: janela.fecharAba(guia.index)
                    HoverHandler { onHoveredChanged: parent.hovered = hovered }
                }
                // ícone do site, ou o anel do carregamento
                Item {
                    id: iconeGuia
                    anchors { left: parent.left; leftMargin: janela.trilhoCompacto ? (parent.width - 16) / 2 : 14; verticalCenter: parent.verticalCenter }
                    width: 16; height: 16
                    Image {
                        anchors.fill: parent
                        visible: guia.conteudo && guia.conteudo.icone !== "" && !guia.conteudo.carregando
                        source: guia.conteudo && guia.conteudo.icone !== "" ? guia.conteudo.icone : ""
                        sourceSize: Qt.size(32, 32)
                    }
                    Icone {
                        anchors.centerIn: parent
                        visible: guia.conteudo && guia.conteudo.icone === "" && !guia.conteudo.carregando
                        nome: guia.conteudo && guia.conteudo.pagina !== "" ? ({ historico: "recentes", favoritos: "estrela", downloads: "download",
                                                                                configuracoes: "engrenagem", inicio: "casa" })[guia.conteudo.pagina] || "globo" : "globo"
                        tamanho: 14; cor: Tema.textoSecundario
                    }
                    MarcaOra { anchors.centerIn: parent; tamanho: 16; simples: true; girando: true
                               visible: guia.conteudo !== null && guia.conteudo.carregando }
                }
                Text {
                    visible: !janela.trilhoCompacto
                    anchors { left: iconeGuia.right; leftMargin: 10; right: botoesGuia.left; rightMargin: 4; verticalCenter: parent.verticalCenter }
                    text: guia.conteudo ? guia.conteudo.titulo : ""
                    elide: Text.ElideRight
                    color: guia.ativa ? Tema.texto : Tema.textoSecundario
                    font { family: Tema.fonteTexto; pixelSize: 13; weight: guia.ativa ? Font.DemiBold : Font.Normal }
                }
                Row {
                    id: botoesGuia
                    visible: !janela.trilhoCompacto
                    anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                    BotaoIcone {
                        visible: guia.conteudo !== null && (guia.conteudo.audivel || guia.conteudo.mudo)
                        width: 24; height: 24; radius: 8
                        icone: guia.conteudo && guia.conteudo.mudo ? "som-mudo" : "som-0"
                        tamanhoIcone: 13; corIcone: Tema.textoSecundario
                        dica: "Silenciar a aba"
                        onClicado: guia.conteudo.web.audioMuted = !guia.conteudo.web.audioMuted
                    }
                    BotaoIcone {
                        visible: guia.ativa || areaGuia.containsMouse
                        width: 24; height: 24; radius: 8
                        icone: "fechar"; tamanhoIcone: 11; corIcone: Tema.textoSecundario
                        dica: "Fechar a aba"
                        onClicado: janela.fecharAba(guia.index)
                    }
                }
                Dica { visivel: janela.trilhoCompacto && areaGuia.containsMouse; texto: guia.conteudo ? guia.conteudo.titulo : "" }
            }
        }

        // ---------------------------------------------------- atalhos do Ora
        Column {
            id: atalhosTrilho
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 10 }
            spacing: 8
            Rectangle {
                visible: janela.privada
                width: parent.width; height: 30; radius: 10
                color: Tema.escuro ? "#3A2E66" : "#D9CFF8"
                Row {
                    anchors.centerIn: parent; spacing: 6
                    Icone { nome: "olho"; tamanho: 13; cor: Tema.escuro ? "#D9CFF8" : "#4B2FB0"; anchors.verticalCenter: parent.verticalCenter }
                    Text { visible: !janela.trilhoCompacto; text: "Janela privada"; color: Tema.escuro ? "#D9CFF8" : "#4B2FB0"
                           anchors.verticalCenter: parent.verticalCenter; font { family: Tema.fonteTexto; pixelSize: 12; weight: Font.DemiBold } }
                }
            }
            Flow {
                width: parent.width
                spacing: 2
                Repeater {
                    model: [{ id: "historico", icone: "recentes", dica: "Histórico (Ctrl+H)" },
                            { id: "favoritos", icone: "estrela", dica: "Favoritos (Ctrl+Shift+O)" },
                            { id: "downloads", icone: "download", dica: "Downloads (Ctrl+J)" },
                            { id: "configuracoes", icone: "engrenagem", dica: "Configurações" },
                            { id: "expandir", icone: "barra", dica: "Mostrar o trilho" }]
                    delegate: Item {
                        required property var modelData
                        visible: modelData.id !== "expandir" || (janela.trilhoCompacto && janela.width >= 820)
                        width: janela.trilhoCompacto ? parent.width : (parent.width - 8) / 4; height: 34
                        BotaoIcone {
                            anchors.centerIn: parent
                            width: 34; height: 34; radius: 10
                            icone: modelData.icone; tamanhoIcone: 16; corIcone: Tema.textoSecundario
                            marcado: janela.aba !== null && janela.aba.pagina === modelData.id
                            dica: modelData.dica
                            onClicado: modelData.id === "expandir" ? ora.definir("trilho_compacto", false) : janela.abrirInterna(modelData.id)
                        }
                        Rectangle {
                            visible: modelData.id === "downloads" && ora.downloadsEmAndamento > 0
                            anchors { horizontalCenter: parent.horizontalCenter; horizontalCenterOffset: 10; top: parent.top }
                            width: 15; height: 15; radius: 8; color: Tema.azulDuia
                            Text { anchors.centerIn: parent; text: ora.downloadsEmAndamento; color: "white"; font { family: Tema.fonteTexto; pixelSize: 9; weight: Font.Bold } }
                        }
                    }
                }
            }
        }
    }

    // ---------------------------------------------------- Ilha: navegação, identidade do site e menu
    Item {
        id: ilha
        anchors { left: parent.left; right: parent.right; top: janela.posicaoAbas === "topo" ? faixaAbas.bottom : parent.top
                  leftMargin: janela.posicaoAbas === "esquerda" ? trilho.width : (janela.cromado ? 6 : 0)
                  rightMargin: janela.posicaoAbas === "direita" ? trilho.width : 0 }
        height: janela.cromado ? 44 : 0
        visible: height > 0
        z: 5
        // Arrastar pela barra move a janela; dois cliques expandem (no lugar da barra de título do sistema)
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.LeftButton
            onPressed: (m) => { if (!janela.maximizada) janela.startSystemMove() }
            onDoubleClicked: janela.maximizada ? janela.showNormal() : janela.showMaximized()
        }
        Rectangle {
            id: capsulaNavegacao
            anchors { left: parent.left; leftMargin: 4; verticalCenter: parent.verticalCenter }
            height: 32; radius: 16
            width: linhaNavegacao.implicitWidth + 8
            color: Tema.escuro ? Qt.rgba(1, 1, 1, 0.06) : Qt.rgba(1, 1, 1, 0.75)
            border { width: 1; color: Tema.borda }
            Row {
                id: linhaNavegacao
                anchors.centerIn: parent
                spacing: 0
                BotaoIcone { width: 28; height: 28; radius: 14; icone: "seta-esquerda"; dica: "Voltar (Alt+←)"
                             ativo: janela.aba !== null && janela.aba.podeVoltar; onClicado: janela.executar("voltar") }
                BotaoIcone { width: 28; height: 28; radius: 14; icone: "seta-direita"; dica: "Avançar (Alt+→)"
                             ativo: janela.web !== null && janela.aba.pagina === "" && janela.web.canGoForward; onClicado: janela.executar("avancar") }
                BotaoIcone {
                    width: 28; height: 28; radius: 14
                    icone: janela.aba && janela.aba.carregando ? "fechar" : "reiniciar"
                    dica: janela.aba && janela.aba.carregando ? "Parar (Esc)" : "Recarregar (F5)"
                    ativo: janela.web !== null && janela.aba.pagina === ""
                    onClicado: janela.aba.carregando ? janela.web.stop() : janela.web.reload()
                }
            }
        }
        BarraDeEndereco {
            id: barraEndereco
            anchors { verticalCenter: parent.verticalCenter }
            x: Math.max(capsulaNavegacao.x + capsulaNavegacao.width + 10,
                        Math.min((parent.width - width) / 2, acoesIlha.x - 10 - width))
            width: Math.min(760, acoesIlha.x - capsulaNavegacao.x - capsulaNavegacao.width - 20)
            janelaOra: janela
        }
        Row {
            id: acoesIlha
            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 4
            BotaoIcone { width: 30; height: 30; radius: 15; icone: "casa"; dica: "Início"
                         onClicado: janela.aba.navegar(ora.configuracoes.ao_iniciar === "pagina" && ora.configuracoes.pagina_inicial ? ora.normalizar(ora.configuracoes.pagina_inicial) : "") }
            // O menu do Ora abre pela marca (no lugar dos "três pontinhos")
            Rectangle {
                width: 30; height: 30; radius: 15
                color: janela.menuAberto || areaMenuOra.containsMouse ? Tema.realce : "transparent"
                MarcaOra { anchors.centerIn: parent; tamanho: 20; simples: true }
                MouseArea { id: areaMenuOra; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: janela.menuAberto = !janela.menuAberto }
                Dica { visivel: areaMenuOra.containsMouse && !janela.menuAberto; texto: "Menu do Ora" }
            }
            // Botões da janela aqui quando as abas não estão numa faixa em cima
            Item { visible: janela.posicaoAbas !== "topo"; width: 6; height: 1 }
            ControlesDaJanela { janela: janela; visible: janela.posicaoAbas !== "topo"; anchors.verticalCenter: parent.verticalCenter }
        }
    }

    // Cartão da página: margens, cantos arredondados (recortes do fundo por cima) e o fio de carregamento aurora
    Rectangle {
        id: molduraCartao
        visible: janela.cromado
        anchors.fill: areaConteudo
        anchors.margins: -1
        color: "transparent"
        radius: 15
        border { width: 1; color: Tema.borda }
        z: 4
    }
    Repeater {
        model: janela.cromado ? 4 : 0
        delegate: Canvas {
            required property int index
            readonly property int r: 14
            width: r; height: r
            z: 4
            x: index % 2 === 0 ? areaConteudo.x : areaConteudo.x + areaConteudo.width - r
            y: index < 2 ? areaConteudo.y : areaConteudo.y + areaConteudo.height - r
            property color cor: janela.corFundo
            onCorChanged: requestPaint()
            onPaint: {
                var c = getContext("2d"); c.reset()
                c.fillStyle = cor; c.fillRect(0, 0, r, r)
                c.globalCompositeOperation = "destination-out"
                c.beginPath(); c.arc(index % 2 === 0 ? r : 0, index < 2 ? r : 0, r, 0, 2 * Math.PI); c.fill()
            }
        }
    }
    Rectangle {
        anchors { left: areaConteudo.left; top: areaConteudo.top; leftMargin: 14 }
        z: 6
        height: 2; radius: 1
        visible: janela.cromado && janela.aba !== null && janela.aba.carregando
        width: (areaConteudo.width - 28) * (janela.aba ? janela.aba.progresso : 0)
        gradient: Gradient { orientation: Gradient.Horizontal
            GradientStop { position: 0; color: janela.ora1 } GradientStop { position: 0.5; color: janela.ora2 } GradientStop { position: 1; color: janela.ora3 } }
        Behavior on width { NumberAnimation { duration: 160 } }
    }

    // ============================================================ barras sobre o conteúdo
    // Pedido de permissão do site (câmera, microfone, localização, notificações...)
    Rectangle {
        id: barraPermissao
        visible: janela.permissao !== null
        anchors { top: areaConteudo.top; horizontalCenter: parent.horizontalCenter; topMargin: 10 }
        width: Math.min(parent.width - 32, linhaPermissao.implicitWidth + 32)
        height: 52; radius: Tema.raio
        color: Tema.vidro
        border { color: Tema.borda; width: 1 }
        z: 20
        Row {
            id: linhaPermissao
            anchors.centerIn: parent
            spacing: 12
            Icone { nome: "escudo"; tamanho: 18; cor: Tema.azulDuia; anchors.verticalCenter: parent.verticalCenter }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: janela.permissao ? "<b>" + ora.dominio(janela.permissao.origin.toString()) + "</b> quer " +
                                         ora.nomePermissao(janela.permissao.permissionType) : ""
                textFormat: Text.StyledText
                color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 }
            }
            Botao { texto: "Bloquear"; onClicado: { janela.permissao.deny(); janela.permissao = null } }
            Botao { texto: "Permitir"; tipo: "primario"; onClicado: { janela.permissao.grant(); janela.permissao = null } }
        }
    }
    // Compartilhar a tela (Meet, Teams...): a tela inteira, com confirmação
    Rectangle {
        visible: janela.pedidoTela !== null
        anchors { top: areaConteudo.top; horizontalCenter: parent.horizontalCenter; topMargin: 10 }
        width: Math.min(parent.width - 32, linhaTela.implicitWidth + 32)
        height: 52; radius: Tema.raio
        color: Tema.vidro
        border { color: Tema.borda; width: 1 }
        z: 21
        Row {
            id: linhaTela
            anchors.centerIn: parent
            spacing: 12
            Icone { nome: "monitor"; tamanho: 18; cor: Tema.azulDuia; anchors.verticalCenter: parent.verticalCenter }
            Text { anchors.verticalCenter: parent.verticalCenter; text: "Compartilhar a tela inteira com este site?"
                   color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
            Botao { texto: "Cancelar"; onClicado: { janela.pedidoTela.cancel(); janela.pedidoTela = null } }
            Botao { texto: "Compartilhar"; tipo: "primario"
                    onClicado: { janela.pedidoTela.selectScreen(janela.pedidoTela.screensModel.index(0, 0)); janela.pedidoTela = null } }
        }
    }
    // Buscar na página
    Rectangle {
        id: barraBusca
        property bool aberta: false
        property int total: 0
        property int ativo: 0
        function abrir() { aberta = true; campoBusca.entrada.forceActiveFocus(); campoBusca.entrada.selectAll() }
        function fechar() { aberta = false; if (janela.web) janela.web.findText(""); total = 0 }
        function resultado(n, a) { total = n; ativo = a }
        function buscar(paraTras) {
            if (!janela.web) return
            janela.web.findText(campoBusca.texto, paraTras ? WebEngineView.FindBackward : 0)
        }
        visible: aberta
        anchors { top: areaConteudo.top; right: parent.right; topMargin: 10; rightMargin: 16 }
        width: 400; height: 46; radius: Tema.raio
        color: Tema.vidro
        border { color: Tema.borda; width: 1 }
        z: 22
        Campo {
            id: campoBusca
            anchors { left: parent.left; leftMargin: 8; right: contagem.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
            height: 32
            icone: "busca"; dica: "Buscar na página"
            onTextoChanged: barraBusca.buscar(false)
            onConfirmado: barraBusca.buscar(false)
            Keys.onEscapePressed: barraBusca.fechar()
        }
        Text {
            id: contagem
            anchors { right: botoesBusca.left; rightMargin: 6; verticalCenter: parent.verticalCenter }
            text: campoBusca.texto === "" ? "" : (barraBusca.total === 0 ? "Nada" : barraBusca.ativo + " de " + barraBusca.total)
            color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 }
        }
        Row {
            id: botoesBusca
            anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
            BotaoIcone { icone: "seta-cima"; tamanhoIcone: 14; dica: "Anterior"; onClicado: barraBusca.buscar(true) }
            BotaoIcone { icone: "seta-baixo"; tamanhoIcone: 14; dica: "Próximo"; onClicado: barraBusca.buscar(false) }
            BotaoIcone { icone: "fechar"; tamanhoIcone: 13; dica: "Fechar"; onClicado: barraBusca.fechar() }
        }
    }
    // Endereço do link sob o mouse
    Rectangle {
        id: bolhaLink
        property string texto: ""
        visible: texto !== "" && janela.aba !== null && janela.aba.pagina === ""
        anchors { left: parent.left; bottom: parent.bottom; margins: 6 }
        width: Math.min(parent.width * 0.6, textoLink.implicitWidth + 20)
        height: 26; radius: 8
        color: Tema.vidro
        border { color: Tema.borda; width: 1 }
        z: 23
        Text { id: textoLink; anchors { fill: parent; leftMargin: 10; rightMargin: 10 } verticalAlignment: Text.AlignVCenter
               text: bolhaLink.texto; elide: Text.ElideMiddle; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
    }
    // Tela cheia: aviso de como sair
    Rectangle {
        id: avisoTelaCheia
        visible: opacity > 0
        opacity: 0
        anchors { top: parent.top; horizontalCenter: parent.horizontalCenter; topMargin: 24 }
        width: textoTelaCheia.implicitWidth + 32; height: 40; radius: 20
        color: Qt.rgba(0, 0, 0, 0.75)
        z: 30
        Text { id: textoTelaCheia; anchors.centerIn: parent; text: "Pressione Esc ou F11 para sair da tela cheia"
               color: "white"; font { family: Tema.fonteTexto; pixelSize: 13 } }
        Behavior on opacity { NumberAnimation { duration: 300 } }
        Timer { id: tempoTelaCheia; interval: 2600; onTriggered: avisoTelaCheia.opacity = 0 }
    }
    onVisibilityChanged: function () {
        if (janela.visibility === Window.FullScreen) { avisoTelaCheia.opacity = 1; tempoTelaCheia.restart() }
        else if (telaCheia) { telaCheia = false; if (web && web.isFullScreen) web.fullScreenCancelled() }
        if (janela.visibility !== Window.Minimized && janela.visibility !== Window.Hidden && janela.aba) janela.aba.redesenhar()
    }
    Shortcut { sequences: ["Escape"]; enabled: janela.visibility === Window.FullScreen; onActivated: janela.visibility = Window.Windowed }

    // ============================================================ bordas (a janela não tem moldura do sistema)
    Repeater {
        model: [
            { b: Qt.LeftEdge, c: Qt.SizeHorCursor }, { b: Qt.RightEdge, c: Qt.SizeHorCursor },
            { b: Qt.TopEdge, c: Qt.SizeVerCursor }, { b: Qt.BottomEdge, c: Qt.SizeVerCursor },
            { b: Qt.TopEdge | Qt.LeftEdge, c: Qt.SizeFDiagCursor }, { b: Qt.BottomEdge | Qt.RightEdge, c: Qt.SizeFDiagCursor },
            { b: Qt.TopEdge | Qt.RightEdge, c: Qt.SizeBDiagCursor }, { b: Qt.BottomEdge | Qt.LeftEdge, c: Qt.SizeBDiagCursor }
        ]
        delegate: MouseArea {
            required property var modelData
            readonly property bool esq: modelData.b & Qt.LeftEdge
            readonly property bool dir: modelData.b & Qt.RightEdge
            readonly property bool cima: modelData.b & Qt.TopEdge
            readonly property bool baixo: modelData.b & Qt.BottomEdge
            readonly property int g: 5
            enabled: !janela.maximizada && janela.visibility !== Window.FullScreen
            visible: enabled
            z: 60
            x: dir ? janela.width - g * (cima || baixo ? 3 : 1) : 0
            y: baixo ? janela.height - g * (esq || dir ? 3 : 1) : 0
            width: (esq || dir) ? g * (cima || baixo ? 3 : 1) : janela.width
            height: (cima || baixo) ? g * (esq || dir ? 3 : 1) : janela.height
            cursorShape: modelData.c
            onPressed: janela.startSystemResize(modelData.b)
        }
    }

    // ============================================================ menu do Ora (pela marca, na ilha)
    MouseArea { anchors.fill: parent; visible: janela.menuAberto; z: 40; onClicked: janela.menuAberto = false }
    Rectangle {
        id: menu
        visible: janela.menuAberto
        z: 41
        anchors { right: parent.right; rightMargin: 10; top: ilha.bottom; topMargin: -4 }
        width: 280
        height: colunaMenu.implicitHeight + 16
        radius: Tema.raio
        color: Tema.vidro
        border { color: Tema.borda; width: 1 }
        Column {
            id: colunaMenu
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 8 }
            spacing: 1
            ItemDeMenu { width: parent.width; texto: "Nova aba"; icone: "mais"; atalho: "Ctrl+T"; onClicado: { janela.menuAberto = false; janela.executar("nova-aba") } }
            ItemDeMenu { width: parent.width; texto: "Nova janela"; icone: "monitor"; atalho: "Ctrl+N"; onClicado: { janela.menuAberto = false; janela.executar("nova-janela") } }
            ItemDeMenu { width: parent.width; texto: "Nova janela privada"; icone: "olho"; atalho: "Ctrl+Shift+N"; onClicado: { janela.menuAberto = false; janela.executar("nova-privada") } }
            Separador { width: parent.width }
            ItemDeMenu { width: parent.width; texto: "Histórico"; icone: "recentes"; atalho: "Ctrl+H"; onClicado: { janela.menuAberto = false; janela.executar("historico") } }
            ItemDeMenu { width: parent.width; texto: "Favoritos"; icone: "estrela"; atalho: "Ctrl+Shift+O"; onClicado: { janela.menuAberto = false; janela.executar("favoritos") } }
            ItemDeMenu { width: parent.width; texto: "Downloads"; icone: "download"; atalho: "Ctrl+J"; onClicado: { janela.menuAberto = false; janela.executar("downloads") } }
            Separador { width: parent.width }
            Item {
                width: parent.width; height: 34
                Text { anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter } text: "Zoom"
                       color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
                Row {
                    anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
                    spacing: 4
                    BotaoIcone { icone: "seta-baixo"; tamanhoIcone: 13; dica: "Diminuir"; ativo: janela.web !== null; onClicado: janela.executar("zoom-menos") }
                    Text { width: 44; horizontalAlignment: Text.AlignHCenter; anchors.verticalCenter: parent.verticalCenter
                           text: janela.web ? Math.round(janela.web.zoomFactor * 100) + "%" : "100%"
                           color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
                    BotaoIcone { icone: "seta-cima"; tamanhoIcone: 13; dica: "Aumentar"; ativo: janela.web !== null; onClicado: janela.executar("zoom-mais") }
                    BotaoIcone { icone: "monitor"; tamanhoIcone: 13; dica: "Tela cheia"; onClicado: { janela.menuAberto = false; janela.executar("tela-cheia") } }
                }
            }
            ItemDeMenu { width: parent.width; texto: "Buscar na página"; icone: "busca"; atalho: "Ctrl+F"; ativo: janela.web !== null; onClicado: { janela.menuAberto = false; janela.executar("buscar") } }
            ItemDeMenu { width: parent.width; texto: "Salvar como PDF"; icone: "pdf"; atalho: "Ctrl+P"; ativo: janela.web !== null; onClicado: { janela.menuAberto = false; janela.executar("pdf") } }
            ItemDeMenu { width: parent.width; texto: "Ferramentas do desenvolvedor"; icone: "codigo"; atalho: "F12"; ativo: janela.web !== null; onClicado: { janela.menuAberto = false; janela.executar("devtools") } }
            Separador { width: parent.width }
            ItemDeMenu { width: parent.width; texto: "Configurações"; icone: "engrenagem"; onClicado: { janela.menuAberto = false; janela.executar("configuracoes") } }
        }
    }

    // ============================================================ abas numa faixa, em cima ou embaixo (ADR 076)
    Rectangle {
        id: faixaAbas
        visible: janela.cromado && !janela.abasNaLateral
        anchors { left: parent.left; right: parent.right }
        y: janela.posicaoAbas === "topo" ? 0 : janela.height - height
        height: visible ? 40 : 0
        color: "transparent"
        z: 5
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.LeftButton
            onPressed: (m) => { if (!janela.maximizada) janela.startSystemMove() }
            onDoubleClicked: janela.maximizada ? janela.showNormal() : janela.showMaximized()
        }
        MarcaOra {
            id: marcaFaixa
            anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
            tamanho: 20
            girando: janela.aba !== null && janela.aba.carregando
        }
        ListView {
            id: listaAbasFaixa
            anchors { left: marcaFaixa.right; leftMargin: 12; top: parent.top; bottom: parent.bottom; topMargin: 5; bottomMargin: 4 }
            readonly property real espaco: atalhosFaixa.x - 56 - x
            width: Math.min(contentWidth, espaco)
            orientation: ListView.Horizontal
            clip: true
            spacing: 4
            model: abas
            boundsBehavior: Flickable.StopAtBounds
            currentIndex: janela.atual
            onCurrentIndexChanged: positionViewAtIndex(currentIndex, ListView.Contain)
            readonly property real larguraAba: Math.max(116, Math.min(224, (espaco - (abas.count - 1) * spacing) / Math.max(1, abas.count)))
            delegate: Rectangle {
                id: chip
                required property int index
                readonly property Item conteudo: repetidor.count > index ? repetidor.itemAt(index) : null
                readonly property bool ativa: index === janela.atual
                width: listaAbasFaixa.larguraAba; height: listaAbasFaixa.height
                radius: height / 2
                color: ativa ? Tema.fundo : (areaChip.containsMouse ? Tema.realce : "transparent")
                border { width: ativa ? 1 : 0; color: Tema.borda }
                Rectangle {          // filete aurora embaixo da aba ativa
                    visible: chip.ativa
                    anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 3 }
                    width: Math.min(46, parent.width * 0.3); height: 3; radius: 2
                    gradient: Gradient { orientation: Gradient.Horizontal
                        GradientStop { position: 0; color: janela.ora1 } GradientStop { position: 1; color: janela.ora3 } }
                }
                MouseArea {
                    id: areaChip
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                    onClicked: (m) => {
                        if (m.button === Qt.MiddleButton) janela.fecharAba(chip.index)
                        else if (m.button === Qt.RightButton) janela.abrirMenuDaAba(chip.index, chip, m.x, m.y)
                        else janela.atual = chip.index
                    }
                }
                Item {
                    id: iconeChip
                    anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                    width: 16; height: 16
                    Image {
                        anchors.fill: parent
                        visible: chip.conteudo && chip.conteudo.icone !== "" && !chip.conteudo.carregando
                        source: chip.conteudo && chip.conteudo.icone !== "" ? chip.conteudo.icone : ""
                        sourceSize: Qt.size(32, 32)
                    }
                    Icone {
                        anchors.centerIn: parent
                        visible: chip.conteudo && chip.conteudo.icone === "" && !chip.conteudo.carregando
                        nome: chip.conteudo && chip.conteudo.pagina !== "" ? ({ historico: "recentes", favoritos: "estrela", downloads: "download",
                                                                                configuracoes: "engrenagem", inicio: "casa" })[chip.conteudo.pagina] || "globo" : "globo"
                        tamanho: 14; cor: Tema.textoSecundario
                    }
                    MarcaOra { anchors.centerIn: parent; tamanho: 16; simples: true; girando: true
                               visible: chip.conteudo !== null && chip.conteudo.carregando }
                }
                Text {
                    anchors { left: iconeChip.right; leftMargin: 8; right: fecharChip.visible ? fecharChip.left : parent.right
                              rightMargin: fecharChip.visible ? 2 : 12; verticalCenter: parent.verticalCenter }
                    text: chip.conteudo ? chip.conteudo.titulo : ""
                    elide: Text.ElideRight
                    color: chip.ativa ? Tema.texto : Tema.textoSecundario
                    font { family: Tema.fonteTexto; pixelSize: 13; weight: chip.ativa ? Font.DemiBold : Font.Normal }
                }
                BotaoIcone {
                    id: fecharChip
                    visible: chip.ativa || areaChip.containsMouse || chip.width > 160
                    anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                    width: 22; height: 22; radius: 11
                    icone: "fechar"; tamanhoIcone: 10; corIcone: Tema.textoSecundario
                    dica: "Fechar a aba"
                    onClicado: janela.fecharAba(chip.index)
                }
            }
        }
        BotaoIcone {
            id: botaoMaisFaixa
            anchors { left: listaAbasFaixa.right; leftMargin: 6; verticalCenter: parent.verticalCenter }
            width: 28; height: 28; radius: 14
            icone: "mais"; tamanhoIcone: 14; dica: "Nova aba (Ctrl+T)"
            onClicado: { janela.novaAba("", true); janela.focarEndereco() }
        }
        ControlesDaJanela {
            id: controlesFaixa
            janela: janela
            visible: janela.posicaoAbas === "topo"
            anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
        }
        Row {
            id: atalhosFaixa
            anchors { right: controlesFaixa.visible ? controlesFaixa.left : parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
            spacing: 2
            Repeater {
                model: [{ id: "historico", icone: "recentes", dica: "Histórico (Ctrl+H)" },
                        { id: "favoritos", icone: "estrela", dica: "Favoritos (Ctrl+Shift+O)" },
                        { id: "downloads", icone: "download", dica: "Downloads (Ctrl+J)" },
                        { id: "configuracoes", icone: "engrenagem", dica: "Configurações" }]
                delegate: Item {
                    required property var modelData
                    width: 28; height: 28
                    BotaoIcone {
                        anchors.fill: parent; radius: 14
                        icone: modelData.icone; tamanhoIcone: 15; corIcone: Tema.textoSecundario
                        marcado: janela.aba !== null && janela.aba.pagina === modelData.id
                        dica: modelData.dica
                        onClicado: janela.abrirInterna(modelData.id)
                    }
                    Rectangle {
                        visible: modelData.id === "downloads" && ora.downloadsEmAndamento > 0
                        anchors { right: parent.right; top: parent.top }
                        width: 14; height: 14; radius: 7; color: Tema.azulDuia
                        Text { anchors.centerIn: parent; text: ora.downloadsEmAndamento; color: "white"; font { family: Tema.fonteTexto; pixelSize: 9; weight: Font.Bold } }
                    }
                }
            }
        }
    }

    // ============================================================ menus de contexto (página e abas)
    property var menuWeb: null                     // a vista que pediu o menu da página
    property var menuPedido: ({})                  // cópia do que estava sob o mouse
    property int menuAba: -1
    function abrirMenuDaPagina(vista, pedido) {
        var c = { link: pedido.linkUrl.toString(), textoLink: pedido.linkText, midia: pedido.mediaUrl.toString(), tipo: pedido.mediaType,
                  selecao: pedido.selectedText, editavel: pedido.isContentEditable, errada: pedido.misspelledWord,
                  sugestoes: pedido.spellCheckerSuggestions, flags: pedido.editFlags, flagsMidia: pedido.mediaFlags }
        menuWeb = vista; menuPedido = c
        var itens = [], sep = { separador: true }
        function add(id, texto, icone, atalho, ativo) { itens.push({ id: id, texto: texto, icone: icone || "", atalho: atalho || "", ativo: ativo !== false }) }
        function fim() { if (itens.length && !itens[itens.length - 1].separador) itens.push(sep) }
        if (c.errada !== "") {
            for (var i = 0; i < Math.min(5, c.sugestoes.length); i++) add("sugestao:" + c.sugestoes[i], c.sugestoes[i], "check")
            if (c.sugestoes.length === 0) add("nada", "Nenhuma sugestão", "", "", false)
            fim()
        }
        if (c.link !== "") {
            add("link-aba", "Abrir o link em nova aba", "mais")
            add("link-janela", "Abrir o link em nova janela", "janela")
            if (!janela.privada) add("link-privada", "Abrir o link numa janela privada", "olho")
            add("link-copiar", "Copiar o endereço do link", "copiar")
            add("link-salvar", "Salvar o link como…", "download")
            fim()
        }
        if (c.tipo === ContextMenuRequest.MediaTypeImage) {
            add("img-aba", "Abrir a imagem em nova aba", "imagem")
            add("img-salvar", "Salvar a imagem como…", "download")
            add("img-copiar", "Copiar a imagem", "copiar")
            add("img-endereco", "Copiar o endereço da imagem", "globo")
            fim()
        } else if (c.tipo === ContextMenuRequest.MediaTypeVideo || c.tipo === ContextMenuRequest.MediaTypeAudio) {
            var pausado = (c.flagsMidia & ContextMenuRequest.MediaPaused) !== 0
            var mudo = (c.flagsMidia & ContextMenuRequest.MediaMuted) !== 0
            add("midia-tocar", pausado ? "Reproduzir" : "Pausar", pausado ? "video" : "video")
            add("midia-som", mudo ? "Ligar o som" : "Tirar o som", mudo ? "som-0" : "som-mudo")
            add("midia-repetir", (c.flagsMidia & ContextMenuRequest.MediaLoop) ? "Não repetir" : "Repetir", "reiniciar")
            if (c.flagsMidia & ContextMenuRequest.MediaCanToggleControls) add("midia-controles", "Mostrar os controles", "controles")
            if (c.flagsMidia & ContextMenuRequest.MediaCanSave) add("midia-salvar", c.tipo === ContextMenuRequest.MediaTypeVideo ? "Salvar o vídeo como…" : "Salvar o áudio como…", "download")
            add("midia-endereco", "Copiar o endereço do " + (c.tipo === ContextMenuRequest.MediaTypeVideo ? "vídeo" : "áudio"), "globo")
            fim()
        }
        if (c.editavel) {
            add("desfazer", "Desfazer", "restaurar", "Ctrl+Z", (c.flags & ContextMenuRequest.CanUndo) !== 0)
            add("refazer", "Refazer", "reiniciar", "Ctrl+Shift+Z", (c.flags & ContextMenuRequest.CanRedo) !== 0)
            fim()
            add("recortar", "Recortar", "recortar", "Ctrl+X", (c.flags & ContextMenuRequest.CanCut) !== 0)
            add("copiar", "Copiar", "copiar", "Ctrl+C", (c.flags & ContextMenuRequest.CanCopy) !== 0)
            add("colar", "Colar", "colar", "Ctrl+V", (c.flags & ContextMenuRequest.CanPaste) !== 0)
            add("colar-simples", "Colar sem formatação", "colar", "Ctrl+Shift+V", (c.flags & ContextMenuRequest.CanPaste) !== 0)
            add("tudo", "Selecionar tudo", "", "Ctrl+A", (c.flags & ContextMenuRequest.CanSelectAll) !== 0)
            fim()
        } else if (c.selecao !== "") {
            add("copiar", "Copiar", "copiar", "Ctrl+C")
            var trecho = c.selecao.length > 24 ? c.selecao.slice(0, 24).trim() + "…" : c.selecao
            add("buscar-selecao", "Buscar “" + trecho + "” no " + janela.nomeDoBuscador(), "busca")
            fim()
        }
        if (c.link === "" && c.tipo === ContextMenuRequest.MediaTypeNone && !c.editavel && c.selecao === "") {
            add("voltar", "Voltar", "seta-esquerda", "Alt+←", vista.canGoBack)
            add("avancar", "Avançar", "seta-direita", "Alt+→", vista.canGoForward)
            add("recarregar", "Recarregar", "reiniciar", "Ctrl+R")
            fim()
            add("salvar-pagina", "Salvar a página como…", "download", "Ctrl+S")
            add("pdf", "Salvar como PDF…", "pdf", "Ctrl+P")
            add("favoritar", ora.ehFavorito(vista.url.toString()) ? "Editar o favorito…" : "Adicionar aos favoritos…", "estrela", "Ctrl+D")
            add("codigo", "Ver o código-fonte", "codigo", "Ctrl+U")
            fim()
        }
        add("inspecionar", "Inspecionar", "terminal", "Ctrl+Shift+I")
        var ponto = vista.mapToItem(janela.contentItem, pedido.position.x, pedido.position.y)
        menuFlutuante.alvo = "pagina"
        menuFlutuante.abrir(ponto.x, ponto.y, itens)
    }
    function nomeDoBuscador() {
        var lista = ora.buscadores()
        for (var i = 0; i < lista.length; i++) if (lista[i].id === ora.configuracoes.buscador) return lista[i].nome
        return "Google"
    }
    function abrirMenuDaAba(indice, item, mx, my) {
        menuAba = indice
        var conteudo = repetidor.itemAt(indice)
        var temWeb = conteudo && conteudo.pagina === "" && conteudo.web
        var itens = [
            { id: "aba-nova", texto: "Nova aba ao lado", icone: "mais" },
            { id: "aba-recarregar", texto: "Recarregar", icone: "reiniciar", ativo: !!temWeb },
            { id: "aba-duplicar", texto: "Duplicar", icone: "copiar", ativo: !!conteudo && conteudo.url !== "" },
            { id: "aba-som", texto: temWeb && conteudo.mudo ? "Ligar o som da aba" : "Silenciar a aba", icone: temWeb && conteudo.mudo ? "som-0" : "som-mudo", ativo: !!temWeb },
            { separador: true },
            { id: "aba-fechar", texto: "Fechar a aba", icone: "fechar", atalho: "Ctrl+W" },
            { id: "aba-outras", texto: "Fechar as outras abas", ativo: abas.count > 1 },
            { id: "aba-depois", texto: janela.abasNaLateral ? "Fechar as abas abaixo" : "Fechar as abas à direita", ativo: indice < abas.count - 1 },
            { separador: true },
            { id: "aba-reabrir", texto: "Reabrir a aba fechada", icone: "restaurar", atalho: "Ctrl+Shift+T", ativo: janela.fechadas.length > 0 }]
        var ponto = item.mapToItem(janela.contentItem, mx, my)
        menuFlutuante.alvo = "aba"
        menuFlutuante.abrir(ponto.x, ponto.y, itens)
    }
    function escolhaDoMenu(id) {
        var v = menuWeb, c = menuPedido
        if (id.indexOf("sugestao:") === 0) { if (v) v.replaceMisspelledWord(id.slice(9)); return }
        switch (id) {
        case "link-aba": novaAba(c.link, ora.configuracoes.ir_para_nova_aba !== false, atual); break
        case "link-janela": ora.novaJanela(false, c.link); break
        case "link-privada": ora.novaJanela(true, c.link); break
        case "link-copiar": v.triggerWebAction(WebEngineView.CopyLinkToClipboard); break
        case "link-salvar": v.triggerWebAction(WebEngineView.DownloadLinkToDisk); break
        case "img-aba": novaAba(c.midia, true, atual); break
        case "img-salvar": v.triggerWebAction(WebEngineView.DownloadImageToDisk); break
        case "img-copiar": v.triggerWebAction(WebEngineView.CopyImageToClipboard); break
        case "img-endereco": v.triggerWebAction(WebEngineView.CopyImageUrlToClipboard); break
        case "midia-tocar": v.triggerWebAction(WebEngineView.ToggleMediaPlayPause); break
        case "midia-som": v.triggerWebAction(WebEngineView.ToggleMediaMute); break
        case "midia-repetir": v.triggerWebAction(WebEngineView.ToggleMediaLoop); break
        case "midia-controles": v.triggerWebAction(WebEngineView.ToggleMediaControls); break
        case "midia-salvar": v.triggerWebAction(WebEngineView.DownloadMediaToDisk); break
        case "midia-endereco": v.triggerWebAction(WebEngineView.CopyMediaUrlToClipboard); break
        case "desfazer": v.triggerWebAction(WebEngineView.Undo); break
        case "refazer": v.triggerWebAction(WebEngineView.Redo); break
        case "recortar": v.triggerWebAction(WebEngineView.Cut); break
        case "copiar": v.triggerWebAction(WebEngineView.Copy); break
        case "colar": v.triggerWebAction(WebEngineView.Paste); break
        case "colar-simples": v.triggerWebAction(WebEngineView.PasteAndMatchStyle); break
        case "tudo": v.triggerWebAction(WebEngineView.SelectAll); break
        case "buscar-selecao": novaAba(ora.urlDeBusca(c.selecao), true, atual); break
        case "voltar": v.goBack(); break
        case "avancar": v.goForward(); break
        case "recarregar": v.reload(); break
        case "salvar-pagina": v.triggerWebAction(WebEngineView.SavePage); break
        case "pdf": executar("pdf"); break
        case "favoritar": barraEndereco.abrirFavorito(); break
        case "codigo": executar("codigo-fonte"); break
        case "inspecionar": if (v) { executar("devtools"); Qt.callLater(function () { v.triggerWebAction(WebEngineView.InspectElement) }) } break
        // menu das abas
        case "aba-nova": novaAba("", true, menuAba); focarEndereco(); break
        case "aba-recarregar": repetidor.itemAt(menuAba).web.reload(); break
        case "aba-duplicar": novaAba(repetidor.itemAt(menuAba).url, true, menuAba); break
        case "aba-som": var w = repetidor.itemAt(menuAba).web; w.audioMuted = !w.audioMuted; break
        case "aba-fechar": fecharAba(menuAba); break
        case "aba-outras": { var manter = abas.get(menuAba).uid
                             for (var i = abas.count - 1; i >= 0; i--) if (abas.get(i).uid !== manter) fecharAba(i) } break
        case "aba-depois": for (var j = abas.count - 1; j > menuAba; j--) fecharAba(j); break
        case "aba-reabrir": reabrirFechada(); break
        }
    }
    MenuFlutuante {
        id: menuFlutuante
        property string alvo: ""
        onEscolhido: (id) => janela.escolhaDoMenu(id)
    }

    // ============================================================ chave de acesso e chave de segurança (WebAuthn)
    // Sem resposta a este pedido, o site ficava parado em "Verificando sua identidade…". O Ora conduz a chave de
    // segurança USB (NFC/USB FIDO2): escolher a conta, digitar o PIN, tocar na chave. Usar o celular (QR) ainda não
    // é possível no motor web: a pessoa escolhe outra forma de entrar no próprio site.
    property var pedidoChave: null
    Rectangle {
        anchors.fill: parent
        visible: janela.pedidoChave !== null
        z: 85
        color: Qt.rgba(0, 0, 0, Tema.escuro ? 0.5 : 0.3)
        MouseArea { anchors.fill: parent }
        Connections {
            target: janela.pedidoChave && janela.pedidoChave.stateChanged !== undefined ? janela.pedidoChave : null
            ignoreUnknownSignals: true
            function onStateChanged() {
                var e = janela.pedidoChave.state
                if (e === WebEngineWebAuthUxRequest.WebAuthUxState.Completed || e === WebEngineWebAuthUxRequest.WebAuthUxState.Cancelled)
                    janela.pedidoChave = null
            }
        }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width - 48, 460)
            height: colunaChave.implicitHeight + 48
            radius: 18
            color: Tema.cartao
            border { width: 1; color: Tema.borda }
            readonly property int estado: janela.pedidoChave ? janela.pedidoChave.state : -1
            Column {
                id: colunaChave
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 24 }
                spacing: 14
                Row {
                    spacing: 12
                    Rectangle { width: 40; height: 40; radius: 12; color: Qt.rgba(0.24, 0.36, 1, 0.14)
                                Icone { anchors.centerIn: parent; nome: "chave"; tamanho: 20; cor: "#3D5BFF" } }
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        Text { text: "Entrar com chave de acesso"; color: Tema.texto; font { family: Tema.fonteTitulo; pixelSize: 17; weight: Font.Bold } }
                        Text { text: janela.pedidoChave ? janela.pedidoChave.relyingPartyId : ""; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                    }
                }
                Rotulo {
                    width: parent.width; font.pixelSize: 14
                    readonly property int e: parent.parent.estado
                    text: e === WebEngineWebAuthUxRequest.WebAuthUxState.SelectAccount ? "Escolha com qual conta entrar:"
                        : e === WebEngineWebAuthUxRequest.WebAuthUxState.CollectPin ? "Digite o PIN da sua chave de segurança."
                        : e === WebEngineWebAuthUxRequest.WebAuthUxState.FinishTokenCollection ? "Toque na sua chave de segurança mais uma vez."
                        : e === WebEngineWebAuthUxRequest.WebAuthUxState.RequestFailed ? janela.motivoFalhaChave()
                        : "Conecte a sua chave de segurança (USB) e toque nela quando ela piscar."
                }
                Rotulo {
                    visible: parent.parent.estado !== WebEngineWebAuthUxRequest.WebAuthUxState.RequestFailed
                    width: parent.width; secundario: true; font.pixelSize: 12
                    text: "Para usar a chave de acesso guardada no celular (QR Code), o Ora ainda não tem suporte. Feche esta janela e, no site, escolha \"Tentar de outro jeito\" para entrar com senha ou código."
                }
                Column {
                    visible: parent.parent.estado === WebEngineWebAuthUxRequest.WebAuthUxState.SelectAccount
                    width: parent.width; spacing: 6
                    Repeater {
                        model: janela.pedidoChave ? janela.pedidoChave.userNames : []
                        delegate: Botao { required property var modelData; width: parent.width; texto: modelData
                                          onClicado: janela.pedidoChave.setSelectedAccount(modelData) }
                    }
                }
                Campo {
                    id: campoPin
                    visible: parent.parent.estado === WebEngineWebAuthUxRequest.WebAuthUxState.CollectPin
                    width: parent.width; height: 38; senha: true; icone: "cadeado"; dica: "PIN"
                    onConfirmado: if (texto !== "") { janela.pedidoChave.setPin(texto); texto = "" }
                }
                Text {
                    visible: campoPin.visible && janela.pedidoChave && janela.pedidoChave.pinRequest.remainingAttempts > 0
                             && janela.pedidoChave.pinRequest.error !== WebEngineWebAuthUxRequest.PinEntryError.NoError
                    width: parent.width; wrapMode: Text.WordWrap
                    text: janela.pedidoChave ? "PIN incorreto. Restam " + janela.pedidoChave.pinRequest.remainingAttempts + " tentativas." : ""
                    color: Tema.erro; font { family: Tema.fonteTexto; pixelSize: 12 }
                }
                Row {
                    anchors.right: parent.right
                    spacing: 10
                    Botao { texto: "Cancelar"; onClicado: { if (janela.pedidoChave) janela.pedidoChave.cancel(); janela.pedidoChave = null } }
                    Botao { visible: parent.parent.parent.estado === WebEngineWebAuthUxRequest.WebAuthUxState.RequestFailed
                            texto: "Tentar de novo"; tipo: "primario"; onClicado: janela.pedidoChave.retry() }
                    Botao { visible: campoPin.visible; texto: "Continuar"; tipo: "primario"
                            onClicado: if (campoPin.texto !== "") { janela.pedidoChave.setPin(campoPin.texto); campoPin.texto = "" } }
                }
            }
        }
    }
    function motivoFalhaChave() {
        if (!pedidoChave) return ""
        var m = pedidoChave.requestFailureReason, R = WebEngineWebAuthUxRequest.RequestFailureReason
        if (m === R.Timeout) return "O tempo acabou antes de você tocar na chave."
        if (m === R.KeyNotRegistered) return "Esta chave de segurança não está cadastrada neste site."
        if (m === R.KeyAlreadyRegistered) return "Esta chave de segurança já está cadastrada neste site."
        if (m === R.SoftPinBlock || m === R.HardPinBlock) return "A chave foi bloqueada por PIN errado demais. Desconecte e conecte de novo (ou veja o manual dela)."
        if (m === R.UserConsentDenied) return "O pedido foi recusado na chave."
        return "Não deu certo com esta chave de segurança. Tente de novo ou escolha outra forma de entrar no site."
    }

    // ============================================================ apresentação da primeira abertura (ADR 075)
    Loader {
        id: apresentacao
        anchors.fill: parent
        z: 90
        active: !janela.privada && !janela.modoAplicativo
                && (ora.demonstracao ? (typeof paginaDemonstracao !== "undefined" && paginaDemonstracao === "apresentacao")
                                     : ora.configuracoes.apresentacao_vista !== true)
        sourceComponent: Apresentacao {
            passo: typeof passoDemonstracao !== "undefined" ? passoDemonstracao : 0
            onConcluida: { apresentacao.active = false; janela.focarEndereco() }
        }
    }

    // Capturas de demonstração do menu das abas e do pedido de chave de acesso
    Timer {
        interval: 600
        running: typeof paginaDemonstracao !== "undefined" && (paginaDemonstracao === "menu-aba" || paginaDemonstracao === "chave")
        onTriggered: {
            if (paginaDemonstracao === "menu-aba") janela.abrirMenuDaAba(0, janela.contentItem, 120, 260)
            else janela.pedidoChave = { state: WebEngineWebAuthUxRequest.WebAuthUxState.Discovery, userNames: [],
                                        relyingPartyId: "accounts.google.com", requestFailureReason: 0,
                                        pinRequest: { remainingAttempts: 0, error: 0 } }
        }
    }

    // Captura das ferramentas do desenvolvedor encaixadas (--pagina ferramentas)
    Timer {
        interval: 900
        running: typeof paginaDemonstracao !== "undefined" && paginaDemonstracao === "ferramentas"
        onTriggered: if (janela.web) janela.abrirDevTools(janela.web)
    }

    Aviso { id: aviso; anchors { bottom: parent.bottom; horizontalCenter: parent.horizontalCenter; bottomMargin: 24 } z: 50 }

    // Captura de tela para os testes e a documentação
    Timer {
        interval: 3500
        running: typeof capturaArquivo !== "undefined" && capturaArquivo !== ""
        onTriggered: janela.contentItem.grabToImage(function (r) { r.saveToFile(capturaArquivo); Qt.quit() })
    }
}
