// DuiaOS — Ora: a marca (o anel aurora com a órbita), desenhada no QML para poder ser animada.
// simples: só o anel e a órbita (sem o quadrado de fundo do ícone); girando: a órbita gira (carregando);
// desenho (0 a 1): quanto do anel já foi traçado; orbita (0 a 1): a órbita aparecendo — usados na apresentação.
import QtQuick

Item {
    id: marca
    property real tamanho: 32
    property bool simples: false
    property bool girando: false
    property real desenho: 1
    property real orbita: 1
    readonly property color cor1: "#22D3EE"
    readonly property color cor2: "#3D5BFF"
    readonly property color cor3: "#A78BFA"
    width: tamanho; height: tamanho

    Rectangle {
        visible: !marca.simples
        anchors.fill: parent
        radius: width * 0.22
        gradient: Gradient {
            GradientStop { position: 0; color: "#16205C" }
            GradientStop { position: 1; color: "#0A0F1F" }
        }
    }
    Canvas {
        id: anel
        anchors.fill: parent
        property real desenho: marca.desenho
        onDesenhoChanged: requestPaint()
        onWidthChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            c.reset()
            var s = width / 128
            var g = c.createLinearGradient(34 * s, 34 * s, 94 * s, 94 * s)
            g.addColorStop(0, marca.cor1); g.addColorStop(0.5, marca.cor2); g.addColorStop(1, marca.cor3)
            c.strokeStyle = g
            c.lineWidth = (marca.simples ? 15 : 11) * s
            c.lineCap = "round"
            c.beginPath()
            var inicio = -Math.PI / 2
            c.arc(64 * s, 64 * s, (marca.simples ? 38 : 30) * s, inicio, inicio + 2 * Math.PI * Math.max(0.001, desenho), false)
            c.stroke()
        }
    }
    Item {
        id: orbita
        anchors.fill: parent
        opacity: marca.orbita
        rotation: -28
        Canvas {
            anchors.fill: parent
            onWidthChanged: requestPaint()
            onPaint: {
                var c = getContext("2d")
                c.reset()
                var s = width / 128
                c.strokeStyle = marca.simples ? marca.cor2 : Qt.rgba(1, 1, 1, 0.85)
                c.globalAlpha = marca.simples ? 0.55 : 1
                c.lineWidth = Math.max(1, 3 * s)
                c.beginPath()
                c.ellipse((64 - 54) * s, (64 - 17) * s, 108 * s, 34 * s)
                c.stroke()
            }
        }
        // O satélite percorre a órbita
        Item {
            id: satelite
            property real angulo: -0.72
            anchors.fill: parent
            Rectangle {
                readonly property real s: marca.width / 128
                width: Math.max(3, 10 * s); height: width; radius: width / 2
                color: marca.simples ? marca.cor1 : "white"
                x: (64 + 54 * Math.cos(satelite.angulo)) * s - width / 2
                y: (64 + 17 * Math.sin(satelite.angulo)) * s - height / 2
            }
            NumberAnimation on angulo {
                running: marca.girando
                from: -0.72; to: -0.72 + 2 * Math.PI
                duration: 1100; loops: Animation.Infinite
            }
        }
    }
}
