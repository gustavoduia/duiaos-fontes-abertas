// DuiaOS — Ora: apresentação da primeira abertura (ADR 075).
// A marca é traçada e ganha a órbita; depois as boas-vindas e as perguntas de primeiro acesso: navegador padrão,
// importar de outro navegador, buscador e jeito do trilho. "Pular" vale em qualquer passo; tudo pode ser mudado
// depois em Configurações.
import QtQuick
import DuiaOS

Rectangle {
    id: apresentacao
    property int passo: 0                       // 0 marca · 1 boas-vindas · 2 padrão · 3 importar · 4 seu jeito · 5 pronto
    readonly property int ultimo: 5
    property bool padrao: false
    property var navegadores: []
    property var importados: ({})               // caminho → mensagem do resultado
    signal concluida()

    color: Tema.escuro ? "#0A0E1C" : "#F4F6FC"

    function avancar() { if (passo < ultimo) passo++; else concluir() }
    function concluir() { ora.definir("apresentacao_vista", true); concluida() }
    Component.onCompleted: { padrao = ora.ehPadrao(); navegadores = ora.navegadoresParaImportar() }

    // Brilhos aurora no fundo, que se mexem devagar
    Repeater {
        model: [{ c: "#22D3EE", x: -0.15, y: -0.25 }, { c: "#3D5BFF", x: 0.55, y: 0.45 }, { c: "#A78BFA", x: 0.75, y: -0.3 }]
        delegate: Canvas {
            required property var modelData
            required property int index
            width: apresentacao.width * 0.8; height: width
            x: apresentacao.width * modelData.x; y: apresentacao.height * modelData.y
            opacity: Tema.escuro ? 0.30 : 0.22
            onWidthChanged: requestPaint()
            onPaint: {          // mancha de luz com borda esfumada
                var c = getContext("2d"); c.reset()
                var g = c.createRadialGradient(width / 2, height / 2, 0, width / 2, height / 2, width / 2)
                g.addColorStop(0, modelData.c); g.addColorStop(1, "transparent")
                c.fillStyle = g; c.fillRect(0, 0, width, height)
            }
            SequentialAnimation on scale {
                loops: Animation.Infinite
                NumberAnimation { from: 1; to: 1.12; duration: 5200 + index * 900; easing.type: Easing.InOutSine }
                NumberAnimation { from: 1.12; to: 1; duration: 5200 + index * 900; easing.type: Easing.InOutSine }
            }
        }
    }
    MouseArea { anchors.fill: parent }          // nada passa para a janela de trás

    // ------------------------------------------------------------ passo 0: a marca sendo traçada
    Item {
        id: abertura
        anchors.fill: parent
        visible: apresentacao.passo === 0
        MarcaOra {
            id: marcaGrande
            anchors { horizontalCenter: parent.horizontalCenter; verticalCenter: parent.verticalCenter; verticalCenterOffset: -40 }
            tamanho: 168
            simples: true
            desenho: 0; orbita: 0
            scale: 0.86
        }
        Text {
            id: nomeOra
            anchors { horizontalCenter: parent.horizontalCenter; top: marcaGrande.bottom; topMargin: 22 }
            text: "Ora"
            opacity: 0
            color: Tema.texto
            font { family: Tema.fonteTitulo; pixelSize: 44; weight: Font.Bold; letterSpacing: 1.5 }
        }
        Text {
            id: frase
            anchors { horizontalCenter: parent.horizontalCenter; top: nomeOra.bottom; topMargin: 6 }
            text: "O navegador do DuiaOS"
            opacity: 0
            color: Tema.textoSecundario
            font { family: Tema.fonteTexto; pixelSize: 16 }
        }
        SequentialAnimation {
            running: apresentacao.passo === 0
            PauseAnimation { duration: 250 }
            ParallelAnimation {
                NumberAnimation { target: marcaGrande; property: "desenho"; from: 0; to: 1; duration: 1100; easing.type: Easing.InOutCubic }
                NumberAnimation { target: marcaGrande; property: "scale"; from: 0.86; to: 1; duration: 1300; easing.type: Easing.OutBack }
            }
            ParallelAnimation {
                NumberAnimation { target: marcaGrande; property: "orbita"; to: 1; duration: 450 }
                ScriptAction { script: marcaGrande.girando = true }
                NumberAnimation { target: nomeOra; property: "opacity"; to: 1; duration: 500 }
                NumberAnimation { target: nomeOra; property: "anchors.topMargin"; from: 38; to: 22; duration: 600; easing.type: Easing.OutCubic }
            }
            NumberAnimation { target: frase; property: "opacity"; to: 1; duration: 450 }
            PauseAnimation { duration: 1200 }
            ScriptAction { script: { marcaGrande.girando = false; apresentacao.passo = 1 } }
        }
        MouseArea { anchors.fill: parent; onClicked: apresentacao.passo = 1 }
    }

    // ------------------------------------------------------------ passos 1 a 5: um cartão no centro
    Rectangle {
        id: cartao
        visible: apresentacao.passo > 0
        anchors.centerIn: parent
        width: Math.min(parent.width - 48, 620)
        height: Math.min(parent.height - 48, conteudo.implicitHeight + 200)
        radius: 22
        color: Tema.escuro ? Qt.rgba(0.08, 0.10, 0.18, 0.92) : Qt.rgba(1, 1, 1, 0.94)
        border { width: 1; color: Tema.borda }
        opacity: visible ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 250 } }

        MarcaOra { id: marcaCartao; anchors { left: parent.left; top: parent.top; margins: 26 } tamanho: 34; simples: true }
        Text {
            anchors { verticalCenter: marcaCartao.verticalCenter; left: marcaCartao.right; leftMargin: 10 }
            text: "Ora"; color: Tema.texto; font { family: Tema.fonteTitulo; pixelSize: 18; weight: Font.Bold }
        }
        Text {
            visible: apresentacao.passo < apresentacao.ultimo
            anchors { verticalCenter: marcaCartao.verticalCenter; right: parent.right; rightMargin: 26 }
            text: "Pular"; color: Tema.textoSecundario
            font { family: Tema.fonteTexto; pixelSize: 13; underline: areaPular.containsMouse }
            MouseArea { id: areaPular; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: apresentacao.concluir() }
        }

        Column {
            id: conteudo
            anchors { left: parent.left; right: parent.right; top: marcaCartao.bottom; margins: 34; topMargin: 26 }
            spacing: 18

            // --- 1: boas-vindas
            Column {
                visible: apresentacao.passo === 1
                width: parent.width; spacing: 18
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: "Bem-vindo ao Ora"; font.pixelSize: 28 }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: "Rápido, compatível com a web de hoje e feito para o DuiaOS. Veja o que muda em relação aos outros navegadores:" }
                Repeater {
                    model: [{ i: "barra", t: "Abas no trilho", d: "As abas ficam numa coluna ao lado, com os títulos inteiros. Os sites que você mais usa ficam fixados no alto." },
                            { i: "escudo", t: "Privacidade de verdade", d: "Pede aos sites que não rastreiem você, tem janela privada e pergunta antes de liberar câmera, microfone ou localização." },
                            { i: "globo", t: "Integrado ao sistema", d: "Os menus ficam na Barra de Recursos, os downloads avisam nas notificações e qualquer site vira um aplicativo." }]
                    delegate: Row {
                        required property var modelData
                        width: conteudo.width; spacing: 14
                        Rectangle {
                            width: 38; height: 38; radius: 12
                            gradient: Gradient { orientation: Gradient.Horizontal
                                GradientStop { position: 0; color: "#22D3EE" } GradientStop { position: 1; color: "#3D5BFF" } }
                            Icone { anchors.centerIn: parent; nome: modelData.i; tamanho: 18; cor: "white" }
                        }
                        Column {
                            width: parent.width - 52; spacing: 2
                            Text { text: modelData.t; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                            Text { width: parent.width; text: modelData.d; wrapMode: Text.WordWrap; color: Tema.textoSecundario
                                   font { family: Tema.fonteTexto; pixelSize: 13 } }
                        }
                    }
                }
            }

            // --- 2: navegador padrão
            Column {
                visible: apresentacao.passo === 2
                width: parent.width; spacing: 18
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: apresentacao.padrao ? "O Ora é o seu navegador" : "Usar o Ora como navegador padrão?"; font.pixelSize: 26 }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: apresentacao.padrao
                               ? "Links que você abre em outros programas (e-mails, documentos, mensagens) já abrem no Ora."
                               : "Assim, os links que você abre em outros programas (e-mails, documentos, mensagens) abrem no Ora." }
                Row {
                    spacing: 10
                    visible: apresentacao.padrao
                    Rectangle { width: 26; height: 26; radius: 13; color: Qt.rgba(0.13, 0.83, 0.93, 0.18)
                                Icone { anchors.centerIn: parent; nome: "check"; tamanho: 14; cor: "#0E9FB5" } }
                    Text { anchors.verticalCenter: parent.verticalCenter; text: "Navegador padrão do sistema"
                           color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                }
                Botao { visible: !apresentacao.padrao; texto: "Usar o Ora como padrão"; tipo: "primario"
                        onClicado: { ora.tornarPadrao(); apresentacao.padrao = true } }
            }

            // --- 3: importar
            Column {
                visible: apresentacao.passo === 3
                width: parent.width; spacing: 14
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: "Trazer seus favoritos"; font.pixelSize: 26 }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: apresentacao.navegadores.length > 0
                               ? "Achamos estes navegadores neste computador. Os favoritos vêm para uma pasta com o nome de cada um."
                               : "Não achamos outro navegador neste computador. Se tiver seus favoritos num arquivo (.html), importe depois em Favoritos › Importar." }
                Repeater {
                    model: apresentacao.navegadores
                    delegate: Rectangle {
                        required property var modelData
                        width: conteudo.width; height: 54; radius: 14
                        color: Tema.escuro ? Qt.rgba(1, 1, 1, 0.04) : "#F3F5FB"
                        border { width: 1; color: Tema.borda }
                        Icone { id: iconeNav; anchors { left: parent.left; leftMargin: 16; verticalCenter: parent.verticalCenter }
                                nome: "globo"; tamanho: 18; cor: Tema.textoSecundario }
                        Column {
                            anchors { left: iconeNav.right; leftMargin: 12; right: botaoImportar.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            Text { text: modelData.nome; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                            Text { visible: text !== ""; width: parent.width; elide: Text.ElideRight
                                   text: apresentacao.importados[modelData.caminho] || ""
                                   color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                        }
                        Botao {
                            id: botaoImportar
                            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            texto: apresentacao.importados[modelData.caminho] ? "Importado" : "Importar favoritos"
                            ativo: !apresentacao.importados[modelData.caminho]
                            onClicado: {
                                var copia = Object.assign({}, apresentacao.importados)
                                copia[modelData.caminho] = ora.importar(modelData.id, modelData.caminho)
                                apresentacao.importados = copia
                            }
                        }
                    }
                }
            }

            // --- 4: seu jeito
            Column {
                visible: apresentacao.passo === 4
                width: parent.width; spacing: 14
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: "Do seu jeito"; font.pixelSize: 26 }
                Text { text: "Buscar com"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                Flow {
                    width: parent.width; spacing: 8
                    Repeater {
                        model: ora.buscadores()
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool escolhido: ora.configuracoes.buscador === modelData.id
                            width: textoBuscador.implicitWidth + 28; height: 34; radius: 17
                            color: escolhido ? "#3D5BFF" : (areaBuscador.containsMouse ? Tema.realce : "transparent")
                            border { width: escolhido ? 0 : 1; color: Tema.bordaForte }
                            Text { id: textoBuscador; anchors.centerIn: parent; text: modelData.nome
                                   color: parent.escolhido ? "white" : Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
                            MouseArea { id: areaBuscador; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                        onClicked: ora.definir("buscador", modelData.id) }
                        }
                    }
                }
                Text { text: "Onde ficam as abas"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                Flow {
                    width: parent.width; spacing: 8
                    Repeater {
                        model: [{ v: "esquerda", t: "À esquerda" }, { v: "direita", t: "À direita" }, { v: "topo", t: "Em cima" }, { v: "rodape", t: "Embaixo" }]
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool escolhido: (ora.configuracoes.posicao_abas || "esquerda") === modelData.v
                            width: textoPosicao.implicitWidth + 28; height: 34; radius: 17
                            color: escolhido ? "#3D5BFF" : (areaPosicao.containsMouse ? Tema.realce : "transparent")
                            border { width: escolhido ? 0 : 1; color: Tema.bordaForte }
                            Text { id: textoPosicao; anchors.centerIn: parent; text: modelData.t
                                   color: parent.escolhido ? "white" : Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
                            MouseArea { id: areaPosicao; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                        onClicked: ora.definir("posicao_abas", modelData.v) }
                        }
                    }
                }
                Row {
                    visible: (ora.configuracoes.posicao_abas || "esquerda") === "esquerda" || ora.configuracoes.posicao_abas === "direita"
                    spacing: 12
                    Repeater {
                        model: [{ v: false, t: "Trilho expandido", d: "ícone e título" }, { v: true, t: "Trilho recolhido", d: "só os ícones" }]
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool escolhido: (ora.configuracoes.trilho_compacto === true) === modelData.v
                            width: (conteudo.width - 12) / 2; height: 92; radius: 14
                            color: Tema.escuro ? Qt.rgba(1, 1, 1, 0.04) : "#F3F5FB"
                            border { width: escolhido ? 2 : 1; color: escolhido ? "#3D5BFF" : Tema.borda }
                            // miniatura do trilho
                            Rectangle {
                                anchors { left: parent.left; top: parent.top; bottom: parent.bottom; margins: 12 }
                                width: modelData.v ? 18 : 54; radius: 6
                                color: Tema.escuro ? Qt.rgba(1, 1, 1, 0.08) : "#DFE4F2"
                                Column { anchors { fill: parent; margins: 5 } spacing: 4
                                    Repeater { model: 4; Rectangle { width: parent.width; height: 6; radius: 3; color: index === 0 ? "#3D5BFF" : Tema.bordaForte } } }
                            }
                            Column {
                                anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                                Text { anchors.right: parent.right; text: modelData.t; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13; weight: Font.DemiBold } }
                                Text { anchors.right: parent.right; text: modelData.d; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                            }
                            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: ora.definir("trilho_compacto", modelData.v) }
                        }
                    }
                }
                Row {
                    spacing: 12
                    Interruptor { ligado: ora.configuracoes.nao_rastrear === true; onAlternado: (v) => ora.definir("nao_rastrear", v) }
                    Text { anchors.verticalCenter: parent.verticalCenter; text: "Pedir aos sites que não me rastreiem"
                           color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
                }
            }

            // --- 5: pronto
            Column {
                visible: apresentacao.passo === 5
                width: parent.width; spacing: 16
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: "Tudo pronto"; font.pixelSize: 28 }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: "Alguns atalhos para começar. Tudo o que você escolheu aqui pode ser mudado em Configurações." }
                Grid {
                    columns: 2; columnSpacing: 18; rowSpacing: 10
                    Repeater {
                        model: [["Ctrl T", "Nova aba"], ["Ctrl L", "Ir para a barra de endereço"], ["Ctrl Shift N", "Janela privada"],
                                ["Ctrl D", "Adicionar aos favoritos"], ["Ctrl Shift T", "Reabrir a aba fechada"]]
                        delegate: Row {
                            required property var modelData
                            spacing: 10
                            Rectangle { width: Math.max(64, teclas.implicitWidth + 16); height: 26; radius: 7
                                        color: Tema.escuro ? Qt.rgba(1, 1, 1, 0.07) : "#EEF1F8"; border { width: 1; color: Tema.borda }
                                        Text { id: teclas; anchors.centerIn: parent; text: modelData[0]; color: Tema.texto
                                               font { family: Tema.fonteCodigo; pixelSize: 12 } } }
                            Text { anchors.verticalCenter: parent.verticalCenter; text: modelData[1]; color: Tema.textoSecundario
                                   font { family: Tema.fonteTexto; pixelSize: 13 } }
                        }
                    }
                }
            }
        }

        // ------------------------------------------------------------ rodapé: pontos e botões
        Row {
            anchors { left: parent.left; leftMargin: 34; bottom: parent.bottom; bottomMargin: 34 }
            spacing: 6
            Repeater {
                model: apresentacao.ultimo
                delegate: Rectangle {
                    required property int index
                    width: index + 1 === apresentacao.passo ? 22 : 8; height: 8; radius: 4
                    color: index + 1 === apresentacao.passo ? "#3D5BFF" : Tema.bordaForte
                    Behavior on width { NumberAnimation { duration: 200 } }
                }
            }
        }
        Row {
            anchors { right: parent.right; rightMargin: 26; bottom: parent.bottom; bottomMargin: 26 }
            spacing: 10
            Botao { visible: apresentacao.passo > 1; texto: "Voltar"; onClicado: apresentacao.passo-- }
            Botao {
                tipo: "primario"
                texto: ({ 1: "Começar", 2: apresentacao.padrao ? "Continuar" : "Agora não", 3: "Continuar", 4: "Continuar",
                          5: "Começar a navegar" })[apresentacao.passo] || "Continuar"
                onClicado: apresentacao.avancar()
            }
        }
    }
    Keys.onReturnPressed: if (passo > 0) avancar()
    Keys.onEscapePressed: concluir()
    focus: visible
}
