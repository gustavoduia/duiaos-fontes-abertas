// DuiaOS — Ora: barra de endereço.
// Fora de foco é uma placa com a identidade do site no centro; em foco, o endereço inteiro selecionado. Enquanto a
// pessoa digita, as sugestões (buscar no buscador escolhido, favoritos e histórico) aparecem por baixo.
// A estrela adiciona ou tira a página dos favoritos.
import QtQuick
import DuiaOS

Rectangle {
    id: barra
    property var janelaOra
    readonly property var aba: janelaOra ? janelaOra.aba : null
    readonly property string url: aba ? aba.url : ""
    readonly property bool web: aba !== null && aba.pagina === ""
    readonly property bool seguro: url.indexOf("https://") === 0
    property bool favorito: false
    property var sugestoes: []
    property int escolhida: -1

    function focar() { entrada.forceActiveFocus(); entrada.selectAll() }
    function atualizarFavorito() { favorito = web && url !== "" ? ora.ehFavorito(url) : false }
    // Estrela: guarda a página (nos Fixados) e abre o editor para escolher o nome e a pasta, ou criar uma pasta
    function abrirFavorito() {
        if (!web || url === "" || janelaOra.privada) return
        if (!favorito) { ora.salvarFavorito(url, aba.titulo, ""); favorito = true; editorFavorito.novo = true }
        else editorFavorito.novo = false
        var f = ora.favoritoDe(url)
        editorFavorito.pasta = f.pasta || ""
        nomeFavorito.texto = f.titulo || aba.titulo
        editorFavorito.criando = false
        editorFavorito.visible = true
        editorFavorito.posicionar()
        nomeFavorito.entrada.forceActiveFocus(); nomeFavorito.entrada.selectAll()
    }
    function alternarFavorito() {
        if (!web || url === "") return
        favorito = ora.alternarFavorito(url, aba.titulo)
    }
    onUrlChanged: { if (!entrada.activeFocus) entrada.text = textoDoEndereco(); atualizarFavorito() }
    Connections { target: ora; function onFavoritosMudaram() { barra.atualizarFavorito() } }
    function textoDoEndereco() { return url.indexOf("ora://") === 0 ? url : url }

    function confirmar() {
        var texto = escolhida >= 0 && escolhida < sugestoes.length ? sugestoes[escolhida].url : entrada.text
        if (texto.trim() === "") return
        entrada.focus = false
        sugestoes = []
        janelaOra.abrir(texto, false)
        if (aba && aba.web) aba.web.forceActiveFocus()
    }
    function calcularSugestoes() {
        var texto = entrada.text.trim()
        if (!entrada.activeFocus || texto === "" || texto === url) { sugestoes = []; return }
        var buscador = ""
        var lista = ora.buscadores()
        for (var i = 0; i < lista.length; i++) if (lista[i].id === ora.configuracoes.buscador) buscador = lista[i].nome
        var itens = [{ url: texto, titulo: "Buscar “" + texto + "” no " + buscador, tipo: "busca" }]
        var achados = ora.sugestoes(texto)
        for (var j = 0; j < achados.length; j++) itens.push(achados[j])
        sugestoes = itens
        escolhida = -1
    }

    height: 32
    radius: 11
    color: entrada.activeFocus ? Tema.cartao : (Tema.escuro ? Qt.rgba(1, 1, 1, 0.06) : Qt.rgba(1, 1, 1, 0.75))
    border { width: entrada.activeFocus ? 2 : 1; color: entrada.activeFocus ? "#3D5BFF" : Tema.borda }
    Aurora {
        visible: Tema.futurista && entrada.activeFocus
        z: -1
        anchors { fill: parent; margins: -3 }
        radius: parent.radius + 3
        opacity: 0.30
    }

    Icone {
        id: cadeado
        opacity: entrada.visible ? 1 : 0
        anchors { left: parent.left; leftMargin: 13; verticalCenter: parent.verticalCenter }
        nome: entrada.activeFocus || barra.url === "" ? "busca" : (barra.web ? (barra.seguro ? "cadeado" : "info") : "globo")
        tamanho: 14
        cor: !entrada.activeFocus && barra.web && !barra.seguro && barra.url.indexOf("http://") === 0 ? Tema.aviso : Tema.textoSecundario
    }
    Text {
        id: naoSeguro
        visible: !entrada.activeFocus && barra.web && barra.url.indexOf("http://") === 0
        anchors { left: cadeado.right; leftMargin: 6; verticalCenter: parent.verticalCenter }
        text: "Não seguro"
        color: Tema.aviso
        font { family: Tema.fonteTexto; pixelSize: 13; weight: Font.DemiBold }
    }
    TextInput {
        id: entrada
        anchors { left: naoSeguro.visible ? naoSeguro.right : cadeado.right; leftMargin: naoSeguro.visible ? 8 : 9
                  right: estrela.left; rightMargin: 6; verticalCenter: parent.verticalCenter }
        clip: true
        color: Tema.texto
        selectionColor: Tema.azulDuia
        selectedTextColor: "white"
        activeFocusOnTab: true
        font { family: Tema.fonteTexto; pixelSize: 14 }
        selectByMouse: true
        inputMethodHints: Qt.ImhUrlCharactersOnly | Qt.ImhNoAutoUppercase
        visible: activeFocus || barra.url === "" || barra.url.indexOf("ora://") === 0
        onActiveFocusChanged: {
            // Endereço inteiro selecionado, mostrado desde o começo (o fim cortado à direita, como nos outros navegadores)
            if (activeFocus) { text = barra.textoDoEndereco(); Qt.callLater(function () { entrada.selectAll(); entrada.ensureVisible(0) }) }
            else { text = barra.textoDoEndereco(); barra.sugestoes = [] }
        }
        onTextEdited: barra.calcularSugestoes()
        onAccepted: barra.confirmar()
        Keys.onEscapePressed: { text = barra.textoDoEndereco(); barra.sugestoes = []; focus = false }
        Keys.onDownPressed: if (barra.sugestoes.length) barra.escolhida = Math.min(barra.escolhida + 1, barra.sugestoes.length - 1)
        Keys.onUpPressed: if (barra.sugestoes.length) barra.escolhida = Math.max(barra.escolhida - 1, -1)
        Text {
            anchors.fill: parent
            verticalAlignment: Text.AlignVCenter
            visible: entrada.text === "" && !entrada.preeditText
            text: "Buscar ou digitar um endereço"
            color: Tema.textoApagado
            font: entrada.font
        }
    }
    // Fora de foco: a identidade do site no centro (cadeado, o site em destaque e o título da página), como
    // uma placa — o endereço completo aparece ao clicar (ADR 075)
    Item {
        id: areaIdentidade
        visible: !entrada.visible
        anchors { left: parent.left; right: estrela.visible ? estrela.left : parent.right; top: parent.top; bottom: parent.bottom
                  leftMargin: 12; rightMargin: 8 }
        clip: true
        Row {
            id: identidade
            anchors.centerIn: parent
            spacing: 8
            Rectangle {
                id: seloSite
                anchors.verticalCenter: parent.verticalCenter
                width: 22; height: 22; radius: 11
                color: barra.seguro ? Qt.rgba(0.13, 0.83, 0.93, 0.16) : (barra.url.indexOf("http://") === 0 ? Qt.rgba(0.96, 0.62, 0.04, 0.18) : Tema.realce)
                Icone { anchors.centerIn: parent; tamanho: 12
                        nome: barra.seguro ? "cadeado" : "info"
                        cor: barra.seguro ? "#0E9FB5" : (barra.url.indexOf("http://") === 0 ? Tema.aviso : Tema.textoSecundario) }
            }
            Text {
                id: textoSite
                anchors.verticalCenter: parent.verticalCenter
                width: Math.min(implicitWidth, areaIdentidade.width - seloSite.width - 8)
                elide: Text.ElideMiddle
                text: barra.url.indexOf("http://") === 0 ? "Não seguro · " + ora.dominio(barra.url) : (ora.dominio(barra.url) || ora.paraMostrar(barra.url))
                color: barra.url.indexOf("http://") === 0 ? Tema.aviso : Tema.texto
                font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold }
            }
            Text {
                id: tituloSite
                readonly property real sobra: areaIdentidade.width - seloSite.width - textoSite.width - 24
                anchors.verticalCenter: parent.verticalCenter
                visible: barra.aba !== null && barra.aba.titulo !== "" && sobra > 100 && ora.dominio(barra.url) !== ""
                width: Math.min(implicitWidth, Math.max(0, sobra))
                elide: Text.ElideRight
                text: "·  " + (barra.aba ? barra.aba.titulo : "")
                color: Tema.textoSecundario
                font { family: Tema.fonteTexto; pixelSize: 13 }
            }
        }
    }
    MouseArea {
        anchors { left: entrada.left; right: entrada.right; top: parent.top; bottom: parent.bottom }
        visible: !entrada.visible
        cursorShape: Qt.IBeamCursor
        onClicked: barra.focar()
    }
    BotaoIcone {
        id: estrela
        anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
        width: 28; height: 28; radius: 14
        visible: barra.web && barra.url !== "" && !janelaOra.privada
        icone: barra.favorito ? "estrela-cheia" : "estrela"; tamanhoIcone: 15
        corIcone: barra.favorito ? "#3D5BFF" : Tema.textoSecundario
        marcado: editorFavorito.visible
        dica: barra.favorito ? "Editar o favorito (Ctrl+D)" : "Adicionar aos favoritos (Ctrl+D)"
        onClicado: editorFavorito.visible ? editorFavorito.visible = false : barra.abrirFavorito()
    }

    // ------------------------------------------------------------ sugestões (fora do cabeçalho, que corta)
    Rectangle {
        id: painel
        parent: janelaOra ? janelaOra.contentItem : barra
        visible: barra.sugestoes.length > 0 && entrada.activeFocus
        z: 60
        readonly property point origem: barra.mapToItem(parent, 0, barra.height + 6)
        x: origem.x; y: origem.y
        width: barra.width
        height: colunaSugestoes.implicitHeight + 12
        radius: Tema.raio
        color: Tema.vidro
        border { color: Tema.borda; width: 1 }
        Column {
            id: colunaSugestoes
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 6 }
            Repeater {
                model: barra.sugestoes
                delegate: Rectangle {
                    required property var modelData
                    required property int index
                    width: colunaSugestoes.width; height: 38; radius: 8
                    color: index === barra.escolhida || areaSug.containsMouse ? Tema.selecao : "transparent"
                    Icone {
                        id: iconeSug
                        anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                        nome: modelData.tipo === "busca" ? "busca" : (modelData.tipo === "favorito" ? "estrela" : "recentes")
                        tamanho: 14; cor: Tema.textoSecundario
                    }
                    Text {
                        id: tituloSug
                        anchors { left: iconeSug.right; leftMargin: 10; verticalCenter: parent.verticalCenter }
                        width: Math.min(implicitWidth, parent.width * 0.55)
                        text: modelData.tipo === "busca" ? modelData.titulo : (modelData.titulo || modelData.url)
                        elide: Text.ElideRight
                        color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 }
                    }
                    Text {
                        visible: modelData.tipo !== "busca"
                        anchors { left: tituloSug.right; leftMargin: 8; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        text: "— " + ora.paraMostrar(modelData.url)
                        elide: Text.ElideRight
                        color: Tema.azulDuia; font { family: Tema.fonteTexto; pixelSize: 13 }
                    }
                    MouseArea { id: areaSug; anchors.fill: parent; hoverEnabled: true
                                onClicked: { barra.escolhida = index; barra.confirmar() } }
                }
            }
        }
    }

    // ------------------------------------------------------------ editor do favorito (nome e pasta)
    MouseArea {
        parent: janelaOra ? janelaOra.contentItem : barra
        anchors.fill: parent
        visible: editorFavorito.visible
        z: 69
        onPressed: editorFavorito.visible = false
    }
    Rectangle {
        id: editorFavorito
        property bool novo: false
        property bool criando: false
        property string pasta: ""
        parent: janelaOra ? janelaOra.contentItem : barra
        visible: false
        z: 70
        function posicionar() {
            var o = estrela.mapToItem(parent, estrela.width, estrela.height + 8)
            x = Math.max(8, Math.min(parent.width - width - 8, o.x - width))
            y = Math.min(o.y, parent.height - height - 8)
        }
        width: 340
        height: colunaFavorito.implicitHeight + 32
        radius: 14
        color: Tema.cartao
        border { color: Tema.borda; width: 1 }
        MouseArea { anchors.fill: parent }
        function concluir() {
            ora.salvarFavorito(barra.url, nomeFavorito.texto, pasta)
            visible = false
        }
        Keys.onEscapePressed: visible = false
        Column {
            id: colunaFavorito
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 16 }
            spacing: 12
            Row {
                spacing: 8
                Icone { nome: "estrela-cheia"; tamanho: 16; cor: "#3D5BFF"; anchors.verticalCenter: parent.verticalCenter }
                Text { text: editorFavorito.novo ? "Favorito adicionado" : "Editar o favorito"; anchors.verticalCenter: parent.verticalCenter
                       color: Tema.texto; font { family: Tema.fonteTitulo; pixelSize: 15; weight: Font.Bold } }
            }
            Text { text: "Nome"; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
            Campo { id: nomeFavorito; width: parent.width; height: 34; onConfirmado: editorFavorito.concluir() }
            Text { text: "Pasta"; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
            Flickable {
                width: parent.width
                height: Math.min(170, colunaPastas.implicitHeight)
                contentHeight: colunaPastas.implicitHeight
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: colunaPastas
                    width: parent.width
                    spacing: 2
                    Repeater {
                        model: [""].concat(ora.pastasDeFavoritos.indexOf(editorFavorito.pasta) < 0 && editorFavorito.pasta !== ""
                                           ? ora.pastasDeFavoritos.concat([editorFavorito.pasta]) : ora.pastasDeFavoritos)
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool escolhida: editorFavorito.pasta === modelData
                            width: colunaPastas.width; height: 32; radius: 8
                            color: escolhida ? Tema.selecao : (areaPastaFav.containsMouse ? Tema.realce : "transparent")
                            Icone { id: iconePastaFav; anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                                    nome: modelData === "" ? "estrela" : "pasta"; tamanho: 15
                                    cor: parent.escolhida ? "#3D5BFF" : Tema.textoSecundario }
                            Text { anchors { left: iconePastaFav.right; leftMargin: 10; right: marcaPastaFav.left; verticalCenter: parent.verticalCenter }
                                   text: modelData === "" ? "Fixados (no alto do trilho)" : modelData; elide: Text.ElideRight
                                   color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13; weight: parent.escolhida ? Font.DemiBold : Font.Normal } }
                            Icone { id: marcaPastaFav; visible: parent.escolhida; anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                                    nome: "check"; tamanho: 14; cor: "#3D5BFF" }
                            MouseArea { id: areaPastaFav; anchors.fill: parent; hoverEnabled: true; onClicked: editorFavorito.pasta = modelData }
                        }
                    }
                }
            }
            Item {
                width: parent.width; height: 34
                Text {
                    visible: !editorFavorito.criando
                    anchors.verticalCenter: parent.verticalCenter
                    text: "+ Nova pasta"; color: "#3D5BFF"
                    font { family: Tema.fonteTexto; pixelSize: 13; weight: Font.DemiBold }
                    MouseArea { anchors.fill: parent; anchors.margins: -6; cursorShape: Qt.PointingHandCursor
                                onClicked: { editorFavorito.criando = true; nomePasta.texto = ""; nomePasta.entrada.forceActiveFocus() } }
                }
                Campo {
                    id: nomePasta
                    visible: editorFavorito.criando
                    anchors { left: parent.left; right: criarPasta.left; rightMargin: 8 }
                    height: 34; icone: "nova-pasta"; dica: "Nome da pasta"
                    onConfirmado: criarPasta.clicado()
                }
                Botao {
                    id: criarPasta
                    visible: editorFavorito.criando
                    anchors.right: parent.right
                    texto: "Criar"
                    onClicado: if (nomePasta.texto.trim() !== "") { editorFavorito.pasta = nomePasta.texto.trim(); editorFavorito.criando = false }
                }
            }
            Row {
                anchors.right: parent.right
                spacing: 8
                Botao { texto: "Remover"; tipo: "perigo"; onClicado: { ora.removerFavorito(barra.url); editorFavorito.visible = false } }
                Botao { texto: "Pronto"; tipo: "primario"; onClicado: editorFavorito.concluir() }
            }
        }
    }
}
