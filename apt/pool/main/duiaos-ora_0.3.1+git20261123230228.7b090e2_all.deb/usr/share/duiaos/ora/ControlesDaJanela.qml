// DuiaOS — Ora: os botões da janela (expandir, minimizar e fechar) na própria barra do navegador, no lugar da
// barra de título do sistema (ADR 077). As bolinhas em tons de azul do tema DuiaOS (ADR 054), na mesma ordem
// das outras janelas; o símbolo aparece com o mouse em cima, como no macOS.
import QtQuick
import QtQuick.Window
import DuiaOS

Row {
    id: controles
    property var janela
    spacing: 8
    readonly property bool maximizada: janela && (janela.visibility === Window.Maximized || janela.visibility === Window.FullScreen)
    HoverHandler { id: sobre }

    function minimizar() {
        // Com o efeito da Ilha (gênio ou escala), como o botão amarelo das outras janelas; sem a Ilha, direto
        if (!ora.minimizarComEfeito()) janela.showMinimized()
    }
    function alternarMaximizar() { if (maximizada) janela.showNormal(); else janela.showMaximized() }

    Repeater {
        model: [{ id: "expandir", cor: "#7DD3FC", corEscura: "#38BDF8", icone: controles.maximizada ? "restaurar" : "mais",
                  dica: controles.maximizada ? "Restaurar" : "Expandir" },
                { id: "minimizar", cor: "#60A5FA", corEscura: "#3B82F6", icone: "seta-baixo", dica: "Minimizar" },
                { id: "fechar", cor: "#3D5BFF", corEscura: "#2F4BE0", icone: "fechar", dica: "Fechar" }]
        delegate: Rectangle {
            required property var modelData
            width: 14; height: 14; radius: 7
            anchors.verticalCenter: parent.verticalCenter
            color: area.pressed ? modelData.corEscura : modelData.cor
            border { width: 1; color: Qt.rgba(0, 0, 0, 0.08) }
            Icone { anchors.centerIn: parent; visible: sobre.hovered; nome: modelData.icone; tamanho: 9; cor: Qt.rgba(0.05, 0.1, 0.25, 0.75) }
            MouseArea {
                id: area
                anchors { fill: parent; margins: -4 }
                onClicked: {
                    if (modelData.id === "fechar") controles.janela.close()
                    else if (modelData.id === "minimizar") controles.minimizar()
                    else controles.alternarMaximizar()
                }
            }
            Accessible.role: Accessible.Button
            Accessible.name: modelData.dica
        }
    }
}
