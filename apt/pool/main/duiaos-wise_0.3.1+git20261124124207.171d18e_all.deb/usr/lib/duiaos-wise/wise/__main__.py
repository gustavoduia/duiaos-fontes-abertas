"""python3 -m wise — abre o Wise (mesmo que /usr/bin/duiaos-wise)."""
import sys

if "--aquecer-no-boot" in sys.argv[1:]:
    # Serviço do sistema (antes do login): sem interface, sem Qt
    from .aquecimento import main
    sys.exit(main())
if "--medir-modelos" in sys.argv[1:]:
    # Medição dos modelos locais (ADR 080): sem interface
    from .medir import main as medir
    sys.exit(medir([a for a in sys.argv[1:] if a != "--medir-modelos"]))
from .interface.main import main

sys.exit(main())
