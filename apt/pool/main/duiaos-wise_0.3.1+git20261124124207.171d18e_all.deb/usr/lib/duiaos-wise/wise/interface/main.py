"""Janela do Wise (QML + PySide6).

Uso:
  duiaos-wise               abre a janela (ou traz para a frente, se já estiver aberta)
  duiaos-wise --alternar    abre ou fecha a janela (Barra de Recursos, Ilha, Super+W, bolha)
  duiaos-wise --fundo       inicia sem mostrar a janela e cumprimenta a pessoa
                            (o DuiaOS chama assim ao abrir a sessão; se já houver
                            um Wise rodando, espera ele terminar para assumir)
  duiaos-wise --desligar    desliga o Wise até ser aberto de novo (e tira a IA local da memória)
  duiaos-wise --demonstracao  sem modelos reais (para testar a interface)
  duiaos-wise --sem-bolha     sem o botão flutuante (testes)
  duiaos-wise --diagnostico   envia agora o diagnóstico ao repositório de diagnósticos (se configurado)
  duiaos-wise --diagnostico-arquivo ARQUIVO [--horas N]
                              grava o diagnóstico das últimas N horas (24) num arquivo para anexar

Uma instância só por pessoa: os pedidos seguintes chegam por um socket local.
O Wise fica sempre rodando: fechar a janela só o põe para descansar (a bolha
continua no canto da tela). Não há opção de sair.
"""
import json
import os
import pwd
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, Property, QTimer, Signal, Slot
from PySide6.QtGui import QGuiApplication, QIcon
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtQml import QQmlApplicationEngine

from .. import VERSAO, agenda, diagnostico, ia_do_sistema, microfone, motores, ouvido_nuvem, segredos, voz, voz_nuvem
from ..agenda import oauth
from ..ferramentas import clima
from ..auditoria import Auditoria
from ..configuracao import Configuracao
from ..ferramentas import registro_padrao
from ..modelos import Gateway
from ..orquestrador import Orquestrador
from .presenca import Presenca

PASTA = Path(__file__).resolve().parent
NOME_SOCKET = f"duiaos-wise-{os.getuid()}"
CONFIGURACOES = "/usr/bin/duiaos-configuracoes"      # Configurações do DuiaOS (páginas "ia" e "wise")
ESPERA_MAXIMA_DA_VOZ_MS = 5000                       # texto escondido esperando a voz começar: no máximo 5 s (ADR 082)
ESPERA_DA_NUVEM_MS = 3000                           # o reconhecimento na nuvem tem até 3 s depois do local (ADR 081)
# Com este arquivo, a sessão não reabre o Wise (a pessoa escolheu "Desligar o Wise" na Barra de Recursos)
ARQUIVO_DESLIGADO = Path(os.environ.get("XDG_RUNTIME_DIR") or "/tmp") / "duiaos-wise-desligado"
NOMES_MOTORES = {"local": "Local", "gemini": "Google Gemini", "openai": "OpenAI"}
# "Ajude a melhorar o DuiaOS" (ADR 040 do DuiaOS): mudar é do sistema (sudo duiaos-relatorios nivel …)
NOMES_NIVEIS = {
    "nao_escolhido": "Ainda não escolhido: nada é enviado.",
    "desligado": "Desligado: nada é enviado.",
    "erros": "Ligado: erros e informações do computador, sem as conversas.",
    "erros_e_uso": "Ligado: erros, informações do computador e uso, sem as conversas.",
    "desenvolvimento": "Desenvolvimento: tudo, inclusive as conversas com o Wise (computador de teste).",
}
SUGESTOES = [
    "Por que o computador está lento?",
    "Vai chover amanhã?",
    "O que tenho na agenda esta semana?",
    "Tem atualização disponível?",
]


def resumo_da_resposta(texto, limite=170):
    """Começo da resposta, sem marcações de Markdown, para o balão do Wise."""
    import re
    texto = re.sub(r"```.*?```", " ", texto, flags=re.S)              # blocos de código
    texto = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", texto)          # [texto](link)
    texto = re.sub(r"(^|\n)\s*(#{1,6}|[-*+]|\d+\.)\s+", r"\1", texto)   # títulos e listas
    texto = re.sub(r"[*_`>]+", "", texto)
    texto = " ".join(texto.split())
    if len(texto) <= limite:
        return texto
    corte = texto[:limite].rsplit(" ", 1)[0].rstrip(",.;:—-")
    return corte + "…"


def ler_chave_gemini():
    return motores.ler_chave("gemini")


def tem_chave_na_nuvem(gateway, ler=None):
    """Só abre o cofre de senhas se o Gemini estiver ligado. Abrir o cofre sem chaveiro criado (o pendrive do
    DuiaOS, uma conta nova) faz o sistema pedir uma senha para um chaveiro novo, e essa janela ficava com o
    teclado — no instalador em tela cheia, a pessoa não conseguia digitar (ADR 065 do DuiaOS)."""
    if not gateway._autorizado("gemini"):
        return False
    return bool((ler or ler_chave_gemini)())


def pedir_a_ia_do_sistema(metodo, *argumentos):
    """Chama o duiaos-ia (D-Bus do sistema) sem esperar: Ativar um modelo, Pausar ou retomar a IA local."""
    comando = ["gdbus", "call", "--system", "--dest", "org.duiaos.IA1", "--object-path", "/org/duiaos/IA1",
               "--method", "org.duiaos.IA1." + metodo] + [str(a) for a in argumentos]
    try:
        subprocess.Popen(comando, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError:
        pass


def primeiro_nome():
    """Primeiro nome da pessoa (do cadastro do sistema), para a saudação."""
    conta = pwd.getpwuid(os.getuid())
    nome = (conta.pw_gecos.split(",")[0].strip() or conta.pw_name).split()[0]
    return nome[:1].upper() + nome[1:]


def texto_saudacao():
    return (f"Olá, {primeiro_nome()}. Que bom te ver por aqui! "
            "Se precisar de ajuda, pode contar comigo. Boa navegação!")


class Ponte(QObject):
    """Estado e ações expostos ao QML."""

    mudou = Signal()
    parcialMudou = Signal()
    configMudou = Signal()
    contasMudou = Signal()
    pedirMostrar = Signal(bool)   # True: mostrar; False: alternar
    vozMudou = Signal()
    sincMudou = Signal()
    _evento = Signal(str, "QVariantMap")   # da thread do orquestrador para a interface
    _pedido = Signal(str, str, str)        # do D-Bus (Configurações, Barra) para a interface: tipo, nome, valor

    def __init__(self, demonstracao=False, presenca=None):
        super().__init__()
        self._demonstracao = demonstracao
        self._presenca = presenca
        self._janela_visivel = False
        self._resposta_nao_vista = False
        self._config = Configuracao.carregar()
        self._mensagens = []
        self._parcial = ""                  # resposta sendo escrita (aparece aos poucos)
        self._parcial_novo = ""
        # A tela recebe o texto novo até 12 vezes por segundo e o mostra aos poucos, com suavidade (Wise.qml)
        self._tempo_parcial = QTimer(self, interval=80, singleShot=True, timeout=self._mostrar_parcial)
        self._parcial_completo = False      # a resposta terminou: falta só a tela acabar de mostrá-la
        self._fim_pendente = None
        # Voz
        self._fala = None
        self._falado_ate = 0                # quantos caracteres da resposta em andamento já foram para a voz
        self._escuta = None
        self._pedido_falado = False         # o pedido em andamento veio do microfone: a resposta é falada (ADR 079)
        # Texto junto com a voz (ADR 082): com a resposta sendo falada, a tela mostra o texto quando a voz o diz.
        # _limite_voz: -1 = sem limite; 0+ = letras liberadas; _ritmo_voz: letras por segundo (0 = ritmo normal)
        self._limite_voz, self._ritmo_voz, self._fins_dos_trechos = -1, 0.0, []
        self._conversa_por_voz = False      # conversa mãos livres: ao terminar de falar, o Wise volta a ouvir
        self._voz = {"ouvindo": False, "transcrevendo": False, "falando": False, "nivel": 0.0, "mensagem": ""}
        self._estado_voz = {}
        self._baixando = {}                 # item → fração
        self._ouvir_ao_baixar = False       # o microfone foi clicado sem o reconhecimento: ouve quando terminar
        self._teste_microfone = None        # teste das Configurações: {"estado", "nivel", "texto", "motivo"}
        self._escuta_de_teste = False
        self._modelos_locais = []
        self._aquecido_para = None          # (modelo, carregado) já preparado para responder na hora
        self._aquecendo = False
        self._aquecer_depois = 0.0
        self._cancelar_aquecimento = threading.Event()
        self._ocupado = False
        self._provedor = ""
        self._situacao = {}
        self._cancelar = threading.Event()
        self._evento.connect(self._ao_evento)
        self._pedido.connect(self._ao_pedido)
        self._tem_chave = False
        self._agenda_ocupada = False
        self._agenda_mensagem = ""
        self._cidade_opcoes = []
        self._cidade_mensagem = ""
        self._cancelar_login = threading.Event()
        if demonstracao:
            from .demonstracao import gateway_de_demonstracao
            self._gateway = gateway_de_demonstracao(self._config)
            self._modelos_locais = ["qwen3.5:4b", "gemma4:e4b"]
        else:
            motores.migrar(self._config)
            self._gateway = Gateway(self._config, ler_chave_gemini)
        self._aprovacoes = {}               # id -> {"evento": Event, "aprovado": bool}
        self._orquestrador = Orquestrador(self._gateway, registro_padrao(), Auditoria(),
                                          lambda tipo, dados: self._evento.emit(tipo, dados),
                                          aprovador=self._aguardar_aprovacao)
        # IA do sistema (DuiaOS): modelo ativo e download do 1º login
        self._ia = None
        self._acompanhamento = ia_do_sistema.Acompanhamento()
        if not demonstracao:
            self._vigia_ia = QTimer(self, interval=2000, timeout=self._vigiar_ia)
            self._vigia_ia.start()
            QTimer.singleShot(0, self._vigiar_ia)      # e prepara o modelo para responder na hora
        self._servico = None
        if not demonstracao:
            from ..servico import Servico
            self._servico = Servico(lambda chave, valor: self._pedido.emit("definir", chave, valor),
                                    lambda nome, dados: self._pedido.emit("acao", nome, dados))
            self.configMudou.connect(self._publicar)
            self.contasMudou.connect(self._publicar)
            self.vozMudou.connect(self._publicar)
            voz.servico(self._registrar_voz)
            threading.Thread(target=self._ler_estado_da_voz, daemon=True).start()
        self.atualizarSituacao()

    # ------------------------------------------------------- IA do sistema
    def _vigiar_ia(self):
        anterior, self._ia = self._ia, ia_do_sistema.ler()
        if self._ia is not None and not self._ia.carregado and not self._aquecendo:
            # Saiu da memória (30 min sem uso, Ollama reiniciado, pausa): o que foi lido se perdeu. Ao voltar,
            # é preciso aquecer de novo — antes, a chave igual fazia o Wise pular o aquecimento (ADR 079)
            self._aquecido_para = None
        self._aquecer_se_preciso()
        progresso, mensagem, mudou = self._acompanhamento.atualizar(self._ia)
        if self._presenca is not None:
            self._presenca.progresso(progresso)
            if mensagem:
                self._presenca.saudar(mensagem)
        if mudou:
            self.atualizarSituacao()
        elif progresso:
            self.configMudou.emit()          # o cabeçalho mostra o andamento

    def _aquecer_se_preciso(self, intencao=False):
        """Prepara o modelo para a primeira pergunta sair na hora: quando o Wise
        abre, quando o modelo ativo muda, quando ele volta para a memória e quando
        as opções medidas para o computador mudam. Com intencao (a pessoa abriu a janela ou clicou no
        microfone), também carrega o modelo que não fica sempre na memória: enquanto ela fala, ele lê."""
        if self._demonstracao or self._ocupado or self._aquecendo or time.monotonic() < self._aquecer_depois:
            return
        if self._ia is not None:
            if not self._ia.ativo or self._ia.calibrando or self._ia.tarefa is not None:
                return                       # sem modelo, medindo ou baixando
            if not self._ia.carregado and not (intencao and self._ia.manter != -1):
                return                       # o duiaos-ia ainda está carregando o modelo
            chave = json.dumps([self._ia.ativo, sorted(self._ia.opcoes.items())])
        else:
            chave = "preferencias"           # fora do DuiaOS: uma vez, ao abrir
        if chave == self._aquecido_para:
            return
        self._aquecendo = True
        self._cancelar_aquecimento.clear()

        def trabalho():
            inicio = time.monotonic()
            segundos = self._orquestrador.aquecer(self._cancelar_aquecimento)
            diagnostico.medida("aquecimento", time.monotonic() - inicio, ok=segundos is not None,
                               cancelado=self._cancelar_aquecimento.is_set(), modelo_s=segundos)
            self._evento.emit("aquecido", {"chave": chave, "ok": segundos is not None,
                                           "cancelado": self._cancelar_aquecimento.is_set()})

        threading.Thread(target=trabalho, daemon=True).start()

    @Slot(str)
    def abrirConfiguracoes(self, secao):
        """Abre as Configurações do DuiaOS na página pedida ("ia" ou "wise")."""
        if secao in ("ia", "wise") and os.access(CONFIGURACOES, os.X_OK):
            subprocess.Popen([CONFIGURACOES, "--secao", secao], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)

    # ------------------------------------------------- motor e modelo (janela)
    def _lista_de_motores(self):
        """Motores que dá para escolher na janela: o local e os da nuvem ativados nas Configurações."""
        lista = []
        for nome in ("local", "gemini", "openai"):
            provedor = self._gateway.motor(nome)
            situacao = self._situacao.get(provedor.nome) or {}
            if self._demonstracao and nome != "local":
                continue
            if nome == "local":
                modelos = [{"id": m, "nome": ia_do_sistema.nome_amigavel(m)} for m in self._modelos_locais]
            else:
                if not (self._demonstracao or motores.ativado(nome)):
                    continue
                modelos = [{"id": m, "nome": m} for m in (motores.modelos(nome) or ([provedor.modelo] if provedor.modelo else []))]
            lista.append({"id": nome, "titulo": NOMES_MOTORES[nome], "nuvem": nome != "local",
                          "pronto": bool(situacao.get("pronto")), "motivo": situacao.get("motivo", ""),
                          "modelo": provedor.modelo or "", "modelos": modelos})
        return lista

    @Slot(str)
    def escolherMotor(self, motor):
        if self._ocupado or motor not in ("local", "gemini", "openai"):
            return
        self._gateway.definir_sessao(motor)
        self._orquestrador.limpar()          # outro motor: a conversa recomeça (cada um guarda o histórico do seu jeito)
        self._mensagens = [m for m in self._mensagens if m.get("tipo") != "aprovacao" or m.get("estado") != "pendente"]
        self.atualizarSituacao()
        self.mudou.emit()

    @Slot(str)
    def escolherModelo(self, modelo):
        if self._ocupado or not modelo:
            return
        motor = self._gateway.motor_atual()
        if motor == "local":
            if modelo in self._modelos_locais and modelo != self._gateway.local.modelo:
                pedir_a_ia_do_sistema("Ativar", modelo)      # o modelo local é o do sistema (um só, para todos)
        elif modelo in (motores.modelos(motor) or [modelo]):
            self._gateway.definir_sessao(motor, modelo)
        QTimer.singleShot(600, self.atualizarSituacao)
        self.atualizarSituacao()

    # ---------------------------------------------------------------- conversa
    @Slot(str)
    def enviar(self, texto):
        self._enviar(texto, falado=False)

    def _enviar(self, texto, falado):
        texto = texto.strip()
        if not texto or self._ocupado:
            return
        self._pedido_falado = falado
        if not falado:
            self._conversa_por_voz = False      # escreveu: a conversa mãos livres acaba
        elif not self._pode_falar() and not self._demonstracao and voz.disponivel():
            self._baixar_voz(self._config.voz)  # falou, mas não há voz para responder: baixa a escolhida
        self._mensagens.append({"tipo": "pessoa", "texto": texto})
        # Se o aquecimento ainda está rodando, ele continua: a pergunta começa com o
        # mesmo texto, então espera o fim dele e só lê as palavras novas. Cortá-lo
        # jogaria fora o que já foi lido e a pergunta teria de ler tudo de novo.
        self._ocupado = True
        self._cancelar.clear()
        self._atualizar_presenca()
        self.mudou.emit()
        threading.Thread(target=self._executar, args=(texto, falado), daemon=True).start()

    # ---------------------------------------------------------------- aprovação
    def _aguardar_aprovacao(self, _tarefa, pedido, cancelado):
        """Chamado pelo orquestrador (thread de trabalho): espera a pessoa decidir
        no cartão da conversa. Cancelar ou 15 minutos sem resposta = não aprovado."""
        espera = {"evento": threading.Event(), "aprovado": False}
        self._aprovacoes[pedido["id"]] = espera
        limite = time.monotonic() + 900
        try:
            while not espera["evento"].wait(0.25):
                if cancelado.is_set() or time.monotonic() > limite:
                    return False
            return espera["aprovado"]
        finally:
            self._aprovacoes.pop(pedido["id"], None)

    @Slot(str, bool)
    def responderAprovacao(self, id_pedido, aprovado):
        espera = self._aprovacoes.get(id_pedido)
        if espera is None:
            return
        espera["aprovado"] = bool(aprovado)
        espera["evento"].set()

    def _cartao(self, id_pedido):
        for mensagem in reversed(self._mensagens):
            if mensagem.get("tipo") == "aprovacao" and mensagem.get("id") == id_pedido:
                return mensagem
        return None

    def _executar(self, texto, falado=False):
        tarefa = self._orquestrador.executar(texto, self._cancelar, falado=falado)
        self._evento.emit("fim", {"estado": tarefa.estado, "resposta": tarefa.resposta, "erro": tarefa.erro,
                                  "tarefa": tarefa.id})

    def _ao_evento(self, tipo, dados):
        if tipo == "cidade":
            self._ao_cidade(dados)
            return
        if tipo == "voz":
            self._ao_voz(dados)
            return
        if tipo == "agenda":
            self._agenda_ocupada, self._agenda_mensagem = False, dados.get("mensagem", "")
            self.contasMudou.emit()
            return
        if tipo == "aquecido":
            self._aquecendo = False
            if dados.get("ok"):
                self._aquecido_para = dados["chave"]
            elif not dados.get("cancelado"):
                self._aquecer_depois = time.monotonic() + 60     # falhou: tenta de novo em 1 min
            return
        if tipo == "parcial":
            # A tela é atualizada no máximo 4 vezes por segundo: redesenhar a cada
            # pedaço tirava processador da IA, que roda no mesmo processador
            self._parcial_novo = dados.get("texto", "")
            if not self._tempo_parcial.isActive():
                self._tempo_parcial.start()
            return
        elif tipo == "provedor":
            self._provedor = ("Nuvem · " if dados.get("nuvem") else "Local · ") + dados.get("titulo", "")
        elif tipo == "atividade":
            if dados.get("nivel") == "N2" and self._cartao_da_tarefa(dados):
                self.mudou.emit()            # o cartão de aprovação já mostra o resultado
                return
            self._mensagens.append({"tipo": "atividade", "texto": dados.get("titulo", ""), "ok": dados.get("ok", False),
                                    "detalhe": dados.get("detalhe", ""), "nivel": dados.get("nivel", "")})
        elif tipo == "aprovacao":
            self._mensagens.append({"tipo": "aprovacao", "id": dados["id"], "tarefa": dados.get("tarefa", ""),
                                    "titulo": dados.get("titulo", ""), "texto": dados.get("resumo", ""),
                                    "detalhes": list(dados.get("detalhes") or []), "estado": "pendente",
                                    "fracao": -1.0, "mensagem": ""})
            if not self._janela_visivel and self._presenca is not None:
                self._resposta_nao_vista = True
                self._presenca.avisar_resposta("Preciso da sua aprovação: " + resumo_da_resposta(dados.get("resumo", ""), 120))
        elif tipo in ("decisao", "progresso", "concluida"):
            cartao = self._cartao(dados.get("id"))
            if cartao is None:
                return
            if tipo == "decisao":
                cartao["estado"] = "fazendo" if dados.get("aprovado") else "nao_aprovado"
            elif tipo == "progresso":
                if isinstance(dados.get("fracao"), (int, float)):
                    cartao["fracao"] = float(dados["fracao"])
                if dados.get("mensagem"):
                    cartao["mensagem"] = str(dados["mensagem"])[:120]
            else:
                cartao["estado"] = "feito" if dados.get("ok") else "falhou"
                cartao["mensagem"] = str(dados.get("mensagem") or "")[:300]
                cartao["fracao"] = 1.0 if dados.get("ok") else cartao["fracao"]
        elif tipo == "fim":
            self._tempo_parcial.stop()
            if dados["estado"] == "concluida" and self._janela_visivel and dados["resposta"]:
                # A tela termina de mostrar o texto com suavidade e só então a resposta entra na conversa
                # (concluirEscrita); o Wise já está livre para o próximo pedido
                self._falar_parcial(dados["resposta"], final=True)
                self._parcial = self._parcial_novo = dados["resposta"]
                self._parcial_completo = True
                self._fim_pendente = dados
                self.parcialMudou.emit()
                self._ocupado = False
                self._atualizar_presenca()
                self.mudou.emit()
                return
            self._parcial = self._parcial_novo = ""
            self._parcial_completo = False
            self.parcialMudou.emit()
            if dados["estado"] == "concluida":
                self._falar_parcial(dados["resposta"], final=True)
                self._mensagens.append({"tipo": "wise", "texto": dados["resposta"], "tarefa": dados.get("tarefa", ""),
                                        "avaliada": False})
            elif dados["estado"] == "cancelada":
                self.calar()
                self._mensagens.append({"tipo": "aviso", "texto": "Pedido cancelado."})
            else:
                self._mensagens.append({"tipo": "erro", "texto": dados["erro"], "tarefa": dados.get("tarefa", ""),
                                        "avaliada": False})
                if self._pedido_falado:
                    self._conversa_por_voz = False
                    self.dizer(resumo_da_resposta(dados["erro"], 160))
            self._ocupado = False
            self._atualizar_presenca()
            self._avisar_resposta(dados)
        self.mudou.emit()

    def _cartao_da_tarefa(self, dados):
        for mensagem in reversed(self._mensagens):
            if mensagem.get("tipo") == "aprovacao" and mensagem.get("tarefa") == dados.get("tarefa") \
                    and mensagem.get("titulo") == dados.get("titulo"):
                return mensagem
        return None

    def _mostrar_parcial(self):
        if self._parcial_novo != self._parcial:
            self._parcial = self._parcial_novo
            self.parcialMudou.emit()
            self._falar_parcial(self._parcial)

    @Slot()
    def concluirEscrita(self):
        """A tela terminou de mostrar a resposta: ela entra na conversa (no mesmo lugar, sem pular)."""
        dados, self._fim_pendente = self._fim_pendente, None
        if dados is None:
            return
        self._parcial = self._parcial_novo = ""
        self._parcial_completo = False
        self._mensagens.append({"tipo": "wise", "texto": dados["resposta"], "tarefa": dados.get("tarefa", ""),
                                "avaliada": False})
        self.parcialMudou.emit()
        self.mudou.emit()

    @Slot()
    def cancelar(self):
        self._cancelar.set()
        self._conversa_por_voz = False
        self.calar()

    # ------------------------------------------------------------------- voz
    def _ler_estado_da_voz(self):
        self._evento.emit("voz", {"estado": voz.estado()})

    def _registrar_voz(self, evento):
        """Eventos do duiaos-voz no diagnóstico: tempos de carga e de fala, nível do microfone, erros."""
        tipo = evento.get("evento")
        dados = {k: v for k, v in evento.items() if k != "evento"}
        if tipo in ("erro", "saida_de_erro", "parou"):
            diagnostico.registrar("voz_erro", onde=tipo, **{("erro_texto" if k in ("mensagem", "linha") else k): v
                                                          for k, v in dados.items()})
        elif tipo in ("voz_carregada", "reconhecimento_carregado", "falando", "fim_fala", "texto", "descarregado", "pronto",
                      "frase"):
            diagnostico.registrar("voz", onde=tipo, **dados)

    def _preparar_voz(self):
        """Com a voz ligada, os modelos já ficam carregados (a primeira resposta é falada sem espera)."""
        if self._demonstracao or not voz.disponivel():
            return
        if self._config.falar_respostas and self._voz_pronta():
            voz.preparar(self._config.voz, ouvir=bool(self._estado_voz.get("ouvir")))

    def _voz_pronta(self):
        return any(v.get("instalada") for v in self._estado_voz.get("vozes", []))

    def _motor_da_voz(self):
        """Voz natural pela nuvem (ADR 080): o motor OpenAI ou Gemini ligado nas Configurações, ou ""."""
        if self._demonstracao or not self._config.voz_na_nuvem:
            return ""
        return voz_nuvem.motor_da_voz()

    def _motor_do_ouvido(self):
        """Entender a fala pela nuvem (ADR 081): o motor OpenAI ou Gemini ligado, ou ""."""
        if self._demonstracao or not self._config.ouvir_na_nuvem:
            return ""
        return voz_nuvem.motor_da_voz()

    @staticmethod
    def _arquivo_da_fala():
        pasta = os.environ.get("XDG_RUNTIME_DIR") or f"/tmp/duiaos-wise-{os.getuid()}"
        return os.path.join(pasta, "duiaos-wise-fala.wav")

    def _transcrever_na_nuvem(self, arquivo, motor):
        """Linha própria: manda a fala para a nuvem e devolve o texto pelo sinal (ou vazio, se falhar)."""
        inicio = time.monotonic()
        try:
            with open(arquivo, "rb") as entrada:
                wav = entrada.read()
            chave = motores.ler_chave(motor) or ""
            if not chave:
                raise ouvido_nuvem.ErroDoProvedor("sem chave do motor na nuvem")
            texto = ouvido_nuvem.transcrever(motor, chave, wav,
                                             motores.modelo_preferido("gemini") or self._config.modelo_gemini)
            diagnostico.registrar("voz", onde="ouvido_nuvem", motor=motor, segundos=round(time.monotonic() - inicio, 2),
                                  texto=texto)
        except (OSError, ouvido_nuvem.ErroDoProvedor) as erro:
            texto = None
            diagnostico.registrar("voz_erro", onde="ouvido_nuvem", motor=motor, erro_texto=str(erro)[:200])
        finally:
            try:
                os.unlink(arquivo)                       # a gravação não fica no computador
            except OSError:
                pass
        self._evento.emit("voz", {"ouvido_nuvem": texto})

    def _pode_falar(self):
        return self._voz_pronta() or bool(self._motor_da_voz())

    def _registrar_voz_nuvem(self, evento):
        tipo = evento.get("evento")
        dados = {k: v for k, v in evento.items() if k != "evento"}
        if tipo == "erro_nuvem":
            diagnostico.registrar("voz_erro", onde="nuvem", **dados)
        else:
            diagnostico.registrar("voz", onde="nuvem_" + str(tipo), **dados)

    def _falar_parcial(self, texto, final=False):
        """Resposta falada: cada trecho vai para a voz assim que fica pronto (o primeiro já na primeira vírgula),
        sem esperar a resposta toda. Fala quando as respostas faladas estão ligadas ou quando a pessoa falou."""
        if not (self._config.falar_respostas or self._pedido_falado) or self._demonstracao or not self._pode_falar():
            return
        frases, self._falado_ate = voz.trechos_prontos(texto, self._falado_ate)
        if final:
            resto = texto[self._falado_ate:].strip()
            if resto:
                frases.append(resto)
            self._falado_ate = 0
        if not frases and not final:
            return
        if frases and self._fala is None:
            self._fins_dos_trechos = []
            self._iniciar_fala(sincronizar=True)
        if self._fala is None:
            return
        for frase in frases:
            anterior = self._fins_dos_trechos[-1] if self._fins_dos_trechos else 0
            self._fins_dos_trechos.append(anterior + len(" ".join(frase.split())) + 1)
            self._fala.dizer(frase)
        if final and self._fala is not None:
            self._fala.concluir()

    def _iniciar_fala(self, sincronizar=False):
        fala = None

        def terminou():
            self._evento.emit("voz", {"fala_terminou": id(fala)})

        def evento_da_nuvem(evento):
            self._registrar_voz_nuvem(evento)
            if evento.get("evento") in ("trecho", "falando"):
                self._evento.emit("voz", {"sinc": evento, "fala": id(fala)})

        def evento_local(evento):
            if evento.get("evento") == "falando":
                self._evento.emit("voz", {"sinc": {"evento": "falando_local"}, "fala": id(fala)})
        motor = self._motor_da_voz()
        velocidade = self._config.velocidade_da_voz
        try:
            if motor:
                local = (lambda fim: voz.Fala(self._config.voz, velocidade, ao_terminar=fim, ao_evento=evento_local)) \
                    if self._voz_pronta() else None
                fala = voz_nuvem.FalaNuvem(motor, motores.ler_chave, self._config.voz, velocidade,
                                           ao_terminar=terminou, ao_evento=evento_da_nuvem, reserva=local,
                                           voz_nuvem=self._config.voz_nuvem, estilo=self._config.estilo_da_voz,
                                           estilo_livre=self._config.estilo_livre)
            else:
                fala = voz.Fala(self._config.voz, velocidade, ao_terminar=terminou, ao_evento=evento_local)
        except OSError:
            return
        self._fala = fala
        if sincronizar:
            self._sincronizar(0, 0.0)              # o texto espera a voz começar
            QTimer.singleShot(ESPERA_MAXIMA_DA_VOZ_MS, lambda f=fala: self._soltar_texto(f))
        self._voz["falando"] = True
        self._atualizar_presenca()
        self.vozMudou.emit()

    def _sincronizar(self, limite, ritmo):
        if (limite, ritmo) != (self._limite_voz, self._ritmo_voz):
            self._limite_voz, self._ritmo_voz = limite, ritmo
            self.sincMudou.emit()

    def _soltar_texto(self, fala=None):
        """A voz não começou a tempo (ou acabou): o texto segue no ritmo normal."""
        if fala is None or (fala is self._fala and self._limite_voz == 0):
            self._sincronizar(-1, 0.0)

    def _ao_sinc(self, dados):
        if self._fala is None or id(self._fala) != dados.get("fala"):
            return
        evento = dados["sinc"]
        tipo = evento.get("evento")
        if tipo == "falando_local":
            # Voz do computador: o texto vai no ritmo da fala, desde o primeiro som
            self._sincronizar(-1, voz_nuvem.LETRAS_POR_SEGUNDO * self._config.velocidade_da_voz)
        elif tipo == "trecho":
            indice = int(evento.get("indice") or 0)
            if indice >= len(self._fins_dos_trechos):
                return
            limite = self._fins_dos_trechos[indice]
            ritmo = max(6.0, float(evento.get("letras") or 0) / max(0.3, float(evento.get("segundos") or 1.0)))
            fala = self._fala
            # O som entra no tocador antes de tocar: libera o trecho quando ele começa de fato
            QTimer.singleShot(int(1000 * float(evento.get("daqui_s") or 0)),
                              lambda: self._sincronizar(max(limite, self._limite_voz), ritmo) if self._fala is fala else None)

    def dizer(self, texto):
        """Fala um texto inteiro (saudação, teste da voz), se houver voz instalada."""
        if self._demonstracao or not self._pode_falar() or not texto:
            return False
        self.calar()
        self._iniciar_fala()
        if self._fala is None:
            return False
        self._fala.dizer(texto)
        self._fala.concluir()
        return True

    @Slot()
    def calar(self):
        self._falado_ate = 0
        self._sincronizar(-1, 0.0)
        if self._fala is not None:
            self._fala.calar()

    @Slot()
    def ouvir(self):
        """Botão do microfone: começa a ouvir; clicar de novo para de ouvir e manda o que foi dito."""
        if self._escuta is not None:
            self._escuta.parar()
            return
        if self._ocupado or self._demonstracao:
            return
        if not voz.disponivel():
            self._voz["mensagem"] = "A voz do sistema não está instalada (pacote duiaos-voz)."
            self.vozMudou.emit()
            return
        if not self._estado_voz.get("ouvir"):
            # Primeira vez: baixa o reconhecimento de fala e começa a ouvir quando terminar
            self._ouvir_ao_baixar = True
            self._baixar_voz("ouvir")
            self._voz["mensagem"] = "Preparando o reconhecimento de fala (uma vez só, cerca de 490 MB). Eu aviso quando puder falar."
            self.vozMudou.emit()
            return
        self.calar()
        self._escuta_de_teste = False
        self._conversa_por_voz = True
        self._aquecer_se_preciso(intencao=True)      # enquanto a pessoa fala, o modelo se prepara
        self._nuvem_escuta = None
        try:
            self._escuta = voz.Escuta(lambda dados: self._evento.emit("voz", {"escuta": dados}),
                                      salvar_audio=self._arquivo_da_fala() if self._motor_do_ouvido() else "")
        except OSError:
            self._escuta = None
            self._voz["mensagem"] = "Não consegui abrir o microfone."
            self.vozMudou.emit()
            return
        self._voz.update(ouvindo=True, transcrevendo=False, nivel=0.0, mensagem="")
        self._atualizar_presenca()
        self.vozMudou.emit()

    def _ao_voz(self, dados):
        if "estado" in dados:
            self._estado_voz = dados["estado"] or {}
            self._preparar_voz()
            if self._ouvir_ao_baixar and self._estado_voz.get("ouvir") and "ouvir" not in self._baixando:
                self._ouvir_ao_baixar = False
                self._voz["mensagem"] = ""
                QTimer.singleShot(300, self.ouvir)
        elif "sinc" in dados:
            self._ao_sinc(dados)
            return
        elif "fala_terminou" in dados:
            if self._fala is not None and id(self._fala) == dados["fala_terminou"]:
                self._sincronizar(-1, 0.0)
                self._fala = None
                self._voz["falando"] = False
                self._atualizar_presenca()
                if self._conversa_por_voz and self._config.conversa_continua and self._janela_visivel \
                        and not self._ocupado and self._escuta is None:
                    QTimer.singleShot(150, self._ouvir_na_conversa)
        elif "baixando" in dados:
            item, andamento = dados["baixando"], dados.get("andamento") or {}
            if andamento.get("pronto") or andamento.get("erro") or dados.get("fim"):
                self._baixando.pop(item, None)
                if andamento.get("erro"):
                    self._voz["mensagem"] = "Não consegui baixar: " + str(andamento["erro"])[:200]
                    self._ouvir_ao_baixar = False
                elif andamento.get("pronto") and not self._demonstracao and voz.disponivel():
                    # Voz nova ou trocada pela rápida (ADR 079): a que estava carregada sai da memória
                    voz.servico().enviar(cmd="descarregar")
                threading.Thread(target=self._ler_estado_da_voz, daemon=True).start()
            else:
                self._baixando[item] = float(andamento.get("fracao") or 0.0)
        elif "ouvido_nuvem" in dados:
            nuvem = self._nuvem_escuta
            if nuvem is None:
                return
            nuvem["texto"], nuvem["pronto"] = dados["ouvido_nuvem"], True
            if nuvem.get("fim") is not None:
                self._concluir_escuta(nuvem.pop("fim"))
            return
        elif "escuta" in dados:
            evento = dados["escuta"]
            if evento.get("audio"):
                motor = self._motor_do_ouvido()
                if motor and not self._escuta_de_teste:
                    self._nuvem_escuta = {"texto": None, "pronto": False, "fim": None}
                    threading.Thread(target=self._transcrever_na_nuvem, args=(evento["audio"], motor), daemon=True).start()
                return
            if "nivel" in evento:
                nivel = float(evento.get("nivel") or 0.0)
                if abs(nivel - self._voz["nivel"]) < 0.08:
                    return                         # mudança pequena: não redesenha
                self._voz["nivel"] = nivel
            if evento.get("transcrevendo"):
                self._voz.update(ouvindo=False, transcrevendo=True)
            if "fim" in evento or "erro" in evento:
                self._escuta = None
                self._ajustar_microfone(evento)
                nuvem = self._nuvem_escuta
                if nuvem is not None and not nuvem["pronto"] and "erro" not in evento:
                    # A nuvem ainda está entendendo: espera um pouco por ela (o texto local fica de reserva)
                    nuvem["fim"] = evento
                    QTimer.singleShot(ESPERA_DA_NUVEM_MS, self._desistir_da_nuvem)
                    return
                self._concluir_escuta(evento)
                return
            if self._escuta_de_teste and self._teste_microfone is not None:
                self._teste_microfone.update(estado="transcrevendo" if evento.get("transcrevendo") else "ouvindo",
                                             nivel=self._voz["nivel"])
            self._atualizar_presenca()
        self.vozMudou.emit()

    def _desistir_da_nuvem(self):
        nuvem = self._nuvem_escuta
        if nuvem is not None and nuvem.get("fim") is not None:
            diagnostico.registrar("voz_erro", onde="ouvido_nuvem", erro_texto="demorou; valeu o reconhecimento local")
            self._concluir_escuta(nuvem.pop("fim"))

    def _ajustar_microfone(self, evento):
        """Microfone estourado ou baixo demais: ajusta o volume de entrada (fora da linha da interface)."""
        if self._demonstracao or "erro" in evento or evento.get("cancelado"):
            return

        def trabalho():
            try:
                mudanca = microfone.ajustar(evento)
            except (OSError, subprocess.SubprocessError, ValueError):
                return
            if mudanca:
                diagnostico.registrar("voz", onde="microfone_ajustado", antes=mudanca[0], depois=mudanca[1],
                                      pico_db=evento.get("pico_db"), nivel_medio_db=evento.get("nivel_medio_db"))
        threading.Thread(target=trabalho, daemon=True).start()

    def _concluir_escuta(self, evento):
        """Fim da escuta: o texto da nuvem (se chegou) ou o local vira o pedido."""
        nuvem, self._nuvem_escuta = self._nuvem_escuta, None
        if nuvem is not None and nuvem.get("texto"):
            evento = {**evento, "texto": nuvem["texto"]}
        self._voz.update(ouvindo=False, transcrevendo=False, nivel=0.0)
        texto = str(evento.get("texto") or "").strip()
        explicacao = str(evento.get("erro") or (evento.get("motivo") if not texto and not evento.get("cancelado") else "") or "")[:220]
        if self._escuta_de_teste:
            self._escuta_de_teste = False
            self._teste_microfone = {"estado": "pronto", "texto": texto, "motivo": explicacao,
                                     "nivel_db": evento.get("nivel_medio_db"), "pico_db": evento.get("pico_db")}
            self._atualizar_presenca()
            self.vozMudou.emit()
            return
        if not texto and self._na_conversa:
            explicacao = ""                       # silêncio depois da resposta: a conversa acabou, sem aviso
        if not texto:
            self._conversa_por_voz = False
        self._na_conversa = False
        self._voz["mensagem"] = explicacao
        self._atualizar_presenca()
        self.vozMudou.emit()
        if texto:
            self._enviar(texto, falado=True)

    _na_conversa = False
    _nuvem_escuta = None

    def _ouvir_na_conversa(self):
        """Conversa por voz: o Wise terminou de falar e volta a ouvir sozinho."""
        if not self._conversa_por_voz or self._ocupado or self._escuta is not None or not self._janela_visivel:
            return
        self.ouvir()
        self._na_conversa = self._escuta is not None

    def testarMicrofone(self):
        """Configurações › Wise: ouve uma frase e mostra o que entendeu, sem mandar para a conversa."""
        if self._escuta is not None or self._demonstracao or not voz.disponivel():
            return
        if not self._estado_voz.get("ouvir"):
            self._baixar_voz("ouvir")
            self._teste_microfone = {"estado": "baixando"}
            self.vozMudou.emit()
            return
        self.calar()
        try:
            self._escuta = voz.Escuta(lambda dados: self._evento.emit("voz", {"escuta": dados}), segundos=12)
        except OSError:
            self._teste_microfone = {"estado": "pronto", "motivo": "Não consegui abrir o microfone."}
            self.vozMudou.emit()
            return
        self._escuta_de_teste = True
        self._teste_microfone = {"estado": "ouvindo", "nivel": 0.0}
        self.vozMudou.emit()

    def _baixar_voz(self, item):
        if item in self._baixando or not voz.disponivel():
            return
        self._baixando[item] = 0.0
        self._voz["mensagem"] = ""
        self.vozMudou.emit()

        def trabalho():
            voz.baixar(item, lambda andamento: self._evento.emit("voz", {"baixando": item, "andamento": andamento}))
            self._evento.emit("voz", {"baixando": item, "fim": True})
        threading.Thread(target=trabalho, daemon=True).start()

    # ------------------------------------- Configurações do DuiaOS e Barra (D-Bus)
    def _estado_publico(self):
        return {
            "versao": VERSAO, "provedor": self._config.provedor, "motor_padrao": self._gateway.motor_padrao(),
            "reserva_na_nuvem": self._config.provedor == "automatico",
            "motores": self._lista_de_motores(), "saudacao": self._config.saudacao,
            "aprovar_toda_acao": self._config.aprovar_toda_acao_na_tela,
            "cidade": self._cidade(), "cidade_opcoes": self._cidade_opcoes, "cidade_mensagem": self._cidade_mensagem,
            "contas_agenda": self._contas_agenda(), "agenda_ocupada": self._agenda_ocupada,
            "agenda_mensagem": self._agenda_mensagem,
            "login_google": oauth.aplicativo("google") is not None,
            "login_microsoft": oauth.aplicativo("microsoft") is not None,
            "voz": {"disponivel": bool(self._estado_voz.get("motor")), "falar_respostas": self._config.falar_respostas,
                    "voz": self._config.voz, "velocidade": self._config.velocidade_da_voz,
                    "conversa_continua": self._config.conversa_continua,
                    "voz_na_nuvem": self._config.voz_na_nuvem, "motor_da_voz": self._motor_da_voz(),
                    "ouvir_na_nuvem": self._config.ouvir_na_nuvem, "motor_do_ouvido": self._motor_do_ouvido(),
                    "voz_nuvem": voz_nuvem.voz_do_motor(self._motor_da_voz(), self._config.voz, self._config.voz_nuvem)
                    if self._motor_da_voz() else self._config.voz_nuvem,
                    "vozes_nuvem": [{"id": v[0], "nome": v[1]} for v in voz_nuvem.VOZES_NUVEM.get(self._motor_da_voz(), [])],
                    "estilo": self._config.estilo_da_voz, "estilo_livre": self._config.estilo_livre,
                    "estilos": [{"id": k, "nome": n} for k, n in voz_nuvem.NOMES_DOS_ESTILOS.items()],
                    "vozes": self._estado_voz.get("vozes", []), "pacotes": self._estado_voz.get("pacotes", {}),
                    "ouvir": bool(self._estado_voz.get("ouvir")), "reconhecimento": self._estado_voz.get("reconhecimento", ""),
                    "baixando": dict(self._baixando), "mensagem": self._voz["mensagem"],
                    "teste_microfone": self._teste_microfone},
        }

    def _publicar(self):
        if self._servico is not None:
            self._servico.publicar(json.dumps(self._estado_publico(), ensure_ascii=False, default=str))

    def _ao_pedido(self, tipo, nome, valor):
        """Pedido das Configurações ou da Barra. Tudo é conferido aqui: só chaves e valores conhecidos."""
        sim = valor.strip().lower() in ("sim", "true", "1")
        if tipo == "definir":
            if nome == "motor_padrao" and valor in ("local", "gemini", "openai"):
                reserva = self._config.provedor == "automatico"
                self.definirProvedor(valor if valor != "local" else ("automatico" if reserva else "local"))
                self._gateway.sessao_motor = ""
            elif nome == "reserva_na_nuvem" and self._gateway.motor_padrao() == "local":
                self.definirProvedor("automatico" if sim else "local")
            elif nome == "saudacao":
                from ..configuracao import SAUDACOES
                if valor in SAUDACOES:
                    self.definirSaudacao(valor)
            elif nome == "aprovar_toda_acao":
                self.definirAprovarTodaAcao(sim)
            elif nome == "falar_respostas":
                self._config.falar_respostas = sim
                self._config.salvar()
                if not sim:
                    self.calar()
                elif not self._voz_pronta():
                    self._baixar_voz(self._config.voz)          # ligou sem voz baixada: baixa a escolhida
                else:
                    self._preparar_voz()
                self.configMudou.emit()
            elif nome == "voz":
                from ..configuracao import VOZES
                if valor in VOZES:
                    self._config.voz = valor
                    self._config.salvar()
                    self.configMudou.emit()
            elif nome == "voz_nuvem":
                from ..configuracao import _voz_nuvem
                if valor == "" or _voz_nuvem(valor):          # "" = a padrão; outro texto: ignorado
                    self._config.voz_nuvem = _voz_nuvem(valor)
                    self._config.salvar()
                    self.configMudou.emit()
            elif nome == "estilo_da_voz":
                from ..configuracao import ESTILOS_DA_VOZ
                if valor in ESTILOS_DA_VOZ:
                    self._config.estilo_da_voz = valor
                    self._config.salvar()
                    self.configMudou.emit()
            elif nome == "estilo_livre":
                self._config.estilo_livre = " ".join(valor.split())[:300]
                self._config.salvar()
                self.configMudou.emit()
            elif nome == "ouvir_na_nuvem":
                self._config.ouvir_na_nuvem = sim
                self._config.salvar()
                self.configMudou.emit()
            elif nome == "voz_na_nuvem":
                self._config.voz_na_nuvem = sim
                self._config.salvar()
                self.configMudou.emit()
            elif nome == "conversa_continua":
                self._config.conversa_continua = sim
                self._config.salvar()
                if not sim:
                    self._conversa_por_voz = False
                self.configMudou.emit()
            elif nome == "velocidade_da_voz":
                from ..configuracao import _velocidade
                self._config.velocidade_da_voz = _velocidade(valor)
                self._config.salvar()
                self.configMudou.emit()
            return
        try:
            dados = json.loads(valor) if valor else {}
        except ValueError:
            return
        if not isinstance(dados, dict):
            return
        texto = lambda chave, limite=300: str(dados.get(chave) or "")[:limite]     # noqa: E731
        if nome == "mostrar":
            self.pedirMostrar.emit(True)
        elif nome == "recarregar":                   # a tela de IA mudou chaves ou motores
            threading.Thread(target=self._ler_estado_da_voz, daemon=True).start()
            self.atualizarSituacao()
        elif nome == "definir_cidade":
            self.definirCidade(texto("texto"), int(dados.get("escolha") or 0))
        elif nome == "esquecer_cidade":
            self.esquecerCidade()
        elif nome == "adicionar_link_agenda":
            self.adicionarLinkAgenda(texto("nome"), texto("url", 2000))
        elif nome == "adicionar_caldav":
            self.adicionarCalDav(texto("nome"), texto("url", 1000), texto("usuario"), texto("senha", 500))
        elif nome == "conectar_agenda" and texto("provedor") in ("google", "microsoft"):
            self.conectarAgenda(texto("provedor"))
        elif nome == "cancelar_conexao_agenda":
            self.cancelarConexaoAgenda()
        elif nome == "remover_conta_agenda":
            self.removerContaAgenda(texto("id"))
        elif nome == "testar_saudacao":
            self.testarSaudacao()
        elif nome == "baixar_voz":
            self._baixar_voz(texto("item", 40))
        elif nome == "remover_voz":
            subprocess.run([voz.COMANDO, "remover", texto("item", 40)], capture_output=True, timeout=30, check=False)
            threading.Thread(target=self._ler_estado_da_voz, daemon=True).start()
        elif nome == "testar_microfone":
            self.testarMicrofone()
        elif nome == "testar_voz":
            if not self.dizer("Olá! Eu sou o Wise. É assim que eu falo com você."):
                self._voz["mensagem"] = "Baixe uma voz primeiro."
                self.vozMudou.emit()
        elif nome == "desligar":
            self.desligar()

    def desligar(self):
        """"Desligar o Wise" (Barra de Recursos): o Wise sai, a sessão não o reabre e a IA local sai da memória.
        Abrir o Wise de novo liga tudo outra vez."""
        self.calar()
        self._cancelar.set()
        voz.servico().encerrar()
        try:
            ARQUIVO_DESLIGADO.write_text("desligado pela pessoa\n")
        except OSError:
            pass
        pedir_a_ia_do_sistema("Pausar", "true")
        QTimer.singleShot(200, QGuiApplication.quit)

    @Slot()
    def novaConversa(self):
        if self._ocupado:
            return
        self._mensagens = []
        self._orquestrador.limpar()
        self.mudou.emit()

    def _avisar_resposta(self, dados):
        """Com a janela fechada, a resposta chega num balão, como se o Wise falasse."""
        if self._janela_visivel or self._presenca is None or dados["estado"] == "cancelada":
            return
        if dados["estado"] == "concluida":
            texto = resumo_da_resposta(dados["resposta"]) or "Terminei o que você pediu."
        else:
            texto = "Não consegui responder desta vez. Clique para ver o que aconteceu."
        self._resposta_nao_vista = True
        self._presenca.avisar_resposta(texto)

    # ---------------------------------------------------------------- presença
    @Slot(bool)
    def janelaVisivel(self, visivel):
        self._janela_visivel = visivel
        if visivel:
            self._aquecer_se_preciso(intencao=True)
        else:
            self._conversa_por_voz = False
        if visivel and self._resposta_nao_vista:
            self._resposta_nao_vista = False
            if self._presenca is not None:
                self._presenca.fechar_balao()
        self._atualizar_presenca()

    def _atualizar_presenca(self):
        if self._presenca is None:
            return
        if self._voz["ouvindo"] or self._voz["transcrevendo"]:
            estado = "ouvindo"
        elif self._ocupado:
            estado = "pensando"
        elif self._voz["falando"]:
            estado = "falando"
        elif self._janela_visivel:
            estado = "aberto"
        else:
            estado = "descansando"
        self._presenca.definir_estado(estado)

    def saudar(self):
        """Cumprimenta a pessoa ao abrir a sessão, conforme a configuração.
        "fala" sozinha ainda não existe (voz na W3): por enquanto não mostra nada."""
        if self._presenca is not None and self._config.saudacao in ("escrita", "fala_e_escrita"):
            self._presenca.saudar(texto_saudacao())
        if self._config.saudacao in ("fala", "fala_e_escrita"):
            # A voz leva um instante para ler o que há instalado: fala assim que souber
            QTimer.singleShot(2500, lambda: self.dizer(texto_saudacao()))

    # ---------------------------------------------------------- configurações
    @Slot()
    def atualizarSituacao(self):
        try:
            self._tem_chave = tem_chave_na_nuvem(self._gateway) if not self._demonstracao else True
        except segredos.CofreIndisponivel:
            self._tem_chave = False
        self._situacao = self._gateway.situacao()
        if not self._demonstracao:
            try:
                instalados = self._gateway.local.modelos_instalados()
            except Exception:  # noqa: BLE001 — Ollama fora do ar
                instalados = []
            ativo = self._gateway.local.modelo
            self._modelos_locais = sorted(set(m for m in instalados if m)) or ([ativo] if ativo else [])
        self.configMudou.emit()

    @Slot(str)
    def definirProvedor(self, provedor):
        from ..configuracao import PROVEDORES
        if provedor not in PROVEDORES:
            return
        self._config.provedor = provedor
        self._config.salvar()
        self.atualizarSituacao()

    @Slot(str)
    def definirSaudacao(self, saudacao):
        self._config.saudacao = saudacao
        self._config.salvar()
        self.configMudou.emit()

    @Slot()
    def testarSaudacao(self):
        if self._presenca is not None and self._config.saudacao != "fala":
            self._presenca.saudar(texto_saudacao())
        if self._config.saudacao in ("fala", "fala_e_escrita"):
            self.dizer(texto_saudacao())

    @Slot(bool)
    def definirNuvem(self, permitida):
        self._config.nuvem_permitida = permitida
        self._config.salvar()
        self.atualizarSituacao()

    @Slot(str, result=str)
    def salvarChave(self, chave):
        chave = chave.strip()
        if not chave:
            return "Digite a chave."
        try:
            segredos.gravar("gemini", chave, "Wise — chave do Google Gemini")
        except segredos.CofreIndisponivel as erro:
            return f"Não consegui guardar a chave: {erro}"
        self.atualizarSituacao()
        return ""

    @Slot(result=str)
    def apagarChave(self):
        try:
            segredos.apagar("gemini")
        except segredos.CofreIndisponivel as erro:
            return f"Não consegui apagar a chave: {erro}"
        self.atualizarSituacao()
        return ""

    def _rotulo_provedor(self):
        if self._ocupado and self._provedor:
            return self._provedor
        if self._ia is not None and self._ia.calibrando:
            return "Ajustando a IA ao computador…"
        if self._gateway.motor_atual() == "local" and self._ia is not None and self._ia.ativo and not self._ia.carregado:
            return "Carregando " + ia_do_sistema.nome_amigavel(self._ia.ativo) + "…"
        if self._ia is not None and not self._ia.ativo and self._ia.tarefa:
            return f"Preparando a IA · {self._ia.tarefa.fracao * 100:.0f}%"
        try:
            escolhido = self._gateway.escolher()
            return ("Nuvem · " if escolhido.nuvem else "Local · ") + escolhido.titulo
        except Exception:
            return "Sem IA configurada"

    # ------------------------------------------------- cidade da previsão (W13)
    @Slot(str, int)
    def definirCidade(self, texto, escolha=0):
        self._cidade_mensagem = "Procurando…"
        self.contasMudou.emit()

        def trabalho():
            try:
                r = clima.definir_cidade(texto, escolha or 0)
            except Exception as erro:  # noqa: BLE001
                r = {"erro": str(erro)}
            self._evento.emit("cidade", r)
        threading.Thread(target=trabalho, daemon=True).start()

    @Slot()
    def esquecerCidade(self):
        clima.esquecer_cidade()
        self._cidade_opcoes, self._cidade_mensagem = [], ""
        self.contasMudou.emit()

    def _ao_cidade(self, r):
        self._cidade_opcoes = [o["cidade"] for o in r.get("opcoes", [])] if r.get("precisa_escolher") else []
        if r.get("cidade_definida"):
            self._cidade_mensagem = ""
        elif self._cidade_opcoes:
            self._cidade_mensagem = "Qual destas?"
        else:
            self._cidade_mensagem = str(r.get("erro", ""))
        self.contasMudou.emit()

    def _cidade(self):
        escolhida = clima.cidade_escolhida()
        return escolhida["cidade"] if escolhida else ""

    # --------------------------------------------------------- agenda (W14)
    def _na_agenda(self, mensagem_inicial, funcao, *argumentos):
        if self._agenda_ocupada:
            return
        self._agenda_ocupada, self._agenda_mensagem = True, mensagem_inicial
        self.contasMudou.emit()

        def trabalho():
            try:
                conta = funcao(*argumentos)
                texto = f"Agenda conectada: {conta['nome']}."
            except (agenda.ErroDaAgenda, segredos.CofreIndisponivel, ValueError) as erro:
                texto = f"Não conectei: {erro}"
            except Exception as erro:  # noqa: BLE001
                texto = f"Não conectei: {type(erro).__name__}"
            self._evento.emit("agenda", {"mensagem": texto})
        threading.Thread(target=trabalho, daemon=True).start()

    @Slot(str, str)
    def adicionarLinkAgenda(self, nome, url):
        self._na_agenda("Conferindo o link…", agenda.adicionar_link, nome, url)

    @Slot(str, str, str, str)
    def adicionarCalDav(self, nome, url, usuario, senha):
        self._na_agenda("Procurando as agendas da conta…", agenda.adicionar_caldav, nome, url, usuario, senha)

    @Slot(str)
    def conectarAgenda(self, provedor):
        self._cancelar_login.clear()
        self._na_agenda("Abri o navegador: entre na sua conta e autorize o Wise.", agenda.conectar, provedor,
                        self._cancelar_login)

    @Slot()
    def cancelarConexaoAgenda(self):
        self._cancelar_login.set()

    @Slot(str)
    def removerContaAgenda(self, id_conta):
        agenda.remover(id_conta)
        self._agenda_mensagem = "Conta removida."
        self.contasMudou.emit()

    def _contas_agenda(self):
        rotulos = {"ics": "Link .ics (só leitura)", "caldav": "CalDAV", "google": "Google", "microsoft": "Microsoft"}
        return [{"id": c["id"], "nome": c.get("nome", ""), "tipo": rotulos.get(c["tipo"], c["tipo"])}
                for c in agenda.contas()]

    # ------------------------------------------------- usar a tela (W15)
    # ------------------------------------------------------------- diagnóstico
    @Slot(int, str)
    def marcarProblema(self, indice, comentario=""):
        """"Não ficou bom": vira um aviso no registro do sistema (o pedido, a resposta e o comentário só no
        nível "desenvolvimento") e pede ao coletor do sistema o envio já (W19)."""
        if not 0 <= indice < len(self._mensagens):
            return
        mensagem = self._mensagens[indice]
        if mensagem.get("tipo") not in ("wise", "erro") or mensagem.get("avaliada"):
            return
        pedido = next((m.get("texto", "") for m in reversed(self._mensagens[:indice]) if m.get("tipo") == "pessoa"), "")
        atividades = []
        for m in self._mensagens[:indice]:
            if m.get("tipo") == "pessoa":
                atividades = []
            elif m.get("tipo") in ("atividade", "aprovacao"):
                atividades.append({k: m.get(k) for k in ("tipo", "texto", "ok", "detalhe", "estado", "mensagem")})
        diagnostico.registrar("reclamacao", tarefa=mensagem.get("tarefa", ""), pedido=pedido,
                              resposta=mensagem.get("texto", ""), comentario=comentario.strip()[:2000],
                              atividades=atividades, provedor=self._provedor)
        diagnostico.uso("wise_reclamacao")
        mensagem["avaliada"] = True
        diagnostico.enviar_agora()
        self.mudou.emit()

    @Slot()
    def enviarRelatoriosAgora(self):
        diagnostico.enviar_agora()

    @Slot(bool)
    def definirAprovarTodaAcao(self, valor):
        self._config.aprovar_toda_acao_na_tela = bool(valor)
        self._config.salvar()
        self.configMudou.emit()

    mensagens = Property("QVariantList", lambda self: self._mensagens, notify=mudou)
    parcial = Property(str, lambda self: self._parcial, notify=parcialMudou)
    parcialCompleto = Property(bool, lambda self: self._parcial_completo, notify=parcialMudou)
    limiteDaVoz = Property(int, lambda self: self._limite_voz, notify=sincMudou)
    ritmoDaVoz = Property(float, lambda self: self._ritmo_voz, notify=sincMudou)
    motores = Property("QVariantList", lambda self: self._lista_de_motores(), notify=configMudou)
    motorAtual = Property(str, lambda self: self._gateway.motor_atual(), notify=configMudou)
    modeloAtual = Property(str, lambda self: (self._gateway.motor(self._gateway.motor_atual()).modelo or ""), notify=configMudou)
    vozEstado = Property("QVariantMap", lambda self: dict(self._voz), notify=vozMudou)
    podeOuvir = Property(bool, lambda self: voz.disponivel(), constant=True)
    falaRespostas = Property(bool, lambda self: self._config.falar_respostas and self._pode_falar(), notify=configMudou)
    ocupado = Property(bool, lambda self: self._ocupado, notify=mudou)
    respostaNaoVista = Property(bool, lambda self: self._resposta_nao_vista, notify=mudou)
    provedorAtual = Property(str, lambda self: self._rotulo_provedor(), notify=configMudou)
    situacao = Property("QVariantMap", lambda self: self._situacao, notify=configMudou)
    provedor = Property(str, lambda self: self._config.provedor, notify=configMudou)
    saudacao = Property(str, lambda self: self._config.saudacao, notify=configMudou)
    nuvemPermitida = Property(bool, lambda self: self._config.nuvem_permitida, notify=configMudou)
    temChaveGemini = Property(bool, lambda self: self._tem_chave, notify=configMudou)
    modeloGemini = Property(str, lambda self: self._config.modelo_gemini, constant=True)
    modeloLocalAmigavel = Property(str, lambda self: ia_do_sistema.nome_amigavel(
        (self._situacao.get("local") or {}).get("modelo") or ""), notify=configMudou)
    temConfiguracoes = Property(bool, lambda self: os.access(CONFIGURACOES, os.X_OK), constant=True)
    sugestoes = Property("QVariantList", lambda self: SUGESTOES, constant=True)
    versao = Property(str, lambda self: VERSAO, constant=True)
    cidade = Property(str, lambda self: self._cidade(), notify=contasMudou)
    cidadeOpcoes = Property("QVariantList", lambda self: self._cidade_opcoes, notify=contasMudou)
    cidadeMensagem = Property(str, lambda self: self._cidade_mensagem, notify=contasMudou)
    contasAgenda = Property("QVariantList", lambda self: self._contas_agenda(), notify=contasMudou)
    agendaOcupada = Property(bool, lambda self: self._agenda_ocupada, notify=contasMudou)
    agendaMensagem = Property(str, lambda self: self._agenda_mensagem, notify=contasMudou)
    loginGoogle = Property(bool, lambda self: oauth.aplicativo("google") is not None, constant=True)
    loginMicrosoft = Property(bool, lambda self: oauth.aplicativo("microsoft") is not None, constant=True)
    aprovarTodaAcao = Property(bool, lambda self: self._config.aprovar_toda_acao_na_tela, notify=configMudou)
    temRegistroDoSistema = Property(bool, lambda self: diagnostico._registro is not None, constant=True)
    nivelRelatorios = Property(str, lambda self: NOMES_NIVEIS.get(
        diagnostico._registro.nivel() if diagnostico._registro else "", ""), notify=configMudou)


def _enviar_a_instancia_aberta(comando):
    socket = QLocalSocket()
    socket.connectToServer(NOME_SOCKET)
    if not socket.waitForConnected(500):
        return False
    socket.write(comando.encode())
    socket.flush()
    socket.waitForBytesWritten(500)
    socket.disconnectFromServer()
    return True


def comando_de_diagnostico(argv):
    """--diagnostico (pede o envio ao coletor do sistema) e --diagnostico-arquivo (grava o registro do Wise e
    as conversas num arquivo, para anexar num pedido de suporte), sem abrir a interface."""
    if "--diagnostico-arquivo" in argv:
        posicao = argv.index("--diagnostico-arquivo")
        if posicao + 1 >= len(argv):
            print("Uso: duiaos-wise --diagnostico-arquivo ARQUIVO [--horas N]", file=sys.stderr)
            return 2
        horas = 24.0
        if "--horas" in argv and argv.index("--horas") + 1 < len(argv):
            horas = float(argv[argv.index("--horas") + 1])
        quantos = gravar_arquivo(argv[posicao + 1], horas)
        print(f"Registro do Wise gravado em {argv[posicao + 1]}: {quantos} linhas (inclui as suas conversas).")
        return 0
    if diagnostico._registro is None:
        print("Este computador não tem o registro do sistema do DuiaOS (pacote duiaos-relatorios).", file=sys.stderr)
        return 1
    diagnostico.enviar_agora()
    print("Pedido o envio ao coletor do sistema (o que vai depende de \"Ajude a melhorar o DuiaOS\"). "
          "Veja com: duiaos-relatorios estado")
    return 0


def gravar_arquivo(destino, horas):
    """Registro do Wise no journal + auditoria (pedidos, ferramentas, respostas) das últimas `horas`."""
    import json
    inicio = time.time() - horas * 3600
    linhas = []
    try:
        saida = subprocess.run(["journalctl", "--no-pager", "-o", "json", "-t", "duiaos-wise",
                                "--since", f"@{int(inicio)}"], capture_output=True, text=True, timeout=60).stdout
        for linha in saida.splitlines():
            try:
                e = json.loads(linha)
            except ValueError:
                continue
            linhas.append({"fonte": "journal", "t": int(e.get("__REALTIME_TIMESTAMP", "0")) / 1e6,
                           **{k: v for k, v in e.items() if k in ("MESSAGE", "PRIORITY", "DUIAOS_EVENTO",
                                                                    "DUIAOS_DADOS", "DUIAOS_RASTRO")}})
    except (OSError, subprocess.SubprocessError):
        pass
    for evento in Auditoria().desde(inicio):
        linhas.append({"fonte": "auditoria", "t": evento["quando"], "tarefa": evento["tarefa"],
                       "tipo": evento["tipo"], "detalhe": evento["detalhe"]})
    linhas.sort(key=lambda l: l["t"])
    with open(destino, "w", encoding="utf-8") as saida:
        for linha in linhas:
            saida.write(json.dumps(linha, ensure_ascii=False, default=str) + "\n")
    return len(linhas)


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    if "--diagnostico" in argv or "--diagnostico-arquivo" in argv:
        return comando_de_diagnostico(argv)
    comando = "alternar" if "--alternar" in argv else ("fundo" if "--fundo" in argv else "mostrar")
    if "--desligar" in argv:
        comando = "desligar"
    demonstracao = "--demonstracao" in argv
    os.environ.setdefault("QT_QPA_PLATFORM", "wayland")
    # O Wise é uma janela comum (barra de título, botões, redimensionar), mesmo
    # quando aberto por um painel do DuiaOS que usa layer-shell.
    os.environ.pop("QT_WAYLAND_SHELL_INTEGRATION", None)

    app = QGuiApplication(argv)
    app.setApplicationName("duiaos-wise")
    app.setApplicationDisplayName("Wise")
    app.setDesktopFileName("duiaos-wise")      # app_id no Wayland (a Ilha reconhece a janela)
    app.setQuitOnLastWindowClosed(False)       # fechar a janela só põe o Wise para descansar
    app.setWindowIcon(QIcon.fromTheme("duiaos-wise"))
    if not demonstracao:
        diagnostico.iniciar(VERSAO)                # registro do sistema (W19), se o DuiaOS o tiver
        diagnostico.instalar_no_qt()

    if comando == "fundo":
        # Já existe um Wise (aberto à mão antes do início da sessão): espera ele
        # terminar para assumir, sem abrir um segundo.
        while _enviar_a_instancia_aberta("ping"):
            time.sleep(5)
    elif _enviar_a_instancia_aberta(comando):
        return 0
    elif comando == "desligar":
        return 0                                # já estava desligado
    if comando != "fundo" and ARQUIVO_DESLIGADO.exists():
        # A pessoa abriu o Wise depois de desligá-lo: liga tudo de novo (a IA local volta para a memória)
        try:
            ARQUIVO_DESLIGADO.unlink()
        except OSError:
            pass
        pedir_a_ia_do_sistema("Pausar", "false")

    servidor = QLocalServer()
    QLocalServer.removeServer(NOME_SOCKET)
    servidor.listen(NOME_SOCKET)

    presenca = Presenca(com_bolha="--sem-bolha" not in argv)
    ponte = Ponte(demonstracao, presenca)
    app.aboutToQuit.connect(presenca.encerrar)

    def ao_conectar():
        conexao = servidor.nextPendingConnection()
        if conexao.waitForReadyRead(500):
            pedido = bytes(conexao.readAll()).decode(errors="ignore").strip()
            if pedido in ("alternar", "mostrar"):
                ponte.pedirMostrar.emit(pedido == "mostrar")
            elif pedido == "desligar":
                ponte.desligar()
        conexao.disconnectFromServer()
    servidor.newConnection.connect(ao_conectar)

    engine = QQmlApplicationEngine()
    engine.rootContext().setContextProperty("wise", ponte)
    from .aparencia import Aparencia
    aparencia = Aparencia()
    engine.rootContext().setContextProperty("aparencia", aparencia)
    engine.load(PASTA / "Wise.qml")
    if not engine.rootObjects():
        return 1
    presenca.iniciar()
    if comando == "fundo":
        QTimer.singleShot(1500, ponte.saudar)   # depois que a bolha aparece
    else:
        ponte.pedirMostrar.emit(True)
    codigo = app.exec()
    del engine          # a interface sai antes da ponte (sem avisos ao fechar)
    return codigo
