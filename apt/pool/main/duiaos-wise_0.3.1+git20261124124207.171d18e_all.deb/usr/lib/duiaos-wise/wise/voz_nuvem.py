"""Voz natural pela nuvem (ADR 080 do DuiaOS): quando o motor OpenAI ou Gemini está ligado nas Configurações,
a fala do Wise usa a voz da nuvem — a mesma família de vozes dos assistentes deles —, com a voz local de reserva.

Só o texto que o Wise vai falar sai do computador, para o provedor que a pessoa ligou (o mesmo consentimento
do motor na nuvem). Cada trecho é pedido assim que fica pronto (até três ao mesmo tempo) e o áudio toca
enquanto chega, em ordem, num tocador só, com a pausa da pontuação. Se a nuvem falhar, o resto da fala
continua pela voz local, sem silêncio.
"""
import base64
import http.client
import json
import queue
import shutil
import subprocess
import threading
import time
import urllib.parse

from . import motores

TAXA = 24000                         # as duas devolvem PCM de 16 bits, mono, 24 kHz
OPENAI_URL = "https://api.openai.com/v1/audio/speech"
OPENAI_MODELO = "gpt-4o-mini-tts"
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{modelo}:streamGenerateContent?alt=sse"
GEMINI_MODELO = "gemini-3.1-flash-tts-preview"
# Como falar (ADR 082): a base vale sempre; o estilo e o ritmo vêm das Configurações › Wise › Voz
BASE = ("Fale em português do Brasil, com sotaque brasileiro natural, frases ligadas e sem soar como leitura. "
        "Não arraste as palavras nem faça pausas longas.")
ESTILOS = {
    "natural": "Tom caloroso e descontraído, como uma conversa entre amigos.",
    "animado": "Tom alegre e animado, com energia e sorriso na voz.",
    "calmo": "Tom calmo, suave e acolhedor.",
    "profissional": "Tom claro, seguro e profissional, como um bom atendente.",
}
NOMES_DOS_ESTILOS = {"natural": "Natural", "animado": "Animado", "calmo": "Calmo", "profissional": "Profissional",
                     "personalizado": "Do meu jeito"}
# Vozes da nuvem que falam bem português (id, nome na tela, gênero); a primeira de cada gênero é a padrão
VOZES_NUVEM = {
    "openai": [("marin", "Marin — feminina, natural", "f"), ("cedar", "Cedar — masculina, natural", "m"),
               ("coral", "Coral — feminina, calorosa", "f"), ("sage", "Sage — feminina, calma", "f"),
               ("shimmer", "Shimmer — feminina, suave", "f"), ("ash", "Ash — masculina, firme", "m"),
               ("ballad", "Ballad — masculina, expressiva", "m"), ("verse", "Verse — masculina, versátil", "m")],
    "gemini": [("Aoede", "Aoede — feminina, leve", "f"), ("Puck", "Puck — masculina, animada", "m"),
               ("Kore", "Kore — feminina, firme", "f"), ("Leda", "Leda — feminina, jovem", "f"),
               ("Zephyr", "Zephyr — feminina, clara", "f"), ("Sulafat", "Sulafat — feminina, calorosa", "f"),
               ("Charon", "Charon — masculino, informativo", "m"), ("Achird", "Achird — masculino, amigável", "m"),
               ("Fenrir", "Fenrir — masculino, empolgado", "m"), ("Orus", "Orus — masculino, firme", "m")],
}
FEMININAS = {"dora"}
# Pausas depois de cada trecho, já sem o silêncio que a nuvem põe no começo e no fim do áudio
PAUSAS = {".": 0.22, "!": 0.24, "?": 0.26, "…": 0.32, ":": 0.14, ";": 0.12, ",": 0.08}
LIMIAR_DE_SILENCIO = 350             # amostra s16 abaixo disto (≈ −40 dB) é silêncio
GUARDA_DO_FIM = int(TAXA * 0.5) * 2  # bytes do fim de cada trecho guardados para tirar o silêncio final
LETRAS_POR_SEGUNDO = 15.0            # ritmo médio da fala em português (para o texto acompanhar a voz)
EM_PARALELO = 3
TEMPO_LIMITE = 20


def motor_da_voz(ativado=motores.ativado):
    """O motor na nuvem que a voz pode usar ("openai", "gemini" ou ""), na ordem de preferência."""
    for motor in ("openai", "gemini"):
        if ativado(motor):
            return motor
    return ""


def voz_do_motor(motor, voz_local, escolhida=""):
    """A voz escolhida nas Configurações (se for deste motor) ou a padrão do mesmo gênero da voz local."""
    ids = [v[0] for v in VOZES_NUVEM[motor]]
    if escolhida in ids:
        return escolhida
    genero = "f" if voz_local in FEMININAS else "m"
    return next(v[0] for v in VOZES_NUVEM[motor] if v[2] == genero)


def jeito_de_falar(estilo="natural", livre="", velocidade=1.0):
    """O texto de instrução de fala: base + estilo + ritmo."""
    estilo_texto = (" ".join(str(livre).split())[:300] if estilo == "personalizado" and str(livre).strip()
                    else ESTILOS.get(estilo, ESTILOS["natural"]))
    if velocidade >= 1.25:
        ritmo = "Fale rápido."
    elif velocidade >= 1.08:
        ritmo = "Fale num ritmo ágil."
    elif velocidade <= 0.92:
        ritmo = "Fale devagar, com calma."
    else:
        ritmo = "Fale num ritmo natural de conversa, nem lento nem apressado."
    return f"{BASE} {estilo_texto} {ritmo}"


def pausa_depois(texto):
    texto = texto.rstrip()
    return PAUSAS.get(texto[-1:], 0.06) if texto else 0.0


def _fim_do_som(dados):
    """Posição (em bytes, par) logo depois da última amostra que não é silêncio."""
    import array
    amostras = array.array("h", dados[:len(dados) // 2 * 2])
    for i in range(len(amostras) - 1, -1, -1):
        if abs(amostras[i]) > LIMIAR_DE_SILENCIO:
            return min(len(amostras), i + int(TAXA * 0.03)) * 2      # uma folga de 30 ms
    return 0


def _comeco_do_som(dados):
    """Posição (em bytes, par) da primeira amostra que não é silêncio, ou None se é tudo silêncio."""
    import array
    amostras = array.array("h", dados[:len(dados) // 2 * 2])
    for i, valor in enumerate(amostras):
        if abs(valor) > LIMIAR_DE_SILENCIO:
            return max(0, i - int(TAXA * 0.02)) * 2
    return None


def tocador():
    """Processo que toca PCM s16, mono, 24 kHz vindo pela entrada (PipeWire, PulseAudio ou ALSA)."""
    for comando in (["pw-cat", "--playback", "--raw", "--format", "s16", "--rate", str(TAXA), "--channels", "1",
                     "--media-role", "Assistant", "--properties", "media.name=Wise", "-"],
                    ["paplay", "--raw", f"--rate={TAXA}", "--format=s16le", "--channels=1", "--client-name=Wise",
                     "--latency-msec=120"],
                    ["aplay", "-q", "-t", "raw", "-f", "S16_LE", "-r", str(TAXA), "-c", "1", "-"]):
        if shutil.which(comando[0]):
            return subprocess.Popen(comando, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return None


class ErroDaVoz(Exception):
    pass


def _conectar(url, corpo, cabecalhos):
    endereco = urllib.parse.urlsplit(url)
    classe = http.client.HTTPConnection if endereco.scheme == "http" else http.client.HTTPSConnection   # http: só testes
    conexao = classe(endereco.hostname, endereco.port, timeout=TEMPO_LIMITE)
    caminho = endereco.path + (f"?{endereco.query}" if endereco.query else "")
    conexao.request("POST", caminho, body=json.dumps(corpo).encode("utf-8"),
                    headers={"Content-Type": "application/json", **cabecalhos})
    resposta = conexao.getresponse()
    if resposta.status >= 400:
        detalhe = resposta.read().decode("utf-8", "replace")[:300]
        conexao.close()
        raise ErroDaVoz(f"HTTP {resposta.status}: {detalhe}")
    return conexao, resposta


def sintetizar(motor, chave, texto, voz, velocidade, ao_audio, cancelado, urls=None, jeito=""):
    """Pede o áudio de um trecho e entrega o PCM aos pedaços, enquanto chega (ao_audio(bytes))."""
    urls = urls or {}
    jeito = jeito or jeito_de_falar(velocidade=velocidade)
    if motor == "openai":
        corpo = {"model": OPENAI_MODELO, "input": texto, "voice": voz, "instructions": jeito,
                 "response_format": "pcm", "speed": max(0.8, min(1.5, float(velocidade) * 1.05))}
        conexao, resposta = _conectar(urls.get("openai", OPENAI_URL), corpo, {"Authorization": "Bearer " + chave})
        try:
            while not cancelado.is_set():
                bloco = resposta.read(4800)
                if not bloco:
                    return
                ao_audio(bloco)
        finally:
            conexao.close()
    elif motor == "gemini":
        corpo = {"contents": [{"parts": [{"text": f"{jeito}\nDiga: {texto}"}]}],
                 "generationConfig": {"responseModalities": ["AUDIO"],
                                      "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voz}},
                                                       "languageCode": "pt-BR"}}}
        conexao, resposta = _conectar(urls.get("gemini", GEMINI_URL).format(modelo=GEMINI_MODELO), corpo,
                                      {"x-goog-api-key": chave})
        try:
            for linha in resposta:
                if cancelado.is_set():
                    return
                linha = linha.strip()
                if not linha.startswith(b"data:"):
                    continue
                dados = json.loads(linha[5:].decode("utf-8"))
                for candidato in dados.get("candidates") or []:
                    for parte in (candidato.get("content") or {}).get("parts") or []:
                        audio = (parte.get("inlineData") or {}).get("data")
                        if audio:
                            ao_audio(base64.b64decode(audio))
        finally:
            conexao.close()
    else:
        raise ErroDaVoz(f"motor de voz desconhecido: {motor}")


class _Trecho:
    def __init__(self, texto):
        self.texto = texto
        self.indice = 0
        self.blocos = queue.Queue()      # bytes…, e None no fim
        self.erro = None


class FalaNuvem:
    """Mesma forma do voz.Fala (dizer, concluir, calar, ao_terminar): frases entram, a voz da nuvem fala.

    Fluidez (ADR 082): o silêncio que a nuvem põe no começo e no fim de cada áudio é tirado, e entre os trechos
    fica só a pausa da pontuação — a fala sai emendada, como uma frase só. Quando um trecho começa a tocar,
    ao_evento recebe {"evento": "trecho", "indice", "letras", "segundos"}: a janela mostra o texto junto com a voz."""

    def __init__(self, motor, ler_chave, voz_local="dora", velocidade=1.0, ao_terminar=None, ao_evento=None,
                 reserva=None, abrir_tocador=tocador, urls=None, voz_nuvem="", estilo="natural", estilo_livre=""):
        self.motor = motor
        self._ler_chave = ler_chave
        self._voz = voz_do_motor(motor, voz_local, voz_nuvem)
        self._velocidade = velocidade
        self._jeito = jeito_de_falar(estilo, estilo_livre, velocidade)
        self._ao_terminar = ao_terminar or (lambda: None)
        self._ao_evento = ao_evento or (lambda _dados: None)
        self._reserva_criar = reserva        # (ao_terminar) -> voz.Fala local, se a nuvem falhar
        self._reserva = None
        self._abrir_tocador = abrir_tocador
        self._urls = urls
        self._trechos = queue.Queue()        # _Trecho…, e None no fim
        self._vagas = threading.Semaphore(EM_PARALELO)
        self._cancelado = threading.Event()
        self._terminou = False
        self._trava = threading.Lock()
        self._chave = None
        self._inicio = time.monotonic()
        self._processo = None
        self._contagem = 0
        threading.Thread(target=self._tocar, daemon=True).start()

    # ------------------------------------------------------------ interface igual à voz.Fala
    def dizer(self, frase):
        frase = " ".join(str(frase).split())
        if not frase or self._terminou or self._cancelado.is_set():
            return
        trecho = _Trecho(frase)
        trecho.indice, self._contagem = self._contagem, self._contagem + 1
        self._trechos.put(trecho)
        threading.Thread(target=self._baixar, args=(trecho,), daemon=True).start()

    def concluir(self):
        self._trechos.put(None)

    def calar(self):
        self._cancelado.set()
        if self._reserva is not None:
            self._reserva.calar()
        self._fechar(na_hora=True)
        self._acabar()

    # ------------------------------------------------------------ trabalho
    def _chave_do_motor(self):
        with self._trava:
            if self._chave is None:
                self._chave = self._ler_chave(self.motor) or ""
            return self._chave

    def _baixar(self, trecho):
        with self._vagas:
            if self._cancelado.is_set():
                trecho.blocos.put(None)
                return
            try:
                chave = self._chave_do_motor()
                if not chave:
                    raise ErroDaVoz("sem chave do motor na nuvem")
                sintetizar(self.motor, chave, trecho.texto, self._voz, self._velocidade, trecho.blocos.put,
                           self._cancelado, self._urls, self._jeito)
            except Exception as erro:  # noqa: BLE001 — rede, chave, cota: a voz local continua
                trecho.erro = str(erro)[:300]
            trecho.blocos.put(None)

    def _escrever(self, dados):
        if self._processo is None:
            self._processo = self._abrir_tocador()
            if self._processo is None:
                raise ErroDaVoz("sem programa para tocar o som")
        self._processo.stdin.write(dados)
        self._processo.stdin.flush()
        self._tocado_ate = max(self._tocado_ate, time.monotonic()) + len(dados) / 2 / TAXA

    def _tocar(self):
        self._tocado_ate = time.monotonic()
        primeira = None
        while not self._cancelado.is_set():
            trecho = self._trechos.get()
            if trecho is None:
                break
            if self._reserva is not None:          # já caiu para a voz local
                self._reserva.dizer(trecho.texto)
                continue
            recebeu, comecou, guardado = 0, False, b""
            try:
                while not self._cancelado.is_set():
                    bloco = trecho.blocos.get()
                    if bloco is None:
                        break
                    recebeu += len(bloco)
                    guardado += bloco
                    if not comecou:                 # tira o silêncio do começo
                        inicio = _comeco_do_som(guardado)
                        if inicio is None:
                            guardado = guardado[len(guardado) // 2 * 2:]   # só silêncio: descarta (fica o byte ímpar)
                            continue
                        guardado, comecou = guardado[inicio:], True
                        if primeira is None:
                            primeira = time.monotonic() - self._inicio
                            self._ao_evento({"evento": "falando", "motor": self.motor, "primeira_s": round(primeira, 2)})
                        espera = max(0.0, self._tocado_ate - time.monotonic())
                        self._ao_evento({"evento": "trecho", "indice": trecho.indice, "letras": len(trecho.texto),
                                         "daqui_s": round(espera, 2),
                                         "segundos": round(len(trecho.texto) / (LETRAS_POR_SEGUNDO * self._velocidade), 2)})
                    # Guarda o fim (pode ser o silêncio final); escreve o resto, em amostras inteiras
                    if len(guardado) > GUARDA_DO_FIM:
                        corte = (len(guardado) - GUARDA_DO_FIM) // 2 * 2
                        self._escrever(guardado[:corte])
                        guardado = guardado[corte:]
                if comecou and not self._cancelado.is_set():
                    self._escrever(guardado[:_fim_do_som(guardado)] + b"\x00\x00" * int(TAXA * pausa_depois(trecho.texto)))
            except (OSError, ValueError, ErroDaVoz) as erro:
                trecho.erro = trecho.erro or str(erro)[:300]
            if self._cancelado.is_set():
                return
            if trecho.erro and recebeu == 0:
                self._cair_para_local(trecho)
                continue
        if self._cancelado.is_set():
            return
        if self._reserva is not None:
            self._reserva.concluir()             # o fim vem pela voz local
            return
        espera = self._tocado_ate - time.monotonic()
        if espera > 0:
            self._cancelado.wait(min(espera, 120))
        self._fechar()
        self._ao_evento({"evento": "fim_fala", "motor": self.motor,
                         "primeira_s": round(primeira, 2) if primeira is not None else None})
        self._acabar()

    def _cair_para_local(self, trecho):
        self._ao_evento({"evento": "erro_nuvem", "motor": self.motor, "erro": trecho.erro})
        if self._reserva_criar is None:
            return
        try:
            self._reserva = self._reserva_criar(self._acabar)
        except OSError:
            self._reserva = None
            return
        self._reserva.dizer(trecho.texto)

    def _fechar(self, na_hora=False):
        processo, self._processo = self._processo, None
        if processo is None:
            return
        try:
            if na_hora:
                processo.kill()
            else:
                processo.stdin.close()
                processo.wait(timeout=10)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            processo.kill()

    def _acabar(self):
        with self._trava:
            if self._terminou:
                return
            self._terminou = True
        self._ao_terminar()
