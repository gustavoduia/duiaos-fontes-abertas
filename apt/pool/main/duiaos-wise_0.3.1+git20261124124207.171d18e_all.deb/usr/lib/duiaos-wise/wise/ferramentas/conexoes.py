"""Ligar e desligar o Wi-Fi e o Bluetooth (reclamação de 12/10).

Pediram "desliga o wifi": sem ferramenta para isso, o modelo ofereceu desligar
o computador. Agora há a ação certa. É N1: só muda este computador e se desfaz
na hora (a Barra de Recursos e o próprio Wise ligam de novo).

Rede (ADR 071 do duiaos): diagnosticar_rede (N0) e ligar_vpn (N1), pelo mesmo módulo de
rede das Configurações. O estado da rede continua na ferramenta `rede` (sistema.py).

Wi-Fi pelo NetworkManager (nmcli radio wifi, permitido à sessão ativa pelo polkit
do próprio NetworkManager); Bluetooth pelo rfkill (/dev/rfkill é liberado à
sessão ativa pelo systemd-logind).
"""
import importlib.util
import os
import subprocess
from pathlib import Path

from .base import ErroDeArgumentos, Ferramenta

APARELHOS = {"wifi": "Wi-Fi", "bluetooth": "Bluetooth"}


def _rodar(*comando, tempo=10):
    try:
        r = subprocess.run(comando, capture_output=True, text=True, timeout=tempo, check=False,
                           env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C.UTF-8"})
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as erro:
        return 1, str(erro)


def estado(aparelho):
    """True (ligado), False (desligado) ou None (não deu para saber / não existe)."""
    if aparelho == "wifi":
        codigo, saida = _rodar("nmcli", "radio", "wifi")
        valor = saida.strip().lower()
        return None if codigo else {"enabled": True, "disabled": False}.get(valor)
    codigo, saida = _rodar("rfkill", "--noheadings", "--output", "SOFT", "list", "bluetooth")
    linhas = [l.strip() for l in saida.splitlines() if l.strip()]
    if codigo or not linhas:
        return None
    return all(l == "unblocked" for l in linhas)


def ligar_ou_desligar(aparelho, ligar):
    if aparelho not in APARELHOS:
        raise ErroDeArgumentos(f"'aparelho' deve ser um de: {', '.join(APARELHOS)}")
    nome = APARELHOS[aparelho]
    antes = estado(aparelho)
    if antes is None:
        return {"erro": f"não encontrei {nome} neste computador"}
    if antes == ligar:
        return {"ja_estava": f"o {nome} já estava {'ligado' if ligar else 'desligado'}"}
    if aparelho == "wifi":
        codigo, saida = _rodar("nmcli", "radio", "wifi", "on" if ligar else "off")
    else:
        codigo, saida = _rodar("rfkill", "unblock" if ligar else "block", "bluetooth")
    if codigo or estado(aparelho) != ligar:
        return {"erro": f"não consegui {'ligar' if ligar else 'desligar'} o {nome}: {saida.strip()[:120]}"}
    return {"feito": True, "mensagem": f"{nome} {'ligado' if ligar else 'desligado'}."}


# ------------------------------------------------------------------ rede (ADR 071 do duiaos)
# O Wise usa o mesmo módulo de rede das Configurações (shell/comum/rede.py do duiaos-shell), para a
# resposta do Wise ser igual ao que a página Rede e Internet mostra. Instalado: /usr/share/duiaos/shell;
# no desenvolvimento, o duiaos clonado ao lado.
_LUGARES_DA_REDE = [Path(os.environ.get("DUIAOS_SHELL", "/usr/share/duiaos/shell")) / "comum" / "rede.py",
                    Path(__file__).resolve().parents[3] / "duiaos" / "shell" / "comum" / "rede.py"]
_REDE = None


def _rede():
    global _REDE
    if _REDE is None:
        for caminho in _LUGARES_DA_REDE:
            if caminho.exists():
                espec = importlib.util.spec_from_file_location("duiaos_rede", caminho)
                modulo = importlib.util.module_from_spec(espec)
                espec.loader.exec_module(modulo)
                _REDE = modulo
                break
    return _REDE


def diagnosticar_rede():
    rede = _rede()
    if rede is None:
        return {"erro": "o módulo de rede do DuiaOS não está instalado"}
    passos = rede.diagnosticar()
    problema = next((p for p in passos if not p["ok"]), None)
    return {"passos": [{"passo": p["nome"], "ok": p["ok"], "explicacao": p["explicacao"], "o_que_fazer": p["dica"]} for p in passos],
            "conclusao": f"O problema está em: {problema['nome']}." if problema else "A rede e a internet estão funcionando."}


def ligar_vpn(ligar, nome=""):
    rede = _rede()
    if rede is None:
        return {"erro": "o módulo de rede do DuiaOS não está instalado"}
    vpns = [c for c in rede.ler_conexoes() if c["tipo"] == "vpn"]
    if not vpns:
        return {"erro": "não há nenhuma VPN neste computador (adicione em Configurações › Rede e Internet › VPN)"}
    if nome:
        escolhidas = [c for c in vpns if c["nome"].lower() == nome.lower()] or [c for c in vpns if nome.lower() in c["nome"].lower()]
    else:
        escolhidas = vpns if len(vpns) == 1 else ([c for c in vpns if c["ativa"]] if not ligar else [])
    if len(escolhidas) != 1:
        return {"pergunte_qual": [c["nome"] for c in vpns]}
    vpn = escolhidas[0]
    if vpn["ativa"] == ligar:
        return {"ja_estava": f"a VPN {vpn['nome']} já estava {'ligada' if ligar else 'desligada'}"}
    try:
        (rede.ativar if ligar else rede.desativar)(vpn["uuid"])
    except rede.ErroDeRede as erro:
        return {"erro": str(erro)}
    return {"feito": True, "mensagem": f"VPN {vpn['nome']} {'ligada' if ligar else 'desligada'}."}


FERRAMENTAS = [
    Ferramenta("diagnosticar_rede", "Diagnóstico da rede",
               "Confere a rede passo a passo (conexão, endereço, roteador, DNS, internet) e diz onde está o problema. "
               "Use quando a pessoa disser que a internet não funciona ou está estranha.",
               diagnosticar_rede),
    Ferramenta("ligar_vpn", "VPN",
               "Liga ou desliga uma VPN já configurada neste computador.",
               ligar_vpn,
               {"type": "object", "properties": {
                   "ligar": {"type": "boolean", "description": "true liga, false desliga."},
                   "nome": {"type": "string", "description": "Nome da VPN, se a pessoa disse (vazio se só houver uma)."}},
                "required": ["ligar"]},
               nivel="N1", da_pessoa=("nome",)),
    Ferramenta("ligar_desligar", "Wi-Fi e Bluetooth",
               "Liga ou desliga o Wi-Fi ou o Bluetooth deste computador.",
               ligar_ou_desligar,
               {"type": "object", "properties": {
                   "aparelho": {"type": "string", "enum": list(APARELHOS)},
                   "ligar": {"type": "boolean", "description": "true liga, false desliga."}},
                "required": ["aparelho", "ligar"]},
               nivel="N1"),
]
