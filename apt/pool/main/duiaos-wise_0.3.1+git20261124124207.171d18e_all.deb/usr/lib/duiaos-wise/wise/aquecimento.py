"""Aquecimento do Wise no boot, antes do login (serviço duiaos-wise-aquecimento).

Medido em 12/10 no Dell: depois do boot, o primeiro aquecimento do Wise levava
~49 s — o modelo lendo, pela primeira vez, as instruções e as ferramentas
(~3.700 pedaços). Como isso só começava depois do login, o primeiro pedido da
pessoa esperava na fila. Depois desse aquecimento, o Ollama reaproveita o que
leu e cada pedido lê só as palavras novas (~1 s).

Este serviço do sistema roda enquanto a Tela de Entrada ainda está aberta: espera
o duiaos-ia deixar o modelo ativo na memória (e terminar a calibração) e manda
ao Ollama exatamente a mesma abertura que o Wise da sessão manda
(Orquestrador.aquecer). Quando a pessoa entra, o aquecimento da sessão encontra
tudo já lido. Não usa a tela, a pasta pessoal nem a internet: só o estado
público da IA do sistema e o Ollama em 127.0.0.1.
"""
import sys
import threading
import time

from . import diagnostico, ia_do_sistema
from .ferramentas import registro_padrao
from .modelos import ErroDoProvedor
from .modelos.local import Local
from .orquestrador import INSTRUCOES

ESPERA_MAXIMA = 15 * 60      # segundos: modelo baixando ou calibrando demais → desiste (a sessão aquece)
INTERVALO = 2
TENTATIVAS = 4               # Ollama ainda subindo no boot
ESPERA_ENTRE_TENTATIVAS = 10


def pronto(estado):
    """Dá para aquecer: há modelo ativo, o duiaos-ia não está medindo nem baixando, e o modelo já está na memória
    — ou é um que não fica sempre nela (ex.: o 9B num computador de 16 GB): o duiaos-ia não o carrega no boot,
    então o próprio aquecimento o carrega (fica o tempo do "manter", 30 min). Antes o aquecimento esperava
    15 min por um carregamento que nunca vinha e desistia; a 1ª pergunta relia tudo (~3 min no Dell, ADR 079)."""
    return (estado is not None and bool(estado.ativo) and not estado.calibrando and estado.tarefa is None
            and (estado.carregado or estado.manter != -1))


def esperar_modelo(ler=ia_do_sistema.ler, espera=ESPERA_MAXIMA, intervalo=INTERVALO, dormir=time.sleep,
                   relogio=time.monotonic):
    """Espera o modelo ativo ficar pronto. Devolve o estado, ou None se passou do limite
    ou se este computador não tem a IA do sistema."""
    limite = relogio() + espera
    while True:
        estado = ler()
        if pronto(estado):
            return estado
        if relogio() >= limite:
            return None
        dormir(intervalo)


def aquecer(ler=ia_do_sistema.ler, local=None, **espera):
    """Devolve os segundos que o modelo gastou, ou None se não aqueceu."""
    estado = esperar_modelo(ler, **espera)
    if estado is None:
        diagnostico.registrar("aviso", onde="aquecimento no boot", motivo="modelo ativo não ficou pronto")
        return None
    local = local or Local(estado.ativo, estado_do_sistema=ler)
    inicio = time.monotonic()
    dormir = espera.get("dormir", time.sleep)
    for tentativa in range(TENTATIVAS):
        try:
            segundos = local.aquecer(INSTRUCOES, registro_padrao().declaracoes(), threading.Event())
            break
        except ErroDoProvedor as erro:
            # No boot o Ollama pode ainda estar subindo (o modelo que não fica sempre na memória não espera o
            # duiaos-ia): tenta de novo algumas vezes antes de deixar para a sessão
            if tentativa + 1 == TENTATIVAS:
                diagnostico.erro("aquecimento no boot", erro)
                return None
            dormir(ESPERA_ENTRE_TENTATIVAS)
        except Exception as erro:  # noqa: BLE001 — recusou: a sessão tenta de novo
            diagnostico.erro("aquecimento no boot", erro)
            return None
    diagnostico.medida("aquecimento_no_boot", time.monotonic() - inicio, ok=segundos is not None,
                       modelo=estado.ativo, modelo_s=segundos)
    return segundos


def main():
    from . import VERSAO
    diagnostico.iniciar(VERSAO)
    aquecer()
    return 0     # não aquecer não é falha do sistema: a sessão aquece ao abrir o Wise


if __name__ == "__main__":
    sys.exit(main())
