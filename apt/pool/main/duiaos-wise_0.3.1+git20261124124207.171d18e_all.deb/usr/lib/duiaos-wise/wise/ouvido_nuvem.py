"""Entender a fala pela nuvem (ADR 081 do DuiaOS): com o motor OpenAI ou Gemini ligado e a preferência
"ouvir_na_nuvem" ligada, a fala gravada pelo duiaos-voz vai para o reconhecimento deles, bem mais preciso em
português. O reconhecimento local roda ao mesmo tempo e vale se a nuvem demorar ou falhar.

Só o áudio da fala (já recortado pelo detector de fala, sem os silêncios) sai do computador, para o provedor que a
pessoa ligou. O contexto ("é um pedido ao Wise, pode citar agenda, Wi-Fi…") ajuda a acertar as palavras do
sistema — o que o reconhecimento devolve continua sendo dado da pessoa, nunca instrução.
"""
import base64
import json
import urllib.error
import urllib.request
import uuid

from .modelos.base import ErroDoProvedor

OPENAI_URL = "https://api.openai.com/v1/audio/transcriptions"
OPENAI_MODELO = "gpt-transcribe"
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"
GEMINI_MODELO = "gemini-3.8-flash"
CONTEXTO = ("Pedido falado ao Wise, o assistente do computador DuiaOS, em português do Brasil. Pode citar agenda, "
            "compromisso, lembrete, Wi-Fi, Bluetooth, VLC, Ora, Mail Box, Ilha, Configurações, Explorador de Arquivos, "
            "previsão do tempo, volume, brilho, atualizar, instalar, abrir, fechar.")
PALAVRAS = ["Wise", "DuiaOS", "agenda", "Wi-Fi", "Bluetooth", "VLC", "Ora", "Mail Box", "Ilha", "Configurações"]
TEMPO_LIMITE = 8


def _multipart(campos, arquivo):
    fronteira = "duiaos" + uuid.uuid4().hex
    partes = []
    for nome, valor in campos:
        partes.append(f'--{fronteira}\r\nContent-Disposition: form-data; name="{nome}"\r\n\r\n{valor}\r\n'.encode())
    partes.append(f'--{fronteira}\r\nContent-Disposition: form-data; name="file"; filename="fala.wav"\r\n'
                  f"Content-Type: audio/wav\r\n\r\n".encode() + arquivo + b"\r\n")
    partes.append(f"--{fronteira}--\r\n".encode())
    return b"".join(partes), f"multipart/form-data; boundary={fronteira}"


def _post(url, corpo, cabecalhos):
    pedido = urllib.request.Request(url, data=corpo, method="POST", headers=cabecalhos)
    try:
        with urllib.request.urlopen(pedido, timeout=TEMPO_LIMITE) as resposta:
            return json.loads(resposta.read().decode("utf-8"))
    except urllib.error.HTTPError as erro:
        raise ErroDoProvedor(f"HTTP {erro.code}: {erro.read().decode('utf-8', 'replace')[:200]}") from erro
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as erro:
        raise ErroDoProvedor(f"sem conexão: {erro}") from erro


def transcrever(motor, chave, wav, modelo_gemini="", urls=None):
    """Áudio WAV (bytes) → texto, pelo motor na nuvem. ErroDoProvedor se não der."""
    urls = urls or {}
    if motor == "openai":
        campos = [("model", OPENAI_MODELO), ("prompt", CONTEXTO), ("response_format", "json"),
                  ("languages[]", "pt")] + [("keywords[]", p) for p in PALAVRAS]
        corpo, tipo = _multipart(campos, wav)
        cabecalhos = {"Authorization": "Bearer " + chave, "Content-Type": tipo}
        try:
            dados = _post(urls.get("openai", OPENAI_URL), corpo, cabecalhos)
        except ErroDoProvedor as erro:
            if "HTTP 400" not in str(erro):
                raise
            # Campos novos recusados: tenta com o mínimo (modelo, contexto e o arquivo)
            corpo, tipo = _multipart([("model", OPENAI_MODELO), ("prompt", CONTEXTO)], wav)
            dados = _post(urls.get("openai", OPENAI_URL), corpo, {**cabecalhos, "Content-Type": tipo})
        return " ".join(str(dados.get("text") or "").split())
    if motor == "gemini":
        corpo = {"contents": [{"parts": [
            {"text": CONTEXTO + "\nTranscreva exatamente o que a pessoa disse, em português do Brasil, com pontuação. "
                                "Responda só com a transcrição, sem comentários. Se não houver fala, responda vazio."},
            {"inlineData": {"mimeType": "audio/wav", "data": base64.b64encode(wav).decode("ascii")}}]}],
            "generationConfig": {"temperature": 0.0}}
        url = urls.get("gemini", GEMINI_URL).format(modelo=modelo_gemini or GEMINI_MODELO)
        dados = _post(url, json.dumps(corpo).encode("utf-8"), {"x-goog-api-key": chave, "Content-Type": "application/json"})
        textos = [p.get("text", "") for c in dados.get("candidates") or [] for p in (c.get("content") or {}).get("parts") or []]
        return " ".join(" ".join(textos).split()).strip('"“”')
    raise ErroDoProvedor(f"motor desconhecido: {motor}")
