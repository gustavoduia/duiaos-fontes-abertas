"""duiaos-wise --medir-modelos [MODELO...] [--baixar] — mede modelos locais para o Wise (ADR 080 do DuiaOS).

Para cada modelo, no processador e na placa de vídeo: (1) a leitura fria do começo do Wise (instruções +
ferramentas, o que o aquecimento faz a cada boot), (2) uma pergunta que precisa de ferramenta ("que horas são?"
tem de chamar data_e_hora) e (3) a velocidade de escrita numa resposta de conversa. Os números vão para a tela e
para o registro do Wise (chegam nos relatórios de "Ajude a melhorar o DuiaOS"). No fim, o modelo ativo volta
para a memória sozinho (o duiaos-ia recarrega e o Wise reaquece).

Sem MODELO, mede o ativo e os candidatos de CANDIDATOS. Com --baixar, baixa pelo Ollama os que faltam, se houver
espaço em disco (o que for baixado fica disponível em Configurações › Inteligência Artificial).
"""
import os
import shutil
import sys
import time

from . import diagnostico, ia_do_sistema
from .ferramentas import registro_padrao
from .modelos import ErroDoProvedor, Mensagem
from .modelos.base import get_json, post_json, post_json_em_partes
from .modelos.local import ABERTURA, Local
from .orquestrador import INSTRUCOES

# Candidatos a conversa rápida neste tipo de computador: atenção comum (lê o começo da conversa mais rápido na
# placa de vídeo que a atenção híbrida do Qwen 3.5) e licença permissiva
CANDIDATOS = {"qwen3:4b": 2.5, "phi4-mini:3.8b": 2.5}
PASTA_DO_OLLAMA = "/usr/share/ollama"
FOLGA_DE_DISCO_GB = 3.0


def _endereco():
    estado = ia_do_sistema.ler()
    return (estado.endereco if estado else "http://127.0.0.1:11434").rstrip("/"), estado


def instalados(endereco):
    return [m.get("name", "") for m in get_json(f"{endereco}/api/tags").get("models", [])]


def baixar(endereco, modelo, tamanho_gb, saida=print):
    livre = shutil.disk_usage(PASTA_DO_OLLAMA if os.path.isdir(PASTA_DO_OLLAMA) else "/").free / 1e9
    if livre < tamanho_gb + FOLGA_DE_DISCO_GB:
        saida(f"  {modelo}: sem espaço em disco ({livre:.1f} GB livres; precisa de ~{tamanho_gb + FOLGA_DE_DISCO_GB:.0f} GB)")
        return False
    saida(f"  baixando {modelo} (~{tamanho_gb} GB)…")
    ultimo = 0.0
    for dados in post_json_em_partes(f"{endereco}/api/pull", {"model": modelo, "stream": True}, tempo=3600):
        if dados.get("error"):
            saida(f"  {modelo}: {dados['error']}")
            return False
        if dados.get("total") and time.monotonic() - ultimo > 5:
            ultimo = time.monotonic()
            saida(f"    {100 * (dados.get('completed') or 0) / dados['total']:.0f}%")
    return True


def _chat(endereco, modelo, mensagens, opcoes, ferramentas=None, escrever=1):
    corpo = {"model": modelo, "messages": mensagens, "stream": False, "think": False, "keep_alive": "5m",
             "options": {**opcoes, "temperature": 0.3, "num_predict": escrever}}
    if ferramentas:
        corpo["tools"] = ferramentas
    return post_json(f"{endereco}/api/chat", corpo, tempo=1800)


def medir(endereco, modelo, opcoes):
    """Um modelo com umas opções. Devolve o dicionário das medidas."""
    ferramentas = Local.converter_ferramentas(registro_padrao().declaracoes())
    comeco = Local.converter_conversa(INSTRUCOES, ABERTURA[:1], abertura=False)
    post_json(f"{endereco}/api/generate", {"model": modelo, "keep_alive": 0}, tempo=60)   # começa do zero
    inicio = time.monotonic()
    frio = _chat(endereco, modelo, comeco, opcoes, ferramentas)
    medidas = {"modelo": modelo, "placa_de_video": bool(opcoes.get("num_gpu")),
               "carregar_s": round((frio.get("load_duration") or 0) / 1e9, 1),
               "comeco_pedacos": frio.get("prompt_eval_count"),
               "comeco_s": round((frio.get("prompt_eval_duration") or 0) / 1e9, 1),
               "frio_total_s": round(time.monotonic() - inicio, 1)}
    medidas["ler_por_s"] = round(medidas["comeco_pedacos"] / medidas["comeco_s"], 1) if medidas["comeco_s"] else 0
    conversa = Local.converter_conversa(INSTRUCOES, [Mensagem("pessoa", "que horas são agora?")])
    inicio = time.monotonic()
    pergunta = _chat(endereco, modelo, conversa, opcoes, ferramentas, escrever=60)
    chamadas = [(c.get("function") or {}).get("name") for c in (pergunta.get("message") or {}).get("tool_calls") or []]
    medidas.update(ferramenta_certa="data_e_hora" in chamadas, pergunta_s=round(time.monotonic() - inicio, 1))
    conversa = Local.converter_conversa(INSTRUCOES, [Mensagem("pessoa", "Oi! Me conta uma curiosidade curta sobre o Brasil.")])
    papo = _chat(endereco, modelo, conversa, opcoes, ferramentas, escrever=80)
    escritos, duracao = papo.get("eval_count") or 0, (papo.get("eval_duration") or 0) / 1e9
    medidas.update(escrever_por_s=round(escritos / duracao, 1) if duracao else 0,
                   resposta=((papo.get("message") or {}).get("content") or "")[:160])
    return medidas


def main(argv):
    from . import VERSAO
    diagnostico.iniciar(VERSAO)
    endereco, estado = _endereco()
    pedidos = [a for a in argv if not a.startswith("--")]
    ativo = estado.ativo if estado else ""
    modelos = pedidos or ([ativo] if ativo else []) + [m for m in CANDIDATOS if m != ativo]
    try:
        presentes = instalados(endereco)
    except ErroDoProvedor:
        print("O motor de IA local (Ollama) não está rodando.")
        return 1
    threads = (estado.opcoes.get("num_thread") if estado else None) or 4
    resultados = []
    for modelo in modelos:
        nome = modelo if ":" in modelo else modelo + ":latest"
        if modelo not in presentes and nome not in presentes:
            if "--baixar" not in argv or not baixar(endereco, modelo, CANDIDATOS.get(modelo, 5.0)):
                print(f"  {modelo}: não está baixado (use --baixar)")
                continue
        for opcoes in ({"num_gpu": 999, "num_thread": threads}, {"num_gpu": 0, "num_thread": threads}):
            onde = "na placa de vídeo" if opcoes["num_gpu"] else "no processador"
            print(f"Medindo {modelo} {onde}…", flush=True)
            try:
                m = medir(endereco, modelo, opcoes)
            except ErroDoProvedor as erro:
                print(f"  falhou: {erro}")
                continue
            resultados.append(m)
            diagnostico.registrar("medida", nome="modelo_medido", **{k: v for k, v in m.items() if k != "resposta"})
            print(f"  começo do Wise: {m['comeco_pedacos']} pedaços em {m['comeco_s']} s ({m['ler_por_s']}/s) · "
                  f"escreve {m['escrever_por_s']}/s · ferramenta certa: {'sim' if m['ferramenta_certa'] else 'NÃO'} · "
                  f"pergunta {m['pergunta_s']} s")
            print(f"  resposta: {m['resposta']}")
    if resultados:
        bons = [r for r in resultados if r["ferramenta_certa"]] or resultados
        melhor = min(bons, key=lambda r: r["comeco_s"] + 150 / max(r["escrever_por_s"], 0.1))
        print(f"\nMais rápido com ferramenta certa: {melhor['modelo']} "
              f"{'na placa de vídeo' if melhor['placa_de_video'] else 'no processador'}.")
    if ativo:
        print(f"O {ativo} volta para a memória em instantes (o Wise se prepara de novo sozinho).")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
