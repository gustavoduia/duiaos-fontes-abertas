// Wise — janela do assistente do DuiaOS.
// Conversa, motor e modelo da conversa, o que o Wise consultou (atividades), voz e cancelar.
import QtQuick
import QtQuick.Window

Window {
    id: janela
    width: 460; height: 700
    minimumWidth: 380; minimumHeight: 480
    visible: false
    title: "Wise"
    color: cores.fundo

    // Cores do DuiaOS (as mesmas de shell/comum/qml/DuiaOS/Tema.qml), no modo e no estilo escolhidos
    // em Configurações › Aparência
    readonly property bool escuro: typeof aparencia !== "undefined" && aparencia !== null && aparencia.escuro
    readonly property bool futurista: typeof aparencia === "undefined" || aparencia === null || aparencia.futurista
    function c(pc, pe, fc, fe) { return futurista ? (escuro ? fe : fc) : (escuro ? pe : pc) }
    QtObject {
        id: cores
        readonly property color fundo: janela.c("#F7F9FC", "#1B1F27", "#F2F4FC", "#0A0F1F")
        readonly property color cartao: janela.c("#FFFFFF", "#262B34", "#FFFFFF", "#131A30")
        readonly property color destaque: janela.c("#E8F0FE", "#22355A", "#E2E8FF", "#1B2752")
        readonly property color azul: janela.c("#2E6BE6", "#2E6BE6", "#3D5BFF", "#5B8CFF")
        readonly property color azulEscuro: janela.c("#255BC7", "#255BC7", "#2F47D9", "#4A76E8")
        readonly property color noite: janela.c("#1A3A73", "#A9C4F7", "#16205C", "#C7D6FF")
        readonly property color texto: janela.c("#1F2933", "#E6EAF0", "#0E1430", "#EEF2FF")
        readonly property color secundario: janela.c("#5B6675", "#A3ADBB", "#56608A", "#9AA6C7")
        readonly property color borda: janela.c("#DDE3EC", "#353B46", "#DADFF2", "#232C4D")
        readonly property color sucesso: janela.futurista ? "#2DD4A7" : "#2FA67A"
        readonly property color aviso: "#E8A33D"
        readonly property color erro: janela.futurista ? "#FF5C7A" : "#D9534F"
        readonly property color fundoErro: janela.escuro ? "#3A1C26" : "#FBEAEA"
        // Degradê aurora (ciano → azul → violeta) dos controles principais do estilo futurista
        readonly property color aurora1: janela.futurista ? (janela.escuro ? "#22D3EE" : "#06B6D4") : azul
        readonly property color aurora3: janela.futurista ? (janela.escuro ? "#A78BFA" : "#7C3AED") : azul
    }
    readonly property string fonteTitulo: "Manrope"
    readonly property string fonte: "Inter"
    readonly property int raio: futurista ? 18 : 14
    property var listaAberta: null          // lista de motor ou de modelo aberta (uma por vez)

    // Texto de conversa → texto com estilo simples (negrito, itálico, listas), para a resposta que está
    // sendo escrita; "apagando" são as últimas letras, que entram clareando aos poucos
    function limpar(t) { return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;") }
    function estilizar(t) {
        t = limpar(t)
        t = t.replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>").replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<i>$2</i>")
        t = t.replace(/`([^`\n]+)`/g, "$1")
        t = t.replace(/(^|\n)#{1,6}\s+([^\n]+)/g, "$1<b>$2</b>").replace(/(^|\n)\s*[-*+]\s+/g, "$1• ")
        return t.replace(/\*\*|`/g, "").replace(/\n/g, "<br>")
    }
    function comRastro(texto, mostrado) {
        var n = Math.floor(mostrado), rastro = Math.min(16, n)
        var firme = estilizar(texto.substring(0, n - rastro)), fim = texto.substring(n - rastro, n).replace(/[*`#]/g, "")
        var base = cores.texto, saida = ""
        for (var i = 0; i < fim.length; i++) {
            var letra = fim[i]
            if (letra === "\n") { saida += "<br>"; continue }
            var alfa = Math.round(255 * (1 - (i + 1 - (mostrado - n)) / (rastro + 1) * 0.92))
            var hex = Math.max(20, Math.min(255, alfa)).toString(16)
            saida += "<font color=\"#" + (hex.length < 2 ? "0" : "") + hex + ("" + base).substring(1) + "\">" + limpar(letra) + "</font>"
        }
        return firme + saida
    }

    Connections {
        target: wise
        function onPedirMostrar(mostrar) {
            if (!mostrar && janela.visible && janela.active) {
                janela.hide()
                return
            }
            janela.show()
            janela.raise()
            janela.requestActivate()
            campo.forceActiveFocus()
        }
        function onMudou() { lista.positionViewAtEnd() }
    }
    onVisibleChanged: {
        wise.janelaVisivel(visible)
        if (visible) wise.atualizarSituacao()
    }

    Rectangle { anchors.fill: parent; color: cores.fundo }

    // ------------------------------------------------------------- cabeçalho
    Rectangle {
        id: cabecalho
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: 104
        z: 5
        color: cores.cartao
        Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom } height: 1; color: cores.borda }

        Row {
            anchors { left: parent.left; leftMargin: 14; top: parent.top; topMargin: 8 }
            spacing: 8
            Carinha {
                width: 38; height: 40
                estado: wise.vozEstado.ouvindo || wise.vozEstado.transcrevendo ? "ouvindo"
                      : (wise.ocupado ? "pensando" : (wise.vozEstado.falando ? "falando" : "aberto"))
            }
            Column {
                anchors.verticalCenter: parent.verticalCenter
                Text { text: "Wise"; color: cores.noite
                       font { family: janela.fonteTitulo; pixelSize: 18; weight: Font.ExtraBold } }
                Row {
                    spacing: 6
                    Rectangle {
                        width: 7; height: 7; radius: 3.5
                        anchors.verticalCenter: parent.verticalCenter
                        color: wise.provedorAtual === "Sem IA configurada" ? cores.aviso
                             : (wise.provedorAtual.indexOf("Nuvem") === 0 ? cores.azul : cores.sucesso)
                    }
                    Text { text: wise.provedorAtual; color: cores.secundario
                           font { family: janela.fonte; pixelSize: 12 } }
                }
            }
        }
        BotaoTexto { anchors { right: parent.right; rightMargin: 12; top: parent.top; topMargin: 14 }
                     texto: "Nova conversa"; visivel: wise.mensagens.length > 0
                     habilitado: !wise.ocupado; onClicado: wise.novaConversa() }

        // Motor e modelo desta conversa (o padrão e as chaves ficam em Configurações do DuiaOS)
        Row {
            id: escolhas
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 14; rightMargin: 14; bottomMargin: 10 }
            spacing: 8
            readonly property var motor: {
                for (var i = 0; i < wise.motores.length; i++) if (wise.motores[i].id === wise.motorAtual) return wise.motores[i]
                return ({ id: "", titulo: "", modelos: [] })
            }
            Lista {
                id: listaMotor
                width: (parent.width - 8) * 0.46
                rotulo: "Motor"
                valor: escolhas.motor.titulo || "Escolher"
                opcoes: wise.motores.map(function (m) { return { id: m.id, nome: m.titulo, detalhe: m.pronto ? "" : m.motivo } })
                atual: wise.motorAtual
                rodape: wise.temConfiguracoes ? "Configurar os motores…" : ""
                ativa: !wise.ocupado
                onEscolhida: (id) => wise.escolherMotor(id)
                onRodapeClicado: wise.abrirConfiguracoes("ia")
            }
            Lista {
                id: listaModelo
                width: (parent.width - 8) * 0.54
                rotulo: "Modelo"
                valor: {
                    var ms = escolhas.motor.modelos || []
                    for (var i = 0; i < ms.length; i++) if (ms[i].id === wise.modeloAtual) return ms[i].nome
                    return wise.modeloAtual || "Nenhum"
                }
                opcoes: (escolhas.motor.modelos || []).map(function (m) { return { id: m.id, nome: m.nome, detalhe: "" } })
                atual: wise.modeloAtual
                rodape: wise.temConfiguracoes ? (wise.motorAtual === "local" ? "Baixar outros modelos…" : "Atualizar a lista…") : ""
                ativa: !wise.ocupado
                onEscolhida: (id) => wise.escolherModelo(id)
                onRodapeClicado: wise.abrirConfiguracoes("ia")
            }
        }
    }

    // -------------------------------------------------------------- conversa
    Item {
        id: areaConversa
        anchors { left: parent.left; right: parent.right; top: cabecalho.bottom; bottom: rodape.top }

        // Boas-vindas e sugestões (conversa vazia)
        Column {
            visible: wise.mensagens.length === 0
            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 28 }
            spacing: 10
            Text { text: "Olá! Eu sou o Wise."; color: cores.noite
                   font { family: janela.fonteTitulo; pixelSize: 24; weight: Font.ExtraBold } }
            Text {
                width: parent.width; wrapMode: Text.WordWrap; color: cores.secundario
                font { family: janela.fonte; pixelSize: 14 }
                text: "Pergunte sobre o seu computador, o tempo ou a sua agenda. Posso instalar e atualizar aplicativos — sempre com a sua aprovação."
            }
            Item { width: 1; height: 6 }
            Repeater {
                model: wise.sugestoes
                delegate: Rectangle {
                    required property string modelData
                    width: Math.min(textoSugestao.implicitWidth + 28, parent.width)
                    height: 38; radius: 19
                    color: areaSugestao.containsMouse ? cores.destaque : cores.cartao
                    border { color: cores.borda; width: 1 }
                    Text { id: textoSugestao; anchors.centerIn: parent; text: modelData; color: cores.texto
                           font { family: janela.fonte; pixelSize: 14 } }
                    MouseArea { id: areaSugestao; anchors.fill: parent; hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor; onClicked: wise.enviar(modelData) }
                }
            }
        }

        ListView {
            id: lista
            anchors { fill: parent; leftMargin: 16; rightMargin: 16 }
            topMargin: 16; bottomMargin: 16
            spacing: 10
            clip: true
            model: wise.mensagens
            onCountChanged: positionViewAtEnd()
            delegate: Item {
                id: item
                required property var modelData
                required property int index
                property bool avaliando: false
                readonly property bool avaliavel: item.modelData.tipo === "wise" || item.modelData.tipo === "erro"
                width: lista.width
                height: item.modelData.tipo === "aprovacao" ? cartaoAprovacao.height
                      : conteudo.height + (avaliavel ? avaliacao.height + 4 : 0)

                // Ação que muda o computador (N2): o impacto e os botões de aprovar
                CartaoAprovacao {
                    id: cartaoAprovacao
                    visible: item.modelData.tipo === "aprovacao"
                    width: lista.width
                    dados: item.modelData.tipo === "aprovacao" ? item.modelData : ({})
                    onResponder: (aprovado) => wise.responderAprovacao(item.modelData.id, aprovado)
                }

                // Pedido da pessoa: balão azul à direita
                Rectangle {
                    id: conteudo
                    visible: item.modelData.tipo !== "aprovacao"
                    anchors.right: item.modelData.tipo === "pessoa" ? parent.right : undefined
                    anchors.left: item.modelData.tipo === "pessoa" ? undefined : parent.left
                    width: item.modelData.tipo === "atividade" ? linhaAtividade.width
                         : Math.min(textoMensagem.implicitWidth + 28, lista.width * (item.modelData.tipo === "pessoa" ? 0.82 : 1))
                    height: item.modelData.tipo === "atividade" ? 26 : textoMensagem.height + 20
                    radius: item.modelData.tipo === "atividade" ? 13 : janela.raio
                    gradient: item.modelData.tipo === "pessoa" && janela.futurista ? degradePessoa : null
                    color: item.modelData.tipo === "pessoa" ? cores.azul
                         : item.modelData.tipo === "atividade" ? "transparent"
                         : item.modelData.tipo === "erro" ? cores.fundoErro : cores.cartao
                    border { width: item.modelData.tipo === "wise" ? 1 : 0; color: cores.borda }

                    Text {
                        id: textoMensagem
                        visible: item.modelData.tipo !== "atividade"
                        x: 14; y: 10
                        width: Math.min(implicitWidth, lista.width * (item.modelData.tipo === "pessoa" ? 0.82 : 1) - 28)
                        wrapMode: Text.Wrap
                        textFormat: item.modelData.tipo === "wise" ? Text.MarkdownText : Text.PlainText
                        text: item.modelData.texto
                        color: item.modelData.tipo === "pessoa" ? "white"
                             : item.modelData.tipo === "erro" ? cores.erro
                             : item.modelData.tipo === "aviso" ? cores.secundario : cores.texto
                        font { family: janela.fonte; pixelSize: 14 }
                        lineHeight: 1.15
                        onLinkActivated: (link) => Qt.openUrlExternally(link)
                    }

                    // Atividade: o que o Wise consultou
                    Row {
                        id: linhaAtividade
                        visible: item.modelData.tipo === "atividade"
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 6
                        Text { text: item.modelData.ok ? "✓" : "!"; color: item.modelData.ok ? cores.sucesso : cores.aviso
                               font { family: janela.fonte; pixelSize: 13; weight: Font.Bold } }
                        Text { color: cores.secundario; font { family: janela.fonte; pixelSize: 13 }
                               text: (item.modelData.nivel === "N2" ? (item.modelData.ok ? "Fiz: " : "Não fiz: ")
                                      : (item.modelData.ok ? "Consultei: " : "Não consegui consultar: ")) + item.modelData.texto
                                     + (item.modelData.detalhe ? " (" + item.modelData.detalhe + ")" : "") }
                    }
                }

                // "Não ficou bom": a pessoa marca a resposta; vai para o diagnóstico (W17)
                Column {
                    id: avaliacao
                    visible: item.avaliavel
                    anchors { left: parent.left; top: conteudo.bottom; topMargin: 4 }
                    width: lista.width
                    spacing: 6
                    Text {
                        visible: !item.avaliando
                        text: item.modelData.avaliada ? "Obrigado. Registrei para melhorar o Wise." : "Não ficou bom"
                        color: cores.secundario
                        font { family: janela.fonte; pixelSize: 12; underline: !item.modelData.avaliada && areaNaoFicouBom.containsMouse }
                        MouseArea { id: areaNaoFicouBom; anchors.fill: parent; hoverEnabled: true
                                    enabled: !item.modelData.avaliada
                                    cursorShape: item.modelData.avaliada ? Qt.ArrowCursor : Qt.PointingHandCursor
                                    onClicked: item.avaliando = true }
                    }
                    Row {
                        visible: item.avaliando
                        spacing: 8
                        CampoTexto { id: campoProblema; width: lista.width - botaoRegistrar.width - botaoDesistir.width - 16
                                     dica: "O que deu errado? (opcional)" }
                        BotaoTexto { id: botaoRegistrar; texto: "Registrar"; anchors.verticalCenter: parent.verticalCenter
                                     onClicado: { wise.marcarProblema(item.index, campoProblema.texto); item.avaliando = false } }
                        BotaoTexto { id: botaoDesistir; texto: "Cancelar"; anchors.verticalCenter: parent.verticalCenter
                                     onClicado: item.avaliando = false }
                    }
                }
            }
            // Rodapé: a resposta enquanto é escrita. O texto que chega do modelo (aos pedaços) é mostrado
            // letra a letra num ritmo contínuo, com as últimas letras entrando aos poucos — como uma frase
            // sendo escrita, não como blocos que piscam. Quando a resposta termina e a tela a alcança, ela
            // entra na conversa no mesmo lugar (wise.concluirEscrita).
            footer: Item {
                id: escrita
                objectName: "escritaDaResposta"
                width: lista.width
                property real mostrado: 0
                readonly property string alvo: wise.parcial
                // Texto junto com a voz (ADR 082): com a resposta sendo falada, só aparece o que a voz já disse,
                // no ritmo dela (limite -1 = sem limite; ritmo 0 = o ritmo normal da escrita)
                readonly property int limite: wise.limiteDaVoz
                readonly property real ritmo: wise.ritmoDaVoz
                readonly property real teto: limite >= 0 ? Math.min(alvo.length, limite) : alvo.length
                readonly property bool escrevendo: alvo !== "" && (mostrado >= 1 || limite !== 0)
                height: (escrevendo ? balaoParcial.height + 10 : 0) + ((wise.ocupado || alvo !== "") && !escrevendo ? 34 : 0)
                onHeightChanged: lista.positionViewAtEnd()
                onAlvoChanged: {
                    if (alvo === "") mostrado = 0
                    else if (mostrado > alvo.length) mostrado = alvo.length
                }
                Timer {
                    interval: 30; repeat: true
                    running: escrita.alvo !== "" && janela.visible
                    onTriggered: {
                        var falta = escrita.teto - escrita.mostrado
                        if (falta > 0) {
                            // Com a voz: no ritmo dela (e alcança se ficou muito para trás). Sem voz: perto do fim do
                            // que chegou, devagar (0,7 letra por quadro ≈ 23 por segundo, o ritmo de uma IA local); com
                            // muito texto esperando, acelera para alcançar em ~1 s
                            var passo = escrita.ritmo > 0 ? Math.max(escrita.ritmo * 0.03, (falta - 60) * 0.05)
                                                          : Math.max(0.7, falta * 0.055)
                            escrita.mostrado = Math.min(escrita.teto, escrita.mostrado + passo)
                        } else if (wise.parcialCompleto && escrita.mostrado >= escrita.alvo.length) {
                            wise.concluirEscrita()
                        }
                    }
                }
                Rectangle {
                    id: balaoParcial
                    visible: escrita.escrevendo
                    anchors { left: parent.left; top: parent.top; topMargin: 10 }
                    width: Math.min(textoParcial.implicitWidth + 28, lista.width)
                    height: textoParcial.height + 20
                    radius: janela.raio
                    color: cores.cartao
                    border { width: 1; color: cores.borda }
                    Behavior on height { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
                    Text {
                        id: textoParcial
                        x: 14; y: 10
                        width: Math.min(implicitWidth, lista.width - 28)
                        wrapMode: Text.Wrap
                        textFormat: Text.StyledText
                        text: janela.comRastro(escrita.alvo, escrita.mostrado)
                        color: cores.texto
                        font { family: janela.fonte; pixelSize: 14 }
                        lineHeight: 1.15
                    }
                }
                Row {
                    visible: (wise.ocupado || escrita.alvo !== "") && !escrita.escrevendo
                    anchors { left: parent.left; bottom: parent.bottom }
                    spacing: 5
                    Repeater {
                        model: 3
                        delegate: Rectangle {
                            required property int index
                            width: 8; height: 8; radius: 4; color: cores.azul
                            SequentialAnimation on opacity {
                                running: wise.ocupado || escrita.alvo !== ""; loops: Animation.Infinite
                                PauseAnimation { duration: index * 160 }
                                NumberAnimation { from: 0.25; to: 1; duration: 320 }
                                NumberAnimation { from: 1; to: 0.25; duration: 320 }
                                PauseAnimation { duration: (2 - index) * 160 }
                            }
                        }
                    }
                }
            }
        }
    }
    Gradient {
        id: degradePessoa
        orientation: Gradient.Horizontal
        GradientStop { position: 0; color: cores.azul }
        GradientStop { position: 1; color: cores.aurora3 }
    }

    // ----------------------------------------------------------------- rodapé
    Rectangle {
        id: rodape
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        // Altura = texto + margens do campo (12 + 12) e do texto (10 + 10), até 6 linhas;
        // daí em diante o campo rola e acompanha o cursor
        height: Math.min(Math.max(campo.contentHeight + 46, 70), 180) + (avisoVoz.visible ? avisoVoz.height + 8 : 0)
        color: cores.cartao
        Rectangle { anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: cores.borda }

        // Voz: o que está acontecendo (ouvindo, entendendo, falando) e como parar
        Rectangle {
            id: avisoVoz
            readonly property var v: wise.vozEstado
            visible: v.ouvindo || v.transcrevendo || v.falando || (v.mensagem || "") !== ""
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14; topMargin: 8 }
            height: 34; radius: 17
            color: cores.destaque
            Row {
                anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                spacing: 8
                // Nível do microfone: cinco barras
                Row {
                    visible: avisoVoz.v.ouvindo
                    spacing: 3
                    anchors.verticalCenter: parent.verticalCenter
                    Repeater {
                        model: 5
                        Rectangle {
                            required property int index
                            width: 3; radius: 1.5; color: cores.azul
                            anchors.verticalCenter: parent.verticalCenter
                            height: 5 + 13 * Math.min(1, (avisoVoz.v.nivel || 0) * (0.6 + ((index * 37) % 5) / 6))
                            Behavior on height { NumberAnimation { duration: 110 } }
                        }
                    }
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    width: avisoVoz.width - 150; elide: Text.ElideRight
                    text: avisoVoz.v.ouvindo ? "Ouvindo… fale à vontade" : (avisoVoz.v.transcrevendo ? "Entendendo o que você disse…"
                        : (avisoVoz.v.falando ? "Falando" : (avisoVoz.v.mensagem || "")))
                    color: cores.noite; font { family: janela.fonte; pixelSize: 13; weight: Font.Medium }
                }
            }
            BotaoTexto {
                anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
                visivel: avisoVoz.v.ouvindo || avisoVoz.v.falando
                texto: avisoVoz.v.ouvindo ? "Pronto" : "Parar de falar"
                onClicado: avisoVoz.v.ouvindo ? wise.ouvir() : wise.calar()
            }
        }

        Rectangle {
            anchors { left: parent.left; right: botaoMicrofone.visible ? botaoMicrofone.left : botaoEnviar.left; bottom: parent.bottom
                      leftMargin: 14; rightMargin: 8; bottomMargin: 12 }
            height: Math.min(Math.max(campo.contentHeight + 22, 46), 156)
            radius: janela.raio
            color: cores.fundo
            border { color: campo.activeFocus ? cores.azul : cores.borda; width: campo.activeFocus ? 2 : 1 }
            Flickable {
                id: rolagem
                anchors { fill: parent; leftMargin: 12; rightMargin: 12; topMargin: 10; bottomMargin: 10 }
                contentHeight: campo.contentHeight
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                // Mantém a linha do cursor sempre à vista (nova linha, colar, setas)
                function mostrarCursor(r) {
                    if (contentY > r.y)
                        contentY = r.y
                    else if (contentY + height < r.y + r.height)
                        contentY = r.y + r.height - height
                }
                TextEdit {
                    id: campo
                    width: rolagem.width
                    wrapMode: TextEdit.Wrap
                    font { family: janela.fonte; pixelSize: 15 }
                    color: cores.texto
                    selectionColor: cores.destaque
                    selectedTextColor: cores.texto
                    focus: true
                    onCursorRectangleChanged: rolagem.mostrarCursor(cursorRectangle)
                    Keys.onReturnPressed: (evento) => {
                        if (evento.modifiers & Qt.ShiftModifier) { evento.accepted = false; return }
                        janela.enviar()
                    }
                    Keys.onEnterPressed: janela.enviar()
                    Keys.onEscapePressed: if (wise.ocupado) wise.cancelar(); else janela.hide()
                }
            }
            Text {
                visible: campo.text.length === 0
                anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                text: "Pergunte ao Wise…"
                color: cores.secundario; font { family: janela.fonte; pixelSize: 15 }
            }
        }
        // Microfone: clicar para falar; clicar de novo (ou parar de falar) manda o pedido
        Rectangle {
            id: botaoMicrofone
            visible: wise.podeOuvir
            anchors { right: botaoEnviar.left; rightMargin: 8; bottom: parent.bottom; bottomMargin: 14 }
            width: 42; height: 42; radius: 21
            readonly property bool ativo: wise.vozEstado.ouvindo
            color: ativo ? cores.azul : (areaMicrofone.containsMouse ? cores.destaque : cores.fundo)
            border { color: ativo ? cores.azul : cores.borda; width: 1 }
            opacity: wise.ocupado ? 0.4 : 1
            // Anel que acompanha a voz
            Rectangle {
                visible: botaoMicrofone.ativo
                anchors.centerIn: parent
                width: parent.width + 6 + 14 * (wise.vozEstado.nivel || 0); height: width; radius: width / 2
                color: "transparent"; border { color: cores.azul; width: 2 }
                opacity: 0.35
                Behavior on width { NumberAnimation { duration: 110 } }
            }
            // Desenho do microfone
            Item {
                anchors.centerIn: parent
                width: 18; height: 22
                readonly property color cor: botaoMicrofone.ativo ? "white" : cores.noite
                Rectangle { x: 5.5; y: 0; width: 7; height: 13; radius: 3.5; color: parent.cor }
                Rectangle { x: 2; y: 6; width: 14; height: 11; radius: 7; color: "transparent"; border { color: parent.cor; width: 1.6 }
                            Rectangle { x: -1; y: -1; width: 16; height: 6; color: botaoMicrofone.color } }
                Rectangle { x: 8.2; y: 16.5; width: 1.6; height: 4; color: parent.cor }
                Rectangle { x: 5; y: 20; width: 8; height: 1.6; radius: 0.8; color: parent.cor }
            }
            MouseArea { id: areaMicrofone; anchors.fill: parent; hoverEnabled: true; enabled: !wise.ocupado
                        cursorShape: Qt.PointingHandCursor; onClicked: wise.ouvir() }
        }
        BotaoPrincipal {
            id: botaoEnviar
            anchors { right: parent.right; rightMargin: 14; bottom: parent.bottom; bottomMargin: 14 }
            texto: wise.ocupado ? "Cancelar" : "Enviar"
            perigo: wise.ocupado
            habilitado: wise.ocupado || campo.text.trim().length > 0
            onClicado: wise.ocupado ? wise.cancelar() : janela.enviar()
        }
    }

    // Fecha a lista aberta ao clicar fora
    MouseArea { anchors.fill: parent; z: 4; visible: janela.listaAberta !== null; onClicked: janela.listaAberta = null }

    function enviar() {
        if (wise.ocupado || campo.text.trim().length === 0)
            return
        wise.enviar(campo.text)
        campo.text = ""
        rolagem.contentY = 0
    }

    // ------------------------------------------------------------ componentes
    // Cartão de aprovação: o que vai mudar no computador, Aprovar / Agora não,
    // e depois o andamento e o resultado. Nada acontece sem o clique em Aprovar.
    component CartaoAprovacao: Rectangle {
        id: ca
        property var dados: ({})
        signal responder(bool aprovado)
        readonly property string estado: dados.estado || ""
        height: colunaCa.height + 28
        radius: 16
        color: cores.cartao
        border { width: 2; color: estado === "pendente" ? cores.aviso
                                 : estado === "falhou" ? cores.erro
                                 : estado === "feito" ? cores.sucesso : cores.borda }
        Column {
            id: colunaCa
            x: 16; y: 14
            width: ca.width - 32
            spacing: 8
            Text {
                text: ca.estado === "pendente" ? "Posso fazer isto?"
                    : ca.estado === "fazendo" ? "Fazendo…"
                    : ca.estado === "feito" ? "Feito"
                    : ca.estado === "falhou" ? "Não deu certo"
                    : "Não fiz"
                color: ca.estado === "falhou" ? cores.erro : cores.noite
                font { family: janela.fonteTitulo; pixelSize: 15; weight: Font.Bold }
            }
            Text { width: parent.width; wrapMode: Text.Wrap; text: ca.dados.texto || ""; color: cores.texto
                   font { family: janela.fonte; pixelSize: 14; weight: Font.Medium } }
            Repeater {
                model: ca.dados.detalhes || []
                delegate: Text {
                    required property string modelData
                    width: colunaCa.width; wrapMode: Text.Wrap; text: "• " + modelData; color: cores.secundario
                    font { family: janela.fonte; pixelSize: 13 }
                }
            }
            // Andamento
            Rectangle {
                visible: ca.estado === "fazendo" && (ca.dados.fracao || 0) >= 0
                width: parent.width; height: 6; radius: 3; color: cores.destaque
                Rectangle { width: parent.width * Math.max(0, Math.min(ca.dados.fracao || 0, 1)); height: parent.height
                            radius: 3; color: cores.azul }
            }
            Text { visible: (ca.dados.mensagem || "") !== "" && ca.estado !== "pendente"
                   width: parent.width; wrapMode: Text.Wrap; text: ca.dados.mensagem || ""
                   color: ca.estado === "falhou" ? cores.erro : cores.secundario
                   font { family: janela.fonte; pixelSize: 13 } }
            Row {
                visible: ca.estado === "pendente"
                spacing: 8
                BotaoPrincipal { texto: "Aprovar"; onClicado: ca.responder(true) }
                Rectangle {
                    width: rotuloNao.implicitWidth + 32; height: 42; radius: 12
                    color: areaNao.containsMouse ? cores.destaque : cores.cartao
                    border { width: 1; color: cores.borda }
                    Text { id: rotuloNao; anchors.centerIn: parent; text: "Agora não"; color: cores.noite
                           font { family: janela.fonte; pixelSize: 14; weight: Font.DemiBold } }
                    MouseArea { id: areaNao; anchors.fill: parent; hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor; onClicked: ca.responder(false) }
                }
            }
        }
    }

    // Lista de escolha (motor, modelo): mostra o valor atual e abre as opções logo abaixo
    component Lista: Rectangle {
        id: li
        property string rotulo
        property string valor
        property var opcoes: []          // [{id, nome, detalhe}]
        property string atual
        property string rodape: ""
        property bool ativa: true
        readonly property bool aberta: janela.listaAberta === li
        signal escolhida(string id)
        signal rodapeClicado()
        height: 38; radius: janela.futurista ? 19 : 10
        color: areaLi.containsMouse && ativa ? cores.destaque : cores.fundo
        border { color: aberta ? cores.azul : cores.borda; width: 1 }
        opacity: ativa ? 1 : 0.55
        Text { id: rotuloLi; anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
               text: li.rotulo; color: cores.secundario; font { family: janela.fonte; pixelSize: 11 } }
        Text { anchors { left: rotuloLi.right; leftMargin: 8; right: setaLi.left; rightMargin: 4; verticalCenter: parent.verticalCenter }
               text: li.valor; elide: Text.ElideRight; color: cores.texto
               font { family: janela.fonte; pixelSize: 13; weight: Font.DemiBold } }
        Text { id: setaLi; anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
               text: "⌄"; color: cores.secundario; font { family: janela.fonte; pixelSize: 14 }
               rotation: li.aberta ? 180 : 0; Behavior on rotation { NumberAnimation { duration: 120 } } }
        MouseArea { id: areaLi; anchors.fill: parent; hoverEnabled: true; enabled: li.ativa; cursorShape: Qt.PointingHandCursor
                    onClicked: janela.listaAberta = li.aberta ? null : li }
        Rectangle {
            visible: li.aberta
            y: li.height + 6; width: Math.max(li.width, 230); z: 20
            x: Math.min(0, janela.width - 14 - li.mapToItem(null, 0, 0).x - width)
            height: Math.min(colunaLi.height + 12, 320); radius: 14
            color: cores.cartao; border { color: cores.borda; width: 1 }
            // Sombra simples
            Rectangle { anchors { fill: parent; margins: -1; topMargin: 2 } z: -1; radius: 15; color: "#000000"; opacity: janela.escuro ? 0.35 : 0.10 }
            Flickable {
                anchors { fill: parent; margins: 6 }
                contentHeight: colunaLi.height; clip: true; boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: colunaLi
                    width: parent.width
                    Text { visible: li.opcoes.length === 0; text: "Nada para escolher ainda"; color: cores.secundario; padding: 10
                           font { family: janela.fonte; pixelSize: 13 } }
                    Repeater {
                        model: li.opcoes
                        delegate: Rectangle {
                            required property var modelData
                            width: colunaLi.width; height: modelData.detalhe ? 48 : 36; radius: 9
                            color: areaOpcao.containsMouse ? cores.destaque : "transparent"
                            Column {
                                anchors { left: parent.left; leftMargin: 10; right: marca.left; rightMargin: 6; verticalCenter: parent.verticalCenter }
                                Text { width: parent.width; text: modelData.nome; elide: Text.ElideRight; color: cores.texto
                                       font { family: janela.fonte; pixelSize: 13; weight: modelData.id === li.atual ? Font.DemiBold : Font.Normal } }
                                Text { visible: !!modelData.detalhe; width: parent.width; text: modelData.detalhe || ""; elide: Text.ElideRight
                                       color: cores.aviso; font { family: janela.fonte; pixelSize: 11 } }
                            }
                            Text { id: marca; anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                                   text: modelData.id === li.atual ? "✓" : ""; color: cores.azul; font { family: janela.fonte; pixelSize: 14; weight: Font.Bold } }
                            MouseArea { id: areaOpcao; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                        onClicked: { janela.listaAberta = null; if (modelData.id !== li.atual) li.escolhida(modelData.id) } }
                        }
                    }
                    Rectangle { visible: li.rodape !== ""; width: colunaLi.width; height: 1; color: cores.borda }
                    Rectangle {
                        visible: li.rodape !== ""
                        width: colunaLi.width; height: 36; radius: 9
                        color: areaRodape.containsMouse ? cores.destaque : "transparent"
                        Text { anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                               text: li.rodape; color: cores.azul; font { family: janela.fonte; pixelSize: 13; weight: Font.Medium } }
                        MouseArea { id: areaRodape; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: { janela.listaAberta = null; li.rodapeClicado() } }
                    }
                }
            }
        }
    }

    component CampoTexto: Rectangle {
        id: ct
        property string dica
        property bool senha: false
        readonly property string texto: entradaCt.text
        function limpar() { entradaCt.text = "" }
        height: 44; radius: 12
        color: cores.cartao
        border { color: entradaCt.activeFocus ? cores.azul : cores.borda; width: entradaCt.activeFocus ? 2 : 1 }
        TextInput {
            id: entradaCt
            anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
            verticalAlignment: TextInput.AlignVCenter
            echoMode: ct.senha ? TextInput.Password : TextInput.Normal
            font { family: janela.fonte; pixelSize: 14 }
            color: cores.texto
            clip: true
        }
        Text {
            visible: entradaCt.text.length === 0
            anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
            text: ct.dica; color: cores.secundario; font { family: janela.fonte; pixelSize: 14 }
        }
    }

    component BotaoTexto: Rectangle {
        id: bt
        property string texto
        property bool habilitado: true
        property bool visivel: true
        signal clicado()
        visible: visivel
        width: rotuloBt.implicitWidth + 20; height: 32; radius: 16
        color: areaBt.containsMouse && habilitado ? cores.destaque : "transparent"
        opacity: habilitado ? 1 : 0.4
        Text { id: rotuloBt; anchors.centerIn: parent; text: bt.texto; color: cores.noite
               font { family: janela.fonte; pixelSize: 13; weight: Font.Medium } }
        MouseArea { id: areaBt; anchors.fill: parent; hoverEnabled: true; enabled: bt.habilitado
                    cursorShape: Qt.PointingHandCursor; onClicked: bt.clicado() }
    }

    component BotaoPrincipal: Rectangle {
        id: bp
        property string texto
        property bool habilitado: true
        property bool perigo: false
        signal clicado()
        width: Math.max(rotuloBp.implicitWidth + 32, 92); height: 42; radius: janela.futurista ? 21 : 12
        gradient: habilitado && !perigo && janela.futurista && !areaBp.pressed ? degradeBotao : null
        color: !habilitado ? cores.borda
             : perigo ? (areaBp.containsMouse ? "#C64541" : cores.erro)
             : (areaBp.pressed ? cores.noite : areaBp.containsMouse ? cores.azulEscuro : cores.azul)
        Text { id: rotuloBp; anchors.centerIn: parent; text: bp.texto; color: "white"
               font { family: janela.fonte; pixelSize: 14; weight: Font.DemiBold } }
        MouseArea { id: areaBp; anchors.fill: parent; hoverEnabled: true; enabled: bp.habilitado
                    cursorShape: Qt.PointingHandCursor; onClicked: bp.clicado() }
    }

    Gradient {
        id: degradeBotao
        orientation: Gradient.Horizontal
        GradientStop { position: 0; color: cores.aurora1 }
        GradientStop { position: 0.5; color: cores.azul }
        GradientStop { position: 1; color: cores.aurora3 }
    }

    component Secao: Text {
        property string titulo
        text: titulo
        topPadding: 8
        color: cores.noite
        font { family: janela.fonteTitulo; pixelSize: 15; weight: Font.Bold }
    }

    component Opcao: Rectangle {
        id: op
        property string titulo
        property string descricao
        property bool marcado: false
        signal escolhido()
        width: parent ? parent.width : 300
        height: colunaOp.height + 22; radius: 14
        color: marcado || areaOp.containsMouse ? cores.destaque : cores.cartao
        border { color: marcado ? cores.azul : cores.borda; width: marcado ? 2 : 1 }
        Rectangle {
            id: bolinha
            x: 14; anchors.verticalCenter: parent.verticalCenter
            width: 18; height: 18; radius: 9
            color: "transparent"; border { color: op.marcado ? cores.azul : cores.secundario; width: 2 }
            Rectangle { anchors.centerIn: parent; width: 8; height: 8; radius: 4; color: cores.azul; visible: op.marcado }
        }
        Column {
            id: colunaOp
            anchors { left: bolinha.right; leftMargin: 12; right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
            spacing: 2
            Text { text: op.titulo; color: cores.texto; font { family: janela.fonte; pixelSize: 14; weight: Font.DemiBold } }
            Text { width: parent.width; wrapMode: Text.WordWrap; text: op.descricao; color: cores.secundario
                   font { family: janela.fonte; pixelSize: 12 } }
        }
        MouseArea { id: areaOp; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                    onClicked: op.escolhido() }
    }

    component Interruptor: Rectangle {
        id: it
        property string titulo
        property string descricao
        property bool ligado: false
        signal alternado(bool valor)
        width: parent ? parent.width : 300
        height: colunaIt.height + 22; radius: 14
        color: cores.cartao; border { color: cores.borda; width: 1 }
        Column {
            id: colunaIt
            anchors { left: parent.left; leftMargin: 14; right: chave.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 2
            Text { text: it.titulo; color: cores.texto; font { family: janela.fonte; pixelSize: 14; weight: Font.DemiBold } }
            Text { width: parent.width; wrapMode: Text.WordWrap; text: it.descricao; color: cores.secundario
                   font { family: janela.fonte; pixelSize: 12 } }
        }
        Rectangle {
            id: chave
            anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
            width: 44; height: 26; radius: 13
            color: it.ligado ? cores.azul : cores.borda
            Rectangle { width: 20; height: 20; radius: 10; color: "white"; y: 3
                        x: it.ligado ? parent.width - width - 3 : 3
                        Behavior on x { NumberAnimation { duration: 120 } } }
        }
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: it.alternado(!it.ligado) }
    }

    component Estado: Row {
        property bool pronto: false
        property string texto
        visible: texto !== ""
        spacing: 8
        Rectangle { width: 8; height: 8; radius: 4; anchors.verticalCenter: parent.verticalCenter
                    color: parent.pronto ? cores.sucesso : cores.aviso }
        Text { text: parent.texto; color: cores.secundario; wrapMode: Text.WordWrap
               width: Math.min(implicitWidth, colunaConfig.width - 20)
               font { family: janela.fonte; pixelSize: 13 } }
    }
}
