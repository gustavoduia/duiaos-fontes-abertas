"""Voz do Wise: falar e ouvir pelo duiaos-voz do sistema (ADRs 063 e 065 do DuiaOS).

O duiaos-voz é um programa separado (GPL-3, com o motor de voz). O Wise mantém um só processo dele aberto
(`duiaos-voz servir`), com os modelos carregados uma vez: manda pedidos em linhas JSON e lê os eventos.
Nada de áudio passa pelo Wise. Se o processo cair, ele é aberto de novo no pedido seguinte.
"""
import itertools
import json
import os
import re
import shutil
import subprocess
import threading

COMANDO = os.environ.get("DUIAOS_VOZ", "duiaos-voz")
# Trechos para a voz (ADR 079 do DuiaOS), como fazem os assistentes de voz: o primeiro sai já na primeira vírgula
# (ou "Claro!"), para a fala começar logo; os outros, a cada frase completa; uma frase muito longa é cortada
# numa vírgula. Fim de frase = pontuação seguida de espaço (não corta "1,5", "19:30" nem "1.430").
_FORTE = re.compile(r"[.!?…]+[\"'”)]?(?=\s)|\n+")
_FRACO = re.compile(r"[,;:—–](?=\s)")
_ABREVIACOES = re.compile(r"(?:^|\s)(?:\d+|[A-Za-zÀ-ÿ]|sr|sra|dr|dra|ex|etc|obs|av|n[ºo]|pág|tel)\.$", re.I)
MINIMO_FRASE = 8                # letras de uma frase do meio da resposta (menos que isso junta com a próxima)
MINIMO_PRIMEIRO = 2             # o primeiro trecho pode ser curto ("Oi!", "Claro!")
PRIMEIRA_VIRGULA = 18           # o primeiro trecho corta na vírgula a partir deste tamanho
VIRGULA_INICIO = 28             # até INICIO letras da resposta, os trechos seguintes cortam na vírgula a partir daqui
INICIO = 160
VIRGULA_LONGA = 110             # depois: só frase longa corta na vírgula
_numeros = itertools.count(1)


def disponivel():
    return shutil.which(COMANDO) is not None


def estado():
    """O que o duiaos-voz tem instalado (dict), ou {} sem ele."""
    if not disponivel():
        return {}
    try:
        saida = subprocess.run([COMANDO, "estado"], capture_output=True, text=True, timeout=20).stdout
        dados = json.loads(saida.strip().splitlines()[-1])
        return dados if isinstance(dados, dict) else {}
    except (OSError, subprocess.SubprocessError, ValueError, IndexError):
        return {}


def trechos_prontos(texto, ja_falados):
    """Trechos de um texto que ainda está sendo escrito, prontos para a voz, a partir do que já foi falado.
    Devolve (trechos novos, quantos caracteres ficam marcados como falados)."""
    resto = texto[ja_falados:]
    cortes = sorted([(m.end(), True) for m in _FORTE.finditer(resto)] + [(m.end(), False) for m in _FRACO.finditer(resto)])
    trechos, posicao = [], 0
    for fim, forte in cortes:
        if fim <= posicao:
            continue
        trecho = " ".join(resto[posicao:fim].split())
        comeco = ja_falados + posicao
        primeiro = comeco == 0
        if forte:
            if _ABREVIACOES.search(trecho) or len(trecho) < (MINIMO_PRIMEIRO if primeiro else MINIMO_FRASE):
                continue
        elif len(trecho) < (PRIMEIRA_VIRGULA if primeiro else VIRGULA_INICIO if comeco < INICIO else VIRGULA_LONGA):
            continue
        trechos.append(trecho)
        posicao = fim
    while posicao < len(resto) and resto[posicao].isspace():
        posicao += 1
    return trechos, ja_falados + posicao


def frases_prontas(texto, ja_faladas):
    """Nome antigo de trechos_prontos."""
    return trechos_prontos(texto, ja_faladas)


class Servico:
    """O processo `duiaos-voz servir`. Os eventos com "id" vão para quem fez o pedido; os outros (e todos,
    para o diagnóstico) vão para `ao_registro`."""

    def __init__(self, ao_registro=None):
        self._ao_registro = ao_registro or (lambda _evento: None)
        self._processo = None
        self._donos = {}                          # id → função que recebe o evento
        self._trava = threading.Lock()

    def _abrir(self):
        if self._processo is not None and self._processo.poll() is None:
            return self._processo
        self._processo = subprocess.Popen([COMANDO, "servir"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE, text=True, bufsize=1)
        threading.Thread(target=self._ler, args=(self._processo,), daemon=True).start()
        threading.Thread(target=self._ler_erros, args=(self._processo,), daemon=True).start()
        return self._processo

    def _ler(self, processo):
        for linha in processo.stdout:
            try:
                evento = json.loads(linha)
            except ValueError:
                continue
            if not isinstance(evento, dict):
                continue
            if evento.get("evento") != "nivel":
                self._ao_registro(evento)
            dono = self._donos.get(str(evento.get("id") or ""))
            if dono is not None:
                dono(evento)
        # O processo acabou: quem esperava resposta recebe um erro
        for ident, dono in list(self._donos.items()):
            dono({"evento": "erro", "id": ident, "mensagem": "a voz do sistema parou; tente de novo", "fim": True})
        self._donos.clear()
        self._ao_registro({"evento": "parou", "codigo": processo.poll()})

    def _ler_erros(self, processo):
        for linha in processo.stderr:
            linha = linha.strip()
            if linha:
                self._ao_registro({"evento": "saida_de_erro", "linha": linha[:300]})

    def enviar(self, **pedido):
        with self._trava:
            try:
                processo = self._abrir()
                processo.stdin.write(json.dumps(pedido, ensure_ascii=False) + "\n")
                processo.stdin.flush()
                return True
            except (OSError, ValueError) as erro:
                self._ao_registro({"evento": "erro", "mensagem": f"não consegui falar com a voz do sistema: {erro}"})
                return False

    def dono(self, ident, funcao):
        if funcao is None:
            self._donos.pop(ident, None)
        else:
            self._donos[ident] = funcao

    def encerrar(self):
        processo, self._processo = self._processo, None
        if processo is not None:
            try:
                processo.stdin.close()
                processo.wait(timeout=3)
            except (OSError, ValueError, subprocess.TimeoutExpired):
                processo.kill()


_servico = None


def servico(ao_registro=None):
    """O processo da voz, aberto uma vez para o Wise inteiro."""
    global _servico
    if _servico is None:
        _servico = Servico(ao_registro)
    elif ao_registro is not None:
        _servico._ao_registro = ao_registro
    return _servico


def preparar(voz="dora", ouvir=False):
    """Carrega os modelos antes do primeiro uso (a primeira fala sai sem esperar)."""
    if disponivel():
        servico().enviar(cmd="preparar", voz=voz, ouvir=bool(ouvir))


class Fala:
    """Uma fala em andamento: as frases entram com dizer() e saem na ordem, sem intervalo."""

    def __init__(self, voz="dora", velocidade=1.0, ao_terminar=None, ao_evento=None):
        self.id = f"f{next(_numeros)}"
        self._voz, self._velocidade = voz, float(velocidade)
        self._ao_terminar = ao_terminar or (lambda: None)
        self._ao_evento = ao_evento or (lambda _dados: None)
        self._terminou = False
        self._servico = servico()
        self._servico.dono(self.id, self._evento)

    def _evento(self, evento):
        self._ao_evento(evento)
        if evento.get("evento") in ("fim_fala",) or (evento.get("evento") == "erro" and evento.get("fim")):
            self._acabar()

    def _acabar(self):
        if not self._terminou:
            self._terminou = True
            self._servico.dono(self.id, None)
            self._ao_terminar()

    def dizer(self, frase):
        frase = " ".join(str(frase).split())
        if frase and not self._terminou:
            if not self._servico.enviar(cmd="falar", id=self.id, texto=frase, voz=self._voz, velocidade=self._velocidade):
                self._acabar()

    def concluir(self):
        """Não há mais frases: termina de falar o que já entrou."""
        if not self._terminou and not self._servico.enviar(cmd="concluir", id=self.id):
            self._acabar()

    def calar(self):
        """Para na hora."""
        self._servico.enviar(cmd="calar")
        self._acabar()


class Escuta:
    """Ouve o microfone até a pessoa terminar de falar. ao_evento recebe {"nivel"}, {"transcrevendo"},
    e no fim {"texto", "fim", ...estatísticas} (com "motivo" quando não houve texto) ou {"erro", "fim"}."""

    def __init__(self, ao_evento, segundos=30, salvar_audio=""):
        self.id = f"o{next(_numeros)}"
        self._ao_evento = ao_evento
        self._servico = servico()
        self._servico.dono(self.id, self._evento)
        pedido = {"cmd": "ouvir", "id": self.id, "segundos": segundos}
        if salvar_audio:
            pedido["salvar_audio"] = str(salvar_audio)      # a fala gravada, para a nuvem (ADR 081)
        if not self._servico.enviar(**pedido):
            self._servico.dono(self.id, None)
            raise OSError("a voz do sistema não abriu")

    def _evento(self, evento):
        tipo = evento.get("evento")
        dados = {k: v for k, v in evento.items() if k not in ("evento", "id")}
        if tipo == "nivel":
            self._ao_evento({"nivel": dados.get("nivel", 0.0), "falando": dados.get("falando", False)})
        elif tipo == "ouvindo":
            self._ao_evento({"ouvindo": True})
        elif tipo == "transcrevendo":
            self._ao_evento({"transcrevendo": True})
        elif tipo == "audio" and dados.get("arquivo"):
            self._ao_evento({"audio": dados["arquivo"], "fala_s": dados.get("fala_s")})
        elif tipo == "texto":
            self._servico.dono(self.id, None)
            self._ao_evento({**dados, "fim": True})
        elif tipo == "erro":
            self._servico.dono(self.id, None)
            self._ao_evento({**dados, "erro": dados.pop("mensagem", "erro na escuta"), "fim": True})

    def parar(self):
        """A pessoa clicou de novo: para de ouvir e transcreve o que já ouviu."""
        self._servico.enviar(cmd="parar_ouvir")

    def cancelar(self):
        self._servico.enviar(cmd="cancelar_ouvir")


def baixar(item, ao_andar):
    """Baixa uma voz ou o reconhecimento; ao_andar recebe {"fracao"} e, no fim, {"pronto"} ou {"erro"}."""
    processo = subprocess.Popen([COMANDO, "baixar", item], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    ultimo = {}
    for linha in processo.stdout:
        try:
            ultimo = json.loads(linha)
        except ValueError:
            continue
        ao_andar(ultimo)
    processo.wait()
    return bool(ultimo.get("pronto"))
