"""Volume do microfone ajustado sozinho (ADR 081 do DuiaOS), como fazem os programas de chamada de vídeo.

Relatórios do Dell: o som chegava estourado (pico acima de 0 dB e nível médio de −7 dB) — a fala distorcida vira
outra palavra ("agenda" → "dieta") e o ruído alto atrasa o fim da escuta. Depois de cada escuta, com as medidas
que o duiaos-voz devolve, o Wise abaixa o volume de entrada do sistema quando estoura e sobe quando está baixo
demais. Usa o wpctl (PipeWire); o novo volume fica guardado pelo próprio sistema.
"""
import re
import shutil
import subprocess

FONTE = "@DEFAULT_AUDIO_SOURCE@"
MINIMO, MAXIMO = 0.2, 1.0


def _rodar(comando):
    return subprocess.run(comando, capture_output=True, text=True, timeout=5, check=False)


def volume(rodar=_rodar):
    if not shutil.which("wpctl"):
        return None
    saida = rodar(["wpctl", "get-volume", FONTE]).stdout or ""
    achado = re.search(r"Volume:\s*([0-9.]+)", saida)
    return float(achado.group(1)) if achado else None


def novo_volume(atual, estatisticas):
    """O volume que o microfone deveria ter, ou None se está bom. Estourado: 70% do atual; baixo: 140%."""
    if atual is None or estatisticas.get("mudo") or estatisticas.get("pico_db") is None:
        return None
    pico, clipado = float(estatisticas["pico_db"]), float(estatisticas.get("clipado") or 0.0)
    if pico >= -0.5 or clipado > 0.001:
        novo = max(MINIMO, round(atual * 0.7, 2))
    elif pico < -32 and float(estatisticas.get("fala_s") or 0) > 0.3:
        novo = min(MAXIMO, round(atual * 1.4, 2))
    else:
        return None
    return novo if abs(novo - atual) >= 0.02 else None


def ajustar(estatisticas, rodar=_rodar):
    """Ajusta o volume de entrada se preciso. Devolve (antes, depois) ou None."""
    atual = volume(rodar)
    novo = novo_volume(atual, estatisticas)
    if novo is None:
        return None
    rodar(["wpctl", "set-volume", FONTE, f"{novo:.2f}"])
    return atual, novo
