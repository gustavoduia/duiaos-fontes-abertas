// DuiaOS — Mail Box: apresentação da primeira abertura (ADR 075).
// O envelope sobe, a aba se fecha e chega o aviso; depois as boas-vindas e as perguntas de primeiro acesso:
// programa de e-mail padrão e trazer as contas de outro programa (Thunderbird). Termina adicionando a conta.
// "Pular" vale em qualquer passo.
import QtQuick
import DuiaOS

Rectangle {
    id: apresentacao
    property int passo: 0                       // 0 marca · 1 boas-vindas · 2 padrão · 3 importar · 4 pronto
    readonly property int ultimo: 4
    property bool padrao: false
    property var paraImportar: []
    signal concluida(var contaImportada)        // null, ou {nome, email, config} para o wizard já preenchido

    color: Tema.escuro ? "#0A0E1C" : "#F4F6FC"

    function avancar() { if (passo < ultimo) passo++; else concluir(null) }
    function concluir(conta) { caixa.concluirApresentacao(); concluida(conta) }
    Component.onCompleted: { padrao = caixa.ehPadrao(); paraImportar = caixa.contasParaImportar() }

    Repeater {
        model: [{ c: "#22D3EE", x: -0.15, y: -0.25 }, { c: "#3D5BFF", x: 0.55, y: 0.45 }, { c: "#7C3AED", x: 0.75, y: -0.3 }]
        delegate: Canvas {
            required property var modelData
            required property int index
            width: apresentacao.width * 0.8; height: width
            x: apresentacao.width * modelData.x; y: apresentacao.height * modelData.y
            opacity: Tema.escuro ? 0.30 : 0.22
            onWidthChanged: requestPaint()
            onPaint: {
                var c = getContext("2d"); c.reset()
                var g = c.createRadialGradient(width / 2, height / 2, 0, width / 2, height / 2, width / 2)
                g.addColorStop(0, modelData.c); g.addColorStop(1, "transparent")
                c.fillStyle = g; c.fillRect(0, 0, width, height)
            }
            SequentialAnimation on scale {
                loops: Animation.Infinite
                NumberAnimation { from: 1; to: 1.12; duration: 5200 + index * 900; easing.type: Easing.InOutSine }
                NumberAnimation { from: 1.12; to: 1; duration: 5200 + index * 900; easing.type: Easing.InOutSine }
            }
        }
    }
    MouseArea { anchors.fill: parent }

    // ------------------------------------------------------------ passo 0: a marca chegando
    Item {
        anchors.fill: parent
        visible: apresentacao.passo === 0
        MarcaMailBox {
            id: marcaGrande
            anchors { horizontalCenter: parent.horizontalCenter; verticalCenter: parent.verticalCenter; verticalCenterOffset: -40 }
            tamanho: 156
            envelope: 0; aba: 0; ponto: 0
            scale: 0.6; opacity: 0
        }
        Text {
            id: nome
            anchors { horizontalCenter: parent.horizontalCenter; top: marcaGrande.bottom; topMargin: 24 }
            text: "Mail Box"; opacity: 0
            color: Tema.texto
            font { family: Tema.fonteTitulo; pixelSize: 42; weight: Font.Bold; letterSpacing: 1 }
        }
        Text {
            id: frase
            anchors { horizontalCenter: parent.horizontalCenter; top: nome.bottom; topMargin: 6 }
            text: "O e-mail do DuiaOS"; opacity: 0
            color: Tema.textoSecundario
            font { family: Tema.fonteTexto; pixelSize: 16 }
        }
        SequentialAnimation {
            running: apresentacao.passo === 0
            PauseAnimation { duration: 200 }
            ParallelAnimation {
                NumberAnimation { target: marcaGrande; property: "opacity"; to: 1; duration: 350 }
                NumberAnimation { target: marcaGrande; property: "scale"; to: 1; duration: 700; easing.type: Easing.OutBack }
            }
            NumberAnimation { target: marcaGrande; property: "envelope"; to: 1; duration: 550; easing.type: Easing.OutCubic }
            NumberAnimation { target: marcaGrande; property: "aba"; to: 1; duration: 450; easing.type: Easing.InOutCubic }
            ParallelAnimation {
                NumberAnimation { target: marcaGrande; property: "ponto"; to: 1; duration: 420; easing.type: Easing.OutBack; easing.overshoot: 3 }
                NumberAnimation { target: nome; property: "opacity"; to: 1; duration: 500 }
                NumberAnimation { target: nome; property: "anchors.topMargin"; from: 40; to: 24; duration: 600; easing.type: Easing.OutCubic }
            }
            NumberAnimation { target: frase; property: "opacity"; to: 1; duration: 450 }
            PauseAnimation { duration: 1100 }
            ScriptAction { script: apresentacao.passo = 1 }
        }
        MouseArea { anchors.fill: parent; onClicked: apresentacao.passo = 1 }
    }

    // ------------------------------------------------------------ passos 1 a 4
    Rectangle {
        id: cartao
        visible: apresentacao.passo > 0
        anchors.centerIn: parent
        width: Math.min(parent.width - 48, 620)
        height: Math.min(parent.height - 48, conteudo.implicitHeight + 200)
        radius: 22
        color: Tema.escuro ? Qt.rgba(0.08, 0.10, 0.18, 0.92) : Qt.rgba(1, 1, 1, 0.94)
        border { width: 1; color: Tema.borda }

        MarcaMailBox { id: marcaCartao; anchors { left: parent.left; top: parent.top; margins: 26 } tamanho: 34 }
        Text {
            anchors { verticalCenter: marcaCartao.verticalCenter; left: marcaCartao.right; leftMargin: 10 }
            text: "Mail Box"; color: Tema.texto; font { family: Tema.fonteTitulo; pixelSize: 18; weight: Font.Bold }
        }
        Text {
            visible: apresentacao.passo < apresentacao.ultimo
            anchors { verticalCenter: marcaCartao.verticalCenter; right: parent.right; rightMargin: 26 }
            text: "Pular"; color: Tema.textoSecundario
            font { family: Tema.fonteTexto; pixelSize: 13; underline: areaPular.containsMouse }
            MouseArea { id: areaPular; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: apresentacao.concluir(null) }
        }

        Column {
            id: conteudo
            anchors { left: parent.left; right: parent.right; top: marcaCartao.bottom; margins: 34; topMargin: 26 }
            spacing: 18

            Column {
                visible: apresentacao.passo === 1
                width: parent.width; spacing: 18
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: "Bem-vindo ao Mail Box"; font.pixelSize: 28 }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: "Todos os seus e-mails num lugar só, com a cara do DuiaOS." }
                Repeater {
                    model: [{ i: "usuarios", t: "Todas as contas juntas", d: "Gmail, Outlook, iCloud, Yahoo, UOL, Terra ou o e-mail da sua empresa: uma Entrada só, ou cada conta separada." },
                            { i: "escudo", t: "Seguro desde o começo", d: "Imagens de fora ficam bloqueadas até você permitir, links suspeitos são avisados e as senhas ficam no cofre do sistema." },
                            { i: "sino", t: "Avisa sem incomodar", d: "As mensagens novas aparecem nas notificações do DuiaOS, e os links de e-mail abrem direto aqui." }]
                    delegate: Row {
                        required property var modelData
                        width: conteudo.width; spacing: 14
                        Rectangle {
                            width: 38; height: 38; radius: 12
                            gradient: Gradient { orientation: Gradient.Horizontal
                                GradientStop { position: 0; color: "#22D3EE" } GradientStop { position: 1; color: "#7C3AED" } }
                            Icone { anchors.centerIn: parent; nome: modelData.i; tamanho: 18; cor: "white" }
                        }
                        Column {
                            width: parent.width - 52; spacing: 2
                            Text { text: modelData.t; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                            Text { width: parent.width; text: modelData.d; wrapMode: Text.WordWrap; color: Tema.textoSecundario
                                   font { family: Tema.fonteTexto; pixelSize: 13 } }
                        }
                    }
                }
            }

            Column {
                visible: apresentacao.passo === 2
                width: parent.width; spacing: 18
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; font.pixelSize: 26
                         text: apresentacao.padrao ? "O Mail Box é o seu programa de e-mail" : "Usar o Mail Box como programa de e-mail padrão?" }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: apresentacao.padrao ? "Quando você clica num endereço de e-mail num site ou documento, a mensagem já abre aqui."
                                                   : "Assim, quando você clicar num endereço de e-mail num site ou documento, a mensagem abre aqui." }
                Row {
                    spacing: 10
                    visible: apresentacao.padrao
                    Rectangle { width: 26; height: 26; radius: 13; color: Qt.rgba(0.13, 0.83, 0.93, 0.18)
                                Icone { anchors.centerIn: parent; nome: "check"; tamanho: 14; cor: "#0E9FB5" } }
                    Text { anchors.verticalCenter: parent.verticalCenter; text: "Programa de e-mail padrão do sistema"
                           color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                }
                Botao { visible: !apresentacao.padrao; texto: "Usar o Mail Box como padrão"; tipo: "primario"
                        onClicado: { caixa.tornarPadrao(); apresentacao.padrao = true } }
            }

            Column {
                visible: apresentacao.passo === 3
                width: parent.width; spacing: 14
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: "Trazer suas contas"; font.pixelSize: 26 }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: apresentacao.paraImportar.length > 0
                               ? "Achamos estas contas no Thunderbird. Escolha uma: o endereço e os servidores já vêm prontos, falta só a senha (por segurança, as senhas não são copiadas)."
                               : "Não achamos outro programa de e-mail neste computador. Sem problema: no próximo passo, é só digitar o seu e-mail e a senha." }
                Repeater {
                    model: apresentacao.paraImportar
                    delegate: Rectangle {
                        required property var modelData
                        width: conteudo.width; height: 56; radius: 14
                        color: Tema.escuro ? Qt.rgba(1, 1, 1, 0.04) : "#F3F5FB"
                        border { width: 1; color: Tema.borda }
                        Icone { id: iconeConta; anchors { left: parent.left; leftMargin: 16; verticalCenter: parent.verticalCenter }
                                nome: "usuario"; tamanho: 18; cor: Tema.textoSecundario }
                        Column {
                            anchors { left: iconeConta.right; leftMargin: 12; right: botaoUsar.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            Text { width: parent.width; elide: Text.ElideRight; text: modelData.email
                                   color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14; weight: Font.DemiBold } }
                            Text { width: parent.width; elide: Text.ElideRight
                                   text: (modelData.nome ? modelData.nome + " · " : "") + "do " + modelData.origem
                                   color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                        }
                        Botao { id: botaoUsar; anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                                texto: "Usar esta conta"; onClicado: apresentacao.concluir(modelData) }
                    }
                }
            }

            Column {
                visible: apresentacao.passo === 4
                width: parent.width; spacing: 16
                Titulo { color: Tema.texto; width: parent.width; wrapMode: Text.WordWrap; text: "Tudo pronto"; font.pixelSize: 28 }
                Rotulo { width: parent.width; secundario: true; font.pixelSize: 14
                         text: caixa.contasLista.length > 0 ? "Suas contas continuam aqui. Alguns atalhos para o dia a dia:"
                                                            : "Agora é só adicionar a sua conta. Alguns atalhos para o dia a dia:" }
                Grid {
                    columns: 2; columnSpacing: 18; rowSpacing: 10
                    Repeater {
                        model: [["Ctrl N", "Nova mensagem"], ["Ctrl R", "Responder"], ["Ctrl Shift R", "Responder a todos"],
                                ["Ctrl F", "Buscar nas mensagens"], ["Delete", "Apagar a mensagem"]]
                        delegate: Row {
                            required property var modelData
                            spacing: 10
                            Rectangle { width: Math.max(64, teclas.implicitWidth + 16); height: 26; radius: 7
                                        color: Tema.escuro ? Qt.rgba(1, 1, 1, 0.07) : "#EEF1F8"; border { width: 1; color: Tema.borda }
                                        Text { id: teclas; anchors.centerIn: parent; text: modelData[0]; color: Tema.texto
                                               font { family: Tema.fonteCodigo; pixelSize: 12 } } }
                            Text { anchors.verticalCenter: parent.verticalCenter; text: modelData[1]; color: Tema.textoSecundario
                                   font { family: Tema.fonteTexto; pixelSize: 13 } }
                        }
                    }
                }
            }
        }

        Row {
            anchors { left: parent.left; leftMargin: 34; bottom: parent.bottom; bottomMargin: 34 }
            spacing: 6
            Repeater {
                model: apresentacao.ultimo
                delegate: Rectangle {
                    required property int index
                    width: index + 1 === apresentacao.passo ? 22 : 8; height: 8; radius: 4
                    color: index + 1 === apresentacao.passo ? "#3D5BFF" : Tema.bordaForte
                    Behavior on width { NumberAnimation { duration: 200 } }
                }
            }
        }
        Row {
            anchors { right: parent.right; rightMargin: 26; bottom: parent.bottom; bottomMargin: 26 }
            spacing: 10
            Botao { visible: apresentacao.passo > 1; texto: "Voltar"; onClicado: apresentacao.passo-- }
            Botao {
                tipo: "primario"
                texto: apresentacao.passo === 4 ? (caixa.contasLista.length > 0 ? "Abrir o Mail Box" : "Adicionar minha conta")
                       : (apresentacao.passo === 1 ? "Começar" : (apresentacao.passo === 2 && !apresentacao.padrao ? "Agora não" : "Continuar"))
                onClicado: apresentacao.avancar()
            }
        }
    }
    Keys.onReturnPressed: if (passo > 0) avancar()
    Keys.onEscapePressed: concluir(null)
    focus: visible
}
