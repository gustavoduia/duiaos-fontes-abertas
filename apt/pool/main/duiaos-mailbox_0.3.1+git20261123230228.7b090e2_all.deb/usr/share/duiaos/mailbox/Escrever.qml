// DuiaOS — Mail Box: janela de escrever (nova mensagem, resposta e encaminhamento), com o texto formatado
// (negrito, listas, links, cores, imagens no meio do texto — editor.html, ADR 077) e anexos separados.
import QtQuick
import QtQuick.Window
import QtQuick.Dialogs
import QtWebEngine
import DuiaOS

Window {
    id: escrever
    property var campos: ({})
    property string conta: campos.conta || ""
    property var anexos: []
    property bool enviando: false
    property bool mostrarCc: (campos.cc || "") !== ""
    property string erro: ""
    // Assinatura da conta escolhida (texto ou HTML, das Configurações): vai no envio; dá para tirar desta mensagem
    readonly property var assinatura: caixa.assinaturaDe(conta)
    readonly property bool eResposta: (campos.em_resposta_a || "") !== ""
    property bool comAssinatura: true
    // Estado do editor, pelo título da página (editor.html): vazio ou com texto, e a formatação onde está o cursor
    property bool editorVazio: true
    property var formato: ({})
    property bool editorPronto: false
    property int nivelFonte: 3
    width: 760; height: 680
    minimumWidth: 520; minimumHeight: 420
    visible: true
    color: Tema.fundo
    title: (campoAssunto.texto || "Nova mensagem") + " — Mail Box"

    function enviar() {
        erro = ""
        if (campoPara.texto.trim() === "" && campoCc.texto.trim() === "" && campoCco.texto.trim() === "") { erro = "Escreva pelo menos um destinatário."; return }
        enviando = true
        editor.runJavaScript("mb.html()", function (html) {
            caixa.enviar({ conta: conta, para: campoPara.texto, cc: campoCc.texto, cco: campoCco.texto, assunto: campoAssunto.texto,
                           corpo: "", corpo_html: html || "<div><br></div>", anexos: anexos, em_resposta_a: campos.em_resposta_a || "",
                           referencias: campos.referencias || "", id_respondida: campos.id_respondida || 0,
                           incluir_assinatura: comAssinatura, citacao: campos.citacao || "" })
        })
    }
    function comando(nome, valor) {
        editor.runJavaScript("mb.comando(" + JSON.stringify(nome) + (valor === undefined ? "" : ", " + JSON.stringify(valor)) + ")")
        editor.forceActiveFocus()
    }
    Connections {
        target: caixa
        function onEnviada() { if (escrever.enviando) { escrever.enviando = false; escrever.close() } }
        function onFalhaEnvio(texto) { if (escrever.enviando) { escrever.enviando = false; escrever.erro = texto } }
    }
    Shortcut { sequences: ["Ctrl+Return", "Ctrl+Enter"]; onActivated: escrever.enviar() }
    Shortcut { sequences: ["Escape"]; enabled: !escrever.enviando && escrever.editorVazio && !caixaLink.visible && !paleta.visible; onActivated: escrever.close() }
    onClosing: destroy()

    FileDialog {
        id: escolherAnexos
        title: "Anexar arquivos"
        fileMode: FileDialog.OpenFiles
        onAccepted: { var l = escrever.anexos.slice(); for (var i = 0; i < selectedFiles.length; i++) l.push(selectedFiles[i].toString()); escrever.anexos = l }
    }
    FileDialog {
        id: escolherImagens
        title: "Inserir imagem no texto"
        fileMode: FileDialog.OpenFiles
        nameFilters: ["Imagens (*.png *.jpg *.jpeg *.gif *.webp *.bmp)"]
        onAccepted: {
            for (var i = 0; i < selectedFiles.length; i++) {
                var url = caixa.imagemEmDataUrl(selectedFiles[i].toString())
                if (url !== "") editor.runJavaScript("mb.imagem(" + JSON.stringify(url) + ")")
                else escrever.erro = "Não deu para usar essa imagem (só imagens de até 25 MB)."
            }
        }
    }

    // Botão da barra de formatação
    component BotaoFormato: BotaoIcone {
        id: bf
        property string rotulo: ""
        property bool negrito: false
        property bool italico: false
        property bool sublinhado: false
        width: Math.max(30, textoBf.implicitWidth + 16); height: 30; radius: 8
        tamanhoIcone: 15
        corIcone: marcado ? Tema.azulDuia : Tema.texto
        Text { id: textoBf; anchors.centerIn: parent; visible: bf.icone === ""; text: bf.rotulo
               color: bf.marcado ? Tema.azulDuia : Tema.texto
               font { family: bf.italico ? "Georgia" : Tema.fonteTexto; pixelSize: 14; bold: bf.negrito; italic: bf.italico; underline: bf.sublinhado } }
    }

    component LinhaCampo: Item {
        property string rotulo: ""
        property alias campo: entradaCampo
        property alias texto: entradaCampo.text
        width: parent ? parent.width : 0
        height: 42
        Text { id: r; anchors { left: parent.left; verticalCenter: parent.verticalCenter } width: 64; text: rotulo
               color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 13 } }
        TextInput {
            id: entradaCampo
            anchors { left: r.right; right: parent.right; verticalCenter: parent.verticalCenter }
            clip: true
            color: Tema.texto; selectionColor: Tema.azulDuia
            font { family: Tema.fonteTexto; pixelSize: 14 }
            selectByMouse: true
            activeFocusOnTab: true      // Tab: Para → Cc → Cco → Assunto → texto
        }
        Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom } height: 1; color: entradaCampo.activeFocus ? Tema.azulDuia : Tema.borda }
    }

    Rectangle { anchors.fill: parent; color: Tema.fundo }
    Column {
        id: cabecalho
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20; topMargin: 12 }
        // De: as contas, em pílulas
        Item {
            width: parent.width; height: 42
            Text { id: rotuloDe; anchors { left: parent.left; verticalCenter: parent.verticalCenter } width: 64; text: "De"
                   color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 13 } }
            Row {
                anchors { left: rotuloDe.right; verticalCenter: parent.verticalCenter }
                spacing: 6
                Repeater {
                    model: caixa.contasLista
                    delegate: Rectangle {
                        required property var modelData
                        readonly property bool escolhida: escrever.conta === modelData.id
                        visible: caixa.contasLista.length > 1 || escolhida
                        width: rotuloConta.implicitWidth + 22; height: 28; radius: 14
                        color: escolhida ? Tema.destaque : "transparent"
                        border { width: 1; color: escolhida ? Tema.azulDuia : Tema.borda }
                        Text { id: rotuloConta; anchors.centerIn: parent; text: modelData.email; color: parent.escolhida ? Tema.azulDuia : Tema.texto
                               font { family: Tema.fonteTexto; pixelSize: 12; weight: parent.escolhida ? Font.DemiBold : Font.Normal } }
                        MouseArea { anchors.fill: parent; onClicked: escrever.conta = modelData.id }
                    }
                }
            }
            Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom } height: 1; color: Tema.borda }
        }
        LinhaCampo { id: campoPara; rotulo: "Para"; texto: escrever.campos.para || ""
            Text { anchors { right: parent.right; verticalCenter: parent.verticalCenter } visible: !escrever.mostrarCc
                   text: "Cc e Cco"; color: Tema.azulDuia; font { family: Tema.fonteTexto; pixelSize: 12 }
                   MouseArea { anchors.fill: parent; anchors.margins: -4; onClicked: escrever.mostrarCc = true } } }
        LinhaCampo { id: campoCc; rotulo: "Cc"; visible: escrever.mostrarCc; height: visible ? 42 : 0; texto: escrever.campos.cc || "" }
        LinhaCampo { id: campoCco; rotulo: "Cco"; visible: escrever.mostrarCc; height: visible ? 42 : 0 }
        LinhaCampo { id: campoAssunto; rotulo: "Assunto"; texto: escrever.campos.assunto || "" }
    }
    // Barra de formatação
    Rectangle {
        id: barraFormato
        anchors { left: parent.left; right: parent.right; top: cabecalho.bottom; margins: 14; topMargin: 8 }
        height: 38; radius: 10
        color: Tema.lateral
        border { width: 1; color: Tema.borda }
        Row {
            anchors { left: parent.left; leftMargin: 4; verticalCenter: parent.verticalCenter }
            spacing: 2
            BotaoFormato { rotulo: "N"; negrito: true; dica: "Negrito (Ctrl+B)"; marcado: escrever.formato.negrito === true; onClicado: escrever.comando("bold") }
            BotaoFormato { rotulo: "I"; italico: true; dica: "Itálico (Ctrl+I)"; marcado: escrever.formato.italico === true; onClicado: escrever.comando("italic") }
            BotaoFormato { rotulo: "S"; sublinhado: true; dica: "Sublinhado (Ctrl+U)"; marcado: escrever.formato.sublinhado === true; onClicado: escrever.comando("underline") }
            Rectangle { width: 1; height: 20; color: Tema.borda; anchors.verticalCenter: parent.verticalCenter }
            BotaoFormato { rotulo: "A−"; dica: "Letra menor"; onClicado: { escrever.nivelFonte = Math.max(1, escrever.nivelFonte - 1); escrever.comando("fontSize", String(escrever.nivelFonte)) } }
            BotaoFormato { rotulo: "A+"; dica: "Letra maior"; onClicado: { escrever.nivelFonte = Math.min(7, escrever.nivelFonte + 1); escrever.comando("fontSize", String(escrever.nivelFonte)) } }
            BotaoFormato { id: botaoCor; rotulo: "A"; dica: "Cor do texto"; onClicado: { paleta.visible = !paleta.visible; caixaLink.visible = false }
                Rectangle { anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 5 } width: 14; height: 3; radius: 1.5; color: paleta.cor } }
            Rectangle { width: 1; height: 20; color: Tema.borda; anchors.verticalCenter: parent.verticalCenter }
            BotaoFormato { icone: "lista"; dica: "Lista com marcadores"; marcado: escrever.formato.lista === true; onClicado: escrever.comando("insertUnorderedList") }
            BotaoFormato { rotulo: "1."; dica: "Lista numerada"; marcado: escrever.formato.numerada === true; onClicado: escrever.comando("insertOrderedList") }
            BotaoFormato { rotulo: "❝"; dica: "Citação"; onClicado: escrever.comando("citacao") }
            Rectangle { width: 1; height: 20; color: Tema.borda; anchors.verticalCenter: parent.verticalCenter }
            BotaoFormato { icone: "globo"; dica: "Link"; onClicado: { caixaLink.visible = !caixaLink.visible; paleta.visible = false; if (caixaLink.visible) { campoLink.text = ""; campoLink.forceActiveFocus() } } }
            BotaoFormato { icone: "imagem"; dica: "Imagem no meio do texto"; onClicado: escolherImagens.open() }
            BotaoFormato { rotulo: "Tx"; dica: "Limpar a formatação"; onClicado: escrever.comando("removeFormat") }
        }
    }
    // Cores do texto
    Rectangle {
        id: paleta
        property color cor: "#1F2933"
        visible: false
        z: 30
        x: barraFormato.x + 4 + botaoCor.x; y: barraFormato.y + barraFormato.height + 4
        width: linhaCores.implicitWidth + 16; height: 40; radius: 10
        color: Tema.cartao; border { width: 1; color: Tema.borda }
        Row {
            id: linhaCores
            anchors.centerIn: parent
            spacing: 6
            Repeater {
                model: ["#1F2933", "#3D5BFF", "#0E9FB5", "#16A34A", "#F59E0B", "#EF4444", "#A855F7", "#8A94A3"]
                delegate: Rectangle {
                    required property string modelData
                    width: 22; height: 22; radius: 11; color: modelData
                    border { width: paleta.cor == modelData ? 2 : 1; color: paleta.cor == modelData ? Tema.azulDuia : Qt.rgba(0, 0, 0, 0.15) }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                onClicked: { paleta.cor = modelData; paleta.visible = false; escrever.comando("foreColor", modelData) } }
                }
            }
        }
    }
    // Link: endereço do link (sobre o texto escolhido, ou o próprio endereço como texto)
    Rectangle {
        id: caixaLink
        visible: false
        z: 30
        anchors { right: barraFormato.right; top: barraFormato.bottom; topMargin: 4 }
        width: 360; height: 44; radius: 10
        color: Tema.cartao; border { width: 1; color: Tema.borda }
        TextInput {
            id: campoLink
            anchors { left: parent.left; right: botaoLink.left; leftMargin: 12; rightMargin: 8; verticalCenter: parent.verticalCenter }
            clip: true; color: Tema.texto; selectionColor: Tema.azulDuia; font { family: Tema.fonteTexto; pixelSize: 13 }
            Text { visible: !campoLink.text; text: "Endereço do link (ex.: duiaos.com.br)"; color: Tema.textoSecundario; font: campoLink.font }
            onAccepted: botaoLink.clicado()
            Keys.onEscapePressed: caixaLink.visible = false
        }
        Botao { id: botaoLink; anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                texto: campoLink.text.trim() === "" ? "Tirar link" : "Pôr link"; tipo: "primario"
                onClicado: { caixaLink.visible = false; escrever.comando("link", campoLink.text.trim()) } }
    }
    Rectangle {
        id: fundoEditor
        anchors { left: parent.left; right: parent.right; top: barraFormato.bottom; bottom: faixaAssinatura.top; leftMargin: 20; rightMargin: 14; topMargin: 6; bottomMargin: 6 }
        color: "transparent"
        WebEngineView {
            id: editor
            anchors.fill: parent
            profile: perfilLeitura
            backgroundColor: "transparent"
            settings.javascriptEnabled: true
            settings.javascriptCanOpenWindows: false
            settings.javascriptCanAccessClipboard: true
            settings.javascriptCanPaste: true
            settings.localContentCanAccessRemoteUrls: false
            settings.localContentCanAccessFileUrls: false
            settings.pluginsEnabled: false
            url: Qt.resolvedUrl("editor.html")
            onLoadingChanged: (pedido) => {
                if (pedido.status !== WebEngineView.LoadSucceededStatus) return
                var inicial = caixa.htmlDoEditor(escrever.campos.corpo || "")
                runJavaScript("mb.definir(" + JSON.stringify(inicial) + ", " + (Tema.escuro ? "true" : "false") + ")")
                escrever.editorPronto = true
                if (campoPara.texto !== "") { forceActiveFocus(); runJavaScript("mb.focar(false)") }
            }
            onTitleChanged: {
                var partes = title.split("|")
                escrever.editorVazio = partes[0] !== "texto"
                try { escrever.formato = partes.length > 1 ? JSON.parse(partes.slice(1).join("|")) : {} } catch (e) { escrever.formato = {} }
            }
            // Links no texto não abrem aqui dentro
            onNavigationRequested: (pedido) => {
                if (pedido.url.toString() !== Qt.resolvedUrl("editor.html").toString()) pedido.reject()
            }
            onNewWindowRequested: (pedido) => { Qt.openUrlExternally(pedido.requestedUrl) }
        }
    }
    Component.onCompleted: if (campoPara.texto === "") campoPara.campo.forceActiveFocus()
    Rectangle {
        id: faixaAssinatura
        visible: escrever.assinatura.tem && (!escrever.eResposta || escrever.assinatura.respostas)
        anchors { left: parent.left; right: parent.right; bottom: listaAnexos.top; margins: 20; bottomMargin: 6 }
        height: visible ? 34 : 0
        radius: 10
        color: Tema.destaque
        Icone { id: iconeAssinatura; anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter } nome: "lapis"; tamanho: 14; cor: Tema.azulDuia }
        Text { anchors { left: iconeAssinatura.right; leftMargin: 8; right: chaveAssinatura.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
               text: escrever.comAssinatura ? (escrever.assinatura.tipo === "html" ? "Com a assinatura em HTML desta conta (ela vai no fim, ao enviar)"
                                                                                  : "Com a assinatura: " + escrever.assinatura.texto.split("\n")[0])
                                            : "Sem assinatura nesta mensagem"
               elide: Text.ElideRight; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 12 } }
        Interruptor { id: chaveAssinatura; anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                      ligado: escrever.comAssinatura; onAlternado: (v) => escrever.comAssinatura = v }
    }
    Flow {
        id: listaAnexos
        anchors { left: parent.left; right: parent.right; bottom: rodape.top; margins: 20; bottomMargin: 8 }
        spacing: 6
        height: escrever.anexos.length ? implicitHeight : 0
        Repeater {
            model: escrever.anexos
            delegate: Rectangle {
                required property var modelData
                required property int index
                height: 30; radius: 15
                width: linhaAnexo.implicitWidth + 20
                color: Tema.cartao
                border { width: 1; color: Tema.borda }
                Row {
                    id: linhaAnexo
                    anchors.centerIn: parent
                    spacing: 6
                    Icone { nome: "documento"; tamanho: 13; cor: Tema.azulDuia; anchors.verticalCenter: parent.verticalCenter }
                    Text { text: decodeURIComponent(modelData.split("/").pop()); color: Tema.texto; anchors.verticalCenter: parent.verticalCenter
                           font { family: Tema.fonteTexto; pixelSize: 12 } }
                    BotaoIcone { width: 20; height: 20; radius: 10; icone: "fechar"; tamanhoIcone: 10; anchors.verticalCenter: parent.verticalCenter
                                 onClicado: { var l = escrever.anexos.slice(); l.splice(index, 1); escrever.anexos = l } }
                }
            }
        }
    }
    Rectangle {
        id: rodape
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 60
        color: Tema.lateral
        Rectangle { anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Tema.borda }
        Row {
            anchors { left: parent.left; leftMargin: 16; verticalCenter: parent.verticalCenter }
            spacing: 10
            Botao { texto: escrever.enviando ? "Enviando…" : "Enviar"; icone: "seta-direita"; tipo: "primario"; ativo: !escrever.enviando; onClicado: escrever.enviar() }
            Botao { texto: "Anexar"; icone: "documento"; onClicado: escolherAnexos.open() }
        }
        Text {
            anchors { left: parent.left; leftMargin: 250; right: descartar.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
            text: escrever.erro; elide: Text.ElideRight; color: Tema.erro; font { family: Tema.fonteTexto; pixelSize: 13 }
        }
        BotaoIcone { id: descartar; anchors { right: parent.right; rightMargin: 16; verticalCenter: parent.verticalCenter }
                     icone: "lixeira"; dica: "Descartar"; ativo: !escrever.enviando; onClicado: escrever.close() }
    }

    Timer {
        interval: 2500
        running: typeof capturaArquivo !== "undefined" && capturaArquivo !== "" && typeof paginaDemonstracao !== "undefined" && paginaDemonstracao === "escrever"
        onTriggered: escrever.contentItem.grabToImage(function (r) { r.saveToFile(capturaArquivo); Qt.quit() })
    }
}
