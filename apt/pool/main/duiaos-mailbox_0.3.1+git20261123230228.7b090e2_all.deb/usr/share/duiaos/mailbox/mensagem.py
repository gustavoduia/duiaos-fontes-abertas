"""DuiaOS — Mail Box: ler, mostrar com segurança e escrever mensagens (MIME).

Ler:     resumo dos cabeçalhos, prévia do texto, anexos, corpo em HTML para a leitura.
Mostrar: HTML limpo — sem scripts, sem formulários que enviam, sem eventos; imagens externas bloqueadas
         até a pessoa liberar (evita o rastreamento por pixel); imagens embutidas (cid:) viram data:.
Escrever: nova mensagem, resposta (Re:, In-Reply-To, References, citação) e encaminhamento, com anexos.

Sem Qt: testável sozinho (shell/testes/test_mailbox.py).
"""
import base64
import email
import email.policy
import html
import mimetypes
import re
import time
from email.header import decode_header, make_header
from email.message import EmailMessage
from email.utils import formataddr, getaddresses, make_msgid, parsedate_to_datetime, formatdate
from html.parser import HTMLParser
from pathlib import Path


def decodificar(valor):
    if not valor:
        return ""
    try:
        return str(make_header(decode_header(str(valor))))
    except Exception:  # noqa: BLE001 — cabeçalho mal codificado: mostra como veio
        return str(valor)


def ler(bruto):
    return email.message_from_bytes(bruto, policy=email.policy.default)


def enderecos(valor):
    return [{"nome": decodificar(n), "email": e} for n, e in getaddresses([decodificar(valor)]) if e]


def data_de(msg, reserva=0):
    try:
        return parsedate_to_datetime(msg["Date"]).timestamp()
    except Exception:  # noqa: BLE001
        return reserva or time.time()


def _texto_da_parte(parte):
    try:
        return parte.get_content()
    except Exception:  # noqa: BLE001 — conjunto de caracteres desconhecido
        carga = parte.get_payload(decode=True) or b""
        return carga.decode("utf-8", errors="replace")


def corpos(msg):
    """(texto, html) da mensagem — a melhor parte de cada tipo."""
    texto = html_ = ""
    for parte in msg.walk():
        if parte.is_multipart() or parte.get_content_disposition() == "attachment":
            continue
        tipo = parte.get_content_type()
        if tipo == "text/plain" and not texto:
            texto = _texto_da_parte(parte)
        elif tipo == "text/html" and not html_:
            html_ = _texto_da_parte(parte)
    return texto, html_


def anexos(msg):
    saida = []
    for i, parte in enumerate(msg.walk()):
        if parte.is_multipart():
            continue
        disposicao = parte.get_content_disposition()
        nome = parte.get_filename()
        if disposicao == "attachment" or (nome and disposicao != "inline" and not parte.get_content_type().startswith("text/")):
            carga = parte.get_payload(decode=True) or b""
            saida.append({"indice": i, "nome": decodificar(nome) or f"anexo-{i}", "tipo": parte.get_content_type(),
                          "tamanho": len(carga)})
    return saida


def conteudo_do_anexo(msg, indice):
    for i, parte in enumerate(msg.walk()):
        if i == indice:
            return parte.get_payload(decode=True) or b""
    return None


def previa(msg, limite=180):
    texto, html_ = corpos(msg)
    if not texto and html_:
        texto = html_para_texto(html_)
    texto = re.sub(r"(?m)^>.*$", "", texto)
    return re.sub(r"\s+", " ", texto).strip()[:limite]


def html_para_texto(conteudo):
    conteudo = re.sub(r"(?is)<(script|style|head)[^>]*>.*?</\1>", " ", conteudo)
    conteudo = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</h\d>", "\n", conteudo)
    return html.unescape(re.sub(r"<[^>]+>", " ", conteudo))


def resumo(bruto, uid=0, flags=()):
    """Cabeçalhos e prévia de uma mensagem, para a lista."""
    msg = ler(bruto)
    remetente = (enderecos(msg["From"]) or [{"nome": "", "email": ""}])[0]
    return {"uid": uid, "message_id": (msg["Message-ID"] or "").strip(), "assunto": decodificar(msg["Subject"]),
            "de_nome": remetente["nome"], "de_email": remetente["email"],
            "para": ", ".join(e["email"] for e in enderecos(msg["To"])),
            "cc": ", ".join(e["email"] for e in enderecos(msg["Cc"])),
            "data": data_de(msg), "lida": "\\Seen" in flags, "sinalizada": "\\Flagged" in flags,
            "respondida": "\\Answered" in flags, "tem_anexo": bool(anexos(msg)), "previa": previa(msg),
            "tamanho": len(bruto), "referencias": (msg["References"] or "").strip(),
            "em_resposta_a": (msg["In-Reply-To"] or "").strip()}


# ------------------------------------------------------------------------------------------- mostrar
_PROIBIDAS = {"script", "iframe", "frame", "frameset", "object", "embed", "applet", "form", "base", "meta", "link",
              "noscript", "template", "portal"}
_VAZIAS = {"br", "hr", "img", "input", "col", "area", "wbr", "source", "track"}
_URL_PERIGOSA = re.compile(r"^\s*(javascript|vbscript|data:text/html)", re.IGNORECASE)
_URL_REMOTA_CSS = re.compile(r"url\(\s*['\"]?\s*(https?:)?//[^)]*\)", re.IGNORECASE)


class _Limpador(HTMLParser):
    def __init__(self, permitir_remoto, imagens_cid):
        super().__init__(convert_charrefs=False)
        self.saida = []
        self.pular = 0
        self.permitir_remoto = permitir_remoto
        self.cid = imagens_cid
        self.bloqueadas = 0

    def _atributos(self, tag, attrs):
        limpos = []
        for nome, valor in attrs:
            nome = nome.lower()
            valor = valor or ""
            if nome.startswith("on") or nome in ("srcdoc", "formaction", "ping"):
                continue
            if nome in ("href", "src", "action", "background", "poster", "xlink:href") and _URL_PERIGOSA.match(valor):
                continue
            if nome == "src" and tag == "img" or nome == "background":
                if valor.lower().startswith("cid:"):
                    valor = self.cid.get(valor[4:].strip("<>"), "")
                elif re.match(r"^\s*(https?:)?//", valor, re.IGNORECASE) and not self.permitir_remoto:
                    self.bloqueadas += 1
                    continue
            if nome == "srcset" and not self.permitir_remoto:
                continue
            if nome == "style" and not self.permitir_remoto and _URL_REMOTA_CSS.search(valor):
                self.bloqueadas += 1
                valor = _URL_REMOTA_CSS.sub("none", valor)
            limpos.append(f' {nome}="{html.escape(valor, quote=True)}"')
        if tag == "a":
            limpos.append(' target="_blank" rel="noopener noreferrer"')
        return "".join(limpos)

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in _PROIBIDAS:
            if tag not in _VAZIAS and tag not in ("meta", "link", "base"):
                self.pular += 1
            return
        if self.pular:
            return
        self.saida.append(f"<{tag}{self._atributos(tag, attrs)}>")

    def handle_startendtag(self, tag, attrs):
        tag = tag.lower()
        if tag in _PROIBIDAS or self.pular:
            return
        self.saida.append(f"<{tag}{self._atributos(tag, attrs)}/>")

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in _PROIBIDAS:
            if tag not in ("meta", "link", "base"):
                self.pular = max(0, self.pular - 1)
            return
        if not self.pular and tag not in _VAZIAS:
            self.saida.append(f"</{tag}>")

    def handle_data(self, data):
        if not self.pular:
            self.saida.append(data)

    def handle_entityref(self, nome):
        if not self.pular:
            self.saida.append(f"&{nome};")

    def handle_charref(self, nome):
        if not self.pular:
            self.saida.append(f"&#{nome};")

    def handle_comment(self, data):
        pass


def _bloquear_css_remoto(conteudo, permitir_remoto):
    """Dentro de <style>: tira @import e url() remotos."""
    if permitir_remoto:
        return conteudo, 0
    def trocar_estilo(m):
        css = m.group(2)
        n = len(_URL_REMOTA_CSS.findall(css)) + len(re.findall(r"@import", css, re.IGNORECASE))
        css = re.sub(r"@import[^;]*;", "", css, flags=re.IGNORECASE)
        css = _URL_REMOTA_CSS.sub("none", css)
        trocar_estilo.total += n
        return m.group(1) + css + m.group(3)
    trocar_estilo.total = 0
    conteudo = re.sub(r"(?is)(<style[^>]*>)(.*?)(</style>)", trocar_estilo, conteudo)
    return conteudo, trocar_estilo.total


def imagens_embutidas(msg):
    mapa = {}
    for parte in msg.walk():
        cid = (parte.get("Content-ID") or "").strip("<> ")
        if cid and parte.get_content_maintype() == "image":
            carga = parte.get_payload(decode=True) or b""
            mapa[cid] = f"data:{parte.get_content_type()};base64,{base64.b64encode(carga).decode()}"
    return mapa


def texto_para_html(texto):
    seguro = html.escape(texto)
    seguro = re.sub(r"(https?://[^\s<>&\"]+)", r'<a href="\1">\1</a>', seguro)
    linhas = []
    for linha in seguro.split("\n"):
        nivel = len(re.match(r"^((&gt;\s?)*)", linha).group(1).replace(" ", "")) // 4
        conteudo = re.sub(r"^((&gt;\s?)*)", "", linha) if nivel else linha
        linhas.append(f'<div class="citacao" style="margin-left:{nivel * 12}px">{conteudo or "&nbsp;"}</div>' if nivel
                      else (conteudo or "<br>"))
    return "<div class=\"texto-simples\">" + "\n".join(l if l.startswith("<div") else l + "<br>" for l in linhas) + "</div>"


def html_para_leitura(msg, permitir_remoto=False, escuro=False):
    """HTML pronto para o WebEngineView sem JavaScript. Devolve (html, imagens_bloqueadas)."""
    texto, html_ = corpos(msg)
    bloqueadas = 0
    if html_:
        html_, n_css = _bloquear_css_remoto(html_, permitir_remoto)
        limpador = _Limpador(permitir_remoto, imagens_embutidas(msg))
        limpador.feed(html_)
        limpador.close()
        corpo = "".join(limpador.saida)
        bloqueadas = limpador.bloqueadas + n_css
        fundo, cor = "#ffffff", "#1f2933"              # e-mails em HTML foram feitos para fundo claro
    else:
        corpo = texto_para_html(texto)
        fundo, cor = ("#131A30", "#E6EAF0") if escuro else ("#ffffff", "#1f2933")
    estilo = (f"<style>html,body{{margin:0;padding:0;background:{fundo};color:{cor};}}"
              "body{padding:20px 24px;font-family:Inter,system-ui,sans-serif;font-size:14px;line-height:1.55;"
              "word-wrap:break-word;overflow-wrap:anywhere}"
              ".texto-simples{white-space:normal}.citacao{border-left:3px solid #8a94a3;padding-left:10px;color:#5b6675}"
              "img{max-width:100%;height:auto}a{color:#2E6BE6}"
              "blockquote{border-left:3px solid #c9d2de;margin:0 0 0 4px;padding-left:12px;color:#5b6675}</style>")
    politica = ("<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; img-src data: "
                + ("https: http:" if permitir_remoto else "") + "; style-src 'unsafe-inline'"
                + (" https: http:" if permitir_remoto else "") + "; font-src data:"
                + (" https: http:" if permitir_remoto else "") + "\">")
    return f"<!DOCTYPE html><html><head><meta charset=\"utf-8\">{politica}{estilo}</head><body>{corpo}</body></html>", bloqueadas


# ------------------------------------------------------------------------------------------- escrever
def _lista(texto):
    return [formataddr((n, e)) if n else e for n, e in getaddresses([texto or ""]) if e]


def limpar_html_assinatura(conteudo):
    """Assinatura HTML da pessoa: sem scripts, formulários, eventos nem links javascript (imagens remotas ficam:
    é ela quem escolhe o logotipo)."""
    limpador = _Limpador(True, {})
    limpador.feed(conteudo or "")
    limpador.close()
    return "".join(limpador.saida).strip()


def _texto_para_html(texto):
    """Corpo em texto → HTML: parágrafos, quebras de linha e as citações ("> ") como blockquote."""
    linhas, saida, citando = (texto or "").split("\n"), [], False
    for linha in linhas:
        e_citacao = linha.startswith(">")
        if e_citacao and not citando:
            saida.append('<blockquote style="margin:0 0 0 4px;padding-left:12px;border-left:3px solid #c9d2de;color:#5b6675">')
            citando = True
        elif not e_citacao and citando:
            saida.append("</blockquote>")
            citando = False
        conteudo = linha[1:].lstrip() if e_citacao else linha
        saida.append(html.escape(conteudo) + "<br>")
    if citando:
        saida.append("</blockquote>")
    return "".join(saida)


def _juntar_assinatura(corpo, assinatura, citacao_original, separador):
    """Põe a assinatura no fim do texto ou, nas respostas com a opção "acima", antes da citação."""
    if citacao_original and assinatura.get("posicao") == "acima" and citacao_original in corpo:
        antes, depois = corpo.split(citacao_original, 1)
        return antes.rstrip() + separador + citacao_original + depois
    return corpo.rstrip() + separador


_IMAGEM_DATA = re.compile(r'(src=")data:(image/(?:png|jpeg|gif|webp|bmp|svg\+xml));base64,([A-Za-z0-9+/=\s]+)(")', re.IGNORECASE)
_LIMITE_IMAGEM = 25 * 1024 * 1024


def preparar_html_do_editor(conteudo):
    """HTML do editor de texto formatado (ADR 077) → (html limpo com as imagens em cid:, [(cid, tipo, bytes)]).
    As imagens coladas ou inseridas no texto chegam como data:; no e-mail elas vão como partes embutidas
    (multipart/related), que todos os programas mostram no lugar certo — e não como anexo."""
    limpador = _Limpador(True, {})
    limpador.feed(conteudo or "")
    limpador.close()
    limpo, imagens = "".join(limpador.saida).strip(), []

    def trocar(m):
        try:
            carga = base64.b64decode(re.sub(r"\s", "", m.group(3)), validate=True)
        except (ValueError, base64.binascii.Error):
            return ""
        if not carga or len(carga) > _LIMITE_IMAGEM:
            return ""
        cid = make_msgid(domain="mailbox.duiaos")[1:-1]
        imagens.append((cid, m.group(2).lower(), carga))
        return f"{m.group(1)}cid:{cid}{m.group(4)}"
    return _IMAGEM_DATA.sub(trocar, limpo), imagens


def _assinatura_em_html(assinatura):
    if not assinatura:
        return ""
    if assinatura.get("tipo") == "html" and assinatura.get("html"):
        return limpar_html_assinatura(assinatura["html"])
    if assinatura.get("texto"):
        return "-- <br>" + html.escape(assinatura["texto"]).replace("\n", "<br>")
    return ""


def html_inicial_do_editor(texto):
    """Texto de partida da janela Escrever (vazio, resposta com citação "> " ou encaminhamento) → HTML do editor.
    A citação vira um blockquote marcado (data-mb-citacao): a assinatura "acima da citação" entra antes dele."""
    saida, citando, marcada = [], False, False
    for linha in (texto or "").split("\n"):
        e_citacao = linha.startswith(">")
        if e_citacao and not citando:
            saida.append("<blockquote" + ("" if marcada else " data-mb-citacao=\"1\"") + ">")
            citando, marcada = True, True
        elif not e_citacao and citando:
            saida.append("</blockquote>")
            citando = False
        conteudo = html.escape(linha[1:].lstrip() if e_citacao else linha)
        saida.append(f"<div>{conteudo or '<br>'}</div>")
    if citando:
        saida.append("</blockquote>")
    resultado = "".join(saida)
    return "" if resultado == "<div><br></div>" else resultado


def _montar_html(msg, corpo_html, assinatura):
    """Corpo formatado: texto simples + HTML com as imagens embutidas (alternative › related)."""
    limpo, imagens = preparar_html_do_editor(corpo_html)
    sig = _assinatura_em_html(assinatura)
    if sig:
        bloco = '<div class="mb-assinatura" style="margin:16px 0">' + sig + "</div>"
        marca = re.search(r"<blockquote[^>]*data-mb-citacao", limpo)
        if marca and assinatura.get("posicao") == "acima":
            limpo = limpo[:marca.start()] + bloco + limpo[marca.start():]
        else:
            limpo += bloco
    corpo = ('<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.5">' + limpo + "</div>")
    documento = f"<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body>{corpo}</body></html>"
    texto = html_para_texto(re.sub(r"(?i)<img[^>]*>", "", corpo)).strip() + "\n"
    msg.set_content(texto)
    msg.add_alternative(documento, subtype="html")
    if imagens:
        parte_html = msg.get_payload()[1]
        for numero, (cid, tipo, carga) in enumerate(imagens, 1):
            principal, sub = tipo.split("/", 1)
            parte_html.add_related(carga, maintype=principal, subtype=sub, cid=f"<{cid}>",
                                   filename=f"imagem-{numero}.{sub.split('+')[0].replace('jpeg', 'jpg')}",
                                   disposition="inline")


def montar(de_nome, de_email, para, assunto, corpo, cc="", cco="", anexos_caminhos=(), em_resposta_a="",
           referencias="", assinatura="", citacao_original="", corpo_html=""):
    """assinatura: texto (o jeito antigo) ou {"tipo": "texto"|"html", "texto", "html", "posicao": "abaixo"|"acima"}.
    Com assinatura HTML, a mensagem vai em texto e em HTML (multipart/alternative), como nos outros programas.
    corpo_html: o texto formatado do editor (negrito, listas, imagens no meio do texto…); ele manda no corpo, e o
    texto simples da mensagem sai dele. Anexos vão sempre como anexo, separados do texto."""
    if isinstance(assinatura, str):
        assinatura = {"tipo": "texto", "texto": assinatura} if assinatura else {}
    msg = EmailMessage()
    msg["From"] = formataddr((de_nome, de_email)) if de_nome else de_email
    if _lista(para):
        msg["To"] = ", ".join(_lista(para))
    if _lista(cc):
        msg["Cc"] = ", ".join(_lista(cc))
    msg["Subject"] = assunto
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=de_email.rpartition("@")[2] or None)
    msg["User-Agent"] = "Mail Box (DuiaOS)"
    if em_resposta_a:
        msg["In-Reply-To"] = em_resposta_a
        msg["References"] = (referencias + " " + em_resposta_a).strip()
    tipo = assinatura.get("tipo", "texto") if assinatura else ""
    if corpo_html and corpo_html.strip():
        _montar_html(msg, corpo_html, assinatura)
    elif tipo == "html" and assinatura.get("html"):
        sig_html = limpar_html_assinatura(assinatura["html"])
        sig_texto = html_para_texto(sig_html).strip()
        marcador = "\u0000ASSINATURA\u0000"
        com_marcador = _juntar_assinatura(corpo, assinatura, citacao_original, "\n\n" + marcador + "\n\n").rstrip()
        texto = com_marcador.replace(marcador, "-- \n" + sig_texto)
        partes_html = _texto_para_html(com_marcador).split(html.escape(marcador))
        corpo_html = ('<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.5">'
                      + ('<div style="margin:12px 0">' + sig_html + "</div>").join(partes_html) + "</div>")
        msg.set_content(texto)
        msg.add_alternative(f"<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body>{corpo_html}</body></html>",
                            subtype="html")
    elif tipo == "texto" and assinatura.get("texto"):
        msg.set_content(_juntar_assinatura(corpo, assinatura, citacao_original, "\n\n-- \n" + assinatura["texto"] + "\n\n").rstrip() + "\n")
    else:
        msg.set_content(corpo)
    for caminho in anexos_caminhos:
        caminho = Path(caminho)
        tipo_arq, _ = mimetypes.guess_type(caminho.name)
        principal, sub = (tipo_arq or "application/octet-stream").split("/", 1)
        msg.add_attachment(caminho.read_bytes(), maintype=principal, subtype=sub, filename=caminho.name)
    destinatarios = [e for campo in (para, cc, cco) if campo for _, e in getaddresses([campo]) if e]
    return msg, destinatarios


def modelos_de_assinatura(dados):
    """Modelos prontos de assinatura HTML, preenchidos com nome, cargo, empresa, telefone, site e e-mail."""
    e = {k: html.escape(str(v or "")) for k, v in dados.items()}
    site = e["site"]
    link_site = (f'<a href="{site if site.startswith("http") else "https://" + site}" style="color:#3D5BFF;text-decoration:none">'
                 f"{site.replace('https://', '').replace('http://', '')}</a>") if site else ""
    linha = lambda *itens: " · ".join(i for i in itens if i)  # noqa: E731
    cargo_empresa = linha(e["cargo"], e["empresa"])
    contato = linha(e["telefone"], f'<a href="mailto:{e["email"]}" style="color:#3D5BFF;text-decoration:none">{e["email"]}</a>'
                    if e["email"] else "", link_site)
    inicial = (e["nome"][:1] or "?").upper()
    return [
        {"id": "simples", "nome": "Simples",
         "html": f'<div style="font-family:Arial,sans-serif;font-size:13px;color:#1f2933"><b>{e["nome"]}</b><br>'
                 + (f"{cargo_empresa}<br>" if cargo_empresa else "") + f'<span style="color:#5b6675">{contato}</span></div>'},
        {"id": "profissional", "nome": "Profissional",
         "html": '<table cellpadding="0" cellspacing="0" style="font-family:Arial,sans-serif;font-size:13px;color:#1f2933">'
                 '<tr><td style="border-left:3px solid #3D5BFF;padding:2px 0 2px 12px">'
                 f'<div style="font-size:15px;font-weight:bold">{e["nome"]}</div>'
                 + (f'<div style="color:#3D5BFF;font-weight:bold">{cargo_empresa}</div>' if cargo_empresa else "")
                 + f'<div style="color:#5b6675;margin-top:4px">{contato}</div></td></tr></table>'},
        {"id": "cartao", "nome": "Cartão",
         "html": '<table cellpadding="0" cellspacing="0" style="font-family:Arial,sans-serif;font-size:13px;color:#1f2933">'
                 '<tr><td style="padding-right:12px;vertical-align:middle"><div style="width:44px;height:44px;border-radius:22px;'
                 'background:#3D5BFF;color:#fff;font-size:20px;font-weight:bold;text-align:center;line-height:44px">'
                 f'{inicial}</div></td><td style="vertical-align:middle"><div style="font-size:15px;font-weight:bold">{e["nome"]}</div>'
                 + (f'<div style="color:#5b6675">{cargo_empresa}</div>' if cargo_empresa else "")
                 + f'<div style="margin-top:2px">{contato}</div></td></tr></table>'},
        {"id": "minimalista", "nome": "Minimalista",
         "html": f'<div style="font-family:Georgia,serif;font-size:13px;color:#1f2933">{e["nome"]}'
                 + (f'<span style="color:#9aa4b2"> — {cargo_empresa}</span>' if cargo_empresa else "") + "</div>"},
    ]


def pagina_de_previa(trecho, escuro=False):
    fundo, cor = ("#141823", "#e6e9f0") if escuro else ("#ffffff", "#1f2933")
    politica = ("<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; img-src data: https: http:; "
                "style-src 'unsafe-inline'\">")
    return (f"<!DOCTYPE html><html><head><meta charset=\"utf-8\">{politica}<style>body{{margin:0;padding:16px;background:{fundo};"
            f"color:{cor};font-family:Arial,sans-serif}}</style></head><body>{trecho}</body></html>")


def assunto_resposta(assunto, prefixo="Re:"):
    base = re.sub(r"^\s*((re|res|enc|fwd?|tr)\s*:\s*)+", "", assunto or "", flags=re.IGNORECASE)
    return f"{prefixo} {base}".strip()


def citacao(msg):
    texto, html_ = corpos(msg)
    if not texto and html_:
        texto = html_para_texto(html_)
    texto = re.sub(r"\n{3,}", "\n\n", texto.strip())
    remetente = (enderecos(msg["From"]) or [{"nome": "", "email": ""}])[0]
    quem = remetente["nome"] or remetente["email"]
    try:
        quando = parsedate_to_datetime(msg["Date"]).strftime("%d/%m/%Y, às %H:%M")
    except Exception:  # noqa: BLE001
        quando = ""
    cabecalho = f"Em {quando}, {quem} escreveu:" if quando else f"{quem} escreveu:"
    return cabecalho + "\n" + "\n".join("> " + l for l in texto.split("\n"))


def rascunho_de_resposta(msg, meu_email, todos=False):
    """Campos iniciais da janela Escrever para responder."""
    responder_para = msg["Reply-To"] or msg["From"]
    para = [e for e in enderecos(responder_para)]
    cc = []
    if todos:
        outros = enderecos(msg["To"]) + enderecos(msg["Cc"])
        vistos = {p["email"].lower() for p in para} | {meu_email.lower()}
        for e in outros:
            if e["email"].lower() not in vistos:
                vistos.add(e["email"].lower())
                cc.append(e)
    formatar = lambda lista: ", ".join(formataddr((e["nome"], e["email"])) if e["nome"] else e["email"] for e in lista)  # noqa: E731
    return {"para": formatar(para), "cc": formatar(cc), "assunto": assunto_resposta(decodificar(msg["Subject"])),
            "corpo": "\n\n" + citacao(msg), "citacao": citacao(msg), "em_resposta_a": (msg["Message-ID"] or "").strip(),
            "referencias": (msg["References"] or "").strip()}


def rascunho_de_encaminhamento(msg):
    texto, html_ = corpos(msg)
    if not texto and html_:
        texto = html_para_texto(html_)
    cabecalho = ("\n\n---------- Mensagem encaminhada ----------\n"
                 f"De: {decodificar(msg['From'])}\nData: {msg['Date'] or ''}\nAssunto: {decodificar(msg['Subject'])}\n"
                 f"Para: {decodificar(msg['To'])}\n\n")
    return {"para": "", "cc": "", "assunto": assunto_resposta(decodificar(msg["Subject"]), "Enc:"),
            "corpo": cabecalho + texto.strip(), "em_resposta_a": "", "referencias": ""}
