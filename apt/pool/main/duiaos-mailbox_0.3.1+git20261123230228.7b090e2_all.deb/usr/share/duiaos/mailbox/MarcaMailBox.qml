// DuiaOS — Mail Box: a marca (o quadrado aurora com o envelope e o aviso), desenhada no QML para ser animada.
// envelope (0 a 1): o envelope subindo para o lugar; aba (0 a 1): a aba do envelope sendo traçada;
// ponto (0 a 1): o aviso de mensagem nova aparecendo — usados na apresentação.
import QtQuick

Item {
    id: marca
    property real tamanho: 32
    property real envelope: 1
    property real aba: 1
    property real ponto: 1
    width: tamanho; height: tamanho

    Rectangle {
        anchors.fill: parent
        radius: width * 0.22
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: "#22D3EE" }
            GradientStop { position: 0.55; color: "#3D5BFF" }
            GradientStop { position: 1; color: "#7C3AED" }
        }
    }
    Canvas {
        id: desenho
        anchors.fill: parent
        property real envelope: marca.envelope
        property real aba: marca.aba
        onEnvelopeChanged: requestPaint()
        onAbaChanged: requestPaint()
        onWidthChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            c.reset()
            var s = width / 128
            var dy = (1 - envelope) * 30 * s
            c.globalAlpha = Math.min(1, envelope * 1.4)
            c.lineWidth = 5 * s
            c.lineJoin = "round"; c.lineCap = "round"
            c.strokeStyle = "white"
            c.fillStyle = Qt.rgba(1, 1, 1, 0.16)
            // corpo do envelope (retângulo de cantos arredondados)
            var x = 28 * s, y = 38 * s + dy, w = 72 * s, h = 52 * s, r = 10 * s
            c.beginPath()
            c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.arcTo(x + w, y, x + w, y + r, r)
            c.lineTo(x + w, y + h - r); c.arcTo(x + w, y + h, x + w - r, y + h, r)
            c.lineTo(x + r, y + h); c.arcTo(x, y + h, x, y + h - r, r)
            c.lineTo(x, y + r); c.arcTo(x, y, x + r, y, r)
            c.closePath(); c.fill(); c.stroke()
            // a aba: das duas pontas até o meio
            if (aba > 0) {
                var meioX = 64 * s, meioY = 68 * s + dy
                c.beginPath()
                c.moveTo(31 * s, 43 * s + dy); c.lineTo(31 * s + (meioX - 31 * s) * aba, 43 * s + dy + (meioY - 43 * s - dy) * aba)
                c.moveTo(97 * s, 43 * s + dy); c.lineTo(97 * s + (meioX - 97 * s) * aba, 43 * s + dy + (meioY - 43 * s - dy) * aba)
                c.stroke()
            }
        }
    }
    Rectangle {          // o aviso de mensagem nova
        readonly property real s: marca.width / 128
        width: 18 * s; height: width; radius: width / 2
        x: 96 * s - width / 2; y: 38 * s - height / 2
        color: "white"
        scale: marca.ponto
    }
}
