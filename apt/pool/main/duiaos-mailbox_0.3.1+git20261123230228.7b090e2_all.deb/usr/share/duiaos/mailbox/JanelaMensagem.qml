// DuiaOS — Mail Box: uma mensagem numa janela só dela (duplo clique na lista), com as ações de responder,
// encaminhar, arquivar e apagar. O conteúdo é mostrado como na área de leitura: sem JavaScript e com as
// imagens externas bloqueadas até a pessoa permitir.
import QtQuick
import QtQuick.Window
import QtWebEngine
import DuiaOS

Window {
    id: janelaMensagem
    // Voltando de outro programa (Alt+Tab), a página do e-mail podia aparecer preta até rolar: 1 px de ajuste
    // por um instante obriga o Chromium a desenhar um quadro novo (ADR 077)
    property int ajusteWeb: 0
    Timer { id: tempoAjusteWeb; interval: 60; onTriggered: ajusteWeb = 0 }
    function redesenharWeb() { ajusteWeb = 1; tempoAjusteWeb.restart() }
    onActiveChanged: if (active) redesenharWeb()
    onVisibilityChanged: if (visibility !== Window.Minimized && visibility !== Window.Hidden) redesenharWeb()
    property int idMensagem: 0
    property bool remoto: false
    property var m: ({})
    readonly property bool pronta: m && m.id !== undefined
    width: 900; height: 760
    minimumWidth: 560; minimumHeight: 420
    visible: true
    color: Tema.fundo
    title: (pronta ? m.assunto : "Mensagem") + " — Mail Box"
    function carregar() { m = caixa.dadosDaMensagem(idMensagem, remoto) }
    Component.onCompleted: carregar()
    onClosing: destroy()
    Connections {
        target: caixa
        function onCorpoBaixado(id) { if (id === janelaMensagem.idMensagem) janelaMensagem.carregar() }
    }
    Shortcut { sequences: ["Escape", "Ctrl+W"]; onActivated: janelaMensagem.close() }
    Shortcut { sequences: ["Ctrl+R"]; onActivated: caixa.responder(janelaMensagem.idMensagem, false) }
    Shortcut { sequences: ["Ctrl+Shift+R"]; onActivated: caixa.responder(janelaMensagem.idMensagem, true) }
    Shortcut { sequences: ["Ctrl+Shift+F"]; onActivated: caixa.encaminhar(janelaMensagem.idMensagem) }

    Rectangle {
        id: barra
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: 52
        color: Tema.lateral
        Row {
            anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
            spacing: 4
            Botao { texto: "Responder"; icone: "seta-esquerda"; tipo: "primario"; onClicado: caixa.responder(janelaMensagem.idMensagem, false) }
            BotaoIcone { anchors.verticalCenter: parent.verticalCenter; icone: "responder-todos"; dica: "Responder a todos (Ctrl+Shift+R)"
                         onClicado: caixa.responder(janelaMensagem.idMensagem, true) }
            BotaoIcone { anchors.verticalCenter: parent.verticalCenter; icone: "seta-direita"; dica: "Encaminhar (Ctrl+Shift+F)"
                         onClicado: caixa.encaminhar(janelaMensagem.idMensagem) }
            Rectangle { width: 1; height: 20; color: Tema.borda; anchors.verticalCenter: parent.verticalCenter }
            BotaoIcone { anchors.verticalCenter: parent.verticalCenter; icone: "compactado"; dica: "Arquivar"
                         onClicado: { caixa.arquivar(janelaMensagem.idMensagem); janelaMensagem.close() } }
            BotaoIcone { anchors.verticalCenter: parent.verticalCenter; icone: "lixeira"; dica: "Mover para a Lixeira"
                         onClicado: { caixa.apagar(janelaMensagem.idMensagem); janelaMensagem.close() } }
            BotaoIcone { anchors.verticalCenter: parent.verticalCenter; icone: "olho"; dica: "Marcar como não lida"
                         onClicado: { caixa.marcarLida(janelaMensagem.idMensagem, false); janelaMensagem.close() } }
            BotaoIcone { anchors.verticalCenter: parent.verticalCenter
                         icone: janelaMensagem.pronta && janelaMensagem.m.sinalizada ? "estrela-cheia" : "estrela"
                         corIcone: janelaMensagem.pronta && janelaMensagem.m.sinalizada ? Tema.aviso : Tema.texto
                         dica: janelaMensagem.pronta && janelaMensagem.m.sinalizada ? "Tirar a marca de importante" : "Marcar como importante"
                         onClicado: { caixa.sinalizar(janelaMensagem.idMensagem, !janelaMensagem.m.sinalizada); janelaMensagem.carregar() } }
        }
        Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom } height: 1; color: Tema.borda }
    }
    Text {
        id: assunto
        anchors { left: parent.left; right: parent.right; top: barra.bottom; margins: 24; topMargin: 18 }
        text: janelaMensagem.pronta ? janelaMensagem.m.assunto : ""
        wrapMode: Text.WordWrap; maximumLineCount: 3; elide: Text.ElideRight
        color: Tema.texto; font { family: Tema.fonteTitulo; pixelSize: 22; weight: Font.Bold }
    }
    Column {
        id: cabecalho
        anchors { left: parent.left; right: parent.right; top: assunto.bottom; margins: 24; topMargin: 12 }
        spacing: 3
        Text { width: parent.width; elide: Text.ElideRight; textFormat: Text.StyledText
               text: janelaMensagem.pronta ? "<b>" + (janelaMensagem.m.de_nome || janelaMensagem.m.de_email) + "</b>&nbsp;&nbsp;<font color='"
                                             + Tema.textoSecundario + "'>" + janelaMensagem.m.de_email + "</font>" : ""
               color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
        Text { width: parent.width; elide: Text.ElideRight
               text: janelaMensagem.pronta ? "Para: " + janelaMensagem.m.para + (janelaMensagem.m.cc ? "   Cc: " + janelaMensagem.m.cc : "") : ""
               color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
        Text { text: janelaMensagem.pronta ? new Date(janelaMensagem.m.data * 1000).toLocaleString(Qt.locale("pt_BR"), "dddd, d 'de' MMMM 'de' yyyy, HH:mm") : ""
               color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
    }
    Rectangle {
        id: faixaImagens
        anchors { left: parent.left; right: parent.right; top: cabecalho.bottom; margins: 24; topMargin: 12 }
        height: visible ? 38 : 0
        visible: janelaMensagem.pronta && janelaMensagem.m.bloqueadas > 0 && !janelaMensagem.m.remoto
        radius: 10; color: Tema.destaque
        Icone { id: iconeEscudo; anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter } nome: "escudo"; tamanho: 15; cor: Tema.azulDuia }
        Text { anchors { left: iconeEscudo.right; leftMargin: 10; verticalCenter: parent.verticalCenter }
               text: "Imagens externas bloqueadas para proteger a sua privacidade."; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
        Text { anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
               text: "Mostrar imagens"; color: Tema.azulDuia; font { family: Tema.fonteTexto; pixelSize: 13; weight: Font.DemiBold }
               MouseArea { anchors.fill: parent; anchors.margins: -6; cursorShape: Qt.PointingHandCursor
                           onClicked: { janelaMensagem.remoto = true; janelaMensagem.carregar() } } }
    }
    Flow {
        id: anexos
        anchors { left: parent.left; right: parent.right; top: faixaImagens.visible ? faixaImagens.bottom : cabecalho.bottom; margins: 24; topMargin: 12 }
        spacing: 8
        visible: janelaMensagem.pronta && janelaMensagem.m.anexos.length > 0
        height: visible ? implicitHeight : 0
        Repeater {
            model: janelaMensagem.pronta ? janelaMensagem.m.anexos : []
            delegate: Rectangle {
                required property var modelData
                height: 36; radius: 10
                width: Math.min(260, rotuloAnexo.implicitWidth + 44)
                color: areaAnexo.containsMouse ? Tema.realce : Tema.cartao
                border { width: 1; color: Tema.borda }
                Icone { id: iconeAnexo; anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter } nome: "documento"; tamanho: 15; cor: Tema.azulDuia }
                Text { id: rotuloAnexo; anchors { left: iconeAnexo.right; leftMargin: 8; verticalCenter: parent.verticalCenter }
                       text: modelData.nome; width: Math.min(implicitWidth, 200); elide: Text.ElideMiddle
                       color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 12 } }
                MouseArea { id: areaAnexo; anchors.fill: parent; hoverEnabled: true; onClicked: caixa.abrirAnexo(janelaMensagem.idMensagem, modelData.indice) }
            }
        }
    }
    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; top: anexos.visible ? anexos.bottom : (faixaImagens.visible ? faixaImagens.bottom : cabecalho.bottom)
                  margins: 16; topMargin: 14 }
        radius: Tema.raio
        color: "#ffffff"
        border { width: 1; color: Tema.borda }
        clip: true
        WebEngineView {
            anchors { fill: parent; margins: 1; rightMargin: 1 + ajusteWeb }
            profile: perfilLeitura
            settings.javascriptEnabled: false
            settings.javascriptCanOpenWindows: false
            settings.localContentCanAccessRemoteUrls: false
            settings.localContentCanAccessFileUrls: false
            settings.autoLoadIconsForPage: false
            backgroundColor: "white"
            property string conteudo: janelaMensagem.pronta ? janelaMensagem.m.html : ""
            onConteudoChanged: loadHtml(conteudo, "about:blank")
            onNavigationRequested: (pedido) => {
                if (pedido.navigationType === WebEngineNavigationRequest.LinkClickedNavigation) { pedido.reject(); caixa.abrirLink(pedido.url.toString()) }
            }
            onNewWindowRequested: (pedido) => caixa.abrirLink(pedido.requestedUrl.toString())
            onContextMenuRequested: (pedido) => { pedido.accepted = pedido.linkUrl.toString() === "" && pedido.selectedText === "" }
        }
        Text { anchors.centerIn: parent; visible: janelaMensagem.pronta && janelaMensagem.m.carregando
               text: "Baixando a mensagem…"; color: "#5B6675"; font { family: Tema.fonteTexto; pixelSize: 14 } }
    }
}
