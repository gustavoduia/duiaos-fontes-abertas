"""DuiaOS — Mail Box: importar as contas de outro programa de e-mail (primeira abertura e Contas).

Lê as contas do Thunderbird (prefs.js do perfil mais recente; também o do Flathub): nome, endereço e servidores de
entrada e de envio. Senhas não são importadas (ficam cifradas no Thunderbird): a pessoa digita a senha no wizard,
que já vem com o endereço e os servidores preenchidos. Para provedores do catálogo (Gmail, Outlook...), vale a
configuração do catálogo, que sabe da senha de app e do OAuth.
"""
import re
from pathlib import Path

import provedores

PASTAS_THUNDERBIRD = (".thunderbird", ".var/app/org.mozilla.Thunderbird/.thunderbird",
                      ".var/app/org.mozilla.thunderbird/.thunderbird", "snap/thunderbird/common/.thunderbird")
_PREF = re.compile(r'^user_pref\("([^"]+)",\s*(.+?)\);\s*$')
# socketType do Thunderbird: 0 nenhuma, 2 STARTTLS, 3 SSL/TLS
_SEGURANCA = {"0": "nenhuma", "1": "nenhuma", "2": "starttls", "3": "ssl"}


def ler_prefs(texto):
    """prefs.js → {chave: valor} (texto sem as aspas, números como texto)."""
    valores = {}
    for linha in texto.splitlines():
        achado = _PREF.match(linha.strip())
        if achado:
            valor = achado.group(2).strip()
            if valor.startswith('"') and valor.endswith('"'):
                valor = valor[1:-1].replace('\\"', '"').replace("\\\\", "\\")
            valores[achado.group(1)] = valor
    return valores


def contas_do_thunderbird(prefs):
    """Contas de e-mail de um prefs.js já lido: [{"nome", "email", "config"}] (sem as de feeds e as locais)."""
    contas = []
    for id_conta in [c.strip() for c in prefs.get("mail.accountmanager.accounts", "").split(",") if c.strip()]:
        servidor = prefs.get(f"mail.account.{id_conta}.server", "")
        tipo = prefs.get(f"mail.server.{servidor}.type", "")
        if tipo not in ("imap", "pop3"):
            continue
        identidade = prefs.get(f"mail.account.{id_conta}.identities", "").split(",")[0].strip()
        email = prefs.get(f"mail.identity.{identidade}.useremail", "").strip()
        if not email or "@" not in email:
            continue
        nome = prefs.get(f"mail.identity.{identidade}.fullName", "").strip()
        padrao_porta = {"imap": {"ssl": 993, "starttls": 143, "nenhuma": 143}, "pop3": {"ssl": 995, "starttls": 110, "nenhuma": 110}}
        seguranca = _SEGURANCA.get(prefs.get(f"mail.server.{servidor}.socketType", "3"), "ssl")
        entrada = {"tipo": tipo, "host": prefs.get(f"mail.server.{servidor}.hostname", ""),
                   "porta": int(prefs.get(f"mail.server.{servidor}.port", padrao_porta[tipo][seguranca])),
                   "seguranca": seguranca, "usuario": prefs.get(f"mail.server.{servidor}.userName", email)}
        smtp = prefs.get(f"mail.identity.{identidade}.smtpServer", "") or prefs.get("mail.smtp.defaultserver", "")
        seg_saida = _SEGURANCA.get(prefs.get(f"mail.smtpserver.{smtp}.try_ssl", "3"), "ssl")
        saida = {"tipo": "smtp", "host": prefs.get(f"mail.smtpserver.{smtp}.hostname", ""),
                 "porta": int(prefs.get(f"mail.smtpserver.{smtp}.port", {"ssl": 465}.get(seg_saida, 587))),
                 "seguranca": seg_saida, "usuario": prefs.get(f"mail.smtpserver.{smtp}.username", email)}
        chave = provedores.por_dominio(email.rpartition("@")[2])
        if chave:
            config = provedores.configuracao(chave, email)
        elif entrada["host"] and saida["host"]:
            config = {"provedor": "", "nome_provedor": "", "entrada": entrada, "saida": saida, "autenticacao": "senha",
                      "salva_enviados": False, "pastas": {}, "verificar_certificado": True}
        else:
            continue
        contas.append({"nome": nome, "email": email, "config": config, "origem": "Thunderbird"})
    return contas


def perfil_thunderbird(casa=None):
    """prefs.js do perfil do Thunderbird usado por último (ou None)."""
    casa = Path(casa or Path.home())
    achados = []
    for pasta in PASTAS_THUNDERBIRD:
        achados.extend((casa / pasta).glob("*/prefs.js"))
    if not achados:
        return None
    return max(achados, key=lambda p: p.stat().st_mtime)


def contas_para_importar(casa=None, ja_tem=()):
    """Contas de outros programas que ainda não estão no Mail Box."""
    prefs = perfil_thunderbird(casa)
    if not prefs:
        return []
    try:
        texto = prefs.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    ja_tem = {e.lower() for e in ja_tem}
    return [c for c in contas_do_thunderbird(ler_prefs(texto)) if c["email"].lower() not in ja_tem]
