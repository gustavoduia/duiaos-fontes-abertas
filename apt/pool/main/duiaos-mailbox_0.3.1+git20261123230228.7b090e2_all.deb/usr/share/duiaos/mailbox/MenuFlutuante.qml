// DuiaOS — Mail Box: menu flutuante (botão direito nas mensagens e nas pastas), em português.
// abrir(x, y, itens): itens = [{ id, texto, icone, atalho, ativo }] ou { separador: true }; escolhido(id) volta.
import QtQuick
import DuiaOS

Item {
    id: menu
    anchors.fill: parent
    visible: false
    z: 80
    property var itens: []
    signal escolhido(string id)

    property real pedidoX: 0
    property real pedidoY: 0
    function abrir(px, py, lista) {
        pedidoX = px; pedidoY = py
        itens = lista
        visible = true
        caixa.forceActiveFocus()
    }
    function fechar() { visible = false }

    MouseArea { anchors.fill: parent; acceptedButtons: Qt.AllButtons; onPressed: menu.fechar() }
    Rectangle {
        id: caixa
        // Fica inteiro na janela: abre para cima ou para a esquerda quando não cabe
        x: Math.max(6, menu.pedidoX + width > menu.width - 6 ? menu.pedidoX - width : menu.pedidoX)
        y: Math.max(6, menu.pedidoY + height > menu.height - 6 ? Math.max(6, menu.pedidoY - height) : menu.pedidoY)
        width: 300
        height: Math.min(menu.height - 12, coluna.implicitHeight + 12)
        radius: 12
        color: Tema.cartao
        border { color: Tema.borda; width: 1 }
        Keys.onEscapePressed: menu.fechar()
        MouseArea { anchors.fill: parent; acceptedButtons: Qt.AllButtons }
        Flickable {
            anchors { fill: parent; margins: 6 }
            contentHeight: coluna.implicitHeight
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            Column {
                id: coluna
                width: parent.width
                Repeater {
                    model: menu.itens
                    delegate: Loader {
                        required property var modelData
                        width: coluna.width
                        sourceComponent: modelData.separador ? separador : item
                        Component { id: separador; Item { height: 9; Rectangle { anchors.centerIn: parent; width: parent.width - 12; height: 1; color: Tema.borda } } }
                        Component {
                            id: item
                            ItemDeMenu {
                                texto: modelData.texto; icone: modelData.icone || ""; atalho: modelData.atalho || ""
                                ativo: modelData.ativo !== false
                                onClicado: { menu.fechar(); menu.escolhido(modelData.id) }
                            }
                        }
                    }
                }
            }
        }
    }
}
