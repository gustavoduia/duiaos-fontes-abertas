// DuiaOS — Mail Box: Configurações (ADR 076). Geral, Leitura e privacidade, Contas (identidade, servidores de
// recebimento e de envio, senhas, teste da conexão), Assinaturas (texto ou HTML, com modelos e prévia) e Pastas
// (criar, renomear e apagar).
import QtQuick
import QtQuick.Window
import QtWebEngine
import DuiaOS

Rectangle {
    id: config
    property string secao: "geral"
    signal fechar()
    signal adicionarConta()
    color: Tema.fundo
    readonly property var prefs: caixa.preferencias
    property string contaEscolhida: caixa.contasLista.length ? caixa.contasLista[0].id : ""
    Keys.onEscapePressed: config.fechar()
    focus: true
    MouseArea { anchors.fill: parent }

    // ------------------------------------------------------------ componentes
    component Secao: Column {
        property string nome: ""
        property string descricao: ""
        default property alias itens: colunaSecao.data
        width: parent ? parent.width : 0
        spacing: 8
        Text { text: nome; color: Tema.texto; topPadding: 8; font { family: Tema.fonteTitulo; pixelSize: 15; weight: Font.Bold } }
        Text { visible: descricao !== ""; width: parent.width; text: descricao; wrapMode: Text.WordWrap; color: Tema.textoSecundario
               font { family: Tema.fonteTexto; pixelSize: 12 } }
        Cartao {
            width: parent.width
            height: colunaSecao.implicitHeight + 28
            Column { id: colunaSecao; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 } spacing: 10 }
        }
    }
    component LinhaInterruptor: Item {
        property string texto: ""
        property string descricao: ""
        property bool ligado: false
        signal alternado(bool ligado)
        width: parent ? parent.width : 0
        height: Math.max(40, colunaTexto.implicitHeight + 10)
        Column {
            id: colunaTexto
            anchors { left: parent.left; right: chave.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 2
            Text { width: parent.width; text: texto; color: Tema.texto; wrapMode: Text.WordWrap; font { family: Tema.fonteTexto; pixelSize: 14 } }
            Text { width: parent.width; visible: descricao !== ""; text: descricao; color: Tema.textoSecundario; wrapMode: Text.WordWrap
                   font { family: Tema.fonteTexto; pixelSize: 12 } }
        }
        Interruptor { id: chave; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                      ligado: parent.ligado; onAlternado: (v) => parent.alternado(v) }
    }
    component Pilulas: Flow {
        property var opcoes: []           // [[valor, rótulo]]
        property var valor
        signal escolhido(var valor)
        width: parent ? parent.width : 0
        spacing: 6
        Repeater {
            model: parent.opcoes
            delegate: Rectangle {
                required property var modelData
                readonly property bool marcada: parent.valor === modelData[0]
                width: rotulo.implicitWidth + 26; height: 32; radius: 16
                color: marcada ? Tema.destaque : (area.containsMouse ? Tema.realce : "transparent")
                border { width: 1; color: marcada ? Tema.azulDuia : Tema.borda }
                Text { id: rotulo; anchors.centerIn: parent; text: modelData[1]; color: parent.marcada ? Tema.azulDuia : Tema.texto
                       font { family: Tema.fonteTexto; pixelSize: 13; weight: parent.marcada ? Font.DemiBold : Font.Normal } }
                MouseArea { id: area; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: parent.parent.escolhido(modelData[0]) }
            }
        }
    }
    component Rotulado: Column {
        property string rotulo: ""
        default property alias conteudo: espaco.data
        spacing: 4
        Text { text: rotulo; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
        Item { id: espaco; width: parent.width; height: childrenRect.height }
    }
    component EscolhaDeConta: Flow {
        width: parent ? parent.width : 0
        spacing: 6
        visible: caixa.contasLista.length > 1
        Repeater {
            model: caixa.contasLista
            delegate: Rectangle {
                required property var modelData
                readonly property bool marcada: config.contaEscolhida === modelData.id
                width: rotuloConta.implicitWidth + 26; height: 32; radius: 16
                color: marcada ? Tema.destaque : "transparent"
                border { width: 1; color: marcada ? Tema.azulDuia : Tema.borda }
                Text { id: rotuloConta; anchors.centerIn: parent; text: modelData.email; color: parent.marcada ? Tema.azulDuia : Tema.texto
                       font { family: Tema.fonteTexto; pixelSize: 13; weight: parent.marcada ? Font.DemiBold : Font.Normal } }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: config.contaEscolhida = modelData.id }
            }
        }
    }

    // ------------------------------------------------------------ lateral
    Rectangle {
        id: lateral
        anchors { left: parent.left; top: parent.top; bottom: parent.bottom }
        width: 240
        color: Tema.lateral
        Column {
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12; topMargin: 18 }
            spacing: 2
            Text { leftPadding: 8; bottomPadding: 14; text: "Configurações"; color: Tema.texto
                   font { family: Tema.fonteTitulo; pixelSize: 20; weight: Font.Bold } }
            Repeater {
                model: [{ id: "geral", nome: "Geral", icone: "engrenagem" }, { id: "privacidade", nome: "Leitura e privacidade", icone: "escudo" },
                        { id: "contas", nome: "Contas", icone: "usuario" }, { id: "assinaturas", nome: "Assinaturas", icone: "lapis" },
                        { id: "pastas", nome: "Pastas", icone: "pasta" }]
                delegate: Rectangle {
                    required property var modelData
                    readonly property bool marcada: config.secao === modelData.id
                    width: parent.width; height: 38; radius: 9
                    color: marcada ? Tema.selecao : (areaSecao.containsMouse ? Tema.realce : "transparent")
                    Icone { id: iconeSecao; anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                            nome: modelData.icone; tamanho: 16; cor: parent.marcada ? Tema.azulDuia : Tema.textoSecundario }
                    Text { anchors { left: iconeSecao.right; leftMargin: 12; verticalCenter: parent.verticalCenter }
                           text: modelData.nome; color: parent.marcada ? Tema.azulDuia : Tema.texto
                           font { family: Tema.fonteTexto; pixelSize: 14; weight: parent.marcada ? Font.DemiBold : Font.Normal } }
                    MouseArea { id: areaSecao; anchors.fill: parent; hoverEnabled: true; onClicked: config.secao = modelData.id }
                }
            }
        }
        Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: Tema.borda }
    }
    BotaoIcone {
        anchors { right: parent.right; top: parent.top; margins: 14 }
        z: 5
        icone: "fechar"; dica: "Fechar as configurações (Esc)"
        onClicado: config.fechar()
    }

    Flickable {
        id: rolagem
        anchors { left: lateral.right; right: parent.right; top: parent.top; bottom: parent.bottom }
        contentHeight: coluna.implicitHeight + 60
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        Column {
            id: coluna
            width: Math.min(rolagem.width - 64, 720)
            x: 32; y: 24
            spacing: 18

            Text { text: ({ geral: "Geral", privacidade: "Leitura e privacidade", contas: "Contas", assinaturas: "Assinaturas", pastas: "Pastas" })[config.secao]
                   color: Tema.texto; font { family: Tema.fonteTitulo; pixelSize: 24; weight: Font.Bold } }

            // ================================================== Geral
            Column {
                visible: config.secao === "geral"
                width: parent.width; spacing: 18
                Secao {
                    nome: "Mensagens novas"
                    Text { text: "Procurar mensagens novas a cada"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
                    Pilulas { opcoes: [[1, "1 minuto"], [3, "3 minutos"], [5, "5 minutos"], [10, "10 minutos"], [15, "15 minutos"], [30, "30 minutos"]]
                              valor: config.prefs.intervalo_minutos; onEscolhido: (v) => caixa.definirPreferencia("intervalo_minutos", v) }
                    LinhaInterruptor { texto: "Avisar das mensagens novas"; descricao: "Na hora em que chegam, nas notificações do DuiaOS, com o remetente e o assunto; clicar abre a mensagem"
                                       ligado: config.prefs.notificar === true; onAlternado: (v) => caixa.definirPreferencia("notificar", v) }
                    LinhaInterruptor { texto: "Mostrar as não lidas no ícone"; descricao: "Um balão vermelho com o número no ícone do Mail Box, na Ilha de Aplicativos"
                                       ligado: config.prefs.contador_no_icone === true; onAlternado: (v) => caixa.definirPreferencia("contador_no_icone", v) }
                }
                Secao {
                    nome: "Lendo as mensagens"
                    Text { text: "Marcar como lida"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
                    Pilulas { opcoes: [["ao_abrir", "Ao abrir"], ["depois_de_3s", "Depois de 3 segundos aberta"], ["nunca", "Só quando eu marcar"]]
                              valor: config.prefs.marcar_lida; onEscolhido: (v) => caixa.definirPreferencia("marcar_lida", v) }
                    Text { text: "Duplo clique numa mensagem"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
                    Pilulas { opcoes: [["janela", "Abre a mensagem numa janela"], ["responder", "Abre a resposta"]]
                              valor: config.prefs.duplo_clique; onEscolhido: (v) => caixa.definirPreferencia("duplo_clique", v) }
                }
                Secao {
                    id: secaoPadrao
                    nome: "Programa de e-mail padrão"
                    property bool padrao: caixa.ehPadrao()
                    Item {
                        width: parent.width; height: 40
                        Text { anchors { left: parent.left; right: botaoPadrao.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                               wrapMode: Text.WordWrap
                               text: secaoPadrao.padrao ? "O Mail Box abre os links de e-mail (mailto) dos sites e documentos."
                                                                        : "Outro programa abre os links de e-mail."
                               color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
                        Botao { id: botaoPadrao; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                                visible: !secaoPadrao.padrao; texto: "Usar o Mail Box"; tipo: "primario"
                                onClicado: { caixa.tornarPadrao(); secaoPadrao.padrao = true } }
                    }
                }
            }

            // ================================================== Leitura e privacidade
            Column {
                visible: config.secao === "privacidade"
                width: parent.width; spacing: 18
                Secao {
                    nome: "Imagens de fora da mensagem"
                    descricao: "Imagens carregadas da internet avisam ao remetente que você abriu a mensagem (e quando, e de onde). Bloqueadas, elas só aparecem quando você clica em \"Mostrar imagens\"."
                    Pilulas { opcoes: [["perguntar", "Bloquear até eu permitir (recomendado)"], ["sempre", "Sempre mostrar"]]
                              valor: config.prefs.imagens_externas; onEscolhido: (v) => caixa.definirPreferencia("imagens_externas", v) }
                }
                Secao {
                    nome: "Proteções que ficam sempre ligadas"
                    Repeater {
                        model: ["As mensagens abrem sem JavaScript, formulários nem programas embutidos.",
                                "Links abrem no navegador, nunca dentro do Mail Box.",
                                "As senhas ficam no cofre do sistema (o mesmo das outras senhas do DuiaOS), nunca em arquivos."]
                        delegate: Row {
                            required property var modelData
                            width: parent.width; spacing: 10
                            Icone { nome: "check"; tamanho: 15; cor: Tema.sucesso }
                            Text { width: parent.width - 30; text: modelData; wrapMode: Text.WordWrap; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
                        }
                    }
                }
            }

            // ================================================== Contas
            Column {
                id: secaoContas
                visible: config.secao === "contas"
                width: parent.width; spacing: 14
                property var c: ({})
                property string resultadoTeste: ""
                property bool testando: false
                property bool testeOk: false
                function carregar() {
                    c = config.contaEscolhida ? caixa.contaCompleta(config.contaEscolhida) : ({})
                    if (!c.email) return
                    nomeConta.texto = c.nome || ""
                    hostEntrada.texto = c.entrada.host; portaEntrada.texto = String(c.entrada.porta); usuarioEntrada.texto = c.entrada.usuario || c.email
                    tipoEntrada.valor = c.entrada.tipo; segEntrada.valor = c.entrada.seguranca
                    hostSaida.texto = c.saida.host; portaSaida.texto = String(c.saida.porta); usuarioSaida.texto = c.saida.usuario || c.email
                    segSaida.valor = c.saida.seguranca
                    senhaEntrada.texto = ""; senhaSaida.texto = ""
                    mesmaSenha.ligado = !c.tem_senha_saida
                    certificado.ligado = c.verificar_certificado !== false
                    resultadoTeste = ""
                }
                function dados() {
                    return { nome: nomeConta.texto,
                             entrada: { tipo: tipoEntrada.valor, host: hostEntrada.texto, porta: parseInt(portaEntrada.texto) || 0,
                                        seguranca: segEntrada.valor, usuario: usuarioEntrada.texto },
                             saida: { tipo: "smtp", host: hostSaida.texto, porta: parseInt(portaSaida.texto) || 0,
                                      seguranca: segSaida.valor, usuario: usuarioSaida.texto },
                             verificar_certificado: certificado.ligado, senha_entrada: senhaEntrada.texto,
                             senha_saida: mesmaSenha.ligado ? "" : senhaSaida.texto, mesma_senha: mesmaSenha.ligado }
                }
                Connections { target: config; function onContaEscolhidaChanged() { secaoContas.carregar() } }
                Connections { target: caixa; function onTesteConfiguracao(ok, texto) { secaoContas.testando = false; secaoContas.testeOk = ok
                                                                                        secaoContas.resultadoTeste = ok ? "Recebimento e envio funcionando." : texto } }
                Component.onCompleted: carregar()
                onVisibleChanged: if (visible) carregar()

                Row {
                    width: parent.width; spacing: 10
                    EscolhaDeConta { width: parent.width - botaoNovaConta.width - 10 }
                    Botao { id: botaoNovaConta; texto: "Adicionar conta"; icone: "mais"; onClicado: config.adicionarConta() }
                }
                Text { visible: !secaoContas.c.email; text: "Nenhuma conta ainda."; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 14 } }
                Column {
                    visible: !!secaoContas.c.email
                    width: parent.width; spacing: 14
                    Secao {
                        nome: "Identidade"
                        Rotulado { width: parent.width; rotulo: "Seu nome (como as pessoas veem)"
                                   Campo { id: nomeConta; width: parent.width; height: 36; icone: "usuario" } }
                        Text { text: "E-mail: " + (secaoContas.c.email || "") + (secaoContas.c.nome_provedor ? "  ·  " + secaoContas.c.nome_provedor : "")
                               color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 13 } }
                    }
                    Secao {
                        nome: "Recebimento"
                        descricao: "Servidor de onde as mensagens chegam."
                        Pilulas { id: tipoEntrada; opcoes: [["imap", "IMAP (recomendado)"], ["pop3", "POP3"]]; onEscolhido: (v) => valor = v }
                        Row {
                            width: parent.width; spacing: 10
                            Rotulado { width: parent.width - 130; rotulo: "Servidor"; Campo { id: hostEntrada; width: parent.width; height: 36; icone: "globo" } }
                            Rotulado { width: 120; rotulo: "Porta"; Campo { id: portaEntrada; width: parent.width; height: 36 } }
                        }
                        Text { text: "Segurança"; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                        Pilulas { id: segEntrada; opcoes: [["ssl", "SSL/TLS"], ["starttls", "STARTTLS"], ["nenhuma", "Nenhuma"]]; onEscolhido: (v) => valor = v }
                        Row {
                            width: parent.width; spacing: 10
                            Rotulado { width: (parent.width - 10) / 2; rotulo: "Usuário"; Campo { id: usuarioEntrada; width: parent.width; height: 36 } }
                            Rotulado { width: (parent.width - 10) / 2
                                       rotulo: secaoContas.c.autenticacao === "senha_de_app" ? "Senha de app (deixe vazio para manter a guardada)" : "Senha (deixe vazio para manter a guardada)"
                                       Campo { id: senhaEntrada; width: parent.width; height: 36; senha: true; icone: "cadeado"
                                               dica: secaoContas.c.tem_senha_entrada ? "•••••••• guardada" : "Nenhuma senha guardada" } }
                        }
                    }
                    Secao {
                        nome: "Envio (SMTP)"
                        descricao: "Servidor que manda as suas mensagens. Quase sempre pede login, com o mesmo usuário e a mesma senha do recebimento."
                        Row {
                            width: parent.width; spacing: 10
                            Rotulado { width: parent.width - 130; rotulo: "Servidor"; Campo { id: hostSaida; width: parent.width; height: 36; icone: "globo" } }
                            Rotulado { width: 120; rotulo: "Porta"; Campo { id: portaSaida; width: parent.width; height: 36 } }
                        }
                        Text { text: "Segurança"; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                        Pilulas { id: segSaida; opcoes: [["ssl", "SSL/TLS (porta 465)"], ["starttls", "STARTTLS (porta 587)"], ["nenhuma", "Nenhuma"]]
                                  onEscolhido: (v) => { valor = v; if (v === "ssl" && portaSaida.texto === "587") portaSaida.texto = "465"
                                                        else if (v === "starttls" && portaSaida.texto === "465") portaSaida.texto = "587" } }
                        Rotulado { width: parent.width; rotulo: "Usuário"; Campo { id: usuarioSaida; width: parent.width; height: 36 } }
                        LinhaInterruptor { id: mesmaSenha; texto: "Usar a mesma senha do recebimento"; onAlternado: (v) => ligado = v }
                        Rotulado { visible: !mesmaSenha.ligado; width: parent.width; rotulo: "Senha do envio"
                                   Campo { id: senhaSaida; width: parent.width; height: 36; senha: true; icone: "cadeado"
                                           dica: secaoContas.c.tem_senha_saida ? "•••••••• guardada" : "Senha do servidor de envio" } }
                    }
                    Secao {
                        nome: "Avançado"
                        LinhaInterruptor { id: certificado; texto: "Conferir o certificado do servidor"
                                           descricao: "Desligue só para servidores próprios com certificado feito em casa"; onAlternado: (v) => ligado = v }
                    }
                    Rectangle {
                        visible: secaoContas.resultadoTeste !== "" || secaoContas.testando
                        width: parent.width; height: textoTeste.implicitHeight + 20; radius: 10
                        color: secaoContas.testando ? Tema.destaque : (secaoContas.testeOk ? Qt.rgba(0.13, 0.7, 0.4, 0.14) : Qt.rgba(0.9, 0.2, 0.2, 0.12))
                        Text { id: textoTeste; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 12 }
                               wrapMode: Text.WordWrap
                               text: secaoContas.testando ? "Testando o recebimento e o envio…" : secaoContas.resultadoTeste
                               color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 } }
                    }
                    Item {
                        width: parent.width; height: 40
                        Botao { anchors.left: parent.left; texto: "Remover a conta"; tipo: "perigo"
                                onClicado: { caixa.removerConta(config.contaEscolhida); config.contaEscolhida = caixa.contasLista.length ? caixa.contasLista[0].id : "" } }
                        Row {
                            anchors.right: parent.right; spacing: 8
                            Botao { texto: "Testar a conexão"; ativo: !secaoContas.testando
                                    onClicado: { secaoContas.testando = true; secaoContas.resultadoTeste = ""; caixa.testarConfiguracao(config.contaEscolhida, secaoContas.dados()) } }
                            Botao { texto: "Salvar"; tipo: "primario"; onClicado: caixa.salvarConfiguracaoConta(config.contaEscolhida, secaoContas.dados()) }
                        }
                    }
                }
            }

            // ================================================== Assinaturas
            Column {
                id: secaoAssinaturas
                visible: config.secao === "assinaturas"
                width: parent.width; spacing: 14
                property var c: ({})
                property string tipo: "texto"
                property var modelos: []
                function carregar() {
                    c = config.contaEscolhida ? caixa.contaCompleta(config.contaEscolhida) : ({})
                    if (!c.email) return
                    tipo = (c.assinatura_tipo === "html" && c.assinatura_html) ? "html" : (c.assinatura ? "texto" : (c.assinatura_tipo === "html" ? "html" : "nenhuma"))
                    textoAssinatura.text = c.assinatura || ""
                    codigoHtml.text = c.assinatura_html || ""
                    respostas.ligado = c.assinatura_respostas !== false
                    posicao.valor = c.assinatura_posicao || "abaixo"
                    atualizarModelos()
                }
                function atualizarModelos() {
                    modelos = caixa.modelosDeAssinatura(config.contaEscolhida, { nome: (c.nome || ""), cargo: cargo.texto, empresa: empresa.texto,
                                                                                 telefone: telefone.texto, site: site.texto })
                }
                Connections { target: config; function onContaEscolhidaChanged() { secaoAssinaturas.carregar() } }
                Component.onCompleted: carregar()
                onVisibleChanged: if (visible) carregar()

                EscolhaDeConta { }
                Secao {
                    nome: "Tipo de assinatura"
                    Pilulas { opcoes: [["nenhuma", "Nenhuma"], ["texto", "Texto"], ["html", "HTML (com formatação, cores e logotipo)"]]
                              valor: secaoAssinaturas.tipo; onEscolhido: (v) => secaoAssinaturas.tipo = v }
                }
                Secao {
                    visible: secaoAssinaturas.tipo === "texto"
                    nome: "Assinatura em texto"
                    descricao: "Vai no fim das mensagens, depois de \"-- \" (o separador que os programas de e-mail reconhecem)."
                    Rectangle {
                        width: parent.width; height: 140; radius: 10
                        color: Tema.cartao; border { width: textoAssinatura.activeFocus ? 2 : 1; color: textoAssinatura.activeFocus ? Tema.azulDuia : Tema.borda }
                        Flickable {
                            anchors { fill: parent; margins: 10 }
                            contentHeight: textoAssinatura.paintedHeight; clip: true
                            TextEdit { id: textoAssinatura; width: parent.width; wrapMode: TextEdit.Wrap; color: Tema.texto; selectByMouse: true
                                       selectionColor: Tema.azulDuia; font { family: Tema.fonteTexto; pixelSize: 14 }
                                       Keys.onTabPressed: (e) => { nextItemInFocusChain(true).forceActiveFocus(); e.accepted = true } }
                        }
                    }
                }
                Secao {
                    visible: secaoAssinaturas.tipo === "html"
                    nome: "Modelos"
                    descricao: "Preencha os dados e escolha um modelo. Depois dá para ajustar o código HTML à vontade."
                    Row {
                        width: parent.width; spacing: 10
                        Rotulado { width: (parent.width - 10) / 2; rotulo: "Cargo"; Campo { id: cargo; width: parent.width; height: 34; onTextoChanged: secaoAssinaturas.atualizarModelos() } }
                        Rotulado { width: (parent.width - 10) / 2; rotulo: "Empresa"; Campo { id: empresa; width: parent.width; height: 34; onTextoChanged: secaoAssinaturas.atualizarModelos() } }
                    }
                    Row {
                        width: parent.width; spacing: 10
                        Rotulado { width: (parent.width - 10) / 2; rotulo: "Telefone"; Campo { id: telefone; width: parent.width; height: 34; onTextoChanged: secaoAssinaturas.atualizarModelos() } }
                        Rotulado { width: (parent.width - 10) / 2; rotulo: "Site"; Campo { id: site; width: parent.width; height: 34; onTextoChanged: secaoAssinaturas.atualizarModelos() } }
                    }
                    Flow {
                        width: parent.width; spacing: 8
                        Repeater {
                            model: secaoAssinaturas.modelos
                            delegate: Rectangle {
                                required property var modelData
                                width: (parent.width - 24) / 4; height: 40; radius: 10
                                color: areaModelo.containsMouse ? Tema.realce : "transparent"
                                border { width: 1; color: Tema.borda }
                                Text { anchors.centerIn: parent; text: modelData.nome; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13; weight: Font.DemiBold } }
                                MouseArea { id: areaModelo; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                            onClicked: codigoHtml.text = modelData.html }
                            }
                        }
                    }
                }
                Secao {
                    visible: secaoAssinaturas.tipo === "html"
                    nome: "Código HTML"
                    Rectangle {
                        width: parent.width; height: 150; radius: 10
                        color: Tema.cartao; border { width: codigoHtml.activeFocus ? 2 : 1; color: codigoHtml.activeFocus ? Tema.azulDuia : Tema.borda }
                        Flickable {
                            anchors { fill: parent; margins: 10 }
                            contentHeight: codigoHtml.paintedHeight; clip: true
                            TextEdit { id: codigoHtml; width: parent.width; wrapMode: TextEdit.WrapAnywhere; color: Tema.texto; selectByMouse: true
                                       selectionColor: Tema.azulDuia; font { family: Tema.fonteCodigo; pixelSize: 12 }
                                       Keys.onTabPressed: (e) => { nextItemInFocusChain(true).forceActiveFocus(); e.accepted = true } }
                        }
                    }
                    Text { text: "Prévia"; color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                    Rectangle {
                        width: parent.width; height: 150; radius: 10; clip: true
                        color: "white"; border { width: 1; color: Tema.borda }
                        WebEngineView {
                            anchors { fill: parent; margins: 1 }
                            profile: perfilLeitura
                            settings.javascriptEnabled: false
                            backgroundColor: "transparent"
                            property string html: caixa.previaAssinatura(codigoHtml.text)
                            onHtmlChanged: loadHtml(html, "about:blank")
                            onNavigationRequested: (pedido) => { if (pedido.navigationType === WebEngineNavigationRequest.LinkClickedNavigation) pedido.reject() }
                            onContextMenuRequested: (pedido) => { pedido.accepted = true }
                        }
                    }
                }
                Secao {
                    visible: secaoAssinaturas.tipo !== "nenhuma"
                    nome: "Quando usar"
                    LinhaInterruptor { id: respostas; texto: "Também nas respostas e nos encaminhamentos"; onAlternado: (v) => ligado = v }
                    Text { visible: respostas.ligado; text: "Nas respostas, a assinatura fica"; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
                    Pilulas { id: posicao; visible: respostas.ligado; opcoes: [["abaixo", "No fim de tudo"], ["acima", "Logo depois do que eu escrevi (antes da mensagem citada)"]]
                              onEscolhido: (v) => valor = v }
                }
                Item {
                    visible: !!secaoAssinaturas.c.email
                    width: parent.width; height: 40
                    Botao { anchors.right: parent.right; texto: "Salvar a assinatura"; tipo: "primario"
                            onClicado: caixa.salvarAssinatura(config.contaEscolhida, {
                                assinatura: secaoAssinaturas.tipo === "texto" ? textoAssinatura.text : (secaoAssinaturas.tipo === "nenhuma" ? "" : textoAssinatura.text),
                                assinatura_tipo: secaoAssinaturas.tipo === "html" ? "html" : "texto",
                                assinatura_html: secaoAssinaturas.tipo === "nenhuma" ? "" : codigoHtml.text,
                                assinatura_respostas: respostas.ligado, assinatura_posicao: posicao.valor || "abaixo" }) }
                }
            }

            // ================================================== Pastas
            Column {
                id: secaoPastas
                visible: config.secao === "pastas"
                width: parent.width; spacing: 14
                property var lista: []
                function carregar() { lista = config.contaEscolhida ? caixa.pastasDaConta(config.contaEscolhida) : [] }
                Connections { target: config; function onContaEscolhidaChanged() { secaoPastas.carregar() } }
                Connections { target: caixa; function onPastasMudaram() { secaoPastas.carregar() } }
                Component.onCompleted: carregar()
                onVisibleChanged: if (visible) carregar()

                Row {
                    width: parent.width; spacing: 10
                    EscolhaDeConta { width: parent.width - botaoNovaPasta.width - 10 }
                    Botao { id: botaoNovaPasta; texto: "Nova pasta"; icone: "nova-pasta"; tipo: "primario"
                            onClicado: { novaPasta.visible = true; nomeNovaPasta.texto = ""; nomeNovaPasta.entrada.forceActiveFocus() } }
                }
                Row {
                    id: novaPasta
                    visible: false
                    width: parent.width; spacing: 8
                    Campo { id: nomeNovaPasta; width: parent.width - 180; height: 36; icone: "pasta"; dica: "Nome da pasta nova"
                            onConfirmado: criar.clicado() }
                    Botao { id: criar; texto: "Criar"; tipo: "primario"
                            onClicado: if (nomeNovaPasta.texto.trim() !== "") { caixa.criarPasta(config.contaEscolhida, nomeNovaPasta.texto.trim(), 0); novaPasta.visible = false } }
                    Botao { texto: "Cancelar"; onClicado: novaPasta.visible = false }
                }
                Cartao {
                    width: parent.width
                    height: colunaPastas.implicitHeight + 16
                    Column {
                        id: colunaPastas
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 8 }
                        Repeater {
                            model: secaoPastas.lista
                            delegate: Item {
                                id: linhaPasta
                                required property var modelData
                                property bool editando: false
                                width: colunaPastas.width; height: 44
                                Icone { id: iconePasta; anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                                        nome: modelData.papel === "" ? "pasta" : ({ entrada: "pasta-downloads", enviados: "abrir", rascunhos: "lapis", lixeira: "lixeira",
                                                                                    spam: "escudo", arquivo: "compactado" })[modelData.papel] || "pasta"
                                        tamanho: 16; cor: Tema.textoSecundario }
                                Column {
                                    visible: !linhaPasta.editando
                                    anchors { left: iconePasta.right; leftMargin: 12; right: acoesPasta.left; verticalCenter: parent.verticalCenter }
                                    Text { text: modelData.nome; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 14 } }
                                    Text { text: modelData.total + (modelData.total === 1 ? " mensagem" : " mensagens") + (modelData.papel !== "" ? " · pasta do sistema" : "")
                                           color: Tema.textoSecundario; font { family: Tema.fonteTexto; pixelSize: 12 } }
                                }
                                Campo {
                                    id: nomeEditado
                                    visible: linhaPasta.editando
                                    anchors { left: iconePasta.right; leftMargin: 12; right: acoesPasta.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                                    height: 34
                                    onConfirmado: { caixa.renomearPasta(modelData.id, texto); linhaPasta.editando = false }
                                    Keys.onEscapePressed: linhaPasta.editando = false
                                }
                                Row {
                                    id: acoesPasta
                                    visible: modelData.papel === ""
                                    anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                                    spacing: 2
                                    BotaoIcone { icone: linhaPasta.editando ? "check" : "lapis"; dica: linhaPasta.editando ? "Salvar o nome" : "Renomear"
                                                 onClicado: { if (linhaPasta.editando) { caixa.renomearPasta(modelData.id, nomeEditado.texto); linhaPasta.editando = false }
                                                              else { nomeEditado.texto = modelData.nome; linhaPasta.editando = true; nomeEditado.entrada.forceActiveFocus() } } }
                                    BotaoIcone { icone: "lixeira"; dica: "Apagar a pasta (e as mensagens dela)"; corIcone: Tema.erro
                                                 onClicado: confirmarApagar.pedir(modelData) }
                                }
                                Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 38 } height: 1; color: Tema.borda }
                            }
                        }
                    }
                }
                Rectangle {
                    id: confirmarApagar
                    property var pasta: null
                    function pedir(p) { pasta = p; visible = true }
                    visible: false
                    width: parent.width; height: 56; radius: 10
                    color: Qt.rgba(0.9, 0.2, 0.2, 0.10); border { width: 1; color: Tema.erro }
                    Text { anchors { left: parent.left; leftMargin: 14; right: botoesApagar.left; verticalCenter: parent.verticalCenter }
                           wrapMode: Text.WordWrap; color: Tema.texto; font { family: Tema.fonteTexto; pixelSize: 13 }
                           text: confirmarApagar.pasta ? "Apagar “" + confirmarApagar.pasta.nome + "” e as mensagens dela, também no servidor?" : "" }
                    Row {
                        id: botoesApagar
                        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        spacing: 8
                        Botao { texto: "Cancelar"; onClicado: confirmarApagar.visible = false }
                        Botao { texto: "Apagar"; tipo: "perigo"; onClicado: { caixa.apagarPasta(confirmarApagar.pasta.id); confirmarApagar.visible = false } }
                    }
                }
            }
        }
    }

    Timer {
        interval: 2600
        running: typeof capturaArquivo !== "undefined" && capturaArquivo !== "" && typeof paginaDemonstracao !== "undefined"
                 && paginaDemonstracao.indexOf("configuracoes") === 0
        onTriggered: config.Window.window.contentItem.grabToImage(function (r) { r.saveToFile(capturaArquivo); Qt.quit() })
    }
}
