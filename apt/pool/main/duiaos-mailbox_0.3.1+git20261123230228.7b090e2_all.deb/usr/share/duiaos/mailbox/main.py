#!/usr/bin/env python3
"""DuiaOS — Mail Box, o gerenciador de e-mails do DuiaOS (ADR 072).

Contas IMAP e POP3 com envio por SMTP; wizard que descobre os servidores pelo endereço (catálogo próprio,
MX, ISPDB, autoconfig, SRV); caixa de entrada unificada; leitura segura (sem JavaScript, imagens externas
bloqueadas até a pessoa liberar); escrever, responder, responder a todos e encaminhar, com anexos;
notificações de e-mails novos; menus na Barra de Recursos. Senhas no cofre do sistema.

Uso:
  main.py [mailto:ENDEREÇO]
  main.py --demonstracao [--pagina caixa|wizard|escrever] [--escuro] [--captura ARQUIVO]
"""
import base64
import fcntl
import json
import mimetypes
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

PASTA = Path(__file__).resolve().parent
# Motor web do DuiaOS (pacote duiaos-motor-web, ADR 072): o Qt WebEngine recente vem antes do PySide6 do Debian,
# só neste processo (os programas que ele abre não herdam).
_MOTOR_WEB = Path(os.environ.get("DUIAOS_MOTOR_WEB", "/usr/lib/duiaos/motor-web"))
if (_MOTOR_WEB / "PySide6").is_dir():
    sys.path.insert(0, str(_MOTOR_WEB))
# shell/comum: instalado, ou o duiaos clonado ao lado deste repositório (desenvolvimento)
for _comum in (Path(os.environ.get("DUIAOS_SHELL", "/usr/share/duiaos/shell")) / "comum",
               PASTA.parents[1] / "duiaos" / "shell" / "comum"):
    if (_comum / "interface.py").is_file():
        sys.path.insert(0, str(_comum))
        break
sys.path.insert(0, str(PASTA))

DEMONSTRACAO = "--demonstracao" in sys.argv
if DEMONSTRACAO:
    _TEMP = Path(tempfile.mkdtemp(prefix="mailbox-demo-"))
    os.environ["XDG_DATA_HOME"] = str(_TEMP / "dados")
    os.environ["XDG_CONFIG_HOME"] = str(_TEMP / "config")
    os.environ["DUIAOS_MAILBOX_COFRE"] = "memoria"

import caixa_postal  # noqa: E402
import autoconfig  # noqa: E402
import cofre as modulo_cofre  # noqa: E402
import importar  # noqa: E402
import mensagem  # noqa: E402
import provedores  # noqa: E402
import servidores  # noqa: E402
import sincronizador  # noqa: E402
try:
    import contador  # noqa: E402  (shell/comum; numa instalação antiga do DuiaOS pode faltar)
except ImportError:
    contador = None

from PySide6.QtCore import QObject, Property, QStandardPaths, QTimer, QUrl, Signal, Slot, QCoreApplication, Qt  # noqa: E402

VERSAO = "0.1"
INTERVALO_SINCRONIA = 3 * 60 * 1000
ARQUIVO_PEDIDO = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "duiaos-mailbox.pedido"
# A apresentação da primeira abertura já foi vista (ADR 075)
ARQUIVO_APRESENTACAO = caixa_postal.ARQUIVO_CONTAS.parent / "apresentacao-vista"
MENSAGENS = {"mailbox_inicio": "Mail Box aberto", "mailbox_conta": "Conta adicionada no Mail Box",
             "mailbox_conta_removida": "Conta removida do Mail Box", "mailbox_erro": "Erro numa conta do Mail Box",
             "mailbox_enviada": "Mensagem enviada pelo Mail Box", "mailbox_falha_envio": "Falha ao enviar no Mail Box"}


def registrar(nivel, evento, **campos):
    """Registro do sistema. Nunca endereços, assuntos ou conteúdo de mensagens."""
    try:
        import duiaos_registro
    except ImportError:
        return
    getattr(duiaos_registro, nivel)(evento, MENSAGENS.get(evento, evento), **campos)


def argumento(nome, padrao=""):
    return sys.argv[sys.argv.index(nome) + 1] if nome in sys.argv and sys.argv.index(nome) + 1 < len(sys.argv) else padrao


def ler_mailto(url):
    """mailto:a@b?subject=..&body=..&cc=.. → campos da janela Escrever."""
    partes = urlsplit(url)
    consulta = {k.lower(): v[0] for k, v in parse_qs(partes.query).items()}
    return {"para": unquote(partes.path), "cc": consulta.get("cc", ""), "assunto": consulta.get("subject", ""),
            "corpo": consulta.get("body", ""), "em_resposta_a": "", "referencias": ""}


class MailBox(QObject):
    contasMudaram = Signal()
    pastasMudaram = Signal()
    mensagensMudaram = Signal()
    leituraMudou = Signal()
    estadoMudou = Signal()
    aviso = Signal(str)
    descoberto = Signal("QVariantMap", str)            # configuração, origem
    testeConcluido = Signal(bool, str)
    enviada = Signal()
    falhaEnvio = Signal(str)
    apresentacaoMudou = Signal()
    corpoBaixado = Signal(int)                          # o corpo de uma mensagem chegou do servidor
    abrirJanelaMensagem = Signal(int)                   # duplo clique: a mensagem numa janela só dela
    prefsMudaram = Signal()
    testeConfiguracao = Signal(bool, str)               # Configurações › Contas › Testar a conexão
    abrirEscrever = Signal("QVariantMap")               # a janela principal cria a janela Escrever
    _evento = Signal(str, "QVariantMap")                # da linha de trabalho para a linha da janela
    _resultado = Signal(str, "QVariantMap")
    _abrir_notificada = Signal(int, int, int)           # clique na notificação: pasta, uid e quantas chegaram

    def __init__(self, perfil_leitura, interceptador):
        super().__init__()
        self.perfil_leitura = perfil_leitura
        self.interceptador = interceptador
        self.contas = caixa_postal.Contas()
        self.prefs = caixa_postal.Preferencias()
        self.banco = caixa_postal.Banco()
        self.cofre = modulo_cofre.abrir()
        self._pasta = -1                    # -1: a Entrada de todas as contas
        self._busca = ""
        self._leitura = {}
        self._estados = {}                  # conta → texto ("Sincronizando…")
        self._erros = {}                    # conta → último erro
        self._janelas_escrever = []
        self._evento.connect(self._tratar_evento)
        self._resultado.connect(self._tratar_resultado)
        self.motor = sincronizador.Motor(self.contas, self.banco, self.cofre, lambda e, d: self._evento.emit(e, d))
        self._relogio = QTimer(self, interval=max(1, int(self.prefs["intervalo_minutos"])) * 60 * 1000, timeout=self.atualizar)
        self._marcar_depois = QTimer(self, singleShot=True, interval=3000, timeout=self._marcar_aberta)
        # Balão vermelho com as não lidas no ícone da Ilha (comum/contador.py): acompanha as pastas
        self._contador_publicado = None
        self.pastasMudaram.connect(self._publicar_contador)
        self.prefsMudaram.connect(self._publicar_contador)
        self._abrir_notificada.connect(self._ao_clicar_notificacao)

    def iniciar(self):
        if DEMONSTRACAO:
            return
        self.motor.iniciar()
        self.motor.sincronizar_todas()
        self._relogio.start()

    # ------------------------------------------------------------ eventos do motor
    def _tratar_evento(self, evento, dados):
        conta = dados.get("conta", "")
        if evento == "pastas":
            self.pastasMudaram.emit()
        elif evento == "mensagens":
            self.pastasMudaram.emit()
            if self._pasta == -1 or self._pasta == dados.get("pasta"):
                self.mensagensMudaram.emit()
        elif evento == "estado":
            self._estados[conta] = dados.get("texto", "")
            if dados.get("texto"):
                self._erros.pop(conta, None)
            self.estadoMudou.emit()
        elif evento == "erro":
            self._erros[conta] = dados.get("texto", "")
            registrar("aviso", "mailbox_erro", provedor=(self.contas.obter(conta) or {}).get("provedor", ""))
            self.estadoMudou.emit()
            self.aviso.emit(dados.get("texto", ""))
        elif evento == "novas":
            self._notificar(conta, [dict(m, pasta_id=dados.get("pasta", 0)) for m in dados.get("lista", [])])
        elif evento == "corpo":
            if self._leitura.get("id") == dados.get("id"):
                self.abrirMensagem(dados["id"], self._leitura.get("remoto", False))
            self.corpoBaixado.emit(int(dados.get("id", 0)))
        elif evento == "aviso":
            self.aviso.emit(dados.get("texto", ""))
        elif evento == "enviada":
            registrar("info", "mailbox_enviada")
            self.enviada.emit()
            self.aviso.emit("Mensagem enviada.")
        elif evento == "falha_envio":
            registrar("aviso", "mailbox_falha_envio")
            self.falhaEnvio.emit(dados.get("texto", ""))

    def _publicar_contador(self):
        if DEMONSTRACAO or contador is None:
            return
        total = 0
        if self.prefs["contador_no_icone"]:
            total = sum(p["nao_lidas"] for p in self.banco.pastas() if p["papel"] == "entrada")
        if total != self._contador_publicado:
            self._contador_publicado = total
            contador.publicar("duiaos-mailbox.desktop", total)

    def _notificar(self, id_conta, lista):
        """Notificação das mensagens novas; clicar nela (ou em "Abrir") abre a mensagem e traz o Mail Box para a
        frente. O notify-send fica esperando o clique numa linha à parte (--wait)."""
        if not lista or not self.prefs["notificar"] or not shutil.which("notify-send"):
            return
        if len(lista) == 1:
            titulo = lista[0]["de_nome"] or lista[0]["de_email"]
            texto = lista[0]["assunto"] or "(sem assunto)"
        else:
            titulo, texto = f"{len(lista)} e-mails novos", ", ".join((m["de_nome"] or m["de_email"]) for m in lista[:3])
        recente = max(lista, key=lambda m: m.get("uid", 0))
        pasta, uid, quantas = int(recente.get("pasta_id", 0) or 0), int(recente.get("uid", 0)), len(lista)

        def esperar():
            try:
                resultado = subprocess.run(["notify-send", "--app-name=Mail Box", "--icon=duiaos-mailbox",
                                            "--hint=string:desktop-entry:duiaos-mailbox", "--wait",
                                            "--action=default=Abrir", "--action=abrir=Abrir", titulo, texto],
                                           capture_output=True, text=True, timeout=6 * 3600, check=False)
            except (OSError, subprocess.TimeoutExpired):
                return
            if resultado.stdout.strip() in ("default", "abrir"):
                self._abrir_notificada.emit(pasta, uid, quantas)
        threading.Thread(target=esperar, daemon=True, name="mailbox-notificacao").start()

    def _ao_clicar_notificacao(self, id_pasta, uid, quantas):
        """Abre a Entrada (ou a mensagem, quando chegou uma só) e traz a janela para a frente."""
        trazer_para_frente()
        if id_pasta <= 0:
            return
        self.escolherPasta(id_pasta if len(self.contas.lista) == 1 else -1)
        if quantas == 1:
            alvo = next((m for m in self.banco.mensagens(id_pasta, limite=50) if m["uid"] == uid), None)
            if alvo:
                self.abrirMensagem(alvo["id"], False)

    # ------------------------------------------------------------ pastas e lista
    def _lista_pastas(self):
        saida = []
        contas = self.contas.lista
        if len(contas) > 1:
            total = sum(p["nao_lidas"] for p in self.banco.pastas() if p["papel"] == "entrada")
            saida.append({"id": -1, "conta": "", "nome": "Todas as caixas de entrada", "papel": "entrada", "nao_lidas": total,
                          "tipo": "pasta", "nivel": 0})
        for conta in contas:
            saida.append({"id": -100, "conta": conta["id"], "nome": conta["email"], "papel": "", "nao_lidas": 0,
                          "tipo": "conta", "nivel": 0, "estado": self._estados.get(conta["id"], ""),
                          "erro": self._erros.get(conta["id"], "")})
            for p in self.banco.pastas(conta["id"]):
                saida.append({"id": p["id"], "conta": conta["id"], "nome": p["nome"], "papel": p["papel"],
                              "nao_lidas": p["nao_lidas"], "tipo": "pasta", "nivel": 1})
        return saida

    def _lista_mensagens(self):
        if self._pasta == -1:
            lista = self.banco.mensagens(busca=self._busca, papel="entrada")
        else:
            lista = self.banco.mensagens(self._pasta, busca=self._busca)
        contas = {c["id"]: c for c in self.contas.lista}
        for m in lista:
            m["email_conta"] = contas.get(m["conta"], {}).get("email", "")
        return lista

    @Slot(int)
    def escolherPasta(self, id_pasta):
        self._pasta = id_pasta
        self._leitura = {}
        self.mensagensMudaram.emit()
        self.leituraMudou.emit()
        self.pastasMudaram.emit()
        pasta = self.banco.pasta(id_pasta) if id_pasta > 0 else None
        if pasta and not DEMONSTRACAO:
            self.motor.pedir(pasta["conta"], "sincronizar_pasta", id_pasta=id_pasta)

    @Slot(str)
    def buscar(self, texto):
        self._busca = texto
        self.mensagensMudaram.emit()

    @Slot()
    def atualizar(self):
        if not DEMONSTRACAO:
            self.motor.sincronizar_todas()

    # ------------------------------------------------------------ leitura
    def _bruto(self, m):
        return self.banco.ler_corpo(m["conta"], m["pasta"], m["uid"])

    def _montar_leitura(self, m, permitir_remoto):
        """O que a área de leitura (ou a janela da mensagem) mostra; pede o corpo ao servidor se ainda não chegou."""
        permitir_remoto = permitir_remoto or self.prefs["imagens_externas"] == "sempre"
        bruto = self._bruto(m)
        leitura = {"id": m["id"], "conta": m["conta"], "assunto": m["assunto"] or "(sem assunto)", "de_nome": m["de_nome"],
                   "de_email": m["de_email"], "para": m["para"], "cc": m["cc"], "data": m["data"], "lida": bool(m["lida"]),
                   "sinalizada": bool(m["sinalizada"]), "anexos": [], "html": "", "bloqueadas": 0, "carregando": bruto is None,
                   "remoto": permitir_remoto}
        if bruto is None:
            if not DEMONSTRACAO:
                self.motor.pedir(m["conta"], "baixar", id_mensagem=m["id"])
        else:
            msg = mensagem.ler(bruto)
            escuro = bool(_aparencia_escura())
            leitura["html"], leitura["bloqueadas"] = mensagem.html_para_leitura(msg, permitir_remoto, escuro)
            leitura["anexos"] = mensagem.anexos(msg)
        return leitura

    @Slot(int)
    def abrirMensagem(self, id_mensagem, permitir_remoto=False):
        m = self.banco.mensagem(id_mensagem)
        if not m:
            self._leitura = {}
            self.leituraMudou.emit()
            return
        leitura = self._montar_leitura(m, permitir_remoto)
        self.interceptador.permitir = leitura["remoto"]
        self._leitura = leitura
        self.leituraMudou.emit()
        if not m["lida"]:
            if self.prefs["marcar_lida"] == "ao_abrir":
                self.marcarLida(id_mensagem, True)
            elif self.prefs["marcar_lida"] == "depois_de_3s":
                self._marcar_depois.start()

    def _marcar_aberta(self):
        if self._leitura.get("id") and not self._leitura.get("lida"):
            self.marcarLida(self._leitura["id"], True)

    @Slot(int, bool, result="QVariantMap")
    def dadosDaMensagem(self, id_mensagem, permitir_remoto=False):
        """Para a janela só da mensagem (duplo clique): o mesmo que a área de leitura mostra."""
        m = self.banco.mensagem(id_mensagem)
        if not m:
            return {}
        leitura = self._montar_leitura(m, permitir_remoto)
        if leitura["remoto"]:
            self.interceptador.permitir = True
        if not m["lida"] and self.prefs["marcar_lida"] != "nunca":
            self.marcarLida(id_mensagem, True)
        return leitura

    @Slot(int)
    def abrirEmJanela(self, id_mensagem):
        self.abrirJanelaMensagem.emit(id_mensagem)

    @Slot()
    def mostrarImagens(self):
        if self._leitura.get("id"):
            self.abrirMensagem(self._leitura["id"], True)

    @Slot(int, bool)
    def marcarLida(self, id_mensagem, valor):
        self._acao(id_mensagem, "marcar", campo="lida", valor=valor)

    @Slot(int, bool)
    def sinalizar(self, id_mensagem, valor):
        self._acao(id_mensagem, "marcar", campo="sinalizada", valor=valor)

    @Slot(int)
    def apagar(self, id_mensagem):
        self._acao(id_mensagem, "apagar")
        self._fechar_leitura(id_mensagem)

    @Slot(int)
    def arquivar(self, id_mensagem):
        m = self.banco.mensagem(id_mensagem)
        if not m:
            return
        destino = self.banco.pasta_por_papel(m["conta"], "arquivo")
        if not destino:
            self.aviso.emit("Esta conta não tem uma pasta de arquivo.")
            return
        self._acao(id_mensagem, "mover", id_destino=destino["id"])
        self._fechar_leitura(id_mensagem)

    @Slot(int, int)
    def moverPara(self, id_mensagem, id_pasta):
        self._acao(id_mensagem, "mover", id_destino=id_pasta)
        self._fechar_leitura(id_mensagem)

    def _acao(self, id_mensagem, acao, **dados):
        m = self.banco.mensagem(id_mensagem)
        if not m:
            return
        if acao == "marcar":
            # Na hora, na tela; o servidor recebe depois, na fila da conta (que pode estar ocupada sincronizando)
            self.banco.marcar(id_mensagem, **{dados["campo"]: dados["valor"]})
            self.banco.recontar(m["pasta"])
            if self._leitura.get("id") == id_mensagem and dados["campo"] in ("lida", "sinalizada"):
                self._leitura = dict(self._leitura, **{dados["campo"]: bool(dados["valor"])})
                self.leituraMudou.emit()
            self.mensagensMudaram.emit()
            self.pastasMudaram.emit()
        if DEMONSTRACAO:
            return
        self.motor.pedir(m["conta"], acao, id_mensagem=id_mensagem, **dados)

    def _fechar_leitura(self, id_mensagem):
        if self._leitura.get("id") == id_mensagem:
            self._leitura = {}
            self.leituraMudou.emit()

    @Slot(int, int, result=str)
    def salvarAnexo(self, id_mensagem, indice):
        m = self.banco.mensagem(id_mensagem)
        bruto = self._bruto(m) if m else None
        if bruto is None:
            return ""
        msg = mensagem.ler(bruto)
        info = next((a for a in mensagem.anexos(msg) if a["indice"] == indice), None)
        conteudo = mensagem.conteudo_do_anexo(msg, indice)
        if info is None or conteudo is None:
            return ""
        pasta = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation) or Path.home())
        pasta.mkdir(parents=True, exist_ok=True)
        nome = Path(info["nome"]).name or "anexo"
        destino, n = pasta / nome, 2
        while destino.exists():
            destino, n = pasta / f"{Path(nome).stem} ({n}){Path(nome).suffix}", n + 1
        destino.write_bytes(conteudo)
        return str(destino)

    @Slot(int, int)
    def abrirAnexo(self, id_mensagem, indice):
        caminho = self.salvarAnexo(id_mensagem, indice)
        if caminho and not DEMONSTRACAO:
            subprocess.Popen(["xdg-open", caminho], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.aviso.emit(f"Anexo salvo em Downloads: {Path(caminho).name}")

    @Slot(str)
    def abrirLink(self, url):
        if url.startswith(("http://", "https://")) and not DEMONSTRACAO:
            subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif url.startswith("mailto:"):
            self.escrever(ler_mailto(url))

    # ------------------------------------------------------------ escrever
    def escrever(self, campos, conta=""):
        campos = dict(campos)
        campos.setdefault("conta", conta or (self.contas.lista[0]["id"] if self.contas.lista else ""))
        campos.setdefault("id_respondida", 0)
        self.abrirEscrever.emit(campos)

    @Slot()
    def novaMensagem(self):
        conta = self._leitura.get("conta") or (self.banco.pasta(self._pasta) or {}).get("conta", "")
        self.escrever({"para": "", "cc": "", "assunto": "", "corpo": "", "em_resposta_a": "", "referencias": ""}, conta)

    @Slot(int, bool)
    def responder(self, id_mensagem, todos):
        m = self.banco.mensagem(id_mensagem)
        bruto = self._bruto(m) if m else None
        if bruto is None:
            return
        conta = self.contas.obter(m["conta"]) or {}
        campos = mensagem.rascunho_de_resposta(mensagem.ler(bruto), conta.get("email", ""), todos)
        campos["id_respondida"] = id_mensagem
        self.escrever(campos, m["conta"])

    @Slot(int)
    def encaminhar(self, id_mensagem):
        m = self.banco.mensagem(id_mensagem)
        bruto = self._bruto(m) if m else None
        if bruto is not None:
            self.escrever(mensagem.rascunho_de_encaminhamento(mensagem.ler(bruto)), m["conta"])

    @Slot("QVariantMap")
    def enviar(self, campos):
        conta = campos.get("conta")
        if not self.contas.obter(conta):
            self.falhaEnvio.emit("Escolha a conta que envia.")
            return
        if DEMONSTRACAO:
            self.enviada.emit()
            return
        anexos = [str(a).replace("file://", "") for a in campos.get("anexos", [])]
        self.motor.pedir(conta, "enviar", de_nome=(self.contas.obter(conta) or {}).get("nome", ""), para=campos.get("para", ""),
                         assunto=campos.get("assunto", ""), corpo=campos.get("corpo", ""), cc=campos.get("cc", ""),
                         cco=campos.get("cco", ""), anexos=anexos, em_resposta_a=campos.get("em_resposta_a", ""),
                         referencias=campos.get("referencias", ""), id_respondida=int(campos.get("id_respondida") or 0),
                         incluir_assinatura=bool(campos.get("incluir_assinatura", True)), citacao=campos.get("citacao", ""),
                         corpo_html=campos.get("corpo_html", ""))

    @Slot(str, result=str)
    def htmlDoEditor(self, texto):
        """Texto de partida da janela Escrever → HTML do editor formatado."""
        return mensagem.html_inicial_do_editor(texto)

    @Slot(str, result=str)
    def imagemEmDataUrl(self, url):
        """Imagem escolhida para ir no meio do texto → data: (o editor não lê arquivos do disco)."""
        caminho = Path(QUrl(url).toLocalFile() if url.startswith("file:") else url)
        tipo = mimetypes.guess_type(caminho.name)[0] or ""
        try:
            if not tipo.startswith("image/") or caminho.stat().st_size > 25 * 1024 * 1024:
                return ""
            return f"data:{tipo};base64," + base64.b64encode(caminho.read_bytes()).decode()
        except OSError:
            return ""

    # ------------------------------------------------------------ contas e wizard
    def _em_fundo(self, nome, funcao):
        def rodar():
            try:
                self._resultado.emit(nome, {"ok": True, "valor": funcao()})
            except servidores.ErroDeConta as erro:
                self._resultado.emit(nome, {"ok": False, "texto": str(erro)})
            except Exception as erro:  # noqa: BLE001
                self._resultado.emit(nome, {"ok": False, "texto": f"Erro inesperado: {type(erro).__name__}"})
        threading.Thread(target=rodar, daemon=True).start()

    def _tratar_resultado(self, nome, r):
        if nome == "descobrir":
            config, origem = r.get("valor") or (None, "")
            self.descoberto.emit(config or {}, origem or "")
        elif nome == "testar":
            self.testeConcluido.emit(bool(r.get("ok")), r.get("texto", ""))
        elif nome == "testar_configuracao":
            self.testeConfiguracao.emit(bool(r.get("ok")), r.get("texto", ""))

    @Slot(str)
    def descobrir(self, email):
        if DEMONSTRACAO:
            chave = provedores.por_dominio(email.rpartition("@")[2])
            self.descoberto.emit(provedores.configuracao(chave, email) if chave else {}, "catalogo" if chave else "")
            return
        self._em_fundo("descobrir", lambda: autoconfig.descobrir(email))

    @Slot(str, result="QVariantMap")
    def provedorDe(self, email):
        chave = provedores.por_dominio(email.rpartition("@")[2])
        return provedores.configuracao(chave, email) if chave else {}

    @Slot(str, str, result="QVariantMap")
    def configuracaoDoProvedor(self, chave, email):
        return provedores.configuracao(chave, email) if chave in provedores.PROVEDORES else {}

    @Slot(str, str, "QVariantMap")
    def testarConta(self, email, senha, config):
        conta = {"entrada": config["entrada"], "saida": config["saida"],
                 "verificar_certificado": config.get("verificar_certificado", True)}
        if DEMONSTRACAO:
            self.testeConcluido.emit(True, "")
            return

        def testar():
            servidores.testar_entrada(conta, senha)
            servidores.testar_saida(conta, senha)
        self._em_fundo("testar", testar)

    @Slot(str, str, str, "QVariantMap", result=str)
    def salvarConta(self, nome, email, senha, config):
        conta = self.contas.adicionar(nome, email, dict(config))
        self.cofre.guardar(conta["id"], "entrada", senha)
        registrar("info", "mailbox_conta", provedor=conta["provedor"], tipo=conta["entrada"]["tipo"])
        self.contasMudaram.emit()
        self.pastasMudaram.emit()
        if not DEMONSTRACAO:
            self.motor.pedir(conta["id"], "sincronizar")
        if not self.cofre.persistente:
            self.aviso.emit("O cofre do sistema não está disponível: a senha vale só até fechar o Mail Box.")
        return conta["id"]

    @Slot(str)
    def removerConta(self, id_conta):
        self.motor.remover(id_conta)
        self.cofre.apagar(id_conta)
        self.banco.remover_conta(id_conta)
        self.contas.remover(id_conta)
        registrar("info", "mailbox_conta_removida")
        if self._pasta != -1:
            self._pasta = -1
        self._leitura = {}
        self.contasMudaram.emit()
        self.pastasMudaram.emit()
        self.mensagensMudaram.emit()
        self.leituraMudou.emit()

    # ------------------------------------------------------------ Configurações (ADR 076)
    @Slot(str, "QVariant")
    def definirPreferencia(self, chave, valor):
        self.prefs.definir(chave, valor)
        if chave == "intervalo_minutos":
            self._relogio.setInterval(max(1, int(valor)) * 60 * 1000)
        if chave == "imagens_externas" and self._leitura.get("id"):
            self.abrirMensagem(self._leitura["id"], valor == "sempre")
        self.prefsMudaram.emit()

    @Slot(str, result="QVariantMap")
    def contaCompleta(self, id_conta):
        """A conta para as Configurações (sem as senhas: só se cada uma está guardada)."""
        c = self.contas.obter(id_conta)
        if not c:
            return {}
        dados = json.loads(json.dumps(c))
        dados["tem_senha_entrada"] = self.cofre.ler(id_conta, "entrada") is not None if not DEMONSTRACAO else True
        dados["tem_senha_saida"] = self.cofre.ler(id_conta, "saida") is not None if not DEMONSTRACAO else False
        return dados

    def _config_editada(self, id_conta, dados):
        c = self.contas.obter(id_conta) or {}
        def servidor(nome):
            base = dict(c.get(nome, {}))
            novo = dados.get(nome) or {}
            for chave in ("tipo", "host", "usuario", "seguranca"):
                if chave in novo:
                    base[chave] = str(novo[chave]).strip()
            if "porta" in novo:
                base["porta"] = int(novo["porta"] or 0)
            return base
        return {"entrada": servidor("entrada"), "saida": servidor("saida"),
                "verificar_certificado": bool(dados.get("verificar_certificado", c.get("verificar_certificado", True))),
                "autenticacao": c.get("autenticacao", "senha")}

    @Slot(str, "QVariantMap")
    def testarConfiguracao(self, id_conta, dados):
        """Testa entrada e envio com o que está na tela (senhas novas, ou as guardadas)."""
        config = self._config_editada(id_conta, dados)
        senha_e = dados.get("senha_entrada") or (self.cofre.ler(id_conta, "entrada") if not DEMONSTRACAO else "x")
        senha_s = dados.get("senha_saida") or (self.cofre.ler(id_conta, "saida") if not DEMONSTRACAO else None) or senha_e
        if DEMONSTRACAO:
            self.testeConfiguracao.emit(True, "")
            return

        def testar():
            servidores.testar_entrada(config, senha_e)
            servidores.testar_saida(config, senha_s)
        self._em_fundo("testar_configuracao", testar)

    @Slot(str, "QVariantMap")
    def salvarConfiguracaoConta(self, id_conta, dados):
        config = self._config_editada(id_conta, dados)
        campos = dict(config)
        if "nome" in dados:
            campos["nome"] = str(dados["nome"]).strip()
        for chave in ("dias_offline", "manter_no_servidor"):
            if chave in dados:
                campos[chave] = dados[chave]
        self.contas.atualizar(id_conta, **campos)
        if dados.get("senha_entrada"):
            self.cofre.guardar(id_conta, "entrada", dados["senha_entrada"])
        if dados.get("senha_saida"):
            self.cofre.guardar(id_conta, "saida", dados["senha_saida"])
        elif dados.get("mesma_senha"):
            self.cofre.apagar(id_conta, "saida")          # o envio usa a senha de entrada
        registrar("info", "mailbox_conta_editada", provedor=(self.contas.obter(id_conta) or {}).get("provedor", ""))
        if not DEMONSTRACAO:
            self.motor.pedir(id_conta, "reconectar")
            self.motor.pedir(id_conta, "sincronizar")
        self._erros.pop(id_conta, None)
        self.contasMudaram.emit()
        self.pastasMudaram.emit()
        self.aviso.emit("Conta salva.")

    @Slot(str, "QVariantMap")
    def salvarAssinatura(self, id_conta, dados):
        campos = {}
        for chave in ("assinatura", "assinatura_tipo", "assinatura_html", "assinatura_respostas", "assinatura_posicao"):
            if chave in dados:
                campos[chave] = dados[chave]
        if campos.get("assinatura_html"):
            campos["assinatura_html"] = mensagem.limpar_html_assinatura(campos["assinatura_html"])
        self.contas.atualizar(id_conta, **campos)
        self.contasMudaram.emit()
        self.aviso.emit("Assinatura salva.")

    @Slot(str, "QVariantMap", result="QVariantList")
    def modelosDeAssinatura(self, id_conta, campos):
        c = self.contas.obter(id_conta) or {}
        dados = {"nome": campos.get("nome") or c.get("nome", ""), "email": c.get("email", ""), "cargo": campos.get("cargo", ""),
                 "empresa": campos.get("empresa", ""), "telefone": campos.get("telefone", ""), "site": campos.get("site", "")}
        return mensagem.modelos_de_assinatura(dados)

    @Slot(str, result=str)
    def previaAssinatura(self, html_assinatura):
        """Página (sem JavaScript) para ver a assinatura HTML como ela vai chegar."""
        escuro = bool(_aparencia_escura())
        return mensagem.pagina_de_previa(mensagem.limpar_html_assinatura(html_assinatura), escuro)

    @Slot(str, result="QVariantMap")
    def assinaturaDe(self, id_conta):
        c = self.contas.obter(id_conta) or {}
        tipo = c.get("assinatura_tipo", "texto")
        tem = (tipo == "html" and c.get("assinatura_html")) or (tipo == "texto" and c.get("assinatura"))
        return {"tem": bool(tem), "tipo": tipo, "texto": c.get("assinatura", ""), "respostas": c.get("assinatura_respostas", True)}

    # ------------------------------------------------------------ pastas
    @Slot(str, str, int)
    def criarPasta(self, id_conta, nome, id_pai=0):
        if not nome.strip():
            return
        if DEMONSTRACAO:
            self.banco.gravar_pasta(id_conta, "local:" + nome.strip(), nome.strip(), "")
            self.pastasMudaram.emit()
            return
        self.motor.pedir(id_conta, "criar_pasta", nome=nome, id_pai=id_pai)

    @Slot(int, str)
    def renomearPasta(self, id_pasta, nome):
        pasta = self.banco.pasta(id_pasta)
        if not pasta or pasta["papel"] or not nome.strip():
            return
        if DEMONSTRACAO:
            self.banco.renomear_pasta(id_pasta, pasta["caminho"], nome.strip())
            self.pastasMudaram.emit()
            return
        self.motor.pedir(pasta["conta"], "renomear_pasta", id_pasta=id_pasta, nome=nome)

    @Slot(int)
    def apagarPasta(self, id_pasta):
        pasta = self.banco.pasta(id_pasta)
        if not pasta or pasta["papel"]:
            return
        if self._pasta == id_pasta:
            self.escolherPasta(-1 if len(self.contas.lista) > 1 else (self.banco.pasta_por_papel(pasta["conta"], "entrada") or {}).get("id", -1))
        if DEMONSTRACAO:
            self.banco.remover_pasta(id_pasta)
            self.pastasMudaram.emit()
            return
        self.motor.pedir(pasta["conta"], "apagar_pasta", id_pasta=id_pasta)

    @Slot(str, result="QVariantList")
    def pastasDaConta(self, id_conta):
        return [{"id": p["id"], "nome": p["nome"], "papel": p["papel"], "total": p["total"], "nao_lidas": p["nao_lidas"],
                 "local": p["caminho"].startswith("local:")} for p in self.banco.pastas(id_conta)]

    @Slot(int, result="QVariantList")
    def pastasParaMoverDe(self, id_mensagem):
        m = self.banco.mensagem(id_mensagem)
        if not m:
            return []
        return [{"id": p["id"], "nome": p["nome"], "papel": p["papel"]} for p in self.banco.pastas(m["conta"]) if p["id"] != m["pasta"]]

    @Slot(int)
    def moverParaSpam(self, id_mensagem):
        m = self.banco.mensagem(id_mensagem)
        destino = self.banco.pasta_por_papel(m["conta"], "spam") if m else None
        if not destino:
            self.aviso.emit("Esta conta não tem uma pasta de spam.")
            return
        self.moverPara(id_mensagem, destino["id"])

    @Slot(str, str, str)
    def editarConta(self, id_conta, nome, assinatura):
        self.contas.atualizar(id_conta, nome=nome, assinatura=assinatura)
        self.contasMudaram.emit()

    @Slot(str)
    def abrirAjuda(self, url):
        if url.startswith("https://") and not DEMONSTRACAO:
            subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def _lista_contas(self):
        return [{"id": c["id"], "nome": c.get("nome", ""), "email": c["email"], "nome_provedor": c.get("nome_provedor", ""),
                 "assinatura": c.get("assinatura", ""), "tipo": c["entrada"]["tipo"], "servidor": c["entrada"]["host"],
                 "estado": self._estados.get(c["id"], ""), "erro": self._erros.get(c["id"], "")}
                for c in self.contas.lista]

    # ------------------------------------------------------------ primeira abertura (ADR 075)
    def _apresentacao_vista(self):
        return DEMONSTRACAO is False and ARQUIVO_APRESENTACAO.exists()

    @Slot()
    def concluirApresentacao(self):
        if not DEMONSTRACAO:
            ARQUIVO_APRESENTACAO.parent.mkdir(parents=True, exist_ok=True)
            ARQUIVO_APRESENTACAO.write_text("1\n")
        registrar("info", "mailbox_apresentacao")
        self.apresentacaoMudou.emit()

    @Slot(result=bool)
    def ehPadrao(self):
        if DEMONSTRACAO or not shutil.which("xdg-mime"):
            return False
        try:
            saida = subprocess.run(["xdg-mime", "query", "default", "x-scheme-handler/mailto"], capture_output=True,
                                   text=True, timeout=3).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            return False
        return saida == "duiaos-mailbox.desktop"

    @Slot()
    def tornarPadrao(self):
        if DEMONSTRACAO:
            return
        try:
            subprocess.run(["xdg-mime", "default", "duiaos-mailbox.desktop", "x-scheme-handler/mailto"], timeout=5, check=False)
        except (OSError, subprocess.SubprocessError):
            pass
        self.aviso.emit("O Mail Box agora abre os links de e-mail.")

    @Slot(result="QVariantList")
    def contasParaImportar(self):
        if DEMONSTRACAO:
            return [{"nome": "Ana Lima", "email": "ana@exemplo.com.br", "origem": "Thunderbird",
                     "config": {"entrada": {"tipo": "imap", "host": "imap.exemplo.com.br", "porta": 993, "seguranca": "ssl"},
                                "saida": {"tipo": "smtp", "host": "smtp.exemplo.com.br", "porta": 465, "seguranca": "ssl"}}}]
        return importar.contas_para_importar(ja_tem=[c["email"] for c in self.contas.lista])

    @Slot(result="QVariantList")
    def destaques(self):
        return [{"id": k, "nome": provedores.PROVEDORES[k]["nome"]} for k in provedores.DESTAQUES]

    # ------------------------------------------------------------ para o QML
    contasLista = Property("QVariantList", _lista_contas, notify=contasMudaram)
    pastas = Property("QVariantList", _lista_pastas, notify=pastasMudaram)
    mensagens = Property("QVariantList", _lista_mensagens, notify=mensagensMudaram)
    leitura = Property("QVariantMap", lambda self: self._leitura, notify=leituraMudou)
    pastaAtual = Property(int, lambda self: self._pasta, notify=pastasMudaram)
    sincronizando = Property(bool, lambda self: any(bool(v) for v in self._estados.values()), notify=estadoMudou)
    estado = Property(str, lambda self: next((v for v in self._estados.values() if v), ""), notify=estadoMudou)
    demonstracao = Property(bool, lambda self: DEMONSTRACAO, constant=True)
    apresentacaoVista = Property(bool, _apresentacao_vista, notify=apresentacaoMudou)
    preferencias = Property("QVariantMap", lambda self: dict(self.prefs.valores), notify=prefsMudaram)
    versao = Property(str, lambda self: VERSAO, constant=True)

    @Property("QVariantList", notify=pastasMudaram)
    def pastasParaMover(self):
        m = self.banco.mensagem(self._leitura.get("id", 0)) if self._leitura else None
        if not m:
            return []
        return [{"id": p["id"], "nome": p["nome"]} for p in self.banco.pastas(m["conta"]) if p["id"] != m["pasta"]]

    @Property(str, notify=pastasMudaram)
    def nomePastaAtual(self):
        if self._pasta == -1:
            return "Entrada" if len(self.contas.lista) <= 1 else "Todas as caixas de entrada"
        p = self.banco.pasta(self._pasta)
        return p["nome"] if p else ""


def _aparencia_escura():
    try:
        import interface
        return interface.aparencia().property("escuro")
    except Exception:  # noqa: BLE001
        return False


def criar_perfil_leitura():
    """Perfil sem disco para mostrar os e-mails; bloqueia toda requisição de rede até a pessoa liberar."""
    from PySide6.QtWebEngineQuick import QQuickWebEngineProfile
    from PySide6.QtWebEngineCore import QWebEngineUrlRequestInterceptor

    class Bloqueio(QWebEngineUrlRequestInterceptor):
        permitir = False

        def interceptRequest(self, info):
            esquema = info.requestUrl().scheme()
            if esquema in ("http", "https", "ws", "wss", "ftp") and not self.permitir:
                info.block(True)

    perfil = QQuickWebEngineProfile()
    interceptador = Bloqueio()
    perfil.setUrlRequestInterceptor(interceptador)
    return perfil, interceptador


# -------------------------------------------------------------------------------- demonstração
def trazer_para_frente():
    """No Wayland um programa sem foco não se põe na frente (requestActivate é ignorado): pede ao labwc pelo
    protocolo wlr-foreign-toplevel (wlrctl), como a Ilha faz ao clicar num ícone."""
    if DEMONSTRACAO or not shutil.which("wlrctl"):
        return
    try:
        subprocess.Popen(["wlrctl", "toplevel", "focus", "app_id:duiaos-mailbox"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as erro:
        registrar("aviso", "mailbox_para_frente_falhou", erro=str(erro))


def preparar_demonstracao(caixa):
    agora = time.time()
    contas = caixa.contas
    pessoal = contas.adicionar("Gustavo", "gustavo@gmail.com", provedores.configuracao("gmail", "gustavo@gmail.com"))
    trabalho = contas.adicionar("Gustavo", "gustavo@duiaos.com.br", provedores.configuracao("hostinger", "gustavo@duiaos.com.br"))
    banco = caixa.banco
    for conta in (pessoal, trabalho):
        for caminho, papel in (("INBOX", "entrada"), ("Sent", "enviados"), ("Drafts", "rascunhos"), ("Trash", "lixeira"),
                               ("Junk", "spam")):
            banco.gravar_pasta(conta["id"], caminho, caixa_postal.NOMES_PAPEIS[papel], papel)
    banco.gravar_pasta(trabalho["id"], "Projetos/DuiaOS", "Projetos › DuiaOS")
    exemplos = [
        (trabalho, "Marina Costa", "marina@estudio.invalid", "Identidade visual do DuiaOS — versão final",
         "<div style='font-family:sans-serif'><h2 style='color:#2E6BE6'>Versão final aprovada</h2><p>Oi, Gustavo!</p>"
         "<p>Segue a versão final da identidade visual, com a paleta Aurora e os novos ícones de traço fino. "
         "Os arquivos estão no anexo, em SVG e PNG.</p><p><img src='https://rastreio.invalid/pixel.gif' width='1'></p>"
         "<p>Qualquer ajuste, me avise.<br>Abraço,<br><b>Marina</b></p></div>", 0.3, False, True),
        (pessoal, "Banco Exemplo", "avisos@banco.invalid", "Sua fatura de novembro chegou",
         None, 2.1, False, False),
        (trabalho, "Equipe GitHub", "noreply@github.invalid", "[gustavoduia/duiaos] Build da ISO 0.3.1 concluído",
         None, 4.5, True, False),
        (pessoal, "Ana Ribeiro", "ana@exemplo.invalid", "Fotos da viagem 📷", None, 8, True, True),
        (trabalho, "Ricardo Alves", "ricardo@parceiro.invalid", "Proposta de parceria para o DuiaOS",
         None, 26, True, False),
        (pessoal, "Loja Online", "pedidos@loja.invalid", "Seu pedido foi enviado", None, 30, True, False),
        (trabalho, "Calendário", "agenda@duiaos.invalid", "Lembrete: reunião de planejamento amanhã às 10h", None, 50, True, False),
    ]
    textos = {"Sua fatura de novembro chegou": "Olá, Gustavo. A fatura de novembro já está disponível no aplicativo.",
              "[gustavoduia/duiaos] Build da ISO 0.3.1 concluído": "O workflow construir-iso terminou com sucesso em 42 minutos.",
              "Fotos da viagem 📷": "Oi! Separei as melhores fotos da viagem. Estão no anexo. Beijos!",
              "Proposta de parceria para o DuiaOS": "Gustavo, gostaríamos de conversar sobre levar o DuiaOS para os nossos notebooks.",
              "Seu pedido foi enviado": "O seu pedido saiu para entrega e chega em até 3 dias úteis.",
              "Lembrete: reunião de planejamento amanhã às 10h": "Pauta: Ora, Mail Box e a próxima versão do Wise."}
    for i, (conta, nome, email_de, assunto, html, horas, lida, anexo) in enumerate(exemplos):
        from email.message import EmailMessage
        from email.utils import formatdate, make_msgid
        msg = EmailMessage()
        msg["From"] = f"{nome} <{email_de}>"
        msg["To"] = conta["email"]
        msg["Subject"] = assunto
        msg["Date"] = formatdate(agora - horas * 3600, localtime=True)
        msg["Message-ID"] = make_msgid(domain="exemplo.invalid")
        msg.set_content(textos.get(assunto, "Oi, Gustavo!"))
        if html:
            msg.add_alternative(html, subtype="html")
        if anexo:
            msg.add_attachment(b"%PDF-1.4 exemplo", maintype="application", subtype="pdf",
                               filename="identidade-visual.pdf" if conta is trabalho else "fotos.zip")
        bruto = msg.as_bytes()
        pasta = banco.pasta_por_papel(conta["id"], "entrada")
        r = mensagem.resumo(bruto, i + 1, {"\\Seen"} if lida else set())
        r["sinalizada"] = i == 4
        banco.gravar_mensagem(conta["id"], pasta["id"], r, bruto)
    for p in banco.pastas():
        banco.recontar(p["id"])


def main():
    captura = argumento("--captura")
    pedido_mailto = next((a for a in sys.argv[1:] if a.startswith("mailto:")), "")
    if not DEMONSTRACAO:
        trava = open(Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "duiaos-mailbox.lock", "w")
        try:
            fcntl.flock(trava, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            ARQUIVO_PEDIDO.write_text(pedido_mailto or "mostrar")
            sys.exit(0)
    if captura:
        os.environ.setdefault("QT_QPA_PLATFORM", "xcb")
    from PySide6.QtWebEngineQuick import QtWebEngineQuick
    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    QtWebEngineQuick.initialize()
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtQml import QQmlApplicationEngine
    import interface

    app = QGuiApplication(sys.argv)
    app.setApplicationName("Mail Box")
    app.setOrganizationName("DuiaOS")
    app.setDesktopFileName("duiaos-mailbox")
    interface.ligar_registro("duiaos-mailbox")
    registrar("info", "mailbox_inicio", versao=VERSAO)

    motor = QQmlApplicationEngine()
    interface.preparar(motor)
    perfil, interceptador = criar_perfil_leitura()
    caixa = MailBox(perfil, interceptador)
    pagina = argumento("--pagina", "caixa")
    if DEMONSTRACAO and pagina not in ("wizard", "apresentacao"):
        preparar_demonstracao(caixa)
    contexto = motor.rootContext()
    contexto.setContextProperty("caixa", caixa)
    contexto.setContextProperty("perfilLeitura", perfil)
    contexto.setContextProperty("capturaArquivo", captura)
    contexto.setContextProperty("paginaDemonstracao", pagina if DEMONSTRACAO else "")
    contexto.setContextProperty("passoDemonstracao", int(argumento("--passo", "0")))
    import menu_do_app
    menu = menu_do_app.criar("mailbox", [])
    contexto.setContextProperty("menuDoApp", menu)
    if DEMONSTRACAO and "--escuro" in sys.argv:
        interface.aparencia().definirEscuro(True)      # preferências da pasta temporária da demonstração
    motor.load(PASTA / "JanelaMailBox.qml")
    if not motor.rootObjects():
        sys.exit(1)
    if DEMONSTRACAO and pagina == "caixa":
        primeira = caixa.banco.mensagens(papel="entrada")
        if primeira:
            caixa.abrirMensagem(primeira[0]["id"])
    if DEMONSTRACAO and pagina == "escrever":
        caixa.escrever({"para": "marina@estudio.invalid", "cc": "", "assunto": "Re: Identidade visual do DuiaOS — versão final",
                        "corpo": "Oi, Marina!\n\nFicou ótimo. Vou levar para a próxima versão.\n\nAbraço,\nGustavo",
                        "em_resposta_a": "", "referencias": ""})
    if pedido_mailto:
        caixa.escrever(ler_mailto(pedido_mailto))

    # Outro "duiaos-mailbox" aberto: mostra esta janela (ou abre o mailto pedido)
    def ver_pedido():
        if ARQUIVO_PEDIDO.exists():
            conteudo = ARQUIVO_PEDIDO.read_text().strip()
            ARQUIVO_PEDIDO.unlink(missing_ok=True)
            if conteudo.startswith("mailto:"):
                caixa.escrever(ler_mailto(conteudo))
            else:
                janela = motor.rootObjects()[0]
                janela.raise_()
                janela.requestActivate()
                trazer_para_frente()
    relogio_pedido = QTimer(interval=700, timeout=ver_pedido)
    if not DEMONSTRACAO:
        relogio_pedido.start()
    caixa.iniciar()
    codigo = app.exec()
    relogio_pedido.stop()
    caixa.motor.encerrar()
    # As janelas QML usam "caixa": o motor do QML sai antes dele
    for janela in motor.rootObjects():
        janela.setProperty("visible", False)
    del motor
    # Ordem de saída do Qt WebEngine: janelas, depois o perfil, por último o aplicativo (sem isso, falha ao fechar)
    perfil.setUrlRequestInterceptor(None)
    del caixa, interceptador, perfil
    del app
    sys.exit(codigo)


if __name__ == "__main__":
    main()
